# Overview

Additional applications, utils, and tools related to hpm_sdk will be shared
in this repository.

## SDK Directory Structure
| Name | Description |
|--------|--------|
| demos | additional demo applications based on hpm_sdk |
| debugging | additional debuggin related |
