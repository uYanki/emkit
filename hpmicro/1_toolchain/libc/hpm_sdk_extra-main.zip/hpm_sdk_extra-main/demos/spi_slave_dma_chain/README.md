# Overview

- References: https://mp.weixin.qq.com/s/aoHiQUlqWytIHJ4_FlCkSg
- 参考文章：https://mp.weixin.qq.com/s/aoHiQUlqWytIHJ4_FlCkSg  《[玩转先楫SPI外设系列之六] 细说SPI从机接收的妙技巧》

