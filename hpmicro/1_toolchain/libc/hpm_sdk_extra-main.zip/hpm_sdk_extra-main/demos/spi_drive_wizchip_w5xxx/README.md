# Overview

- References: https://mp.weixin.qq.com/s/eh6ayiFqA0HTdbhU-fdseQ
- 参考文章：https://mp.weixin.qq.com/s/eh6ayiFqA0HTdbhU-fdseQ  《[hpm_application]先楫单片机使用SPI驱动网络接口芯片W5xxx(wiznet)》

