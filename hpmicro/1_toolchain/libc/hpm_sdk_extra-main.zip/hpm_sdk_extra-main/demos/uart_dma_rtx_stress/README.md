# Overview

- References: https://mp.weixin.qq.com/s/uyF9HMq-oKEThdAnbtr1JA
- 参考文章：https://mp.weixin.qq.com/s/uyF9HMq-oKEThdAnbtr1JA  《[玩转先楫串口uart外设系列之二]接收性能验证-使用DMA》

