# Overview

- References: https://mp.weixin.qq.com/s/xi0TCWHR6ibOl7yCdN3onw
- 参考文章：https://mp.weixin.qq.com/s/xi0TCWHR6ibOl7yCdN3onw  《USB端点不够用？不存在的！满血USB端点的MCU助你一臂之力！》

