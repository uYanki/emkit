# Overview

- References: https://mp.weixin.qq.com/s/oJNRqQ5p-BDehpVP0Q7N9A
- 参考文章：https://mp.weixin.qq.com/s/oJNRqQ5p-BDehpVP0Q7N9A  《[hpm_application]先楫hpm6750做个USB显示器当电脑副屏》

