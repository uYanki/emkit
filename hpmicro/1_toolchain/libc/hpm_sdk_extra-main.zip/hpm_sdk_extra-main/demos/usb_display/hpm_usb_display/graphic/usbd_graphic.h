/*
 * Copyright (c) 2023 HPMicro
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */

#ifndef USBD_GRAPHIC_H
#define USBD_GRAPHIC_H
struct usbd_interface *usbd_graphic_init_intf(struct usbd_interface *intf);
#endif
