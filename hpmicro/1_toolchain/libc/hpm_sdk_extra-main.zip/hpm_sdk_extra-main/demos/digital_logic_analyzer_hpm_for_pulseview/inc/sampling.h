#ifndef SAMPLING_H_
#define SAMPLING_H_

#include "hpm_common.h"

void init_lobs_one_group_config(void);
void lobs_open(void);
void lobs_close(void);
void lobs_loop(void);
#endif