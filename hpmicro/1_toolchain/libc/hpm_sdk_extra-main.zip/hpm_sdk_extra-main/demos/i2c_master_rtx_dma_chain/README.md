# Overview

- References: https://mp.weixin.qq.com/s/rcxbvCTON4U4IuqKgQ6U7Q
- 参考文章：https://mp.weixin.qq.com/s/rcxbvCTON4U4IuqKgQ6U7Q  什么！I2C能全程无阻塞 CPU 0负载实现通信？

