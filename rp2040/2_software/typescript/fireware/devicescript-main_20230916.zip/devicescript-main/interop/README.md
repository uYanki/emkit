# @devicescrit/interop

Interfaces for interaction with DeviceScript files.
