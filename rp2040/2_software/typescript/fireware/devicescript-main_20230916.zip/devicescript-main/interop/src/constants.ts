export const MIN_NODE_VERSION = 16
export const MARKETPLACE_EXTENSION_ID = "devicescript.devicescript-vscode"
