#include "devs_internal.h"

void methX_Function_start(devs_ctx_t *ctx) {
    if (ctx->stack_top_for_gc < 1) {
        devs_throw_range_error(ctx, "need function arg");
        return;
    }

    unsigned flag = DEVS_OPCALL_BG;
    unsigned numargs = ctx->stack_top_for_gc - 1;
    devs_fiber_t *fib = devs_fiber_start(ctx, numargs, flag);

    if (fib != NULL)
        devs_ret(ctx, devs_value_from_handle(DEVS_HANDLE_TYPE_FIBER, fib->handle_tag));
}

value_t prop_Function_prototype(devs_ctx_t *ctx, value_t self) {
    value_t th;
    devs_activation_t *clo;
    int fn = devs_get_fnidx(ctx, self, &th, &clo);
    if (fn < 0 || fn >= DEVS_FIRST_BUILTIN_FUNCTION ||
        !(devs_img_get_function(ctx->img, fn)->flags & DEVS_FUNCTIONFLAG_IS_CTOR))
        return devs_throw_expecting_error_ext(ctx, "ctor function", self);
    value_t r = devs_short_map_get(ctx, ctx->fn_protos, fn);
    if (devs_is_undefined(r)) {
        r = devs_value_from_gc_obj(
            ctx, devs_map_try_alloc(
                     ctx, devs_get_builtin_object(ctx, DEVS_BUILTIN_OBJECT_OBJECT_PROTOTYPE)));
        if (!devs_is_undefined(r)) {
            devs_value_pin(ctx, r);
            devs_any_set(ctx, r, devs_builtin_string(DEVS_BUILTIN_STRING_CONSTRUCTOR),
                         devs_value_from_handle(DEVS_HANDLE_TYPE_STATIC_FUNCTION, fn));
            devs_short_map_set(ctx, ctx->fn_protos, fn, r);
            devs_value_unpin(ctx, r);
        }
    }
    return r;
}

value_t prop_Function_name(devs_ctx_t *ctx, value_t self) {
    value_t th;
    devs_activation_t *clo;
    int fn = devs_get_fnidx(ctx, self, &th, &clo);
    if (fn < 0)
        return devs_throw_expecting_error(ctx, DEVS_BUILTIN_STRING_FUNCTION, self);

    int bltin = fn - DEVS_FIRST_BUILTIN_FUNCTION;
    if (bltin >= 0) {
        JD_ASSERT(bltin < devs_num_builtin_functions);
        const devs_builtin_function_t *h = &devs_builtin_functions[bltin];
        return devs_builtin_string(h->builtin_string_id);
    } else {
        return devs_value_from_handle(DEVS_HANDLE_TYPE_IMG_BUFFERISH,
                                      devs_img_get_function(ctx->img, fn)->name_idx);
    }
}
