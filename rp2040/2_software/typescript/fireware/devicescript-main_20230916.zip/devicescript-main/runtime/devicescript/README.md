## TODO

Use cases:
* LED display client with double-buffering
* display number (two digits) on dot matrix screen
* scroll text on dot matrix screen (compile-in font?)
* compute median of measurements

