---
name: Driver request
about: Request for a missing device driver
title: ""
labels: driver request
assignees: ""
---

** Device description **

Describe which device, sensor or peripherical you want a driver for.

** Datasheet, firmware, etc... **

Links to datasheet information
