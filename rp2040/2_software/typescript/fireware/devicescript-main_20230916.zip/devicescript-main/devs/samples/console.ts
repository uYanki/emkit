import * as ds from "@devicescript/core"

function testIt() {
    const x = 7, y = 12
    console.log("Hello world")
    console.log("X is", x, "and Y is", y)
    console.log("X=", x, "Y=", y)
}

testIt()