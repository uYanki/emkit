import * as ds from "@devicescript/core"

/* this never worked
const c = new ds.Color()
console.log(c.color.red, c.color.green, c.color.blue)
*/