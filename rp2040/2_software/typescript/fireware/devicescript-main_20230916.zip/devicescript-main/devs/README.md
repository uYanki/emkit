# DeviceScript Scripts

This folder contains DeviceScript samples, tests, and the "standard library".
It also has a `tsconfig.json` file appropriate for VS Code syntax completion.
