# DeviceScript bytecode format

For documentation, please see [Runtime Implementation](https://microsoft.github.io/devicescript/language/runtime)
page, or the [Bytecode Format](https://microsoft.github.io/devicescript/language/bytecode) page.
