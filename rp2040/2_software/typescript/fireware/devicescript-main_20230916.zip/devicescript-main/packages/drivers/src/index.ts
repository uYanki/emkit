import { configureHardware } from "@devicescript/servers"

export * from "./driver"
export * from "./core"
export * from "./shtc3"
export * from "./sht30"
export * from "./aht20"
export * from "./ltr390"
export * from "./bme680"
export * from "./ssd1306"
export * from "./characterscreen"
export * from "./indexedscreen"
export * from "./dotmatrix"
export * from "./st7735"
export * from "./uc8151"
export * from "./trafficlight"
export * from "./ledserver"
export * from "./accelerometer"

export * from "./esp32c3fh4rgb"
export * from "./picobricks"
export * from "./xiaoexpansionboard"

configureHardware({ scanI2C: false })
