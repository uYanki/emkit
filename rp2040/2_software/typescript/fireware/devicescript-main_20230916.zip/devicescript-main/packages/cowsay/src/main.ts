import { cowsay } from "./cowsay"

cowsay("Hello!!!")
