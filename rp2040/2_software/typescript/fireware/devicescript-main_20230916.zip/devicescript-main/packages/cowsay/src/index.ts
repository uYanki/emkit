export * from "./cowsay"
