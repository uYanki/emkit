import * as ds from "@devicescript/core"

/**
 * The cloud adapter client
 */
export const cloud = new ds.CloudAdapter()
