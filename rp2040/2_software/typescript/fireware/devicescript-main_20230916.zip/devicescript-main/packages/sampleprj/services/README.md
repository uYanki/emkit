# Services

Add custom service definition in this folder.

-   [Read documentation](http://microsoft.github.io/devicescript/developer/custom-services)
