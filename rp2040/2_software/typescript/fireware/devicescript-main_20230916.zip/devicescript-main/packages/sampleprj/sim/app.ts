import "./auroscope"
import { startHouse } from "./house"

startHouse()