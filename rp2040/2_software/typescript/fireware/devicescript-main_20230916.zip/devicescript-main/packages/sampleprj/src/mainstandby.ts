import { standby } from '@devicescript/runtime'

setTimeout(async () => {
    await standby(1000)
}, 1000)