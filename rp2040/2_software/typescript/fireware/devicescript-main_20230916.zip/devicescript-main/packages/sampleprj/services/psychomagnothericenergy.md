# Psychomagnotheric Energy

    identifier: 0x1f1dc7d5
    extends: _sensor

Measures the presence of ghosts in Ghostbusters.

## Registers

    ro energy_level: u0.16 / @ reading

A measure of the presence of ghosts.

    ro energy_level_error: u0.16 / @ reading_error

Error on the measure.