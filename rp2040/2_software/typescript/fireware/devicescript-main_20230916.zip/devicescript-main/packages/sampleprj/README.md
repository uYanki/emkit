# Sample Debug Project

Sample project for testing [DeviceScript](https://microsoft.github.io/devicescript/)
VSCode extension.
