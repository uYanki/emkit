import * as ds from "@devicescript/core"

/**
 * The settings object.
 */
export const settings = new ds.Settings()
