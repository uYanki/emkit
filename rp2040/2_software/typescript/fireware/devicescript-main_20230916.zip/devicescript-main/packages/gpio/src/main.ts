import { describe, expect, test } from "@devicescript/test"

describe("gpio", () => {})
