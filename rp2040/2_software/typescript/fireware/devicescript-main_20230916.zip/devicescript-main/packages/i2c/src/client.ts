import { I2C } from "./i2c_impl";

/**
 * The I2C adapter client
 */
export const i2c = new I2C()
