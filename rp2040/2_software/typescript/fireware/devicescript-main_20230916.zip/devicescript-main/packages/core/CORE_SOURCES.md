Do not remove this file, and do not bundle it into prelude.ts.
The build system relies on it.
