IIC slave test
=====
"project_cfg.h" is the hardware related configuration files. Include pin config ...

1.GPIO work as IIC master device.Write data to IIC slave device .Get data from IIC salve device.