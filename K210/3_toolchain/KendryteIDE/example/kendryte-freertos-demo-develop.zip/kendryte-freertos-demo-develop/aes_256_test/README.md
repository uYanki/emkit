AES-256 hardware cipher
=====
include AES-CBC-256/AES-ECB-256/AES-GCM-256.

1.Traversal test.
2.Compare the time spent on hardware aes and software aes.
