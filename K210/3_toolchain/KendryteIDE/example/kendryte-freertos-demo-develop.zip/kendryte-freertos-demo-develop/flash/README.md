Flash driver test
=====
"project_cfg.h" is the hardware related configuration files. Include pin config ...

1.Two tasks have been created.One task is to write flash, another task to read flash.