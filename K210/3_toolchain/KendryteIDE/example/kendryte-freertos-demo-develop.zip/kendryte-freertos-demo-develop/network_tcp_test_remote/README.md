# network tcp remote

This demo belongs to the kendryte auxiliary tool,
Can't run directly on k210. Need to run on a networked Linux virtual machine.

make

./client ipaddr

./serve

