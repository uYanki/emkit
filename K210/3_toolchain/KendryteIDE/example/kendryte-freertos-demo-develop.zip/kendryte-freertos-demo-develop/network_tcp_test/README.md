network tcp test
=====
1.dhcp.  

2.dns.  

3.tcp client.  

4.tcp server  
