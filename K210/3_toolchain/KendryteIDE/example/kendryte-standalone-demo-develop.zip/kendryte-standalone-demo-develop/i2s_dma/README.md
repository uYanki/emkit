I2S
=====
Receive voice then play.