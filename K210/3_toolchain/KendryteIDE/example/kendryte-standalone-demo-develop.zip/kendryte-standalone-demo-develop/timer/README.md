# TIMER

This demo show that how to use timer with interrupt.