I2S
=====
Play music.