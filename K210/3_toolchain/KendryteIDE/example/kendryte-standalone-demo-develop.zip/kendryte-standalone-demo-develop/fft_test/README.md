# FFT and IFFT hardware calculation

include 

- FFT-512/IFFT-512
- FFT-256/IFFT-256
- FFT-128/IFFT-128
- FFT-64/IFFT-64

1.Calculate the frequency, phase and amplitude of the time domain signal.

2.Compare the time spent on hardware FFT and software FFT.
