SPI Flash w25q
=====
1. Use SPI3
2. Write data which is 256 bytes long at 0x400000 then read it by standard mode or quad mode.