I2S
=====
1.Feed watchdog
2.System reset 16s later.