SPI LCD
=====
Display "Canaan" and "Kendryte K210"