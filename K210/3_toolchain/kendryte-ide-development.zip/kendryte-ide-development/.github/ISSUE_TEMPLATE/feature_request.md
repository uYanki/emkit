---
name: Feature request (功能请求)
about: Suggest an idea for this project (提议将来添加到IDE的新功能)

---

<!-- Please search existing issues to avoid creating duplicates. -->
<!-- 请务必先搜索是否有人提出过相同的问题 -->

<!-- Describe the feature you'd like. -->
<!-- 描述你需要的功能 -->

----
<!-- If you have a way to resolve this, please describe it here -->
<!-- 如果你有关于如何实现的点子，请写在这里 -->
