---
name: Question (问题)
about: Ask question about IDE (在使用IDE的过程中出现的疑问)
---

<!-- Please note, this place is only for the IDE, not SDK or C++ problems or Chip functional -->
<!-- 注意！此处只处理IDE相关问题，关于SDK、C++编程、芯片功能之类的问题不在此范围 -->
<!-- If you have such question, please visit forum: forum.kendryte.com -->
<!-- 如果你有这样的问题，欢迎到论坛提出： forum.kendryte.com -->

### Your Question:
<!-- 问题描述 -->

<!-- 在这里描述你的问题，注意换行需要两个空格 -->
