#ifdef PKG_USING_OPENMV_CP
#include "qstrdefsomv.h"
#endif

#ifdef PRJ_USING_EXTMODS_MISC
#include "qstrdefsmisc.h"
#endif
