#include "k210/qstrdefsk210.h"

#if (defined(EXTMODS_MISC_USING_LVGL))
#include "lvgl/qstrdefslvgl.h"
#endif
