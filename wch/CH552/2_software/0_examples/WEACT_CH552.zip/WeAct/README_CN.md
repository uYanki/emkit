# SDK

* 01-KeilExample 为Keil开发例程
* 02-ArduinoExample 为Arduino开发例程
* 03-SDCCExample 为makefile开发例程，使用SDCC编译器
* 04-WCH_EVT 为WCH官方提供的开发资料

## 如何进入烧录模式（IAP模式）
按住P36键，重新拔插USB即可，如果是Keil&SDCC例程，从App进入烧录模式的方法：按住P36键，单击RST键，0.5S后松开P36键即可进入ISP模式。

> Tools/WCHISPTool_Setup.exe 为WCH官方烧录工具
