# SDK

* 01-KeilExample -> Develop routines by Keil
* 02-ArduinoExample -> Develop routines by Arduino
* 03-SDCCExample -> Develop routines by makefiles, using the SDCC compiler
* 04-WCH_EVT -> Official development materials provided by WCH

## How to enter Burn Mode (IAP mode)
Hold down the P36 button and reinsert the USB Cable. For Keil&SDCC Example, the way to enter the burn mode from App is to hold down the P36 key, click the RST key, and release the P36 key 0.5S later to enter the ISP mode