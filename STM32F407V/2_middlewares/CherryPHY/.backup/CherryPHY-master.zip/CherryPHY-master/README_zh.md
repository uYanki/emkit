# CherryPHY

[English](./README.md)

CherryPHY 是一个简单的以太网 PHY 配置工具。

## PHY 支持列表

|   Vendor      |  chipname            |
|:-------------:|:--------------------:|
|   TI          |  dp83847/dp83848     |
|   REALTEK     |  rtl8201/rtl8211     |
|   MICROCHIP   |  lan8720/ksz8081     |
|   MOTOR COMM  |  yt8512/yt8522       |
