# CherryPHY

[中文版](./README_zh.md)

CherryPHY is a simple Ethernet PHY configuration tool.

## PHY Support List

|   Vendor      |  chipname            |
|:-------------:|:--------------------:|
|   TI          |  dp83847/dp83848     |
|   REALTEK     |  rtl8201/rtl8211     |
|   MICROCHIP   |  lan8720/ksz8081     |
|   MOTOR COMM  |  yt8512/yt8522       |