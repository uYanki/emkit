# X window App
Show GuiLite inside X Window, support all Linux desktop distro

## How to build
`gcc xWindow.c -lX11 -lpthread -o xWindow`
