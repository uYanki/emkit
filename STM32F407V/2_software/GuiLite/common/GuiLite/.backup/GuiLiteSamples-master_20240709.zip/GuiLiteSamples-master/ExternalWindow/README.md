# External Window
Run GuiLite sample inside external Window(e.g, X window, Qt window) by framebuffer sharing.

# How to work?
- Run `./xWindow widthOfGuiLite heighOfGuiLite | ./HelloXXX shared-fb`
- Run `./qtWindow widthOfGuiLite heighOfGuiLite | ./HelloXXX shared-fb`
