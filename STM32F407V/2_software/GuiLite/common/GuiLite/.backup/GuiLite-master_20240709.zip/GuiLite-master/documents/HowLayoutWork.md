# How to layout widgets for GuiLiteSamples::HostMonitor?

All widgets were described by struct WND_TREE and ?.xml.cpp files

## How to layout slide group?
![Layout slides group](layout_slide_group.png)
## How to layout single slide?
![Layout single slide](layout_single_slide.png)
## How to layout dialog?
![Layout dialog](layout_dialog.png)