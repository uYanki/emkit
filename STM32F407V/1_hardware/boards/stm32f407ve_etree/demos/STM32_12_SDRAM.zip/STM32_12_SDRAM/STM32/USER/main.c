#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "fsmc.h"
#include "lcd.h"
	

int main(void)
{ 
	u32 num=0;
	u16 testbuf[8]={11,22,33,44,55,66,77,88};
	u16 mybuffer[8];
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);      //��ʼ����ʱ����
	uart_init(115200);		//��ʼ�����ڲ�����Ϊ115200
	LED_Init();					  //��ʼ��LED
 	FSMC_Init();          //��ʼ��LCD FSMC�ӿ�
	LCD_SEL = 1;          //ѡ��LCD
	LCD_Init();
	delay_ms(1000);
	//LCD_Clear(WHITE);
	POINT_COLOR=RED;	  
	LCD_ShowString(30,50,200,16,16,"FPGA/STM32F4");	
	LCD_ShowString(30,70,200,16,16,"SDRAM TEST");	
	LCD_ShowString(30,90,200,16,16,"ETree Board");
	LCD_ShowString(30,110,200,16,16,"2021/9/11");	  
	LCD_ShowString(30,130,200,16,16,"Hello World!");	      
	
	LCD_SEL = 0;				//ѡ��SDRAM
	
	SDRAM_WriteBuffer(testbuf,0,8);
	SDRAM_ReadBuffer(mybuffer,0,8);
	
	printf("MyBuffer is ");
	for(num=0;num<8;num++)
		printf("%d ",mybuffer[num]);
	
  while(1);
	return 0;
}
