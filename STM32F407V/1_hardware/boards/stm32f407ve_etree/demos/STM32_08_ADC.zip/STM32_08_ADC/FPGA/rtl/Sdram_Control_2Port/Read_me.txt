SDRAM Control IP for 2 Port, Modified from Terasic.

=========================================================================

13/09/23	CrazyBingo	1.0	Original

14/10/26	CrazyBingo	2.0	Modification
-------------------------------------------------------------------------

More Question, Please Email to: thereturnofbingo@qq.com Look for CrazyBingo!