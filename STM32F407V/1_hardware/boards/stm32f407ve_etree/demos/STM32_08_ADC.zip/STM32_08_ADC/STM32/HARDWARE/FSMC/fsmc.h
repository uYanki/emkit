#ifndef __FSMC_H
#define __FSMC_H		
#include "sys.h"	 
#include "stdlib.h" 


#define FPGA_REG0_BASE			((u32)(0x60000000))
#define FPGA_REG1_BASE			((u32)(0x60020000))
#define FPGA_REG2_BASE			((u32)(0x60040000))
#define FPGA_REG3_BASE			((u32)(0x60060000))
#define FPGA_REG4_BASE			((u32)(0x60080000))
#define FPGA_REG5_BASE			((u32)(0x600A0000))
#define FPGA_REG6_BASE			((u32)(0x600C0000))
#define FPGA_REG7_BASE			((u32)(0x600E0000))

#define FPGA_REG0						*(vu16 *)FPGA_REG0_BASE
#define FPGA_REG1						*(vu16 *)FPGA_REG1_BASE
#define FPGA_REG2						*(vu16 *)FPGA_REG2_BASE
#define FPGA_REG3						*(vu16 *)FPGA_REG3_BASE
#define FPGA_REG4						*(vu16 *)FPGA_REG4_BASE
#define FPGA_REG5						*(vu16 *)FPGA_REG5_BASE
#define FPGA_REG6						*(vu16 *)FPGA_REG6_BASE
#define FPGA_REG7						*(vu16 *)FPGA_REG7_BASE
//---------------------------------------------------------


void FSMC_Init(void);
u16  FPGA_RD_REG0(void);
void FPGA_WR_REG0(vu16 data);
u16  FPGA_RD_REG1(void);
void FPGA_WR_REG1(vu16 data);
u16  FPGA_RD_REG2(void);
void FPGA_WR_REG2(vu16 data);
u16  FPGA_RD_REG3(void);
void FPGA_WR_REG3(vu16 data);
u16  FPGA_RD_REG4(void);
void FPGA_WR_REG4(vu16 data);
u16  FPGA_RD_REG5(void);
void FPGA_WR_REG5(vu16 data);
u16  FPGA_RD_REG6(void);
void FPGA_WR_REG6(vu16 data);
u16  FPGA_RD_REG7(void);
void FPGA_WR_REG7(vu16 data);

void SDRAM_WriteWord(u16 Buffer, u32 WriteAddr);
void opt_delay(u8 i);		


#endif 