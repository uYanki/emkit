#ifndef __VGA_H
#define __VGA_H
#include "sys.h"
#include "fsmc.h"
#include "delay.h"
#include "font.h" 


#define VGA_WIDTH     640
#define VGA_HEIGH     480

//������ɫ
#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE         	 0x001F  
#define BRED             0XF81F
#define GRED 			 0XFFE0
#define GBLUE			 0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			 0XBC40 //��ɫ
#define BRRED 			 0XFC07 //�غ�ɫ
#define GRAY  			 0X8430 //��ɫ

void VGA_Clear(u16 Color);	 												//����
void VGA_ColorBar(void);
void VGA_DrawPoint(u16 x,u16 y, u16 color);
void VGA_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2);
void VGA_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2);
void VGA_Draw_Circle(u16 x0,u16 y0,u8 r);
void VGA_ShowChar(u16 x,u16 y,u8 num,u8 size,u8 mode);
void VGA_ShowString(u16 x,u16 y,u16 width,u16 height,u8 size,u8 *p);
u32 VGA_Pow(u8 m,u8 n);
void VGA_ShowNum(u16 x,u16 y,u32 num,u8 len,u8 size);


#endif
