# Intended for Sphinx only

The files in this folder are only used to generate documentation using Sphinx (from Doxygen's XML output).

See building docs instructions in docs/README.md
