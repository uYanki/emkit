GettingStarted.ino
==================

.. literalinclude:: ../../../../examples/GettingStarted/GettingStarted.ino
    :lines: 7-
    :linenos:
    :lineno-match:
