
#ifndef DRIVER_DHT20_H
#define DRIVER_DHT20_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct dht20_handle_s {
    uint8_t inited;  // inited flag
} dht20_handle_t;

uint8_t dht20_info(dht20_info_t* info);
uint8_t dht20_init(dht20_handle_t* handle);
uint8_t dht20_deinit(dht20_handle_t* handle);
uint8_t dht20_read_temperature_humidity(dht20_handle_t* handle, uint32_t* temperature_raw, float* temperature_s, uint32_t* humidity_raw, uint8_t* humidity_s);
uint8_t dht20_read_temperature(dht20_handle_t* handle, uint32_t* temperature_raw, float* temperature_s);
uint8_t dht20_read_humidity(dht20_handle_t* handle, uint32_t* humidity_raw, uint8_t* humidity_s);
uint8_t dht20_set_reg(dht20_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t dht20_get_reg(dht20_handle_t* handle, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
