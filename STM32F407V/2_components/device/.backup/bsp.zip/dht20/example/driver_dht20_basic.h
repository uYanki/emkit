
#ifndef DRIVER_DHT20_BASIC_H
#define DRIVER_DHT20_BASIC_H
#include "driver_dht20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t dht20_basic_init(void);
uint8_t dht20_basic_deinit(void);
uint8_t dht20_basic_read(float *temperature, uint8_t *humidity);
#ifdef __cplusplus
}
#endif
#endif
