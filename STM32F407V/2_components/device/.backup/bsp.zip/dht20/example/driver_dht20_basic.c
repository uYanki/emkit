
#include "driver_dht20_basic.h"
static dht20_handle_t gs_handle;        // dht20 handle
uint8_t dht20_basic_init(void)
{
    uint8_t res;
    /* link interface function */
    DRIVER_DHT20_LINK_INIT(&gs_handle, dht20_handle_t);
    DRIVER_DHT20_LINK_IIC_INIT(&gs_handle, dht20_interface_iic_init);
    DRIVER_DHT20_LINK_IIC_DEINIT(&gs_handle, dht20_interface_iic_deinit);
    DRIVER_DHT20_LINK_IIC_READ_CMD(&gs_handle, dht20_interface_iic_read_cmd);
    DRIVER_DHT20_LINK_IIC_WRITE_CMD(&gs_handle, dht20_interface_iic_write_cmd);
    DRIVER_DHT20_LINK_DELAY_MS(&gs_handle, dht20_interface_delay_ms);
    DRIVER_DHT20_LINK_DEBUG_PRINT(&gs_handle, dht20_interface_debug_print);
    /* dht20 init */
    res = dht20_init(&gs_handle);
    if (res != 0)
    {
        dht20_interface_debug_print("dht20: init failed.\n");
        
        return 1;
    }
    return 0;
}
uint8_t dht20_basic_read(float *temperature, uint8_t *humidity)
{
    uint32_t temperature_raw;
    uint32_t humidity_raw;
    /* read temperature and humidity */
    if (dht20_read_temperature_humidity(&gs_handle, (uint32_t *)&temperature_raw, temperature, 
                                       (uint32_t *)&humidity_raw, humidity) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t dht20_basic_deinit(void)
{
    /* deinit dht20 and close bus */
    if (dht20_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
