
#ifndef DRIVER_DHT20_READ_TEST_H
#define DRIVER_DHT20_READ_TEST_H
#include "driver_dht20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t dht20_read_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
