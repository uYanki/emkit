
#ifndef DRIVER_AMG8833_INTERRUPT_H
#define DRIVER_AMG8833_INTERRUPT_H
#include "driver_amg8833_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define AMG8833_INTERRUPT_DEFAULT_FRAME_RATE          AMG8833_FRAME_RATE_1_FPS         // 1 fps 
#define AMG8833_INTERRUPT_DEFAULT_AVERAGE_MODE        AMG8833_AVERAGE_MODE_TWICE       // twice 
uint8_t amg8833_interrupt_irq_handler(void);
uint8_t amg8833_interrupt_init(amg8833_address_t addr_pin,
                               amg8833_interrupt_mode_t mode,
                               float high_level, float low_level, 
                               float hysteresis_level,
                               void (*callback)(uint8_t type) 
                              );
uint8_t amg8833_interrupt_deinit(void);
uint8_t amg8833_interrupt_get_table(uint8_t table[8][1]);
uint8_t amg8833_interrupt_read_temperature_array(float temp[8][8]);
uint8_t amg8833_interrupt_read_temperature(float *temp);
#ifdef __cplusplus
}
#endif
#endif
