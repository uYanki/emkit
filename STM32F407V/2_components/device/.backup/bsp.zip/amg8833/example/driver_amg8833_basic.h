
#ifndef DRIVER_AMG8833_BASIC_H
#define DRIVER_AMG8833_BASIC_H
#include "driver_amg8833_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define AMG8833_BASIC_DEFAULT_FRAME_RATE          AMG8833_FRAME_RATE_10_FPS        // 10 fps 
#define AMG8833_BASIC_DEFAULT_AVERAGE_MODE        AMG8833_AVERAGE_MODE_TWICE       // twice 
uint8_t amg8833_basic_init(amg8833_address_t addr_pin);
uint8_t amg8833_basic_deinit(void);
uint8_t amg8833_basic_read_temperature_array(float temp[8][8]);
uint8_t amg8833_basic_read_temperature(float *temp);
#ifdef __cplusplus
}
#endif
#endif
