
#include "driver_amg8833.h"

#define MANUFACTURER_NAME  "Panasonic"         // manufacturer name
#define SUPPLY_VOLTAGE_MIN 3.0f                // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f                // chip max supply voltage




#define AMG8833_REG_PCTL  0x00 // power control register
#define AMG8833_REG_RST   0x01 // software reset register
#define AMG8833_REG_FPSC  0x02 // frame rate register
#define AMG8833_REG_INTC  0x03 // interrupt function register
#define AMG8833_REG_STAT  0x04 // interrupt flag, low voltage flag register
#define AMG8833_REG_SCLR  0x05 // interrupt flag clear register
#define AMG8833_REG_AVE   0x07 // moving average output mode register
#define AMG8833_REG_INTHL 0x08 // interrupt upper value lower level register
#define AMG8833_REG_INTHH 0x09 // interrupt upper value upper level register
#define AMG8833_REG_INTLL 0x0A // interrupt lower value lower level register
#define AMG8833_REG_INTLH 0x0B // interrupt lower value upper level register
#define AMG8833_REG_IHYSL 0x0C // interrupt hysteresis value lower level register
#define AMG8833_REG_IHYSH 0x0D // interrupt hysteresis value upper level register
#define AMG8833_REG_TTHL  0x0E // thermistor output value lower level register
#define AMG8833_REG_TTHH  0x0F // thermistor output value upper level register
#define AMG8833_REG_INT0  0x10 // pixel 1 - 8 interrupt result register
#define AMG8833_REG_INT1  0x11 // pixel 9 - 16 interrupt result register
#define AMG8833_REG_INT2  0x12 // pixel 17 - 24 interrupt result register
#define AMG8833_REG_INT3  0x13 // pixel 25 - 32 interrupt result register
#define AMG8833_REG_INT4  0x14 // pixel 33 - 40 interrupt result register
#define AMG8833_REG_INT5  0x15 // pixel 41 - 48 interrupt result register
#define AMG8833_REG_INT6  0x16 // pixel 49 - 56 interrupt result register
#define AMG8833_REG_INT7  0x17 // pixel 57 - 64 interrupt result register
#define AMG8833_REG_T01L  0x80 // pixel 1 output value lower level register
#define AMG8833_REG_T01H  0x81 // pixel 1 output value upper level register
static uint8_t a_amg8833_iic_read( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_read(iic_addr, reg, data, len) != 0) /* read the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_amg8833_iic_write( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_write(iic_addr, reg, data, len) != 0) /* write the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t amg8833_set_addr_pin( amg8833_address_t addr_pin)
{
    {
        
    }
    iic_addr = (uint8_t)addr_pin; /* set pin */
    return 0; /* success return 0 */
}
uint8_t amg8833_get_addr_pin( amg8833_address_t* addr_pin)
{
    {
        
    }
    *addr_pin = (amg8833_address_t)(iic_addr); /* get pin */
    return 0; /* success return 0 */
}
uint8_t amg8833_init(amg8833_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (receive_callback == NULL) /* check receive_callback */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    prev = 0x00;                                                              /* normal mode */
    res  = a_amg8833_iic_write( AMG8833_REG_PCTL, (uint8_t*)&prev, 1); /* write pctl register */
    if (res != 0)                                                             /* check result */
    {
        
        
        
    }
    delay_ms(50);                                                    /* wait 50 ms */
    prev = 0x3F;                                                             /* initial reset */
    res  = a_amg8833_iic_write( AMG8833_REG_RST, (uint8_t*)&prev, 1); /* write rst register */
    if (res != 0)                                                            /* check result */
    {
        
        
        
    }
    delay_ms(2);                                                     /* wait 2 ms */
    prev = 0x30;                                                             /* flag reset */
    res  = a_amg8833_iic_write( AMG8833_REG_RST, (uint8_t*)&prev, 1); /* write rst register */
    if (res != 0)                                                            /* check result */
    {
        
        
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t amg8833_deinit(amg8833_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    prev = 0x10;                                                              /* sleep mode*/
    res  = a_amg8833_iic_write( AMG8833_REG_PCTL, (uint8_t*)&prev, 1); /* write pctl register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    res = iic_deinit(); /* iic deinit */
    if (res != 0)               /* check result */
    {
        
        
    } else {
        iic_init = 0; /* flag close */
        return 0; /* success return 0 */
    }
}
uint8_t amg8833_irq_handler(amg8833_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_STAT, (uint8_t*)&prev, 1); /* read stat register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    res = a_amg8833_iic_write( AMG8833_REG_SCLR, (uint8_t*)&prev, 1); /* write sclr register */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    if ((prev & (1 << AMG8833_STATUS_INTF)) != 0) /* if interrupt outbreak */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(AMG8833_STATUS_INTF); /* run callback */
        }
    }
    if ((prev & (1 << AMG8833_STATUS_OVF_IRS)) != 0) /* if temperature output overflow */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(AMG8833_STATUS_OVF_IRS); /* run callback */
        }
    }
    if ((prev & (1 << AMG8833_STATUS_OVF_THS)) != 0) /* if thermistor temperature output overflow */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(AMG8833_STATUS_OVF_THS); /* run callback */
        }
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_mode( amg8833_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = mode;                                                              /* set the prev */
    res  = a_amg8833_iic_write( AMG8833_REG_PCTL, (uint8_t*)&prev, 1); /* write pctl register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_mode( amg8833_mode_t* mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_PCTL, (uint8_t*)&prev, 1); /* read pctl register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    *mode = (amg8833_mode_t)(prev); /* set the mode */
    return 0; /* success return 0 */
}
uint8_t amg8833_reset( amg8833_reset_type_t type)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = type;                                                             /* set the prev */
    res  = a_amg8833_iic_write( AMG8833_REG_RST, (uint8_t*)&prev, 1); /* write rst register */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_frame_rate( amg8833_frame_rate_t rate)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_FPSC, (uint8_t*)&prev, 1); /* read fpsc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                       /* clear the config */
    prev |= rate << 0;                                                       /* set the config */
    res = a_amg8833_iic_write( AMG8833_REG_FPSC, (uint8_t*)&prev, 1); /* write fpsc register */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_frame_rate( amg8833_frame_rate_t* rate)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_FPSC, (uint8_t*)&prev, 1); /* read fpsc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    *rate = (amg8833_frame_rate_t)((prev >> 0) & 0x01); /* set the rate */
    return 0; /* success return 0 */
}
uint8_t amg8833_set_interrupt_mode( amg8833_interrupt_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* read intc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                       /* clear the config */
    prev |= mode << 1;                                                       /* set the config */
    res = a_amg8833_iic_write( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* write intc register */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt_mode( amg8833_interrupt_mode_t* mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* read intc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    *mode = (amg8833_interrupt_mode_t)((prev >> 1) & 0x01); /* set the mode */
    return 0; /* success return 0 */
}
uint8_t amg8833_set_interrupt( amg8833_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* read intc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                       /* clear the config */
    prev |= enable << 0;                                                     /* set the config */
    res = a_amg8833_iic_write( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* write intc register */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt( amg8833_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTC, (uint8_t*)&prev, 1); /* read intc register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    *enable = (amg8833_bool_t)((prev >> 0) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t amg8833_get_status( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_STAT, (uint8_t*)&prev, 1); /* read stat register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    *status = prev; /* set the status */
    return 0; /* success return 0 */
}
uint8_t amg8833_clear_status( amg8833_status_t status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 1 << status;                                                       /* set the command */
    res  = a_amg8833_iic_write( AMG8833_REG_SCLR, (uint8_t*)&prev, 1); /* write sclr register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_average_mode( amg8833_average_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_AVE, (uint8_t*)&prev, 1); /* read ave register */
    if (res != 0)                                                          /* check result */
    {
        
        
    }
    prev &= ~(1 << 5);                                                      /* clear the config */
    prev |= mode << 5;                                                      /* set the config */
    res = a_amg8833_iic_write( AMG8833_REG_AVE, (uint8_t*)&prev, 1); /* write ave register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_average_mode( amg8833_average_mode_t* mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_AVE, (uint8_t*)&prev, 1); /* read ave register */
    if (res != 0)                                                          /* check result */
    {
        
        
    }
    *mode = (amg8833_average_mode_t)((prev >> 5) & 0x01); /* set the mode */
    return 0; /* success return 0 */
}
uint8_t amg8833_set_interrupt_high_level( int16_t level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (level >> 0) & 0xFF;                                                  /* get lower */
    buf[1] = (level >> 8) & 0xF;                                                   /* get upper */
    res    = a_amg8833_iic_write( AMG8833_REG_INTHL, (uint8_t*)&buf[0], 1); /* write inthl register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    res = a_amg8833_iic_write( AMG8833_REG_INTHH, (uint8_t*)&buf[1], 1); /* write inthh register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt_high_level( int16_t* level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTHL, (uint8_t*)&buf[0], 1); /* read inthl register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTHH, (uint8_t*)&buf[1], 1); /* read inthh register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    if ((buf[1] & (1 << 3)) != 0) /* check negtive */
    {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) |
                           ((uint16_t)(0xF) << 12) | (buf[0] << 0)); /* get the level */
    } else {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) | (buf[0] << 0)); /* get the level */
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_interrupt_low_level( int16_t level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (level >> 0) & 0xFF;                                                  /* get lower */
    buf[1] = (level >> 8) & 0xF;                                                   /* get upper */
    res    = a_amg8833_iic_write( AMG8833_REG_INTLL, (uint8_t*)&buf[0], 1); /* write intll register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    res = a_amg8833_iic_write( AMG8833_REG_INTLH, (uint8_t*)&buf[1], 1); /* write intlh register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt_low_level( int16_t* level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTLL, (uint8_t*)&buf[0], 1); /* read intll register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INTLH, (uint8_t*)&buf[1], 1); /* read intlh register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    if ((buf[1] & (1 << 3)) != 0) /* check negtive */
    {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) |
                           ((uint16_t)(0xF) << 12) | (buf[0] << 0)); /* get the level */
    } else {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) | (buf[0] << 0)); /* get the level */
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_interrupt_hysteresis_level( int16_t level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (level >> 0) & 0xFF;                                                  /* get lower */
    buf[1] = (level >> 8) & 0xF;                                                   /* get upper */
    res    = a_amg8833_iic_write( AMG8833_REG_IHYSL, (uint8_t*)&buf[0], 1); /* write ihysl register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    res = a_amg8833_iic_write( AMG8833_REG_IHYSH, (uint8_t*)&buf[1], 1); /* write ihysh register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt_hysteresis_level( int16_t* level)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_IHYSL, (uint8_t*)&buf[0], 1); /* read ihysl register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_IHYSH, (uint8_t*)&buf[1], 1); /* read ihysh register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    if ((buf[1] & (1 << 3)) != 0) /* check negtive */
    {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) |
                           ((uint16_t)(0xF) << 12) | (buf[0] << 0)); /* get the level */
    } else {
        *level = (int16_t)(((uint16_t)(buf[1]) << 8) | (buf[0] << 0)); /* get the level */
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_interrupt_level_convert_to_register( float temp, int16_t* reg)
{
    {
        
    }
    {
        
    }
    *reg = (int16_t)(temp / 0.25f); /* convert real data to register data */
    return 0; /* success return 0 */
}
uint8_t amg8833_interrupt_level_convert_to_data( int16_t reg, float* temp)
{
    {
        
    }
    {
        
    }
    *temp = (float)(reg)*0.25f; /* convert raw data to real data */
    return 0; /* success return 0 */
}
uint8_t amg8833_read_temperature( int16_t* raw, float* temp)
{
    uint8_t res;
    uint8_t buf[2];
    int16_t data;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_TTHL, (uint8_t*)&buf[0], 1); /* read tthl register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_TTHH, (uint8_t*)&buf[1], 1); /* read tthh register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    *raw = (int16_t)(((uint16_t)(buf[1] & 0xF) << 8) | (buf[0] << 0)); /* get the raw */
    data = (int16_t)(((uint16_t)(buf[1] & 0x7) << 8) | (buf[0] << 0)); /* get the raw */
    if ((buf[1] & 0x8) != 0)                                           /* if negtive */
    {
        data = data * (-1); /* x (-1) */
    }
    *temp = data * 0.0625f; /* convert the temperature */
    return 0; /* success return 0 */
}
uint8_t amg8833_read_temperature_array( int16_t raw[8][8], float temp[8][8])
{
    uint8_t res;
    uint8_t i;
    uint8_t j;
    uint8_t buf[128];
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_T01L, (uint8_t*)buf, 128); /* read t01l register */
    if (res != 0)                                                           /* check result */
    {
        
        
    }
    for (i = 0; i < 8; i++) /* run 8 times */
    {
        for (j = 0; j < 8; j++) /* run 8 times */
        {
            raw[7 - i][7 - j]  = (int16_t)(((uint16_t)buf[i * 16 + j * 2 + 1] << 8) | /* get raw data */
                                          buf[i * 16 + j * 2 + 0]);                  /* get raw data */
            temp[7 - i][7 - j] = (float)raw[7 - i][7 - j] * 0.25f;                    /* get converted temperature */
        }
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_get_interrupt_table( uint8_t table[8][1])
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT0, (uint8_t*)table[7], 1); /* read int0 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT1, (uint8_t*)table[6], 1); /* read int1 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT2, (uint8_t*)table[5], 1); /* read int2 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT3, (uint8_t*)table[4], 1); /* read int3 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT4, (uint8_t*)table[3], 1); /* read int4 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT5, (uint8_t*)table[2], 1); /* read int5 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT6, (uint8_t*)table[1], 1); /* read int6 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    res = a_amg8833_iic_read( AMG8833_REG_INT7, (uint8_t*)table[0], 1); /* read int7 register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t amg8833_set_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_amg8833_iic_write( reg, buf, len); /* write data */
}
uint8_t amg8833_get_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_amg8833_iic_read( reg, buf, len); /* read data */
}
uint8_t amg8833_info(amg8833_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(amg8833_info_t));                 /* initialize amg8833 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
