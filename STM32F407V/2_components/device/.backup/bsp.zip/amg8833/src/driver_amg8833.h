
#ifndef DRIVER_AMG8833_H
#define DRIVER_AMG8833_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    AMG8833_ADDRESS_0 = 0xD0,  // ad select pin connected to the GND
    AMG8833_ADDRESS_1 = 0xD2,  // ad select pin connected to the VCC
} amg8833_address_t;
typedef enum {
    AMG8833_BOOL_FALSE = 0x00,  // false
    AMG8833_BOOL_TRUE  = 0x01,  // true
} amg8833_bool_t;
typedef enum {
    AMG8833_MODE_NORMAL       = 0x00,  // normal mode
    AMG8833_MODE_SLEEP        = 0x10,  // sleep mode
    AMG8833_MODE_STAND_BY_60S = 0x20,  // stand-by 60s mode
    AMG8833_MODE_STAND_BY_10S = 0x21,  // stand-by 10s mode
} amg8833_mode_t;
typedef enum {
    AMG8833_RESET_TYPE_FLAG = 0x30,  // flag reset type
    AMG8833_RESET_TYPE_INIT = 0x3F,  // initial reset type
} amg8833_reset_type_t;
typedef enum {
    AMG8833_FRAME_RATE_10_FPS = 0x00,  // 10 fps
    AMG8833_FRAME_RATE_1_FPS  = 0x01,  // 1 fps
} amg8833_frame_rate_t;
typedef enum {
    AMG8833_INTERRUPT_MODE_DIFFERENCE = 0x00,  // difference interrupt mode
    AMG8833_INTERRUPT_MODE_ABSOLUTE   = 0x01,  // absolute value interrupt mode
} amg8833_interrupt_mode_t;
typedef enum {
    AMG8833_STATUS_OVF_THS = 0x03,  // thermistor temperature output overflow
    AMG8833_STATUS_OVF_IRS = 0x02,  // temperature output overflow
    AMG8833_STATUS_INTF    = 0x01,  // interrupt outbreak
} amg8833_status_t;
typedef enum {
    AMG8833_AVERAGE_MODE_ONCE  = 0x00,  // once moving average output mode
    AMG8833_AVERAGE_MODE_TWICE = 0x01,  // twice moving average output mode
} amg8833_average_mode_t;
typedef struct amg8833_handle_s {
    uint8_t inited;    // inited flag
    uint8_t iic_addr;  // iic address
} amg8833_handle_t;

uint8_t amg8833_info(amg8833_info_t* info);
uint8_t amg8833_irq_handler(amg8833_handle_t* handle);
uint8_t amg8833_set_addr_pin(amg8833_handle_t* handle, amg8833_address_t addr_pin);
uint8_t amg8833_get_addr_pin(amg8833_handle_t* handle, amg8833_address_t* addr_pin);
uint8_t amg8833_init(amg8833_handle_t* handle);
uint8_t amg8833_deinit(amg8833_handle_t* handle);
uint8_t amg8833_read_temperature(amg8833_handle_t* handle, int16_t* raw, float* temp);
uint8_t amg8833_read_temperature_array(amg8833_handle_t* handle, int16_t raw[8][8], float temp[8][8]);
uint8_t amg8833_get_interrupt_table(amg8833_handle_t* handle, uint8_t table[8][1]);
uint8_t amg8833_set_mode(amg8833_handle_t* handle, amg8833_mode_t mode);
uint8_t amg8833_get_mode(amg8833_handle_t* handle, amg8833_mode_t* mode);
uint8_t amg8833_reset(amg8833_handle_t* handle, amg8833_reset_type_t type);
uint8_t amg8833_set_frame_rate(amg8833_handle_t* handle, amg8833_frame_rate_t rate);
uint8_t amg8833_get_frame_rate(amg8833_handle_t* handle, amg8833_frame_rate_t* rate);
uint8_t amg8833_set_interrupt_mode(amg8833_handle_t* handle, amg8833_interrupt_mode_t mode);
uint8_t amg8833_get_interrupt_mode(amg8833_handle_t* handle, amg8833_interrupt_mode_t* mode);
uint8_t amg8833_set_interrupt(amg8833_handle_t* handle, amg8833_bool_t enable);
uint8_t amg8833_get_interrupt(amg8833_handle_t* handle, amg8833_bool_t* enable);
uint8_t amg8833_get_status(amg8833_handle_t* handle, uint8_t* status);
uint8_t amg8833_clear_status(amg8833_handle_t* handle, amg8833_status_t status);
uint8_t amg8833_set_average_mode(amg8833_handle_t* handle, amg8833_average_mode_t mode);
uint8_t amg8833_get_average_mode(amg8833_handle_t* handle, amg8833_average_mode_t* mode);
uint8_t amg8833_set_interrupt_high_level(amg8833_handle_t* handle, int16_t level);
uint8_t amg8833_get_interrupt_high_level(amg8833_handle_t* handle, int16_t* level);
uint8_t amg8833_set_interrupt_low_level(amg8833_handle_t* handle, int16_t level);
uint8_t amg8833_get_interrupt_low_level(amg8833_handle_t* handle, int16_t* level);
uint8_t amg8833_set_interrupt_hysteresis_level(amg8833_handle_t* handle, int16_t level);
uint8_t amg8833_get_interrupt_hysteresis_level(amg8833_handle_t* handle, int16_t* level);
uint8_t amg8833_interrupt_level_convert_to_register(amg8833_handle_t* handle, float temp, int16_t* reg);
uint8_t amg8833_interrupt_level_convert_to_data(amg8833_handle_t* handle, int16_t reg, float* temp);
uint8_t amg8833_set_reg(amg8833_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t amg8833_get_reg(amg8833_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
