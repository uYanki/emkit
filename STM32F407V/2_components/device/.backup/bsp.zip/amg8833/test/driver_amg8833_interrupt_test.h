
#ifndef DRIVER_AMG8833_INTERRUPT_TEST_H
#define DRIVER_AMG8833_INTERRUPT_TEST_H
#include "driver_amg8833_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t amg8833_interrupt_test_irq_handler(void);
uint8_t amg8833_interrupt_test(amg8833_address_t addr_pin, 
                               amg8833_interrupt_mode_t mode,
                               float high_level, float low_level, 
                               float hysteresis_level, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
