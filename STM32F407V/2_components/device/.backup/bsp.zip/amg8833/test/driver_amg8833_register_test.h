
#ifndef DRIVER_AMG8833_REGISTER_TEST_H
#define DRIVER_AMG8833_REGISTER_TEST_H
#include "driver_amg8833_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t amg8833_register_test(amg8833_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
