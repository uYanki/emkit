
#ifndef DRIVER_MPU6050_H
#define DRIVER_MPU6050_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MPU6050_ADDRESS_AD0_LOW  = 0xD0,  // AD0 pin set LOW
    MPU6050_ADDRESS_AD0_HIGH = 0xD2,  // AD0 pin set HIGH
} mpu6050_address_t;
typedef enum {
    MPU6050_WAKE_UP_FREQUENCY_1P25_HZ = 0x00,  // 1.25Hz
    MPU6050_WAKE_UP_FREQUENCY_5_HZ    = 0x01,  // 5Hz
    MPU6050_WAKE_UP_FREQUENCY_20_HZ   = 0x02,  // 20Hz
    MPU6050_WAKE_UP_FREQUENCY_40_HZ   = 0x03,  // 40Hz
} mpu6050_wake_up_frequency_t;
typedef enum {
    MPU6050_BOOL_FALSE = 0x00,  // disable function
    MPU6050_BOOL_TRUE  = 0x01,  // enable function
} mpu6050_bool_t;
typedef enum {
    MPU6050_SOURCE_ACC_X  = 0x05,  // accelerometer x
    MPU6050_SOURCE_ACC_Y  = 0x04,  // accelerometer y
    MPU6050_SOURCE_ACC_Z  = 0x03,  // accelerometer z
    MPU6050_SOURCE_GYRO_X = 0x02,  // gyroscope x
    MPU6050_SOURCE_GYRO_Y = 0x01,  // gyroscope y
    MPU6050_SOURCE_GYRO_Z = 0x00,  // gyroscope z
} mpu6050_source_t;
typedef enum {
    MPU6050_CLOCK_SOURCE_INTERNAL_8MHZ      = 0x00,  // internal 8MHz
    MPU6050_CLOCK_SOURCE_PLL_X_GYRO         = 0x01,  // pll with x axis gyroscope reference
    MPU6050_CLOCK_SOURCE_PLL_Y_GYRO         = 0x02,  // pll with y axis gyroscope reference
    MPU6050_CLOCK_SOURCE_PLL_Z_GYRO         = 0x03,  // pll with z axis gyroscope reference
    MPU6050_CLOCK_SOURCE_PLL_EXT_32P768_KHZ = 0x04,  // pll extern 32.768 KHz
    MPU6050_CLOCK_SOURCE_PLL_EXT_19P2_MHZ   = 0x05,  // pll extern 19.2 MHz
    MPU6050_CLOCK_SOURCE_STOP_CLOCK         = 0x07,  // stop the clock
} mpu6050_clock_source_t;
typedef enum {
    MPU6050_SIGNAL_PATH_RESET_TEMP  = 0x00,  // temperature sensor analog and digital signal paths
    MPU6050_SIGNAL_PATH_RESET_ACCEL = 0x01,  // accelerometer analog and digital signal paths
    MPU6050_SIGNAL_PATH_RESET_GYRO  = 0x02,  // gyroscope analog and digital signal paths
} mpu6050_signal_path_reset_t;
typedef enum {
    MPU6050_EXTERN_SYNC_INPUT_DISABLED = 0x00,  // input disabled
    MPU6050_EXTERN_SYNC_TEMP_OUT_L     = 0x01,  // temp out low
    MPU6050_EXTERN_SYNC_GYRO_XOUT_L    = 0x02,  // gyro xout low
    MPU6050_EXTERN_SYNC_GYRO_YOUT_L    = 0x03,  // gyro yout low
    MPU6050_EXTERN_SYNC_GYRO_ZOUT_L    = 0x04,  // gyro zout low
    MPU6050_EXTERN_SYNC_ACCEL_XOUT_L   = 0x05,  // accel xout low
    MPU6050_EXTERN_SYNC_ACCEL_YOUT_L   = 0x06,  // accel yout low
    MPU6050_EXTERN_SYNC_ACCEL_ZOUT_L   = 0x07,  // accel zout low
} mpu6050_extern_sync_t;
typedef enum                           //           accelerometer                     gyroscope
{                                      // bandwidth(Hz) fs(KHz) delay(ms)   bandwidth(Hz) fs(KHz) delay(ms)
    MPU6050_LOW_PASS_FILTER_0 = 0x00,  //      260         1         0          256          8      0.98
    MPU6050_LOW_PASS_FILTER_1 = 0x01,  //      184         1       2.0          188          1       1.9
    MPU6050_LOW_PASS_FILTER_2 = 0x02,  //       94         1       3.0           98          1       2.8
    MPU6050_LOW_PASS_FILTER_3 = 0x03,  //       44         1       4.9           42          1       4.8
    MPU6050_LOW_PASS_FILTER_4 = 0x04,  //       21         1       8.5           20          1       8.3
    MPU6050_LOW_PASS_FILTER_5 = 0x05,  //       10         1      13.8           10          1      13.4
    MPU6050_LOW_PASS_FILTER_6 = 0x06,  //        5         1      19.0            5          1      18.6
} mpu6050_low_pass_filter_t;
typedef enum {
    MPU6050_AXIS_Z = 0x05,  // z
    MPU6050_AXIS_Y = 0x06,  // y
    MPU6050_AXIS_X = 0x07,  // x
} mpu6050_axis_t;
typedef enum {
    MPU6050_GYROSCOPE_RANGE_250DPS  = 0x00,  // ±250 dps
    MPU6050_GYROSCOPE_RANGE_500DPS  = 0x01,  // ±500 dps
    MPU6050_GYROSCOPE_RANGE_1000DPS = 0x02,  // ±1000 dps
    MPU6050_GYROSCOPE_RANGE_2000DPS = 0x03,  // ±2000 dps
} mpu6050_gyroscope_range_t;
typedef enum {
    MPU6050_ACCELEROMETER_RANGE_2G  = 0x00,  // ±2 g
    MPU6050_ACCELEROMETER_RANGE_4G  = 0x01,  // ±4 g
    MPU6050_ACCELEROMETER_RANGE_8G  = 0x02,  // ±8 g
    MPU6050_ACCELEROMETER_RANGE_16G = 0x03,  // ±16 g
} mpu6050_accelerometer_range_t;
typedef enum {
    MPU6050_FIFO_TEMP  = 0x07,  // temperature
    MPU6050_FIFO_XG    = 0x06,  // gyroscope x
    MPU6050_FIFO_YG    = 0x05,  // gyroscope y
    MPU6050_FIFO_ZG    = 0x04,  // gyroscope z
    MPU6050_FIFO_ACCEL = 0x03,  // accelerometer
} mpu6050_fifo_t;
typedef enum {
    MPU6050_PIN_LEVEL_HIGH = 0x00,  // active low
    MPU6050_PIN_LEVEL_LOW  = 0x01,  // active high
} mpu6050_pin_level_t;
typedef enum {
    MPU6050_PIN_TYPE_PUSH_PULL  = 0x00,  // push pull
    MPU6050_PIN_TYPE_OPEN_DRAIN = 0x01,  // open drain
} mpu6050_pin_type_t;
typedef enum {
    MPU6050_INTERRUPT_MOTION        = 6,  // motion
    MPU6050_INTERRUPT_FIFO_OVERFLOW = 4,  // fifo overflow
    MPU6050_INTERRUPT_I2C_MAST      = 3,  // i2c master
    MPU6050_INTERRUPT_DMP           = 1,  // dmp
    MPU6050_INTERRUPT_DATA_READY    = 0,  // data ready
} mpu6050_interrupt_t;
typedef enum {
    MPU6050_IIC_SLAVE_0 = 0x00,  // slave0
    MPU6050_IIC_SLAVE_1 = 0x01,  // slave1
    MPU6050_IIC_SLAVE_2 = 0x02,  // slave2
    MPU6050_IIC_SLAVE_3 = 0x03,  // slave3
    MPU6050_IIC_SLAVE_4 = 0x04,  // slave4
} mpu6050_iic_slave_t;
typedef enum {
    MPU6050_IIC_CLOCK_348_KHZ = 0x00,  // 348 kHz
    MPU6050_IIC_CLOCK_333_KHZ = 0x01,  // 333 kHz
    MPU6050_IIC_CLOCK_320_KHZ = 0x02,  // 320 kHz
    MPU6050_IIC_CLOCK_308_KHZ = 0x03,  // 308 kHz
    MPU6050_IIC_CLOCK_296_KHZ = 0x04,  // 296 kHz
    MPU6050_IIC_CLOCK_286_KHZ = 0x05,  // 286 kHz
    MPU6050_IIC_CLOCK_276_KHZ = 0x06,  // 276 kHz
    MPU6050_IIC_CLOCK_267_KHZ = 0x07,  // 267 kHz
    MPU6050_IIC_CLOCK_258_KHZ = 0x08,  // 258 kHz
    MPU6050_IIC_CLOCK_500_KHZ = 0x09,  // 500 kHz
    MPU6050_IIC_CLOCK_471_KHZ = 0x0A,  // 471 kHz
    MPU6050_IIC_CLOCK_444_KHZ = 0x0B,  // 444 kHz
    MPU6050_IIC_CLOCK_421_KHZ = 0x0C,  // 421 kHz
    MPU6050_IIC_CLOCK_400_KHZ = 0x0D,  // 400 kHz
    MPU6050_IIC_CLOCK_381_KHZ = 0x0E,  // 381 kHz
    MPU6050_IIC_CLOCK_364_KHZ = 0x0F,  // 364 kHz
} mpu6050_iic_clock_t;
typedef enum {
    MPU6050_IIC_READ_MODE_RESTART        = 0x00,  // restart
    MPU6050_IIC_READ_MODE_STOP_AND_START = 0x01,  // stop and start
} mpu6050_iic_read_mode_t;
typedef enum {
    MPU6050_IIC_MODE_WRITE = 0x00,  // write
    MPU6050_IIC_MODE_READ  = 0x01,  // read
} mpu6050_iic_mode_t;
typedef enum {
    MPU6050_IIC_TRANSACTION_MODE_DATA     = 0x00,  // data only
    MPU6050_IIC_TRANSACTION_MODE_REG_DATA = 0x01,  // write a register address prior to reading or writing data
} mpu6050_iic_transaction_mode_t;
typedef enum {
    MPU6050_IIC4_TRANSACTION_MODE_DATA = 0x00,  // data only
    MPU6050_IIC4_TRANSACTION_MODE_REG  = 0x01,  // register only
} mpu6050_iic4_transaction_mode_t;
typedef enum {
    MPU6050_IIC_GROUP_ORDER_EVEN = 0x00, /**< when cleared to 0, bytes from register addresses 0 and 1, 2 and 3,
                                              etc (even, then odd register addresses) are paired to form a word. */
    MPU6050_IIC_GROUP_ORDER_ODD = 0x01,  /**< when set to 1, bytes from register addresses are paired 1 and 2, 3 and 4,
                                              etc. (odd, then even register addresses) are paired to form a word. */
} mpu6050_iic_group_order_t;
typedef enum {
    MPU6050_IIC_STATUS_PASS_THROUGH  = 0x80,  // pass through
    MPU6050_IIC_STATUS_IIC_SLV4_DONE = 0x40,  // slave4 done
    MPU6050_IIC_STATUS_IIC_LOST_ARB  = 0x20,  // lost arbitration
    MPU6050_IIC_STATUS_IIC_SLV4_NACK = 0x10,  // slave4 nack
    MPU6050_IIC_STATUS_IIC_SLV3_NACK = 0x08,  // slave3 nack
    MPU6050_IIC_STATUS_IIC_SLV2_NACK = 0x04,  // slave2 nack
    MPU6050_IIC_STATUS_IIC_SLV1_NACK = 0x02,  // slave1 nack
    MPU6050_IIC_STATUS_IIC_SLV0_NACK = 0x01,  // slave0 nack
} mpu6050_iic_status_t;
typedef enum {
    MPU6050_IIC_DELAY_ES_SHADOW = 7, /**< delays shadowing of external sensor data until
                                          all data has been received */
    MPU6050_IIC_DELAY_SLAVE_4 = 4,   // slave 4
    MPU6050_IIC_DELAY_SLAVE_3 = 3,   // slave 3
    MPU6050_IIC_DELAY_SLAVE_2 = 2,   // slave 2
    MPU6050_IIC_DELAY_SLAVE_1 = 1,   // slave 1
    MPU6050_IIC_DELAY_SLAVE_0 = 0,   // slave 0
} mpu6050_iic_delay_t;
typedef enum {
    MPU6050_DMP_INTERRUPT_MODE_CONTINUOUS = 0x00,  // continuous mode
    MPU6050_DMP_INTERRUPT_MODE_GESTURE    = 0x01,  // gesture mode
} mpu6050_dmp_interrupt_mode_t;
typedef enum {
    MPU6050_DMP_FEATURE_TAP            = 0x001,  // feature tap
    MPU6050_DMP_FEATURE_ORIENT         = 0x002,  // feature orient
    MPU6050_DMP_FEATURE_3X_QUAT        = 0x004,  // feature 3x quat
    MPU6050_DMP_FEATURE_PEDOMETER      = 0x008,  // feature pedometer
    MPU6050_DMP_FEATURE_6X_QUAT        = 0x010,  // feature 6x quat
    MPU6050_DMP_FEATURE_GYRO_CAL       = 0x020,  // feature gyro cal
    MPU6050_DMP_FEATURE_SEND_RAW_ACCEL = 0x040,  // feature send raw accel
    MPU6050_DMP_FEATURE_SEND_RAW_GYRO  = 0x080,  // feature send raw gyro
    MPU6050_DMP_FEATURE_SEND_CAL_GYRO  = 0x100,  // feature send cal gyro
} mpu6050_dmp_feature_t;
typedef enum {
    MPU6050_DMP_TAP_X_UP   = 0x01,  // tap x up
    MPU6050_DMP_TAP_X_DOWN = 0x02,  // tap x down
    MPU6050_DMP_TAP_Y_UP   = 0x03,  // tap y up
    MPU6050_DMP_TAP_Y_DOWN = 0x04,  // tap y down
    MPU6050_DMP_TAP_Z_UP   = 0x05,  // tap z up
    MPU6050_DMP_TAP_Z_DOWN = 0x06,  // tap z down
} mpu6050_dmp_tap_t;
typedef enum {
    MPU6050_DMP_ORIENT_PORTRAIT          = 0x00,  // portrait
    MPU6050_DMP_ORIENT_LANDSCAPE         = 0x01,  // landscape
    MPU6050_DMP_ORIENT_REVERSE_PORTRAIT  = 0x02,  // reverse portrait
    MPU6050_DMP_ORIENT_REVERSE_LANDSCAPE = 0x03,  // reverse landscape
} mpu6050_dmp_orient_t;
typedef struct mpu6050_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t  inited;      // inited flag
    uint8_t  dmp_inited;  // dmp inited flag
    uint16_t orient;      // orient
    uint16_t mask;        // mask
    uint8_t  buf[1024];   // inner buffer
} mpu6050_handle_t;

uint8_t mpu6050_info(mpu6050_info_t* info);
uint8_t mpu6050_set_addr_pin(mpu6050_handle_t* handle, mpu6050_address_t addr_pin);
uint8_t mpu6050_get_addr_pin(mpu6050_handle_t* handle, mpu6050_address_t* addr_pin);
uint8_t mpu6050_irq_handler(mpu6050_handle_t* handle);
uint8_t mpu6050_init(mpu6050_handle_t* handle);
uint8_t mpu6050_deinit(mpu6050_handle_t* handle);
uint8_t mpu6050_read(mpu6050_handle_t* handle, int16_t (*accel_raw)[3], float (*accel_g)[3], int16_t (*gyro_raw)[3], float (*gyro_dps)[3], uint16_t* len);
uint8_t mpu6050_read_temperature(mpu6050_handle_t* handle, int16_t(*raw), float* degrees);
uint8_t mpu6050_set_fifo(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_fifo(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_force_fifo_reset(mpu6050_handle_t* handle);
uint8_t mpu6050_set_iic_master(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_master(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_fifo_reset(mpu6050_handle_t* handle);
uint8_t mpu6050_get_fifo_reset(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_iic_master_reset(mpu6050_handle_t* handle);
uint8_t mpu6050_get_iic_master_reset(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_sensor_reset(mpu6050_handle_t* handle);
uint8_t mpu6050_get_sensor_reset(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_device_reset(mpu6050_handle_t* handle);
uint8_t mpu6050_get_device_reset(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_clock_source(mpu6050_handle_t* handle, mpu6050_clock_source_t clock_source);
uint8_t mpu6050_get_clock_source(mpu6050_handle_t* handle, mpu6050_clock_source_t* clock_source);
uint8_t mpu6050_set_temperature_sensor(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_temperature_sensor(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_cycle_wake_up(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_cycle_wake_up(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_sleep(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_sleep(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_standby_mode(mpu6050_handle_t* handle, mpu6050_source_t source, mpu6050_bool_t enable);
uint8_t mpu6050_get_standby_mode(mpu6050_handle_t* handle, mpu6050_source_t source, mpu6050_bool_t* enable);
uint8_t mpu6050_set_wake_up_frequency(mpu6050_handle_t* handle, mpu6050_wake_up_frequency_t frequency);
uint8_t mpu6050_get_wake_up_frequency(mpu6050_handle_t* handle, mpu6050_wake_up_frequency_t* frequency);
uint8_t mpu6050_get_fifo_count(mpu6050_handle_t* handle, uint16_t* count);
uint8_t mpu6050_fifo_get(mpu6050_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t mpu6050_fifo_set(mpu6050_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t mpu6050_set_signal_path_reset(mpu6050_handle_t* handle, mpu6050_signal_path_reset_t path);
uint8_t mpu6050_set_sample_rate_divider(mpu6050_handle_t* handle, uint8_t d);
uint8_t mpu6050_get_sample_rate_divider(mpu6050_handle_t* handle, uint8_t* d);
uint8_t mpu6050_set_extern_sync(mpu6050_handle_t* handle, mpu6050_extern_sync_t sync);
uint8_t mpu6050_get_extern_sync(mpu6050_handle_t* handle, mpu6050_extern_sync_t* sync);
uint8_t mpu6050_set_low_pass_filter(mpu6050_handle_t* handle, mpu6050_low_pass_filter_t filter);
uint8_t mpu6050_get_low_pass_filter(mpu6050_handle_t* handle, mpu6050_low_pass_filter_t* filter);
uint8_t mpu6050_set_gyroscope_test(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t enable);
uint8_t mpu6050_get_gyroscope_test(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t* enable);
uint8_t mpu6050_set_gyroscope_range(mpu6050_handle_t* handle, mpu6050_gyroscope_range_t range);
uint8_t mpu6050_get_gyroscope_range(mpu6050_handle_t* handle, mpu6050_gyroscope_range_t* range);
uint8_t mpu6050_set_accelerometer_test(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t enable);
uint8_t mpu6050_get_accelerometer_test(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t* enable);
uint8_t mpu6050_set_accelerometer_range(mpu6050_handle_t* handle, mpu6050_accelerometer_range_t range);
uint8_t mpu6050_get_accelerometer_range(mpu6050_handle_t* handle, mpu6050_accelerometer_range_t* range);
uint8_t mpu6050_set_fifo_enable(mpu6050_handle_t* handle, mpu6050_fifo_t fifo, mpu6050_bool_t enable);
uint8_t mpu6050_get_fifo_enable(mpu6050_handle_t* handle, mpu6050_fifo_t fifo, mpu6050_bool_t* enable);
uint8_t mpu6050_set_interrupt_level(mpu6050_handle_t* handle, mpu6050_pin_level_t level);
uint8_t mpu6050_get_interrupt_level(mpu6050_handle_t* handle, mpu6050_pin_level_t* level);
uint8_t mpu6050_set_interrupt_pin_type(mpu6050_handle_t* handle, mpu6050_pin_type_t type);
uint8_t mpu6050_get_interrupt_pin_type(mpu6050_handle_t* handle, mpu6050_pin_type_t* type);
uint8_t mpu6050_set_interrupt_latch(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_interrupt_latch(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_interrupt_read_clear(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_interrupt_read_clear(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_fsync_interrupt_level(mpu6050_handle_t* handle, mpu6050_pin_level_t level);
uint8_t mpu6050_get_fsync_interrupt_level(mpu6050_handle_t* handle, mpu6050_pin_level_t* level);
uint8_t mpu6050_set_fsync_interrupt(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_fsync_interrupt(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_bypass(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_bypass(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_interrupt(mpu6050_handle_t* handle, mpu6050_interrupt_t type, mpu6050_bool_t enable);
uint8_t mpu6050_get_interrupt(mpu6050_handle_t* handle, mpu6050_interrupt_t type, mpu6050_bool_t* enable);
uint8_t mpu6050_get_interrupt_status(mpu6050_handle_t* handle, uint8_t* status);
uint8_t mpu6050_set_gyroscope_x_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_gyroscope_x_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_gyroscope_y_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_gyroscope_y_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_gyroscope_z_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_gyroscope_z_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_accelerometer_x_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_accelerometer_x_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_accelerometer_y_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_accelerometer_y_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_accelerometer_z_test(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_accelerometer_z_test(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_motion_threshold(mpu6050_handle_t* handle, uint8_t threshold);
uint8_t mpu6050_get_motion_threshold(mpu6050_handle_t* handle, uint8_t* threshold);
uint8_t mpu6050_motion_threshold_convert_to_register(mpu6050_handle_t* handle, float mg, uint8_t* reg);
uint8_t mpu6050_motion_threshold_convert_to_data(mpu6050_handle_t* handle, uint8_t reg, float* mg);
uint8_t mpu6050_set_motion_duration(mpu6050_handle_t* handle, uint8_t duration);
uint8_t mpu6050_get_motion_duration(mpu6050_handle_t* handle, uint8_t* duration);
uint8_t mpu6050_motion_duration_convert_to_register(mpu6050_handle_t* handle, uint8_t ms, uint8_t* reg);
uint8_t mpu6050_motion_duration_convert_to_data(mpu6050_handle_t* handle, uint8_t reg, uint8_t* ms);
uint8_t mpu6050_set_force_accel_sample(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_self_test(mpu6050_handle_t* handle, int32_t gyro_offset_raw[3], int32_t accel_offset_raw[3]);
uint8_t mpu6050_set_iic_clock(mpu6050_handle_t* handle, mpu6050_iic_clock_t clk);
uint8_t mpu6050_get_iic_clock(mpu6050_handle_t* handle, mpu6050_iic_clock_t* clk);
uint8_t mpu6050_set_iic_multi_master(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_multi_master(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_wait_for_external_sensor(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_wait_for_external_sensor(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_read_mode(mpu6050_handle_t* handle, mpu6050_iic_read_mode_t mode);
uint8_t mpu6050_get_iic_read_mode(mpu6050_handle_t* handle, mpu6050_iic_read_mode_t* mode);
uint8_t mpu6050_set_iic_fifo_enable(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_fifo_enable(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_mode(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_mode_t mode);
uint8_t mpu6050_get_iic_mode(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_mode_t* mode);
uint8_t mpu6050_set_iic_address(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t addr_7bit);
uint8_t mpu6050_get_iic_address(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t* addr_7bit);
uint8_t mpu6050_set_iic_register(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t reg);
uint8_t mpu6050_get_iic_register(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t* reg);
uint8_t mpu6050_set_iic_data_out(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t data);
uint8_t mpu6050_get_iic_data_out(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t* data);
uint8_t mpu6050_set_iic_enable(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_enable(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_byte_swap(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_byte_swap(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic_transaction_mode(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_transaction_mode_t mode);
uint8_t mpu6050_get_iic_transaction_mode(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_transaction_mode_t* mode);
uint8_t mpu6050_set_iic_group_order(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_group_order_t order);
uint8_t mpu6050_get_iic_group_order(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, mpu6050_iic_group_order_t* order);
uint8_t mpu6050_set_iic_transferred_len(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t len);
uint8_t mpu6050_get_iic_transferred_len(mpu6050_handle_t* handle, mpu6050_iic_slave_t slave, uint8_t* len);
uint8_t mpu6050_get_iic_status(mpu6050_handle_t* handle, uint8_t* status);
uint8_t mpu6050_set_iic_delay_enable(mpu6050_handle_t* handle, mpu6050_iic_delay_t delay, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic_delay_enable(mpu6050_handle_t* handle, mpu6050_iic_delay_t delay, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic4_enable(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic4_enable(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic4_interrupt(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_get_iic4_interrupt(mpu6050_handle_t* handle, mpu6050_bool_t* enable);
uint8_t mpu6050_set_iic4_transaction_mode(mpu6050_handle_t* handle, mpu6050_iic4_transaction_mode_t mode);
uint8_t mpu6050_get_iic4_transaction_mode(mpu6050_handle_t* handle, mpu6050_iic4_transaction_mode_t* mode);
uint8_t mpu6050_set_iic_delay(mpu6050_handle_t* handle, uint8_t delay);
uint8_t mpu6050_get_iic_delay(mpu6050_handle_t* handle, uint8_t* delay);
uint8_t mpu6050_set_iic4_data_out(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_iic4_data_out(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_set_iic4_data_in(mpu6050_handle_t* handle, uint8_t data);
uint8_t mpu6050_get_iic4_data_in(mpu6050_handle_t* handle, uint8_t* data);
uint8_t mpu6050_read_extern_sensor_data(mpu6050_handle_t* handle, uint8_t* data, uint8_t len);
uint8_t mpu6050_dmp_load_firmware(mpu6050_handle_t* handle);
uint8_t mpu6050_dmp_set_pedometer_walk_time(mpu6050_handle_t* handle, uint32_t ms);
uint8_t mpu6050_dmp_get_pedometer_walk_time(mpu6050_handle_t* handle, uint32_t* ms);
uint8_t mpu6050_dmp_set_pedometer_step_count(mpu6050_handle_t* handle, uint32_t count);
uint8_t mpu6050_dmp_get_pedometer_step_count(mpu6050_handle_t* handle, uint32_t* count);
uint8_t mpu6050_dmp_set_shake_reject_timeout(mpu6050_handle_t* handle, uint16_t ms);
uint8_t mpu6050_dmp_get_shake_reject_timeout(mpu6050_handle_t* handle, uint16_t* ms);
uint8_t mpu6050_dmp_set_shake_reject_time(mpu6050_handle_t* handle, uint16_t ms);
uint8_t mpu6050_dmp_get_shake_reject_time(mpu6050_handle_t* handle, uint16_t* ms);
uint8_t mpu6050_dmp_set_shake_reject_thresh(mpu6050_handle_t* handle, uint16_t dps);
uint8_t mpu6050_dmp_get_shake_reject_thresh(mpu6050_handle_t* handle, uint16_t* dps);
uint8_t mpu6050_dmp_set_tap_time_multi(mpu6050_handle_t* handle, uint16_t ms);
uint8_t mpu6050_dmp_get_tap_time_multi(mpu6050_handle_t* handle, uint16_t* ms);
uint8_t mpu6050_dmp_set_tap_time(mpu6050_handle_t* handle, uint16_t ms);
uint8_t mpu6050_dmp_get_tap_time(mpu6050_handle_t* handle, uint16_t* ms);
uint8_t mpu6050_dmp_set_min_tap_count(mpu6050_handle_t* handle, uint8_t cnt);
uint8_t mpu6050_dmp_get_min_tap_count(mpu6050_handle_t* handle, uint8_t* cnt);
uint8_t mpu6050_dmp_set_tap_axes(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t enable);
uint8_t mpu6050_dmp_get_tap_axes(mpu6050_handle_t* handle, mpu6050_axis_t axis, mpu6050_bool_t* enable);
uint8_t mpu6050_dmp_set_tap_thresh(mpu6050_handle_t* handle, mpu6050_axis_t axis, uint16_t mg_ms);
uint8_t mpu6050_dmp_get_tap_thresh(mpu6050_handle_t* handle, mpu6050_axis_t axis, uint16_t* mg_ms);
uint8_t mpu6050_dmp_set_fifo_rate(mpu6050_handle_t* handle, uint16_t rate);
uint8_t mpu6050_dmp_get_fifo_rate(mpu6050_handle_t* handle, uint16_t* rate);
uint8_t mpu6050_dmp_set_gyro_calibrate(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_dmp_set_3x_quaternion(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_dmp_set_6x_quaternion(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_dmp_set_interrupt_mode(mpu6050_handle_t* handle, mpu6050_dmp_interrupt_mode_t mode);
uint8_t mpu6050_dmp_set_gyro_bias(mpu6050_handle_t* handle, int32_t bias[3]);
uint8_t mpu6050_dmp_set_accel_bias(mpu6050_handle_t* handle, int32_t bias[3]);
uint8_t mpu6050_dmp_set_orientation(mpu6050_handle_t* handle, int8_t mat[9]);
uint8_t mpu6050_dmp_set_feature(mpu6050_handle_t* handle, uint16_t mask);
uint8_t mpu6050_dmp_read(mpu6050_handle_t* handle,
                         int16_t (*accel_raw)[3],
                         float (*accel_g)[3],
                         int16_t (*gyro_raw)[3],
                         float (*gyro_dps)[3],
                         int32_t (*quat)[4],
                         float*    pitch,
                         float*    roll,
                         float*    yaw,
                         uint16_t* l);
uint8_t mpu6050_dmp_set_tap_callback(mpu6050_handle_t* handle, void (*callback)(uint8_t count, uint8_t direction));
uint8_t mpu6050_dmp_set_orient_callback(mpu6050_handle_t* handle, void (*callback)(uint8_t orientation));
uint8_t mpu6050_dmp_set_enable(mpu6050_handle_t* handle, mpu6050_bool_t enable);
uint8_t mpu6050_dmp_gyro_accel_raw_offset_convert(mpu6050_handle_t* handle,
                                                  int32_t           gyro_offset_raw[3],
                                                  int32_t           accel_offset_raw[3],
                                                  int32_t           gyro_offset[3],
                                                  int32_t           accel_offset[3]);
uint8_t mpu6050_set_reg(mpu6050_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t mpu6050_get_reg(mpu6050_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
