
#ifndef DRIVER_MPU6050_FIFO_TEST_H
#define DRIVER_MPU6050_FIFO_TEST_H
#include "driver_mpu6050_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mpu6050_fifo_test_irq_handler(void);
uint8_t mpu6050_fifo_test(mpu6050_address_t addr, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
