
#include "driver_aht20.h"

#define MANUFACTURER_NAME         "ASAIR"              // manufacturer name
#define SUPPLY_VOLTAGE_MIN        2.2f                 // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f                 // chip max supply voltage




#define AHT20_ADDRESS             0x70        // iic device address
static uint8_t a_aht20_iic_read(aht20_handle_t *handle, uint8_t *data, uint16_t len)
{
    if (iic_read_cmd(AHT20_ADDRESS, data, len) != 0)        /* read the register */
    {
        
    }
    else
    {
        return 0;                                                   /* success return 0 */
    }
}
static uint8_t a_aht20_iic_write(aht20_handle_t *handle, uint8_t *data, uint16_t len)
{
    if (iic_write_cmd(AHT20_ADDRESS, data, len) != 0)        /* write the register */
    {
        
    }
    else
    {
        return 0;                                                    /* success return 0 */
    }
}
static uint8_t a_aht20_calc_crc(uint8_t *data, uint8_t len)
{
    uint8_t i;
    uint8_t byte;
    uint8_t crc = 0xFF;
    for (byte = 0; byte < len; byte++)          /* len times */
    {
        crc ^= data[byte];                      /* xor byte */
        for (i = 8; i > 0; --i)                 /* one byte */
        {
            if ((crc & 0x80) != 0)              /* if high*/
            {
                crc = (crc << 1) ^ 0x31;        /* xor 0x31 */
            }
            else
            {
                crc = crc << 1;                 /* skip */
            }
        }
    }
    return crc;                                 /* return crc */
}
static uint8_t a_aht20_jh_reset_reg(aht20_handle_t *handle, uint8_t addr)
{
    uint8_t buf[3];
    uint8_t regs[3];
    buf[0] = addr;                                     /* set the addr */
    buf[1] = 0x00;                                     /* set 0x00 */
    buf[2] = 0x00;                                     /* set 0x00 */
    if (a_aht20_iic_write( buf, 3) != 0)        /* write the command */
    {
        
    }
    delay_ms(5);                               /* delay 5ms */
    if (a_aht20_iic_read( regs, 3) != 0)        /* read regs */
    {
        
    }
    delay_ms(10);                              /* delay 10ms */
    buf[0] = 0xB0 | addr;                              /* set addr */
    buf[1] = regs[1];                                  /* set regs[1] */
    buf[2] = regs[2];                                  /* set regs[2] */
    if (a_aht20_iic_write( buf, 3) != 0)        /* write the data */
    {
        
    }
    return 0;                                          /* success return 0 */
}
uint8_t aht20_init(aht20_handle_t *handle)
{
    uint8_t status;
    
    {
        
    }
    if (debug_print == NULL)                                   /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                      /* check iic_init */
    {
        
        
        
    }
    if (iic_deinit == NULL)                                    /* check iic_deinit */
    {
        
        
        
    }
    if (iic_read_cmd == NULL)                                  /* check iic_read_cmd */
    {
        
        
        
    }
    if (iic_write_cmd == NULL)                                 /* check iic_write_cmd */
    {
        
        
        
    }
    if (delay_ms == NULL)                                      /* check delay_ms */
    {
        
        
        
    }
    if (iic_init() != 0)                                       /* iic init */
    {
        
        
        
    }
    delay_ms(500);                                             /* wait for 500 ms */
    if (a_aht20_iic_read( &status, 1) != 0)                     /* read the status */
    {
        
        (void)iic_deinit();                                    /* close the iic */
        
        
    }
    if ((status & 0x18) != 0x18)                                       /* check the status */
    {
        if (a_aht20_jh_reset_reg( 0x1B) != 0)                   /* reset the 0x1B */
        {
            
            (void)iic_deinit();                                /* close the iic */
            
            
        }
        if (a_aht20_jh_reset_reg( 0x1C) != 0)                   /* reset the 0x1C */
        {
            
            (void)iic_deinit();                                /* close the iic */
            
            
        }
        if (a_aht20_jh_reset_reg( 0x1E) != 0)                   /* reset the 0x1E */
        {
            
            (void)iic_deinit();                                /* close the iic */
            
            
        }
    }
    delay_ms(10);                                              /* delay 10ms */
    inited = 1;                                                /* flag finish initialization */
    return 0;                                                          /* success return 0 */
}
uint8_t aht20_deinit(aht20_handle_t *handle)
{
    
    {
        
    }
    
    {
        
    }
    if (iic_deinit() != 0)                                 /* iic deinit */
    {
        
        
        
    }
    inited = 0;                                            /* set closed flag */
    return 0;                                                      /* success return 0 */
}
uint8_t aht20_read_temperature_humidity(aht20_handle_t *handle, uint32_t *temperature_raw, float *temperature_s,
                                        uint32_t *humidity_raw, uint8_t *humidity_s)
{
    uint8_t status;
    uint8_t buf[7];
    
    {
        
    }
    
    {
        
    }
    buf[0] = 0xAC;                                                    /* set the addr */
    buf[1] = 0x33;                                                    /* set 0x33 */
    buf[2] = 0x00;                                                    /* set 0x00 */
    if (a_aht20_iic_write( buf, 3) != 0)                       /* write the command */
    {
        
        
        
    }
    delay_ms(85);                                             /* delay 85ms */
    if (a_aht20_iic_read( &status, 1) != 0)                    /* read the status */
    {
        
        
        
    }
    if ((status & 0x80) == 0)                                         /* check the status */
    {
        if (a_aht20_iic_read( buf, 7) != 0)                    /* read data */
        {
            
            
            
        }
        if (a_aht20_calc_crc(buf, 6) != buf[6])                       /* check the crc */
        {
            
            
            
        }
        
        *humidity_raw = (((uint32_t)buf[1]) << 16) |
                        (((uint32_t)buf[2]) << 8) |
                        (((uint32_t)buf[3]) << 0);                    /* set the humidity */
        *humidity_raw = (*humidity_raw) >> 4;                         /* right shift 4 */
        *humidity_s = (uint8_t)((float)(*humidity_raw)
                                / 1048576.0f * 100.0f);               /* convert the humidity */
        *temperature_raw = (((uint32_t)buf[3]) << 16) |
                           (((uint32_t)buf[4]) << 8) |
                           (((uint32_t)buf[5]) << 0);                 /* set the temperature */
        *temperature_raw = (*temperature_raw) & 0xFFFFF;              /* cut the temperature part */
        *temperature_s = (float)(*temperature_raw) 
                                 / 1048576.0f * 200.0f
                                 - 50.0f;                             /* right shift 4 */
        
        return 0;                                                     /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t aht20_read_temperature(aht20_handle_t *handle, uint32_t *temperature_raw, float *temperature_s)
{
    uint8_t status;
    uint8_t buf[7];
    
    {
        
    }
    
    {
        
    }
    buf[0] = 0xAC;                                                    /* set the addr */
    buf[1] = 0x33;                                                    /* set 0x33 */
    buf[2] = 0x00;                                                    /* set 0x00 */
    if (a_aht20_iic_write( buf, 3) != 0)                       /* write the command */
    {
        
        
        
    }
    delay_ms(85);                                             /* delay 85ms */
    if (a_aht20_iic_read( &status, 1) != 0)                    /* read the status */
    {
        
        
        
    }
    if ((status & 0x80) == 0)                                         /* check the status */
    {
        if (a_aht20_iic_read( buf, 7) != 0)                    /* read data */
        {
            
            
            
        }
        if (a_aht20_calc_crc(buf, 6) != buf[6])                       /* check the crc */
        {
            
            
            
        }
        
        *temperature_raw = (((uint32_t)buf[3]) << 16) |
                           (((uint32_t)buf[4]) << 8) |
                           (((uint32_t)buf[5]) << 0);                 /* set the temperature */
        *temperature_raw = (*temperature_raw) & 0xFFFFF;              /* cut the temperature part */
        *temperature_s = (float)(*temperature_raw) 
                                 / 1048576.0f * 200.0f
                                 - 50.0f;                             /* right shift 4 */
        
        return 0;                                                     /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t aht20_read_humidity(aht20_handle_t *handle, uint32_t *humidity_raw, uint8_t *humidity_s)
{
    uint8_t status;
    uint8_t buf[7];
    
    {
        
    }
    
    {
        
    }
    buf[0] = 0xAC;                                                    /* set the addr */
    buf[1] = 0x33;                                                    /* set 0x33 */
    buf[2] = 0x00;                                                    /* set 0x00 */
    if (a_aht20_iic_write( buf, 3) != 0)                       /* write the command */
    {
        
        
        
    }
    delay_ms(85);                                             /* delay 85ms */
    if (a_aht20_iic_read( &status, 1) != 0)                    /* read the status */
    {
        
        
        
    }
    if ((status & 0x80) == 0)                                         /* check the status */
    {
        if (a_aht20_iic_read( buf, 7) != 0)                    /* read data */
        {
            
            
            
        }
        if (a_aht20_calc_crc(buf, 6) != buf[6])                       /* check the crc */
        {
            
            
            
        }
        
        *humidity_raw = (((uint32_t)buf[1]) << 16) |
                        (((uint32_t)buf[2]) << 8) |
                        (((uint32_t)buf[3]) << 0);                    /* set the humidity */
        *humidity_raw = (*humidity_raw) >> 4;                         /* right shift 4 */
        *humidity_s = (uint8_t)((float)(*humidity_raw)
                                / 1048576.0f * 100.0f);               /* convert the humidity */
        
        return 0;                                                     /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t aht20_set_reg(aht20_handle_t *handle, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    } 
    if (a_aht20_iic_write( buf, len) != 0)        /* write data */
    {
        
    }
    else
    {
        return 0;                                        /* success return 0 */
    }
}
uint8_t aht20_get_reg(aht20_handle_t *handle, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    } 
    if (a_aht20_iic_read( buf, len) != 0)        /* read data */
    {
        
    }
    else
    {
        return 0;                                       /* success return 0 */
    }
}
uint8_t aht20_info(aht20_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(aht20_info_t));                          /* initialize aht20 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
