
#ifndef DRIVER_AHT20_H
#define DRIVER_AHT20_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct aht20_handle_s {
    uint8_t inited;  // inited flag
} aht20_handle_t;

uint8_t aht20_info(aht20_info_t* info);
uint8_t aht20_init(aht20_handle_t* handle);
uint8_t aht20_deinit(aht20_handle_t* handle);
uint8_t aht20_read_temperature_humidity(aht20_handle_t* handle, uint32_t* temperature_raw, float* temperature_s, uint32_t* humidity_raw, uint8_t* humidity_s);
uint8_t aht20_read_temperature(aht20_handle_t* handle, uint32_t* temperature_raw, float* temperature_s);
uint8_t aht20_read_humidity(aht20_handle_t* handle, uint32_t* humidity_raw, uint8_t* humidity_s);
uint8_t aht20_set_reg(aht20_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t aht20_get_reg(aht20_handle_t* handle, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
