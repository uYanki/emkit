
#ifndef DRIVER_HMC5883L_READ_TEST_H
#define DRIVER_HMC5883L_READ_TEST_H
#include "driver_hmc5883l_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t hmc5883l_read_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
