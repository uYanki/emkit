
#include "driver_hmc5883l.h"

#define MANUFACTURER_NAME  "Honeywell"          // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.16f                // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f                 // chip max supply voltage




#define HMC5883_ADDRESS 0x3C // iic address
#define HMC5883_REG_CRA    0x00 // cra register
#define HMC5883_REG_CRB    0x01 // crb register
#define HMC5883_REG_MODE   0x02 // mode register
#define HMC5883_REG_OUTXM  0x03 // outxm register
#define HMC5883_REG_OUTXL  0x04 // outxl register
#define HMC5883_REG_OUTYM  0x07 // outym register
#define HMC5883_REG_OUTYL  0x08 // outyl register
#define HMC5883_REG_OUTZM  0x05 // outzm register
#define HMC5883_REG_OUTZL  0x06 // outzl register
#define HMC5883_REG_STATUS 0x09 // status register
#define HMC5883_REG_IDA    0x0A // ida register
#define HMC5883_REG_IDB    0x0B // idb register
#define HMC5883_REG_IDC    0x0C // idc register
static uint8_t a_hmc5883l_test(hmc5883l_handle_t* handle)
{
    uint8_t reg, times, status;
    uint8_t buf[6];
    int16_t data;
    reg = 0x71;                                                                      /* set 0x71 */
    if (iic_write(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&reg, 1) != 0) /* write cra reg */
    {
        
        
    }
    reg = 0xA0;                                                                      /* set 0xA0 */
    if (iic_write(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&reg, 1) != 0) /* write crb reg */
    {
        
        
    }
    reg = 0x00;                                                                       /* set 0x00 */
    if (iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&reg, 1) != 0) /* write mode reg */
    {
        
        
    }
    delay_ms(100); /* wait 100 ms */
    times = 15;            /* set try 15 times */
    while (times != 0) /* check the times */
    {
        if (iic_read(HMC5883_ADDRESS, HMC5883_REG_STATUS,
                             (uint8_t*)&status, 1) != 0) /* read status */
        {
            
            return 1; /* return errror */
        }
        status = status & 0x01; /* get status bit */
        if (status == 0)        /* check status */
        {
            times--; /* times-- */
        } else {
            break; /* break */
        }
    }
    if (times == 0) /* if timeout */
    {
        
        
    }
    if (iic_read(HMC5883_ADDRESS, HMC5883_REG_OUTXM, (uint8_t*)buf, 6) != 0) /* read raw data */
    {
        
        
    }
    data = (int16_t)(((uint16_t)buf[0] << 8) | buf[1]); /* get x data */
    if ((data <= 243) || (data > 575))                  /* check x data */
    {
        
        
    }
    data = (int16_t)(((uint16_t)buf[2] << 8) | buf[3]); /* get y data */
    if ((data <= 243) || (data > 575))                  /* check y data */
    {
        
        
    }
    data = (int16_t)(((uint16_t)buf[4] << 8) | buf[5]); /* get z data */
    if ((data <= 243) || (data > 575))                  /* check z data */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t hmc5883l_init(hmc5883l_handle_t* handle)
{
    uint8_t id;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    if (iic_read(HMC5883_ADDRESS, HMC5883_REG_IDA, (uint8_t*)&id, 1) != 0) /* read ida failed */
    {
        
        
        
    }
    if (id != 'H') /* check id a */
    {
        
        
        
    }
    if (iic_read(HMC5883_ADDRESS, HMC5883_REG_IDB, (uint8_t*)&id, 1) != 0) /* read idb failed */
    {
        
        
        
    }
    if (id != '4') /* check id b */
    {
        
        (void)iic_deinit();                            /* iid deinit */
        
    }
    if (iic_read(HMC5883_ADDRESS, HMC5883_REG_IDC, (uint8_t*)&id, 1) != 0) /* read idc */
    {
        
        
        
    }
    if (id != '3') /* check id c */
    {
        
        
        
    }
    if (a_hmc5883l_test(handle) != 0) /* run test */
    {
        
        
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_deinit(hmc5883l_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C);                                                                /* clear mode */
    prev &= ~(0x03);                                                                /* clear config */
    prev |= 0x02;                                                                   /* set config */
    res = iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write mode config */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    if (iic_deinit() != 0) /* iic deinit */
    {
        
        return 2; /* iic deinit failed */
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_set_average_sample( hmc5883l_average_sample_t average_sample)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 7);           /* clear cra 7 */
    prev &= ~(3 << 5);           /* clear config */
    prev |= average_sample << 5; /* set config */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* write cra config */
}
uint8_t hmc5883l_get_average_sample( hmc5883l_average_sample_t* average_sample)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= (3 << 5);                                         /* get raw reg */
    *average_sample = (hmc5883l_average_sample_t)(prev >> 5); /* get config */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_set_data_output_rate( hmc5883l_data_output_rate_t data_rate)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 7);      /* clear cra 7 */
    prev &= ~(7 << 2);      /* clear config */
    prev |= data_rate << 2; /* set config */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* write cra config */
}
uint8_t hmc5883l_get_data_output_rate( hmc5883l_data_output_rate_t* data_rate)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= (7 << 2);                                      /* get raw reg */
    *data_rate = (hmc5883l_data_output_rate_t)(prev >> 2); /* get config */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_set_mode( hmc5883l_mode_t mode)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 7); /* clear cra 7 */
    prev &= ~(3 << 0); /* clear config */
    prev |= mode << 0; /* set config */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* write cra config */
}
uint8_t hmc5883l_get_mode( hmc5883l_mode_t* mode)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRA, (uint8_t*)&prev, 1); /* read cra config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= 3 << 0;                       /* get raw reg */
    *mode = (hmc5883l_mode_t)(prev >> 0); /* get config */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_set_gain( hmc5883l_gain_t gain)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(0x1F);   /* clear crb */
    prev &= ~(7 << 5); /* clear config */
    prev |= gain << 5; /* set gain */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&prev, 1); /* write config */
}
uint8_t hmc5883l_get_gain( hmc5883l_gain_t* gain)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= (7 << 5);                     /* get raw reg */
    *gain = (hmc5883l_gain_t)(prev >> 5); /* get config */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_enable_high_speed_iic(hmc5883l_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        return 3; /* return eror */
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C);  /* clear mode bit */
    prev |= (1 << 7); /* enable high speed iic */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t hmc5883l_disable_high_speed_iic(hmc5883l_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C);   /* clear mode bit */
    prev &= ~(1 << 7); /* disable high speed iic */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t hmc5883l_single_read( int16_t raw[3], float m_gauss[3])
{
    uint8_t  res, gain, status, prev;
    uint16_t num = 5000;
    uint8_t  buf[6];
    float    resolution;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C);                                                                /* clear mode bits */
    prev &= ~(0x03);                                                                /* clear config */
    prev |= 0x01;                                                                   /* set config */
    res = iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write mode regsiter */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&gain, 1); /* read crb register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    gain = gain >> 5; /* set gain */
    switch (gain)     /* choose resolution */
    {                 /* check gain */
        case 0x00: {
            resolution = 0.73f; /* set resolution */
            break; /* break */
        }
        case 0x01: {
            resolution = 0.92f; /* set resolution */
            break; /* break */
        }
        case 0x02: {
            resolution = 1.22f; /* set resolution 1.22 */
            break; /* break */
        }
        case 0x03: {
            resolution = 1.52f; /* set resolution 1.52 */
            break; /* break */
        }
        case 0x04: {
            resolution = 2.27f; /* set resolution 2.27 */
            break; /* break */
        }
        case 0x05: {
            resolution = 2.56f; /* set resolution 2.56 */
            break; /* break */
        }
        case 0x06: {
            resolution = 3.03f; /* set resolution 3.03 */
            break; /* break */
        }
        case 0x07: {
            resolution = 4.35f; /* set resolution 4.35 */
            break; /* break */
        }
        default: /* unknow code */
        {
            resolution = 0.00f; /* set resolution 0.00 */
            break; /* break */
        }
    }
    while (num != 0) /* check num */
    {
        res = iic_read(HMC5883_ADDRESS, HMC5883_REG_STATUS, (uint8_t*)&status, 1); /* read status register */
        if (res != 0)                                                                      /* check result */
        {
            
            
        }
        if ((status & 0x01) != 0) /* check status */
        {
            break; /* break loop */
        }
        delay_ms(10); /* check 10 ms */
        num--;                /* retry times-- */
        if (num == 0)         /* if timeout */
        {
            
            
        }
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_OUTXM, (uint8_t*)buf, 6); /* read raw data */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    raw[0]     = (int16_t)(((uint16_t)buf[0] << 8) | buf[1]); /* get x raw */
    raw[1]     = (int16_t)(((uint16_t)buf[2] << 8) | buf[3]); /* get y raw */
    raw[2]     = (int16_t)(((uint16_t)buf[4] << 8) | buf[5]); /* get z raw */
    m_gauss[0] = (float)(raw[0]) * resolution;                /* calculate x */
    m_gauss[1] = (float)(raw[1]) * resolution;                /* calculate y */
    m_gauss[2] = (float)(raw[2]) * resolution;                /* calculate z */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_start_continuous_read(hmc5883l_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C); /* clear mode bits */
    prev &= ~(0x03); /* clear config */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t hmc5883l_stop_continuous_read(hmc5883l_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* read mode register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    prev &= ~(0x7C); /* clear mode bits */
    prev &= ~(0x03); /* clear config */
    prev |= 1 << 1;  /* set config */
    return iic_write(HMC5883_ADDRESS, HMC5883_REG_MODE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t hmc5883l_continuous_read( int16_t raw[3], float m_gauss[3])
{
    uint8_t  res, gain, status;
    uint16_t num = 5000;
    uint8_t  buf[6];
    float    resolution;
    {
        
    }
    {
        
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_CRB, (uint8_t*)&gain, 1); /* read crb register failed */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    gain = gain >> 5; /* set gain */
    switch (gain)     /* choose resolution */
    {
        case 0x00: {
            resolution = 0.73f; /* set resolution 0.73 */
            break; /* break */
        }
        case 0x01: {
            resolution = 0.92f; /* set resolution 0.92 */
            break; /* break */
        }
        case 0x02: {
            resolution = 1.22f; /* set resolution 1.22 */
            break; /* break */
        }
        case 0x03: {
            resolution = 1.52f; /* set resolution 1.52 */
            break; /* break */
        }
        case 0x04: {
            resolution = 2.27f; /* set resolution 2.27 */
            break; /* break */
        }
        case 0x05: {
            resolution = 2.56f; /* set resolution 2.56 */
            break; /* break */
        }
        case 0x06: {
            resolution = 3.03f; /* set resolution 3.03 */
            break; /* break */
        }
        case 0x07: {
            resolution = 4.35f; /* set resolution 4.35 */
            break; /* break */
        }
        default: /* unknow code */
        {
            resolution = 0.00f; /* set resolution 0.00 */
            break; /* break */
        }
    }
    while (num != 0) /* check num */
    {
        res = iic_read(HMC5883_ADDRESS, HMC5883_REG_STATUS, (uint8_t*)&status, 1); /* read status register */
        if (res != 0)                                                                      /* check result */
        {
            
            
        }
        if ((status & 0x01) != 0) /* check status */
        {
            break; /* break loop */
        }
        delay_ms(10); /* check 10 ms */
        num--;
        if (num == 0) /* if timeout */
        {
            
            
        }
    }
    res = iic_read(HMC5883_ADDRESS, HMC5883_REG_OUTXM, (uint8_t*)buf, 6); /* read raw data */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    raw[0]     = (int16_t)(((uint16_t)buf[0] << 8) | buf[1]); /* get x raw */
    raw[1]     = (int16_t)(((uint16_t)buf[2] << 8) | buf[3]); /* get y raw */
    raw[2]     = (int16_t)(((uint16_t)buf[4] << 8) | buf[5]); /* get z raw */
    m_gauss[0] = (float)(raw[0]) * resolution;                /* calculate x */
    m_gauss[1] = (float)(raw[1]) * resolution;                /* calculate y */
    m_gauss[2] = (float)(raw[2]) * resolution;                /* calculate z */
    return 0; /* success return 0 */
}
uint8_t hmc5883l_set_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return iic_write(HMC5883_ADDRESS, reg, buf, len); /* write data */
}
uint8_t hmc5883l_get_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return iic_read(HMC5883_ADDRESS, reg, buf, len); /* read data */
}
uint8_t hmc5883l_info(hmc5883l_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(hmc5883l_info_t));                /* initialize hmc5883l info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
