
#ifndef DRIVER_HMC5883L_H
#define DRIVER_HMC5883L_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    HMC5883L_AVERAGE_SAMPLE_1 = 0x00,  // average sample 1
    HMC5883L_AVERAGE_SAMPLE_2 = 0x01,  // average sample 2
    HMC5883L_AVERAGE_SAMPLE_4 = 0x02,  // average sample 4
    HMC5883L_AVERAGE_SAMPLE_8 = 0x03,  // average sample 8
} hmc5883l_average_sample_t;
typedef enum {
    HMC5883L_DATA_OUTPUT_RATE_0P75 = 0x00,  // 0.75Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_1P5  = 0x01,  // 1.5Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_3    = 0x02,  // 3Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_7P5  = 0x03,  // 7.5Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_15   = 0x04,  // 15Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_30   = 0x05,  // 30Hz output rate
    HMC5883L_DATA_OUTPUT_RATE_75   = 0x06,  // 75Hz output rate
} hmc5883l_data_output_rate_t;
typedef enum {
    HMC5883L_MODE_NORMAL        = 0x00,  // normal mode
    HMC5883L_MODE_POSITIVE_BIAS = 0x01,  // positive bias mode
    HMC5883L_MODE_NEGATIVE_BIAS = 0x02,  // negative bias mode
} hmc5883l_mode_t;
typedef enum {
    HMC5883L_GAIN_1370 = 0x00,  // gain 1370
    HMC5883L_GAIN_1090 = 0x01,  // gain 1090
    HMC5883L_GAIN_820  = 0x02,  // gain 820
    HMC5883L_GAIN_660  = 0x03,  // gain 660
    HMC5883L_GAIN_440  = 0x04,  // gain 440
    HMC5883L_GAIN_390  = 0x05,  // gain 390
    HMC5883L_GAIN_330  = 0x06,  // gain 330
    HMC5883L_GAIN_230  = 0x07,  // gain 230
} hmc5883l_gain_t;
typedef struct hmc5883l_handle_s {
    uint8_t inited;  // inited flag
} hmc5883l_handle_t;

uint8_t hmc5883l_info(hmc5883l_info_t* info);
uint8_t hmc5883l_init(hmc5883l_handle_t* handle);
uint8_t hmc5883l_deinit(hmc5883l_handle_t* handle);
uint8_t hmc5883l_single_read(hmc5883l_handle_t* handle, int16_t raw[3], float m_gauss[3]);
uint8_t hmc5883l_start_continuous_read(hmc5883l_handle_t* handle);
uint8_t hmc5883l_stop_continuous_read(hmc5883l_handle_t* handle);
uint8_t hmc5883l_continuous_read(hmc5883l_handle_t* handle, int16_t raw[3], float m_gauss[3]);
uint8_t hmc5883l_set_average_sample(hmc5883l_handle_t* handle, hmc5883l_average_sample_t average_sample);
uint8_t hmc5883l_get_average_sample(hmc5883l_handle_t* handle, hmc5883l_average_sample_t* average_sample);
uint8_t hmc5883l_set_data_output_rate(hmc5883l_handle_t* handle, hmc5883l_data_output_rate_t data_rate);
uint8_t hmc5883l_get_data_output_rate(hmc5883l_handle_t* handle, hmc5883l_data_output_rate_t* data_rate);
uint8_t hmc5883l_set_mode(hmc5883l_handle_t* handle, hmc5883l_mode_t mode);
uint8_t hmc5883l_get_mode(hmc5883l_handle_t* handle, hmc5883l_mode_t* mode);
uint8_t hmc5883l_set_gain(hmc5883l_handle_t* handle, hmc5883l_gain_t gain);
uint8_t hmc5883l_get_gain(hmc5883l_handle_t* handle, hmc5883l_gain_t* gain);
uint8_t hmc5883l_enable_high_speed_iic(hmc5883l_handle_t* handle);
uint8_t hmc5883l_disable_high_speed_iic(hmc5883l_handle_t* handle);
uint8_t hmc5883l_set_reg(hmc5883l_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t hmc5883l_get_reg(hmc5883l_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);

#ifdef __cplusplus
}
#endif
#endif
