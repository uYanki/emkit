
#ifndef DRIVER_HMC5883L_BASIC_H
#define DRIVER_HMC5883L_BASIC_H
#include "driver_hmc5883l_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define HMC5883L_BASIC_DEFAULT_AVERAGE_SAMPLE   HMC5883L_AVERAGE_SAMPLE_8           // average 8 sample 
#define HMC5883L_BASIC_DEFAULT_DATA_OUTPUT_RATE HMC5883L_DATA_OUTPUT_RATE_15        // 15Hz output rate 
#define HMC5883L_BASIC_DEFAULT_MODE             HMC5883L_MODE_NORMAL                // normal mode 
#define HMC5883L_BASIC_DEFAULT_GAIN             HMC5883L_GAIN_820                   // gain 820 
uint8_t hmc5883l_basic_init(void);
uint8_t hmc5883l_basic_deinit(void);
uint8_t hmc5883l_basic_read(float m_gauss[3]);
#ifdef __cplusplus
}
#endif
#endif
