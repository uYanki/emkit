
#ifndef DRIVER_DS3231_READWRITE_TEST_H
#define DRIVER_DS3231_READWRITE_TEST_H
#include "driver_ds3231_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds3231_readwrite_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
