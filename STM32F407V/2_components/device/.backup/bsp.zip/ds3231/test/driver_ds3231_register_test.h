
#ifndef DRIVER_DS3231_REGISTER_TEST_H
#define DRIVER_DS3231_REGISTER_TEST_H
#include "driver_ds3231_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds3231_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
