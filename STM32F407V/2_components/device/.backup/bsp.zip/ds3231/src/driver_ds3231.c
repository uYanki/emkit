
#include "driver_ds3231.h"

#define MANUFACTURER_NAME        "Maxim Integrated"         // manufacturer name
#define SUPPLY_VOLTAGE_MIN       2.3f                       // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX       5.5f                       // chip max supply voltage




#define DS3231_REG_SECOND        0x00                       // second register
#define DS3231_REG_MINUTE        0x01                       // minute register
#define DS3231_REG_HOUR          0x02                       // hour register
#define DS3231_REG_WEEK          0x03                       // week register
#define DS3231_REG_DATE          0x04                       // date register
#define DS3231_REG_MONTH         0x05                       // month register
#define DS3231_REG_YEAR          0x06                       // year register
#define DS3231_REG_ALARM1_SECOND 0x07                       // alarm1 second register
#define DS3231_REG_ALARM1_MINUTE 0x08                       // alarm1 minute register
#define DS3231_REG_ALARM1_HOUR   0x09                       // alarm1 hour register
#define DS3231_REG_ALARM1_WEEK   0x0A                       // alarm1 week register
#define DS3231_REG_ALARM2_MINUTE 0x0B                       // alarm2 minute register
#define DS3231_REG_ALARM2_HOUR   0x0C                       // alarm2 hour register
#define DS3231_REG_ALARM2_WEEK   0x0D                       // alarm2 week register
#define DS3231_REG_CONTROL       0x0E                       // control register
#define DS3231_REG_STATUS        0x0F                       // status register
#define DS3231_REG_XTAL          0x10                       // xtal register
#define DS3231_REG_TEMPERATUREH  0x11                       // temperature high register
#define DS3231_REG_TEMPERATUREL  0x12                       // temperature low register
#define DS3231_ADDRESS           0xD0                       // iic device address
static uint8_t a_ds3231_iic_write( uint8_t reg, uint8_t data)
{
    if (iic_write(DS3231_ADDRESS, reg, &data, 1) != 0) /* write data */
 else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_ds3231_iic_multiple_read( uint8_t reg, uint8_t* buf, uint8_t len)
{
    if (iic_read(DS3231_ADDRESS, reg, buf, len) != 0) /* read data */
 else { /* success return 0 */
        return 0;
    }
}
static uint8_t a_ds3231_hex2bcd(uint8_t val)
{
    uint8_t i, j, k;
    i = val / 10;     /* get tens place */
    j = val % 10;     /* get ones place */
    k = j + (i << 4); /* set bcd */
    return k;         /* return bcd */
}
static uint8_t a_ds3231_bcd2hex(uint8_t val)
{
    uint8_t temp;
    temp = val & 0x0F;        /* get ones place */
    val  = (val >> 4) & 0x0F; /* get tens place */
    val  = val * 10;          /* set tens place */
    temp = temp + val;        /* get hex */
    return temp;              /* return hex */
}
uint8_t ds3231_set_time( ds3231_time_t* t)
{
    uint8_t  res;
    uint8_t  reg;
    uint8_t  century;
    uint16_t year;

    if (t == NULL) /* check time */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        if ((t->year < 1990) || (t->year > 2190)) /* check year */
        {
            
        }
        if ((t->month == 0) || (t->month > 12)) /* check month */
        {
            
        }
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if ((t->hour < 1) || (t->hour > 12)) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
        if (t->second > 59) /* check second */
        {
            
        }
    } else if (t->format == DS3231_FORMAT_24H) /* if 24H */
    {
        if ((t->year < 1990) || (t->year > 2190)) /* check year */
        {
            
        }
        if ((t->month == 0) || (t->month > 12)) /* check month */
        {
            
        }
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if (t->hour > 23) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
        if (t->second > 59) /* check second */
        {
            
        }
    } else {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_SECOND, a_ds3231_hex2bcd(t->second)); /* write second */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_MINUTE, a_ds3231_hex2bcd(t->minute)); /* write minute */
    if (res != 0)                                                                     /* check reuslt */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        reg = (uint8_t)((1 << 6) | (t->am_pm << 5) | a_ds3231_hex2bcd(t->hour)); /* set hour in 12H */
    } else                                                                       /* if 24H */
    {
        reg = (0 << 6) | a_ds3231_hex2bcd(t->hour); /* set hour in 24H */
    }
    res = a_ds3231_iic_write( DS3231_REG_HOUR, reg); /* write hour */
    if (res != 0)                                           /* check result */
    {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_WEEK, a_ds3231_hex2bcd(t->week)); /* write week */
    if (res != 0)                                                                 /* check result */
    {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_DATE, a_ds3231_hex2bcd(t->date)); /* write data */
    if (res != 0)                                                                 /* check result */
    {
        
    }
    year = t->year - 1990; /* year -1990 */
    if (year >= 100)       /* check year */
    {
        century = 1; /* set century */
        year -= 100; /* year -= 100 */
    } else {
        century = 0; /* set century 0 */
    }
    res = a_ds3231_iic_write( DS3231_REG_MONTH, a_ds3231_hex2bcd(t->month) | (century << 7)); /* write month and century */
    if (res != 0)                                                                                    /* check result */
    {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_YEAR, a_ds3231_hex2bcd((uint8_t)year)); /* write year */
    if (res != 0)                                                                       /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_time( ds3231_time_t* t)
{
    uint8_t res;
    uint8_t buf[7];

    if (t == NULL) /* check time */
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 7);                                           /* clear the buffer */
    res = a_ds3231_iic_multiple_read( DS3231_REG_SECOND, (uint8_t*)buf, 7); /* multiple_read */
    if (res != 0)                                                                  /* check result */
    {
        
    }
    t->year   = a_ds3231_bcd2hex(buf[6]) + 1990 + ((buf[5] >> 7) & 0x01) * 100; /* get year */
    t->month  = a_ds3231_bcd2hex(buf[5] & 0x1F);                                /* get month */
    t->week   = a_ds3231_bcd2hex(buf[3]);                                       /* get week */
    t->date   = a_ds3231_bcd2hex(buf[4]);                                       /* get date */
    t->am_pm  = (ds3231_am_pm_t)((buf[2] >> 5) & 0x01);                         /* get am pm */
    t->format = (ds3231_format_t)((buf[2] >> 6) & 0x01);                        /* get format */
    if (t->format == DS3231_FORMAT_12H)                                         /* if 12H */
    {
        t->hour = a_ds3231_bcd2hex(buf[2] & 0x1F); /* get hour */
    } else {
        t->hour = a_ds3231_bcd2hex(buf[2] & 0x3F); /* get hour */
    }
    t->minute = a_ds3231_bcd2hex(buf[1]); /* get minute */
    t->second = a_ds3231_bcd2hex(buf[0]); /* get second */
    return 0;                             /* success return 0 */
}
uint8_t ds3231_set_alarm1( ds3231_time_t* t, ds3231_alarm1_mode_t mode)
{
    uint8_t res;
    uint8_t reg;

    if (t == NULL) /* check time */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if ((t->hour < 1) || (t->hour > 12)) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
        if (t->second > 59) /* check second  */
        {
            
        }
    } else if (t->format == DS3231_FORMAT_24H) /* if 24H */
    {
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if (t->hour > 23) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
        if (t->second > 59) /* check second */
        {
            
        }
    } else {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM1_SECOND, a_ds3231_hex2bcd(t->second) | ((mode & 0x01) << 7)); /* write second */
    if (res != 0)                                                                                                   /* check result */
    {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM1_MINUTE, a_ds3231_hex2bcd(t->minute) | (((mode >> 1) & 0x01) << 7)); /* write minute */
    if (res != 0)                                                                                                          /* check result */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        reg = (uint8_t)((((mode >> 2) & 0x01) << 7) | (1 << 6) | (t->am_pm << 5) | a_ds3231_hex2bcd(t->hour)); /* set hour in 12H */
    } else                                                                                                     /* if 24H */
    {
        reg = (((mode >> 2) & 0x01) << 7) | a_ds3231_hex2bcd(t->hour); /* set hour in 24H */
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM1_HOUR, reg); /* write hour */
    if (res != 0)                                                  /* check result */
    {
        
    }
    if (mode >= DS3231_ALARM1_MODE_WEEK_HOUR_MINUTE_SECOND_MATCH) /* if week */
    {
        reg = (((mode >> 3) & 0x01) << 7) | (1 << 6) | a_ds3231_hex2bcd(t->week); /* set data in week */
    } else                                                                        /* if day */
    {
        reg = (((mode >> 3) & 0x01) << 7) | a_ds3231_hex2bcd(t->date); /* set data in date */
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM1_WEEK, reg); /* write week */
    if (res != 0)                                                  /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_alarm1( ds3231_time_t* t, ds3231_alarm1_mode_t* mode)
{
    uint8_t res;
    uint8_t buf[4];

    if (t == NULL) /* check time */
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 4);                                                  /* clear the buffer */
    res = a_ds3231_iic_multiple_read( DS3231_REG_ALARM1_SECOND, (uint8_t*)buf, 4); /* multiple_read */
    if (res != 0)                                                                         /* check result */
    {
        
    }
    t->year  = 0;                    /* get year */
    t->month = 0;                    /* get month */
    if (((buf[3] >> 6) & 0x01) != 0) /* if week */
    {
        t->week = a_ds3231_bcd2hex(buf[3] & 0x0F); /* get week */
        t->date = 0;                               /* get data */
    } else                                         /* if data */
    {
        t->week = 0;                               /* get week */
        t->date = a_ds3231_bcd2hex(buf[3] & 0x3F); /* get data */
    }
    t->am_pm  = (ds3231_am_pm_t)((buf[2] >> 5) & 0x01);  /* get am pm */
    t->format = (ds3231_format_t)((buf[2] >> 6) & 0x01); /* get format */
    if (t->format == DS3231_FORMAT_12H)                  /* if 12H */
    {
        t->hour = a_ds3231_bcd2hex(buf[2] & 0x1F); /* get hour */
    } else                                         /* if 24H */
    {
        t->hour = a_ds3231_bcd2hex(buf[2] & 0x3F); /* get hour */
    }
    t->minute = a_ds3231_bcd2hex(buf[1] & 0x7F); /* get minute */
    t->second = a_ds3231_bcd2hex(buf[0] & 0x7F); /* get second */
    *mode     = (ds3231_alarm1_mode_t)(((buf[0] >> 7) & 0x01) << 0 | ((buf[1] >> 7) & 0x01) << 1 | ((buf[2] >> 7) & 0x01) << 2 | ((buf[3] >> 7) & 0x01) << 3 |
                                   ((buf[3] >> 6) & 0x01) << 4); /* get mode */
    return 0;                                                        /* success return 0 */
}
uint8_t ds3231_set_alarm2( ds3231_time_t* t, ds3231_alarm2_mode_t mode)
{
    uint8_t res;
    uint8_t reg;

    if (t == NULL) /* check time */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if ((t->hour < 1) || (t->hour > 12)) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
    } else if (t->format == DS3231_FORMAT_24H) /* if 24H */
    {
        if ((t->week == 0) || (t->week > 7)) /* check week */
        {
            
        }
        if ((t->date == 0) || (t->date > 31)) /* check data */
        {
            
        }
        if (t->hour > 23) /* check hour */
        {
            
        }
        if (t->minute > 59) /* check minute */
        {
            
        }
    } else {
        
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM2_MINUTE, a_ds3231_hex2bcd(t->minute) | (((mode >> 0) & 0x01) << 7)); /* write minute */
    if (res != 0)                                                                                                          /* check result */
    {
        
    }
    if (t->format == DS3231_FORMAT_12H) /* if 12H */
    {
        reg = (uint8_t)((((mode >> 1) & 0x01) << 7) | (1 << 6) | (t->am_pm << 5) | a_ds3231_hex2bcd(t->hour)); /* set hour in 12H */
    } else                                                                                                     /* if 24H */
    {
        reg = (((mode >> 1) & 0x01) << 7) | a_ds3231_hex2bcd(t->hour); /* set hour in 24H */
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM2_HOUR, reg); /* write hour */
    if (res != 0)                                                  /* check result */
    {
        
    }
    if (mode >= DS3231_ALARM1_MODE_WEEK_HOUR_MINUTE_SECOND_MATCH) /* if week */
    {
        reg = (((mode >> 2) & 0x01) << 7) | (1 << 6) | a_ds3231_hex2bcd(t->week); /* set data in week */
    } else                                                                        /* if day */
    {
        reg = (((mode >> 2) & 0x01) << 7) | a_ds3231_hex2bcd(t->date); /* set data in date */
    }
    res = a_ds3231_iic_write( DS3231_REG_ALARM2_WEEK, reg); /* write week */
    if (res != 0)                                                  /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_alarm2( ds3231_time_t* t, ds3231_alarm2_mode_t* mode)
{
    uint8_t res;
    uint8_t buf[3];

    if (t == NULL) /* check time */
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 3);                                                  /* clear the buffer */
    res = a_ds3231_iic_multiple_read( DS3231_REG_ALARM2_MINUTE, (uint8_t*)buf, 3); /* multiple read */
    if (res != 0)                                                                         /* check result */
    {
        
    }
    t->year  = 0;                    /* get year */
    t->month = 0;                    /* get month */
    if (((buf[2] >> 6) & 0x01) != 0) /* if week */
    {
        t->week = a_ds3231_bcd2hex(buf[2] & 0x0F); /* get week */
        t->date = 0;                               /* get data */
    } else                                         /* if data */
    {
        t->week = 0;                               /* get week */
        t->date = a_ds3231_bcd2hex(buf[2] & 0x3F); /* get data */
    }
    t->am_pm  = (ds3231_am_pm_t)((buf[1] >> 5) & 0x01);  /* get am pm */
    t->format = (ds3231_format_t)((buf[1] >> 6) & 0x01); /* get format */
    if (t->format == DS3231_FORMAT_12H)                  /* if 12H */
    {
        t->hour = a_ds3231_bcd2hex(buf[1] & 0x1F); /* get hour */
    } else                                         /* if 24H */
    {
        t->hour = a_ds3231_bcd2hex(buf[1] & 0x3F); /* get hour */
    }
    t->minute = a_ds3231_bcd2hex(buf[0] & 0x7F);                                                                                                               /* get minute */
    t->second = 0;                                                                                                                                             /* get second */
    *mode     = (ds3231_alarm2_mode_t)(((buf[0] >> 7) & 0x01) << 0 | ((buf[1] >> 7) & 0x01) << 1 | ((buf[2] >> 7) & 0x01) << 2 | ((buf[2] >> 6) & 0x01) << 4); /* get mode */
    return 0;                                                                                                                                                  /* success return 0 */
}
uint8_t ds3231_set_oscillator( ds3231_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << 7);                                          /* clear config */
    prev |= (!enable) << 7;                                     /* set enable */
    res = a_ds3231_iic_write( DS3231_REG_CONTROL, prev); /* write control */
    if (res != 0)                                               /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_oscillator( ds3231_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    *enable = (ds3231_bool_t)(!((prev >> 7) & 0x01)); /* get enable */
    return 0;                                         /* success return 0 */
}
uint8_t ds3231_set_alarm_interrupt( ds3231_alarm_t alarm, ds3231_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << alarm);                                      /* clear config */
    prev |= enable << alarm;                                    /* set enable */
    res = a_ds3231_iic_write( DS3231_REG_CONTROL, prev); /* write control */
    if (res != 0)                                               /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_alarm_interrupt( ds3231_alarm_t alarm, ds3231_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    *enable = (ds3231_bool_t)((prev >> alarm) & 0x01); /* get enable */
    return 0;                                          /* success return 0 */
}
uint8_t ds3231_set_pin( ds3231_pin_t pin)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << 2);                                          /* clear config */
    prev |= pin << 2;                                           /* set pin */
    res = a_ds3231_iic_write( DS3231_REG_CONTROL, prev); /* write control */
    if (res != 0)                                               /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_pin( ds3231_pin_t* pin)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    *pin = (ds3231_pin_t)((prev >> 2) & 0x01); /* get pin */
    return 0;                                  /* success return 0 */
}
uint8_t ds3231_set_square_wave( ds3231_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << 6);                                          /* clear config */
    prev |= enable << 6;                                        /* set enable */
    res = a_ds3231_iic_write( DS3231_REG_CONTROL, prev); /* write control */
    if (res != 0)                                               /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_square_wave( ds3231_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    *enable = (ds3231_bool_t)((prev >> 6) & 0x01); /* get enable */
    return 0;                                      /* success return 0 */
}
uint8_t ds3231_get_temperature( int16_t* raw, float* s)
{
    uint8_t  res;
    uint8_t  prev;
    uint32_t times;
    uint8_t  buf[2];

    memset(buf, 0, sizeof(uint8_t) * 2);                                              /* clear the buffer */
    res = a_ds3231_iic_multiple_read( DS3231_REG_CONTROL, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << 5);                                          /* clear config */
    prev |= 1 << 5;                                             /* set enable */
    res = a_ds3231_iic_write( DS3231_REG_CONTROL, prev); /* write control */
    if (res != 0)                                               /* check result */
    {
        
    }
    times = 500;       /* set 5s */
    while (times != 0) /* check times */
    {
        delay_ms(10);                                                            /* delay 10 ms */
        res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* read status */
        if (res != 0)                                                                    /* check result */
        {
            
        }
        if (((prev >> 2) & 0x01) == 0) /* check result */
        {
            break; /* break */
        }
        times--; /* times-- */
    }
    if (times == 0) /* if zero */
    {
        
    }
    res = a_ds3231_iic_multiple_read( DS3231_REG_TEMPERATUREH, (uint8_t*)buf, 2); /* read temperature */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    *raw = (int16_t)(((uint16_t)buf[0]) << 8) | buf[1]; /* set raw temperature */
    *raw = (*raw) >> 6;                                 /* right shift */
    if (((*raw) & 0x0200) != 0)                         /* set negtive value */
    {
        *raw = (*raw) | 0xFC00U; /* set negtive part */
    }
    *s = (float)(*raw) * 0.25f; /* set converted temperature */
    return 0;                   /* success return 0 */
}
uint8_t ds3231_get_status( uint8_t* status)
{
    uint8_t res;

    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)status, 1); /* multiple read */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_set_aging_offset( int8_t offset)
{
    uint8_t res;

    res = a_ds3231_iic_write( DS3231_REG_XTAL, offset); /* write offset */
    if (res != 0)                                              /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_aging_offset( int8_t* offset)
{
    uint8_t res;

    res = a_ds3231_iic_multiple_read( DS3231_REG_XTAL, (uint8_t*)offset, 1); /* read offset */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_aging_offset_convert_to_register( float offset, int8_t* reg)
{
  * reg = (int8_t)(offset / 0.12f); /* convert real data to register data */
    return 0;                              /* success return 0 */
}
uint8_t ds3231_aging_offset_convert_to_data( int8_t reg, float* offset)
{
  * offset = (float)(reg)*0.12f; /* convert raw data to real data */
    return 0;                           /* success return 0 */
}
uint8_t ds3231_irq_handler(ds3231_handle_t* handle)
{
    uint8_t res, prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                    /* check result */
    {
        
    }                                                         /* if oscillator stop */
    if ((prev & DS3231_STATUS_ALARM_2) != 0)                  /* if alarm 2 */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(DS3231_STATUS_ALARM_2); /* run callback */
        }
    }
    if ((prev & DS3231_STATUS_ALARM_1) != 0) /* if alarm 1 */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(DS3231_STATUS_ALARM_1); /* run callback */
        }
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_init(ds3231_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;

    if (debug_print == NULL) /* check debug_print */

    if (iic_init == NULL) /* check iic_init */
    {
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
    }
    if (receive_callback == NULL) /* check receive_callback */
    {
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
    }
    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* multiple_read */
    if (res != 0)                                                                    /* check result */
    {
        
        
    }
    prev &= ~(1 << 7);                                         /* clear config */
    res = a_ds3231_iic_write( DS3231_REG_STATUS, prev); /* write status */
    if (res != 0)                                              /* check result */
    {
        
        
    }
    inited = 1; /* flag finish initialization */
    return 0;           /* success return 0 */
}
uint8_t ds3231_deinit(ds3231_handle_t* handle)
{

    if (iic_deinit() != 0) /* iic deinit */
    {
        
    }
    inited = 0; /* flag close */
    return 0;           /* success return 0 */
}
uint8_t ds3231_alarm_clear( ds3231_alarm_t alarm)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* multiple_read  */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << alarm);                                     /* clear config */
    res = a_ds3231_iic_write( DS3231_REG_STATUS, prev); /* write status */
    if (res != 0)                                              /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_set_32khz_output( ds3231_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                         /* clear config */
    prev |= enable << 3;                                       /* set enable */
    res = a_ds3231_iic_write( DS3231_REG_STATUS, prev); /* write status */
    if (res != 0)                                              /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t ds3231_get_32khz_output( ds3231_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_ds3231_iic_multiple_read( DS3231_REG_STATUS, (uint8_t*)&prev, 1); /* multiple read */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    *enable = (ds3231_bool_t)((prev >> 3) & 0x01); /* get enable */
    return 0;                                      /* success return 0 */
}
uint8_t ds3231_info(ds3231_info_t* info)
{
    

    memset(info, 0, sizeof(ds3231_info_t));                  /* initialize ds3231 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0;                                                /* success return 0 */
}
