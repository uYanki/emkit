
#ifndef DRIVER_DS3231_H
#define DRIVER_DS3231_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    DS3231_BOOL_FALSE = 0x00,  // disable function
    DS3231_BOOL_TRUE  = 0x01,  // enable function
} ds3231_bool_t;
typedef enum {
    DS3231_ALARM_1 = 0x00,  // alarm 1
    DS3231_ALARM_2 = 0x01,  // alarm 2
} ds3231_alarm_t;
typedef enum {
    DS3231_AM = 0x00,  // am
    DS3231_PM = 0x01,  // pm
} ds3231_am_pm_t;
typedef enum {
    DS3231_PIN_SQUARE_WAVE = 0x00,  // square wave pin
    DS3231_PIN_INTERRUPT   = 0x01,  // interrupt pin
} ds3231_pin_t;
typedef enum {
    DS3231_FORMAT_12H = 0x01,  // 12h format
    DS3231_FORMAT_24H = 0x00,  // 24h format
} ds3231_format_t;
typedef enum {
    DS3231_STATUS_ALARM_2 = (1 << 1),  // alarm 2 status
    DS3231_STATUS_ALARM_1 = (1 << 0),  // alarm 1 status
} ds3231_status_t;
typedef enum {
    DS3231_ALARM1_MODE_ONCE_A_SECOND                 = 0x0F,  // interrupt once a second
    DS3231_ALARM1_MODE_SECOND_MATCH                  = 0x0E,  // interrupt second match
    DS3231_ALARM1_MODE_MINUTE_SECOND_MATCH           = 0x0C,  // interrupt minute second match
    DS3231_ALARM1_MODE_HOUR_MINUTE_SECOND_MATCH      = 0x08,  // interrupt hour minute second match
    DS3231_ALARM1_MODE_DATE_HOUR_MINUTE_SECOND_MATCH = 0x00,  // interrupt date hour minute second match
    DS3231_ALARM1_MODE_WEEK_HOUR_MINUTE_SECOND_MATCH = 0x10,  // interrupt week hour minute second match
} ds3231_alarm1_mode_t;
typedef enum {
    DS3231_ALARM2_MODE_ONCE_A_MINUTE          = 0x07,  // interrupt once a minute
    DS3231_ALARM2_MODE_MINUTE_MATCH           = 0x06,  // interrupt minute match
    DS3231_ALARM2_MODE_HOUR_MINUTE_MATCH      = 0x04,  // interrupt hour minute match
    DS3231_ALARM2_MODE_DATE_HOUR_MINUTE_MATCH = 0x00,  // interrupt data hour minute match
    DS3231_ALARM2_MODE_WEEK_HOUR_MINUTE_MATCH = 0x10,  // interrupt week hour minute match
} ds3231_alarm2_mode_t;
typedef struct ds3231_time_s {
    uint16_t        year;    // year
    uint8_t         month;   // month
    uint8_t         week;    // week
    uint8_t         date;    // date
    uint8_t         hour;    // hour
    uint8_t         minute;  // minute
    uint8_t         second;  // second
    ds3231_format_t format;  // data format
    ds3231_am_pm_t  am_pm;   // am pm
} ds3231_time_t;
typedef struct ds3231_handle_s {
    uint8_t inited;  // inited flag
} ds3231_handle_t;

uint8_t ds3231_info(ds3231_info_t* info);
uint8_t ds3231_init(ds3231_handle_t* handle);
uint8_t ds3231_deinit(ds3231_handle_t* handle);
uint8_t ds3231_irq_handler(ds3231_handle_t* handle);
uint8_t ds3231_set_time(ds3231_handle_t* handle, ds3231_time_t* t);
uint8_t ds3231_get_time(ds3231_handle_t* handle, ds3231_time_t* t);
uint8_t ds3231_set_oscillator(ds3231_handle_t* handle, ds3231_bool_t enable);
uint8_t ds3231_get_oscillator(ds3231_handle_t* handle, ds3231_bool_t* enable);
uint8_t ds3231_get_status(ds3231_handle_t* handle, uint8_t* status);
uint8_t ds3231_set_pin(ds3231_handle_t* handle, ds3231_pin_t pin);
uint8_t ds3231_get_pin(ds3231_handle_t* handle, ds3231_pin_t* pin);
uint8_t ds3231_set_square_wave(ds3231_handle_t* handle, ds3231_bool_t enable);
uint8_t ds3231_get_square_wave(ds3231_handle_t* handle, ds3231_bool_t* enable);
uint8_t ds3231_set_32khz_output(ds3231_handle_t* handle, ds3231_bool_t enable);
uint8_t ds3231_get_32khz_output(ds3231_handle_t* handle, ds3231_bool_t* enable);
uint8_t ds3231_get_temperature(ds3231_handle_t* handle, int16_t* raw, float* s);
uint8_t ds3231_set_aging_offset(ds3231_handle_t* handle, int8_t offset);
uint8_t ds3231_get_aging_offset(ds3231_handle_t* handle, int8_t* offset);
uint8_t ds3231_aging_offset_convert_to_register(ds3231_handle_t* handle, float offset, int8_t* reg);
uint8_t ds3231_aging_offset_convert_to_data(ds3231_handle_t* handle, int8_t reg, float* offset);
uint8_t ds3231_set_alarm_interrupt(ds3231_handle_t* handle, ds3231_alarm_t alarm, ds3231_bool_t enable);
uint8_t ds3231_get_alarm_interrupt(ds3231_handle_t* handle, ds3231_alarm_t alarm, ds3231_bool_t* enable);
uint8_t ds3231_set_alarm1(ds3231_handle_t* handle, ds3231_time_t* t, ds3231_alarm1_mode_t mode);
uint8_t ds3231_get_alarm1(ds3231_handle_t* handle, ds3231_time_t* t, ds3231_alarm1_mode_t* mode);
uint8_t ds3231_set_alarm2(ds3231_handle_t* handle, ds3231_time_t* t, ds3231_alarm2_mode_t mode);
uint8_t ds3231_get_alarm2(ds3231_handle_t* handle, ds3231_time_t* t, ds3231_alarm2_mode_t* mode);
uint8_t ds3231_alarm_clear(ds3231_handle_t* handle, ds3231_alarm_t alarm);
uint8_t ds3231_set_reg(ds3231_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t ds3231_get_reg(ds3231_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
