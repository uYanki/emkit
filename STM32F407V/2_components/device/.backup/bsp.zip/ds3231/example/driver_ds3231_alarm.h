
  
#ifndef DRIVER_DS3231_ALARM_H
#define DRIVER_DS3231_ALARM_H
#include "driver_ds3231_interface.h"
#include <time.h>
#ifdef __cplusplus
extern "C"{
#endif
#define DS3231_ALARM_DEFAULT_AGING_OFFSET        0        // 0 offset 
uint8_t ds3231_alarm_irq_handler(void);
uint8_t ds3231_alarm_init(void (*alarm_receive_callback)(uint8_t type));
uint8_t ds3231_alarm_deinit(void);
uint8_t ds3231_alarm_set_alarm1(ds3231_time_t *t, ds3231_alarm1_mode_t mode);
uint8_t ds3231_alarm_get_alarm1(ds3231_time_t *t, ds3231_alarm1_mode_t *mode);
uint8_t ds3231_alarm_set_alarm2(ds3231_time_t *t, ds3231_alarm2_mode_t mode);
uint8_t ds3231_alarm_get_alarm2(ds3231_time_t *t, ds3231_alarm2_mode_t *mode);
uint8_t ds3231_alarm_clear_flag(ds3231_alarm_t alarm);
uint8_t ds3231_alarm_enable(ds3231_alarm_t alarm);
uint8_t ds3231_alarm_disable(ds3231_alarm_t alarm);
uint8_t ds3231_alarm_set_time(ds3231_time_t *t);
uint8_t ds3231_alarm_get_time(ds3231_time_t *t);
uint8_t ds3231_alarm_set_timestamp(time_t timestamp);
uint8_t ds3231_alarm_get_timestamp(time_t *timestamp);
uint8_t ds3231_alarm_set_timestamp_time_zone(int8_t zone);
uint8_t ds3231_alarm_get_timestamp_time_zone(int8_t *zone);
uint8_t ds3231_alarm_get_temperature(int16_t *raw, float *s);
uint8_t ds3231_alarm_alarm_ascii_time(char *buf, uint8_t len);
#ifdef __cplusplus
}
#endif
#endif
