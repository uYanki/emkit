
  
#ifndef DRIVER_DS3231_BASIC_H
#define DRIVER_DS3231_BASIC_H
#include "driver_ds3231_interface.h"
#include <time.h>
#ifdef __cplusplus
extern "C"{
#endif
#define DS3231_BASIC_DEFAULT_AGING_OFFSET        0        // 0 offset 
uint8_t ds3231_basic_init(void);
uint8_t ds3231_basic_deinit(void);
uint8_t ds3231_basic_set_time(ds3231_time_t *t);
uint8_t ds3231_basic_get_time(ds3231_time_t *t);
uint8_t ds3231_basic_set_timestamp(time_t timestamp);
uint8_t ds3231_basic_get_timestamp(time_t *timestamp);
uint8_t ds3231_basic_set_timestamp_time_zone(int8_t zone);
uint8_t ds3231_basic_get_timestamp_time_zone(int8_t *zone);
uint8_t ds3231_basic_get_temperature(int16_t *raw, float *s);
uint8_t ds3231_basic_get_ascii_time(char *buf, uint8_t len);
#ifdef __cplusplus
}
#endif
#endif
