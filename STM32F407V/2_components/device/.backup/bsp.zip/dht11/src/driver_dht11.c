
#include "driver_dht11.h"

#define MANUFACTURER_NAME  "ASAIR"       // manufacturer name
#define SUPPLY_VOLTAGE_MIN 3.3f          // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.5f          // chip max supply voltage




static uint8_t a_dht11_reset(dht11_handle_t* handle)
{
    uint8_t retry = 0;
    uint8_t res;
    uint8_t value;
    res = bus_write(0); /* set low */
    if (res != 0)               /* check result */
    {
        
        
    }
    delay_ms(20);       /* wait 20ms */
    disable_irq();      /* disable interrupt */
    res = bus_write(1); /* set high */
    if (res != 0)               /* check result */
    {
        enable_irq();                                /* enable interrupt */
        
        
    }
    delay_us(30);                     /* wait 20-40us */
    res = bus_read((uint8_t*)&value); /* read 1 bit */
    if (res != 0)                             /* check reault */
    {
        enable_irq();                             /* enable interrupt */
        
        
    }
    while ((value != 0) && (retry < 100)) /* wait 40-80us */
    {
        res = bus_read((uint8_t*)&value); /* read 1 bit */
        if (res != 0)                             /* check result */
        {
            enable_irq();                             /* enable interrupt */
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* delay 1us */
    }
    if (retry >= 100) /* if retry times is over 100 times */
    {
        enable_irq();                             /* enable interrupt */
        
        
    } else {
        retry = 0; /* reset retry times */
    }
    res = bus_read((uint8_t*)&value); /* read 1 bit */
    if (res != 0)                             /* check result */
    {
        enable_irq();                             /* enable interrupt */
        
        
    }
    while ((!value) && (retry < 100)) /* wait for 40-80us */
    {
        res = bus_read((uint8_t*)&value); /* read 1 bit */
        if (res != 0)                             /* check result */
        {
            enable_irq();                             /* enable interrupt */
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* delay 1 us */
    }
    if (retry >= 100) /* if retry times is over 100 times */
    {
        enable_irq();                             /* enable interrupt */
        
        
    }
    enable_irq(); /* enable interrupt */
    return 0; /* success return 0 */
}
static uint8_t a_dht11_read_bit( uint8_t* value)
{
    uint8_t retry = 0;
    uint8_t res;
    res = bus_read((uint8_t*)value); /* read 1 bit */
    if (res != 0)                            /* check result */
    {
        
        
    }
    while (((*value) != 0) && (retry < 100)) /* wait 100us */
    {
        res = bus_read((uint8_t*)value); /* read 1 bit */
        if (res != 0)                            /* check result */
        {
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* delay 1 us */
    }
    retry = 0;                                 /* reset retry times */
    res   = bus_read((uint8_t*)value); /* read 1 bit */
    if (res != 0)                              /* check result */
    {
        
        
    }
    while ((!(*value)) && (retry < 100)) /* wait 100us */
    {
        res = bus_read((uint8_t*)value); /* read 1 bit */
        if (res != 0)                            /* check result */
        {
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* wait 1 us */
    }
    delay_us(40);                    /* wait 40us */
    res = bus_read((uint8_t*)value); /* read 1 bit */
    if (res != 0)                            /* check result */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_dht11_read_byte( uint8_t* byte)
{
    uint8_t i;
    uint8_t res;
    uint8_t value;
    *byte = 0;              /* set byte 0 */
    for (i = 0; i < 8; i++) /* read 8 bits */
    {
        *byte <<= 1;                                      /* left shift 1 bit */
        res = a_dht11_read_bit( (uint8_t*)&value); /* read 1 bit */
        if (res != 0)                                     /* check result */
        {
            
            
        }
        *byte |= value; /* set LSB */
    }
    return 0; /* success return 0 */
}
uint8_t dht11_read_humidity( uint16_t* raw, uint8_t* s)
{
    uint8_t buf[5];
    uint8_t i;
    {
        
    }
    {
        
    }
    if (a_dht11_reset(handle) == 0) /* reset the chip */
    {
        disable_irq();  /* disable interrupt */
        for (i = 0; i < 5; i++) /* read 5 bytes */
        {
            if (a_dht11_read_byte( (uint8_t*)&buf[i]) != 0) /* read each byte */
            {
                enable_irq();                              /* enable interrupt */
                
                
            }
        }
        enable_irq();                              /* enable interrupt */
        if ((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4]) /* calculate checksum */
        {
            *raw = (uint16_t)buf[0] << 8 | buf[1]; /* get raw data */
            *s   = buf[0];                         /* convert raw data to real data */
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else {
        
        
    }
}
uint8_t dht11_read_temperature_humidity( uint16_t* temperature_raw, float* temperature_s, uint16_t* humidity_raw, uint8_t* humidity_s)
{
    uint8_t buf[5];
    uint8_t i;
    {
        
    }
    {
        
    }
    if (a_dht11_reset(handle) == 0) /* reset the chip */
    {
        disable_irq();  /* disable interrupt */
        for (i = 0; i < 5; i++) /* read 5 bytes */
        {
            if (a_dht11_read_byte( (uint8_t*)&buf[i]) != 0) /* read each byte */
            {
                enable_irq();                              /* enable interrupt */
                
                
            }
        }
        enable_irq();                              /* enable interrupt */
        if ((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4]) /* calculate checksum */
        {
            if (buf[3] > 127) /* if temperature is below zero */
            {
                *temperature_raw = (uint16_t)buf[2] << 8 | buf[3]; /* get temperature raw data */
                *temperature_s   = (float)(-(buf[2] * 10 +
                                               buf[3] &
                                           ~(1 << 7))) /
                                 10.0f; /* convert temperature raw data to temperature real data */
            } else {
                *temperature_raw = (uint16_t)buf[2] << 8 | buf[3];        /* get temperature raw data */
                *temperature_s   = (float)(buf[2] * 10 + buf[3]) / 10.0f; /* convert temperature raw data to temperature real data */
            }
            *humidity_raw = (uint16_t)buf[0] << 8 | buf[1]; /* get humidity raw */
            *humidity_s   = buf[0];                         /* convert humidity raw data to real data */
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else {
        
        
    }
}
uint8_t dht11_read_temperature( uint16_t* raw, float* s)
{
    uint8_t buf[5];
    uint8_t i;
    {
        
    }
    {
        
    }
    if (a_dht11_reset(handle) == 0) /* reset the chip */
    {
        disable_irq();  /* disable interrupt */
        for (i = 0; i < 5; i++) /* read 5 bytes */
        {
            if (a_dht11_read_byte( (uint8_t*)&buf[i]) != 0) /* read each byte */
            {
                enable_irq();                              /* enable interrupt */
                
                
            }
        }
        enable_irq();                              /* enable interrupt */
        if ((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4]) /* calculate checksum */
        {
            if (buf[3] > 127) /* if temperature is below zero */
            {
                *raw = (uint16_t)buf[2] << 8 | buf[3];                       /* get temperature raw data */
                *s   = (float)(-(buf[2] * 10 + buf[3] & ~(1 << 7))) / 10.0f; /* convert temperature raw data to temperature real data */
            } else {
                *raw = (uint16_t)buf[2] << 8 | buf[3];        /* get temperature raw data */
                *s   = (float)(buf[2] * 10 + buf[3]) / 10.0f; /* convert temperature raw data to temperature real data */
            }
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else {
        
        
    }
}
uint8_t dht11_init(dht11_handle_t* handle)
{
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (bus_init == NULL) /* check bus_init */
    {
        
        
    }
    if (bus_deinit == NULL) /* check bus_deinit */
    {
        
        
    }
    if (bus_read == NULL) /* check bus_read */
    {
        
        
    }
    if (bus_write == NULL) /* check bus_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (delay_us == NULL) /* check delay_us */
    {
        
        
    }
    if (enable_irq == NULL) /* check enable_irq */
    {
        
        
    }
    if (disable_irq == NULL) /* check disable_irq */
    {
        
        
    }
    if (bus_init() != 0) /* initialize bus */
    {
        
        
    }
    if (a_dht11_reset(handle) != 0) /* reset the chip */
    {
        
        (void)bus_deinit();                    /* close bus */
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t dht11_deinit(dht11_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (bus_deinit() != 0) /* close bus */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t dht11_info(dht11_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(dht11_info_t));                   /* initialize dht11 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "GPIO", 8);                     /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
