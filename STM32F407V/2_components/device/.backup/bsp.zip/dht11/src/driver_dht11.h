
#ifndef DRIVER_DHT11_H
#define DRIVER_DHT11_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct dht11_handle_s {
    uint8_t inited;  // inited flag
} dht11_handle_t;

uint8_t dht11_info(dht11_info_t* info);
uint8_t dht11_init(dht11_handle_t* handle);
uint8_t dht11_deinit(dht11_handle_t* handle);
uint8_t dht11_read_temperature_humidity(dht11_handle_t* handle, uint16_t* temperature_raw, float* temperature_s, uint16_t* humidity_raw, uint8_t* humidity_s);
uint8_t dht11_read_humidity(dht11_handle_t* handle, uint16_t* raw, uint8_t* s);
uint8_t dht11_read_temperature(dht11_handle_t* handle, uint16_t* raw, float* s);
#ifdef __cplusplus
}
#endif
#endif
