
#ifndef DRIVER_DHT11_BASIC_H
#define DRIVER_DHT11_BASIC_H
#include "driver_dht11_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t dht11_basic_init(void);
uint8_t dht11_basic_deinit(void);
uint8_t dht11_basic_read(float *temperature, uint8_t *humidity);
#ifdef __cplusplus
}
#endif
#endif
