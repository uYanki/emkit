
#include "driver_dht11_basic.h"
static dht11_handle_t gs_handle;        // dht11 handle
uint8_t dht11_basic_init(void)
{
    uint8_t res;
    /* link interface function */
    DRIVER_DHT11_LINK_INIT(&gs_handle, dht11_handle_t);
    DRIVER_DHT11_LINK_BUS_INIT(&gs_handle, dht11_interface_init);
    DRIVER_DHT11_LINK_BUS_DEINIT(&gs_handle, dht11_interface_deinit);
    DRIVER_DHT11_LINK_BUS_READ(&gs_handle, dht11_interface_read);
    DRIVER_DHT11_LINK_BUS_WRITE(&gs_handle, dht11_interface_write);
    DRIVER_DHT11_LINK_DELAY_MS(&gs_handle, dht11_interface_delay_ms);
    DRIVER_DHT11_LINK_DELAY_US(&gs_handle, dht11_interface_delay_us);
    DRIVER_DHT11_LINK_ENABLE_IRQ(&gs_handle, dht11_interface_enable_irq);
    DRIVER_DHT11_LINK_DISABLE_IRQ(&gs_handle, dht11_interface_disable_irq);
    DRIVER_DHT11_LINK_DEBUG_PRINT(&gs_handle, dht11_interface_debug_print);
    /* dht11 init */
    res = dht11_init(&gs_handle);
    if (res != 0)
    {
        dht11_interface_debug_print("dht11: init failed.\n");
        
        return 1;
    }
    return 0;
}
uint8_t dht11_basic_read(float *temperature, uint8_t *humidity)
{
    uint16_t temperature_raw;
    uint16_t humidity_raw;
    /* read temperature and humidity */
    if (dht11_read_temperature_humidity(&gs_handle, (uint16_t *)&temperature_raw, temperature, 
                                       (uint16_t *)&humidity_raw, humidity) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t dht11_basic_deinit(void)
{
    /* deinit dht11 and close bus */
    if (dht11_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
