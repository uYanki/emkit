
#ifndef DRIVER_AS5600_REGISTER_TEST_H
#define DRIVER_AS5600_REGISTER_TEST_H
#include "driver_as5600_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t as5600_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
