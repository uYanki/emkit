
#ifndef DRIVER_AS5600_H
#define DRIVER_AS5600_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    AS5600_BOOL_FALSE = 0x00,  // disable
    AS5600_BOOL_TRUE  = 0x01,  // enable
} as5600_bool_t;
typedef enum {
    AS5600_POWER_MODE_NOM  = 0x00,  // normal
    AS5600_POWER_MODE_LPM1 = 0x01,  // low power 1
    AS5600_POWER_MODE_LPM2 = 0x02,  // low power 2
    AS5600_POWER_MODE_LPM3 = 0x03,  // low power 3
} as5600_power_mode_t;
typedef enum {
    AS5600_HYSTERESIS_OFF  = 0x00,  // off
    AS5600_HYSTERESIS_1LSB = 0x01,  // 1 lsb
    AS5600_HYSTERESIS_2LSB = 0x02,  // 2 lsb
    AS5600_HYSTERESIS_3LSB = 0x03,  // 3 lsb
} as5600_hysteresis_t;
typedef enum {
    AS5600_OUTPUT_STAGE_ANALOG_FULL    = 0x00,  // full range from 0% to 100% between gnd and vdd
    AS5600_OUTPUT_STAGE_ANALOG_REDUCED = 0x01,  // reduced range from 10% to 90% between gnd and vdd
    AS5600_OUTPUT_STAGE_PWM            = 0x02,  // digital pwm
} as5600_output_stage_t;
typedef enum {
    AS5600_PWM_FREQUENCY_115HZ = 0x00,  // 115Hz
    AS5600_PWM_FREQUENCY_230HZ = 0x01,  // 230Hz
    AS5600_PWM_FREQUENCY_460HZ = 0x02,  // 460Hz
    AS5600_PWM_FREQUENCY_920HZ = 0x03,  // 920Hz
} as5600_pwm_frequency_t;
typedef enum {
    AS5600_SLOW_FILTER_16X = 0x00,  // 16x
    AS5600_SLOW_FILTER_8X  = 0x01,  // 8x
    AS5600_SLOW_FILTER_4X  = 0x02,  // 4x
    AS5600_SLOW_FILTER_2X  = 0x03,  // 2x
} as5600_slow_filter_t;
typedef enum {
    AS5600_FAST_FILTER_THRESHOLD_SLOW_FILTER_ONLY = 0x00,  // slow filter only
    AS5600_FAST_FILTER_THRESHOLD_6LSB             = 0x01,  // 6 lsb
    AS5600_FAST_FILTER_THRESHOLD_7LSB             = 0x02,  // 7 lsb
    AS5600_FAST_FILTER_THRESHOLD_9LSB             = 0x03,  // 9 lsb
    AS5600_FAST_FILTER_THRESHOLD_10LSB            = 0x07,  // 10 lsb
    AS5600_FAST_FILTER_THRESHOLD_18LSB            = 0x04,  // 18 lsb
    AS5600_FAST_FILTER_THRESHOLD_21LSB            = 0x05,  // 21 lsb
    AS5600_FAST_FILTER_THRESHOLD_24LSB            = 0x06,  // 24 lsb
} as5600_fast_filter_threshold_t;
typedef enum {
    AS5600_STATUS_MD = (1 << 5),  // agc minimum gain overflow, magnet too strong
    AS5600_STATUS_ML = (1 << 4),  // agc maximum gain overflow, magnet too weak
    AS5600_STATUS_MH = (1 << 3),  // magnet was detected
} as5600_status_t;
typedef enum {
    AS5600_BURN_CMD1    = 0x01,  // load the actual otp content command 1
    AS5600_BURN_CMD2    = 0x11,  // load the actual otp content command 2
    AS5600_BURN_CMD3    = 0x10,  // load the actual otp content command 3
    AS5600_BURN_ANGLE   = 0x80,  // angle
    AS5600_BURN_SETTING = 0x40,  // setting
} as5600_burn_t;
typedef struct as5600_handle_s {
    uint8_t (*iic_init)(void);                                                    // point to an iic_init function address
    uint8_t (*iic_deinit)(void);                                                  // point to an iic_deinit function address
    uint8_t (*iic_read)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);   // point to an iic_read function address
    uint8_t (*iic_write)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);  // point to an iic_write function address
    void (*delay_ms)(uint32_t ms);                                                // point to a delay_ms function address
    void (*debug_print)(const char* const fmt, ...);                              // point to a debug_print function address
    uint8_t inited;                                                               // inited flag
} as5600_handle_t;
typedef struct as5600_info_s {
    char     chip_name[32];          // chip name
    char     manufacturer_name[32];  // manufacturer name
    char     interface[8];           // chip interface name
    float    supply_voltage_min_v;   // chip min supply voltage
    float    supply_voltage_max_v;   // chip max supply voltage
    float    max_current_ma;         // chip max current
    float    temperature_min;        // chip min operating temperature
    float    temperature_max;        // chip max operating temperature
    uint32_t driver_version;         // driver version
} as5600_info_t;
#define DRIVER_AS5600_LINK_INIT(HANDLE, STRUCTURE)  memset(HANDLE, 0, sizeof(STRUCTURE))
#define DRIVER_AS5600_LINK_IIC_INIT(HANDLE, FUC)    (HANDLE)->iic_init = FUC
#define DRIVER_AS5600_LINK_IIC_DEINIT(HANDLE, FUC)  (HANDLE)->iic_deinit = FUC
#define DRIVER_AS5600_LINK_IIC_READ(HANDLE, FUC)    (HANDLE)->iic_read = FUC
#define DRIVER_AS5600_LINK_IIC_WRITE(HANDLE, FUC)   (HANDLE)->iic_write = FUC
#define DRIVER_AS5600_LINK_DELAY_MS(HANDLE, FUC)    (HANDLE)->delay_ms = FUC
#define DRIVER_AS5600_LINK_DEBUG_PRINT(HANDLE, FUC) (HANDLE)->debug_print = FUC
uint8_t as5600_info(as5600_info_t* info);
uint8_t as5600_init(as5600_handle_t* handle);
uint8_t as5600_deinit(as5600_handle_t* handle);
uint8_t as5600_read(as5600_handle_t* handle, uint16_t* angle_raw, float* deg);
uint8_t as5600_angle_convert_to_register(as5600_handle_t* handle, float deg, uint16_t* reg);
uint8_t as5600_angle_convert_to_data(as5600_handle_t* handle, uint16_t reg, float* deg);
uint8_t as5600_set_start_position(as5600_handle_t* handle, uint16_t pos);
uint8_t as5600_get_start_position(as5600_handle_t* handle, uint16_t* pos);
uint8_t as5600_set_stop_position(as5600_handle_t* handle, uint16_t pos);
uint8_t as5600_get_stop_position(as5600_handle_t* handle, uint16_t* pos);
uint8_t as5600_set_max_angle(as5600_handle_t* handle, uint16_t ang);
uint8_t as5600_get_max_angle(as5600_handle_t* handle, uint16_t* ang);
uint8_t as5600_set_watch_dog(as5600_handle_t* handle, as5600_bool_t enable);
uint8_t as5600_get_watch_dog(as5600_handle_t* handle, as5600_bool_t* enable);
uint8_t as5600_set_fast_filter_threshold(as5600_handle_t* handle, as5600_fast_filter_threshold_t threshold);
uint8_t as5600_get_fast_filter_threshold(as5600_handle_t* handle, as5600_fast_filter_threshold_t* threshold);
uint8_t as5600_set_slow_filter(as5600_handle_t* handle, as5600_slow_filter_t filter);
uint8_t as5600_get_slow_filter(as5600_handle_t* handle, as5600_slow_filter_t* filter);
uint8_t as5600_set_pwm_frequency(as5600_handle_t* handle, as5600_pwm_frequency_t freq);
uint8_t as5600_get_pwm_frequency(as5600_handle_t* handle, as5600_pwm_frequency_t* freq);
uint8_t as5600_set_output_stage(as5600_handle_t* handle, as5600_output_stage_t stage);
uint8_t as5600_get_output_stage(as5600_handle_t* handle, as5600_output_stage_t* stage);
uint8_t as5600_set_hysteresis(as5600_handle_t* handle, as5600_hysteresis_t hysteresis);
uint8_t as5600_get_hysteresis(as5600_handle_t* handle, as5600_hysteresis_t* hysteresis);
uint8_t as5600_set_power_mode(as5600_handle_t* handle, as5600_power_mode_t mode);
uint8_t as5600_get_power_mode(as5600_handle_t* handle, as5600_power_mode_t* mode);
uint8_t as5600_get_raw_angle(as5600_handle_t* handle, uint16_t* ang);
uint8_t as5600_get_angle(as5600_handle_t* handle, uint16_t* ang);
uint8_t as5600_get_status(as5600_handle_t* handle, uint8_t* status);
uint8_t as5600_get_agc(as5600_handle_t* handle, uint8_t* agc);
uint8_t as5600_get_magnitude(as5600_handle_t* handle, uint16_t* magnitude);
uint8_t as5600_set_burn(as5600_handle_t* handle, as5600_burn_t burn);
uint8_t as5600_set_reg(as5600_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t as5600_get_reg(as5600_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
