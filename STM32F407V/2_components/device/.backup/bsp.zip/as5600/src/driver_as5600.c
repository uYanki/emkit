
#include "driver_as5600.h"

#define MANUFACTURER_NAME  "AMS"        // manufacturer name
#define SUPPLY_VOLTAGE_MIN 4.5f         // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.5f         // chip max supply voltage




#define AS5600_ADDRESS 0x6C // iic device address
#define AS5600_REG_ZMCO        0x00 // written times register
#define AS5600_REG_ZPOS_H      0x01 // start position register high
#define AS5600_REG_ZPOS_L      0x02 // start position register low
#define AS5600_REG_MPOS_H      0x03 // stop position register high
#define AS5600_REG_MPOS_L      0x04 // stop position register low
#define AS5600_REG_MANG_H      0x05 // maximum angle register high
#define AS5600_REG_MANG_L      0x06 // maximum angle register low
#define AS5600_REG_CONF_H      0x07 // conf register high
#define AS5600_REG_CONF_L      0x08 // conf register low
#define AS5600_REG_RAW_ANGLE_H 0x0C // raw angle register high
#define AS5600_REG_RAW_ANGLE_L 0x0D // raw angle register low
#define AS5600_REG_ANGLE_H     0x0E // angle register high
#define AS5600_REG_ANGLE_L     0x0F // angle register low
#define AS5600_REG_STATUS      0x0B // status register
#define AS5600_REG_AGC         0x1A // automatic gain control register
#define AS5600_REG_MAGNITUDE_H 0x1B // magnitude register high
#define AS5600_REG_MAGNITUDE_L 0x1C // magnitude register low
#define AS5600_REG_BURN        0xFF // burn register
static uint8_t a_as5600_iic_read( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_read(AS5600_ADDRESS, reg, data, len) != 0) /* read the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_as5600_iic_write( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_write(AS5600_ADDRESS, reg, data, len) != 0) /* write the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_init(as5600_handle_t* handle)
{
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t as5600_deinit(as5600_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (iic_deinit() != 0) /* iic deinit */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t as5600_read( uint16_t* angle_raw, float* deg)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_RAW_ANGLE_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *angle_raw = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the raw angle */
        *deg       = (float)(*angle_raw) * (360.0f / 4096.0f);        /* convert the raw data to the real data */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_angle_convert_to_register( float deg, uint16_t* reg)
{
    {
        
    }
    {
        
    }
    *reg = (uint16_t)(deg / (360.0f / 4096.0f)); /* convert real data to register data */
    return 0; /* success return 0 */
}
uint8_t as5600_angle_convert_to_data( uint16_t reg, float* deg)
{
    {
        
    }
    {
        
    }
    *deg = (float)(reg) * (360.0f / 4096.0f); /* convert raw data to real data */
    return 0; /* success return 0 */
}
uint8_t as5600_set_start_position( uint16_t pos)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (pos > 0xFFF) /* check the pos */
    {
        
        
    }
    buf[0] = (pos >> 8) & 0x0F;                                     /* set high part */
    buf[1] = (pos >> 0) & 0xFF;                                     /* set low part */
    if (a_as5600_iic_write( AS5600_REG_ZPOS_H, buf, 2) != 0) /* write conf */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_start_position( uint16_t* pos)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_ZPOS_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *pos = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the position */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_set_stop_position( uint16_t pos)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (pos > 0xFFF) /* check the pos */
    {
        
        
    }
    buf[0] = (pos >> 8) & 0x0F;                                     /* set high part */
    buf[1] = (pos >> 0) & 0xFF;                                     /* set low part */
    if (a_as5600_iic_write( AS5600_REG_MPOS_H, buf, 2) != 0) /* write conf */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_stop_position( uint16_t* pos)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_MPOS_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *pos = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the position */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_set_max_angle( uint16_t ang)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (ang > 0xFFF) /* check the ang */
    {
        
        
    }
    buf[0] = (ang >> 8) & 0x0F;                                     /* set high part */
    buf[1] = (ang >> 0) & 0xFF;                                     /* set low part */
    if (a_as5600_iic_write( AS5600_REG_MANG_H, buf, 2) != 0) /* write conf */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_max_angle( uint16_t* ang)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_MANG_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *ang = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the position */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_set_watch_dog( as5600_bool_t enable)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(1 << 5);                                                /* clear the settings */
    prev |= enable << 5;                                              /* set the bool */
    if (a_as5600_iic_write( AS5600_REG_CONF_H, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_watch_dog( as5600_bool_t* enable)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *enable = (as5600_bool_t)((prev >> 5) & 0x1); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t as5600_set_fast_filter_threshold( as5600_fast_filter_threshold_t threshold)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(7 << 2);                                                /* clear the settings */
    prev |= threshold << 2;                                           /* set the threshold */
    if (a_as5600_iic_write( AS5600_REG_CONF_H, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_fast_filter_threshold( as5600_fast_filter_threshold_t* threshold)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *threshold = (as5600_fast_filter_threshold_t)((prev >> 2) & 0x7); /* set the threshold */
    return 0; /* success return 0 */
}
uint8_t as5600_set_slow_filter( as5600_slow_filter_t filter)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(3 << 0);                                                /* clear the settings */
    prev |= filter << 0;                                              /* set the filter */
    if (a_as5600_iic_write( AS5600_REG_CONF_H, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_slow_filter( as5600_slow_filter_t* filter)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_H, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *filter = (as5600_slow_filter_t)(prev & 0x3); /* get the filter */
    return 0; /* success return 0 */
}
uint8_t as5600_set_pwm_frequency( as5600_pwm_frequency_t freq)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(3 << 6);                                                /* clear the settings */
    prev |= freq << 6;                                                /* set the freq */
    if (a_as5600_iic_write( AS5600_REG_CONF_L, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_pwm_frequency( as5600_pwm_frequency_t* freq)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *freq = (as5600_pwm_frequency_t)((prev >> 6) & 0x3); /* set the frequency */
    return 0; /* success return 0 */
}
uint8_t as5600_set_output_stage( as5600_output_stage_t stage)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(3 << 4);                                                /* clear the settings */
    prev |= stage << 4;                                               /* set the stage */
    if (a_as5600_iic_write( AS5600_REG_CONF_L, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_output_stage( as5600_output_stage_t* stage)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *stage = (as5600_output_stage_t)((prev >> 4) & 0x3); /* get the output stage */
    return 0; /* success return 0 */
}
uint8_t as5600_set_hysteresis( as5600_hysteresis_t hysteresis)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(3 << 2);                                                /* clear the settings */
    prev |= hysteresis << 2;                                          /* set the hysteresis */
    if (a_as5600_iic_write( AS5600_REG_CONF_L, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_hysteresis( as5600_hysteresis_t* hysteresis)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *hysteresis = (as5600_hysteresis_t)((prev >> 2) & 0x3); /* get the hysteresis */
    return 0; /* success return 0 */
}
uint8_t as5600_set_power_mode( as5600_power_mode_t mode)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    prev &= ~(3 << 0);                                                /* clear the settings */
    prev |= mode << 0;                                                /* set the power mode */
    if (a_as5600_iic_write( AS5600_REG_CONF_L, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_power_mode( as5600_power_mode_t* mode)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_CONF_L, &prev, 1) != 0) /* read conf */
    {
        
        
    }
    *mode = (as5600_power_mode_t)((prev >> 0) & 0x3); /* get the power mode */
    return 0; /* success return 0 */
}
uint8_t as5600_get_raw_angle( uint16_t* ang)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_RAW_ANGLE_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *ang = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the angle */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_angle( uint16_t* ang)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_ANGLE_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *ang = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the angle */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_status( uint8_t* status)
{
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_STATUS, status, 1) != 0) /* read conf */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_agc( uint8_t* agc)
{
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_AGC, agc, 1) != 0) /* read conf */
    {
        
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t as5600_get_magnitude( uint16_t* magnitude)
{
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (a_as5600_iic_read( AS5600_REG_MAGNITUDE_H, buf, 2) != 0) /* read conf */
    {
        
        
    } else {
        *magnitude = (uint16_t)(((buf[0] >> 0) & 0xF) << 8) | buf[1]; /* set the angle */
        return 0; /* success return 0 */
    }
}
uint8_t as5600_set_burn( as5600_burn_t burn)
{
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = burn;                                                    /* set the burn */
    if (a_as5600_iic_write( AS5600_REG_BURN, &prev, 1) != 0) /* write conf */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_set_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_as5600_iic_write( reg, buf, len); /* write data */
    if (res != 0)                                    /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_get_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_as5600_iic_read( reg, buf, len); /* read data */
    if (res != 0)                                   /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t as5600_info(as5600_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(as5600_info_t));                  /* initialize as5600 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
