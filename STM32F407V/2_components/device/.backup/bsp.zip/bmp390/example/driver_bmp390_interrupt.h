
#ifndef DRIVER_BMP390_INTERRUPT_H
#define DRIVER_BMP390_INTERRUPT_H
#include "driver_bmp390_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define BMP390_INTERRUPT_DEFAULT_SPI_WIRE                 BMP390_SPI_WIRE_4                        // 4 wire spi 
#define BMP390_INTERRUPT_DEFAULT_IIC_WATCHDOG_TIMER       BMP390_BOOL_FALSE                        // disable iic watchdog timer 
#define BMP390_INTERRUPT_DEFAULT_IIC_WATCHDOG_PERIOD      BMP390_IIC_WATCHDOG_PERIOD_1P25_MS       // set watchdog timer period 1.25ms 
#define BMP390_INTERRUPT_DEFAULT_INTERRUPT_PIN_TYPE       BMP390_INTERRUPT_PIN_TYPE_PUSH_PULL      // interrupt pin type push pull 
#define BMP390_INTERRUPT_DEFAULT_INTERRUPT_ACTIVE_LEVEL   BMP390_INTERRUPT_ACTIVE_LEVEL_HIGHER     // interrupt pin active level higher 
#define BMP390_INTERRUPT_DEFAULT_PRESSURE                 BMP390_BOOL_TRUE                         // enable pressure 
#define BMP390_INTERRUPT_DEFAULT_TEMPERATURE              BMP390_BOOL_TRUE                         // enable temperature 
#define BMP390_INTERRUPT_DEFAULT_PRESSURE_OVERSAMPLING    BMP390_OVERSAMPLING_x32                  // pressure oversampling x32 
#define BMP390_INTERRUPT_DEFAULT_TEMPERATURE_OVERSAMPLING BMP390_OVERSAMPLING_x2                   // temperature oversampling x2 
#define BMP390_INTERRUPT_DEFAULT_ODR                      BMP390_ODR_12P5_HZ                       // output data rate 12.5Hz 
#define BMP390_INTERRUPT_DEFAULT_FILTER_COEFFICIENT       BMP390_FILTER_COEFFICIENT_15             // set filter coefficient 15 
uint8_t bmp390_interrupt_irq_handler(void);
uint8_t bmp390_interrupt_init(bmp390_interface_t interface, bmp390_address_t addr_pin, 
                              void (*interrupt_receive_callback)(uint8_t type));
uint8_t bmp390_interrupt_deinit(void);
uint8_t bmp390_interrupt_read(float *temperature_c, float *pressure_pa);
#ifdef __cplusplus
}
#endif
#endif
