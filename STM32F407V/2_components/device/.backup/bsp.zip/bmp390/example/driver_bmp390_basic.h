
#ifndef DRIVER_BMP390_BASIC_H
#define DRIVER_BMP390_BASIC_H
#include "driver_bmp390_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define BMP390_BASIC_DEFAULT_SPI_WIRE                 BMP390_SPI_WIRE_4                        // 4 wire spi 
#define BMP390_BASIC_DEFAULT_IIC_WATCHDOG_TIMER       BMP390_BOOL_TRUE                         // enable iic watchdog timer 
#define BMP390_BASIC_DEFAULT_IIC_WATCHDOG_PERIOD      BMP390_IIC_WATCHDOG_PERIOD_40_MS         // set watchdog timer period 40ms 
#define BMP390_BASIC_DEFAULT_PRESSURE                 BMP390_BOOL_TRUE                         // enable pressure *
#define BMP390_BASIC_DEFAULT_TEMPERATURE              BMP390_BOOL_TRUE                         // enable temperature 
#define BMP390_BASIC_DEFAULT_PRESSURE_OVERSAMPLING    BMP390_OVERSAMPLING_x32                  // pressure oversampling x32 
#define BMP390_BASIC_DEFAULT_TEMPERATURE_OVERSAMPLING BMP390_OVERSAMPLING_x2                   // temperature oversampling x2 
#define BMP390_BASIC_DEFAULT_ODR                      BMP390_ODR_12P5_HZ                       // output data rate 12.5Hz 
#define BMP390_BASIC_DEFAULT_FILTER_COEFFICIENT       BMP390_FILTER_COEFFICIENT_15             // set filter coefficient 15 
uint8_t bmp390_basic_init(bmp390_interface_t interface, bmp390_address_t addr_pin);
uint8_t bmp390_basic_deinit(void);
uint8_t bmp390_basic_read(float *temperature_c, float *pressure_pa);
#ifdef __cplusplus
}
#endif
#endif
