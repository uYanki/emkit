
#ifndef DRIVER_BMP390_REGISTER_TEST_H
#define DRIVER_BMP390_REGISTER_TEST_H
#include "driver_bmp390_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t bmp390_register_test(bmp390_interface_t interface, bmp390_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
