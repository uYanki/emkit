
#include "driver_mcp4725.h"
#include <math.h>

#define MANUFACTURER_NAME         "Microchip"                // manufacturer name
#define SUPPLY_VOLTAGE_MIN        2.7f                       // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f                       // chip max supply voltage




uint8_t mcp4725_init(mcp4725_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                     /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                        /* check iic_init */
    {
        
        
        
    }
    if (iic_deinit == NULL)                                      /* check iic_deinit */
    {
        
        
        
    }
    if (iic_read_cmd == NULL)                                    /* check iic_read_cmd */
    {
        
        
        
    }
    if (iic_write_cmd == NULL)                                   /* check iic_write_cmd */
    {
        
        
        
    }
    if (delay_ms == NULL)                                        /* check delay_ms */
    {
        
        
        
    }
    if (iic_init() != 0)                                         /* iic init */
    {
        
        
        
    }
    inited = 1;                                                  /* flag finish initialization */
    return 0;                                                            /* success return 0 */
}
uint8_t mcp4725_deinit(mcp4725_handle_t *handle)
{
    
    {
        
    }
    
    {
        
    }
    if (iic_deinit() != 0)                                   /* iic deinit */
    {
        
        
        
    }   
    inited = 0;                                              /* flag close */
    return 0;                                                        /* success return 0 */
}
uint8_t mcp4725_set_addr_pin(mcp4725_handle_t *handle, mcp4725_address_t addr_pin)
{
    
    {
        
    }
    iic_addr = (uint8_t)((0x60 | addr_pin) << 1);        /* set iic address */
    return 0;                                                    /* success return 0 */
}
uint8_t mcp4725_get_addr_pin(mcp4725_handle_t *handle, mcp4725_address_t *addr_pin)
{
    
    {
        
    }
    if (((iic_addr >> 1) & ~0x60) != 0)
    {
        *addr_pin = (mcp4725_address_t)(0x01);        /* get iic address */
    }
    else
    {
        *addr_pin = (mcp4725_address_t)(0x00);        /* get iic address */
    }
    return 0;                                         /* success return 0 */
}
uint8_t mcp4725_set_mode(mcp4725_handle_t *handle, mcp4725_mode_t mode)
{
    
    {
        
    }
    
    {
        
    }
    mode = (uint8_t)mode;        /* set mode */
    return 0;                            /* success return 0 */
}
uint8_t mcp4725_get_mode(mcp4725_handle_t *handle, mcp4725_mode_t *mode)
{
    
    {
        
    }
    
    {
        
    }
    *mode = (mcp4725_mode_t)(mode);        /* get mode */
    return 0;                                      /* success return 0 */
}
uint8_t mcp4725_set_power_mode(mcp4725_handle_t *handle, mcp4725_power_down_mode_t mode)
{
    
    {
        
    }
    
    {
        
    }
    power_mode = (uint8_t)mode;        /* set power mode */
    return 0;                                  /* success return 0 */
}
uint8_t mcp4725_get_power_mode(mcp4725_handle_t *handle, mcp4725_power_down_mode_t *mode)
{
    
    {
        
    }
    
    {
        
    }
    *mode = (mcp4725_power_down_mode_t)(power_mode);        /* get power mode */
    return 0;                                                       /* success return 0 */
}
uint8_t mcp4725_set_reference_voltage(mcp4725_handle_t *handle, float ref_voltage)
{
    
    {
        
    }
    
    {
        
    }
    ref_voltage = ref_voltage;        /* set reference voltage */
    return 0;                                 /* success return 0 */
}
uint8_t mcp4725_get_reference_voltage(mcp4725_handle_t *handle, float *ref_voltage)
{
    
    {
        
    }
    
    {
        
    }
    *ref_voltage = ref_voltage;        /* get reference voltage */
    return 0;                                  /* success return 0 */
}
uint8_t mcp4725_read(mcp4725_handle_t *handle, uint16_t *value)
{
    uint8_t buf[5];
    
    {
        
    }
    
    {
        
    }
    if (iic_read_cmd(iic_addr, (uint8_t *)buf, 5) != 0)   /* read data */
    {
        
        
        
    }
    if (mode == MCP4725_MODE_DAC)                                 /* if use dac mode */
    {
        *value = (uint16_t)(((uint16_t)buf[1]) << 8 | buf[2]);            /* get value */
        *value = (*value) >> 4;                                           /* right shift 4 */
        
        return 0;                                                         /* success return 0 */
    }
    else if (mode == MCP4725_MODE_EEPROM)                         /* if use eeprom mode */
    {
        *value = (uint16_t)((uint16_t)(buf[3] & 0x0F) << 8 | buf[4]);     /* get value */
        
        return 0;                                                         /* success return 0 */
    }
    else
    {
        
        
        
    }
} 
uint8_t mcp4725_write(mcp4725_handle_t *handle, uint16_t value)
{
    uint8_t buf[6];
    
    {
        
    }
    
    {
        
    }
    value = value & 0xFFF;                                                        /* get valid part */
    if (mode == MCP4725_MODE_DAC)                                         /* dac mode */
    {
        buf[0] = (uint8_t)((value >> 8) & 0xFF);                                  /* set msb */
        buf[0] = (uint8_t)(buf[0] | (power_mode << 4));                   /* set power mode */
        buf[1] = (uint8_t)(value & 0xFF);                                         /* set lsb */
        buf[2] = (uint8_t)((value >> 8) & 0xFF);                                  /* set msb */
        buf[2] = (uint8_t)(buf[2] | (power_mode << 4));                   /* set power mode */
        buf[3] = (uint8_t)(value & 0xFF);                                         /* set lsb */
        
        return iic_write_cmd(iic_addr, (uint8_t *)buf, 4);        /* write command */
    }
    else if (mode == MCP4725_MODE_EEPROM)                                 /* eeprom mode */
    {
        buf[0] = (uint8_t)(0x03 << 5);                                            /* set mode */
        buf[0] = (uint8_t)(buf[0] | (power_mode << 1));                   /* set power mode */
        value = value << 4;                                                       /* right shift 4 */
        buf[1] = (uint8_t)((value >> 8) & 0xFF);                                  /* set msb */
        buf[2] = (uint8_t)(value & 0xFF);                                         /* set lsb */
        buf[3] = (uint8_t)(0x03 << 5);                                            /* set mode */
        buf[3] = (uint8_t)(buf[3] | (power_mode << 1));                   /* set power mode */
        value = value << 4;                                                       /* right shift 4 */
        buf[4] = (uint8_t)((value >> 8) & 0xFF);                                  /* set msb */
        buf[5] = (uint8_t)(value & 0xFF);                                         /* set lsb */
        
        return iic_write_cmd(iic_addr, (uint8_t *)buf, 6);        /* write command */
    }
    else
    {
        
        
        
    }
}
uint8_t mcp4725_convert_to_register(mcp4725_handle_t *handle, float s, uint16_t *reg)
{
    
    {
        
    }
    
    {
        
    }
    if (fabsf(ref_voltage - 0.0f) < 1e-6f)                                 /* check reference voltage */ 
    {
        
        
        
    }
    *reg = (uint16_t)(s * 4096.0000000f / ref_voltage);                    /* calculate register */
    return 0;                                                                      /* success return 0 */
}
uint8_t mcp4725_convert_to_data(mcp4725_handle_t *handle, uint16_t reg, float *s)
{
    
    {
        
    }
    
    {
        
    }
    *s = (float)(reg) * ref_voltage / 4096.00000000f;        /* calculate data */
    return 0;                                                        /* success return 0 */
}
uint8_t mcp4725_set_reg(mcp4725_handle_t *handle, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    return iic_write_cmd(iic_addr, buf, len);        /* write data */
}
uint8_t mcp4725_get_reg(mcp4725_handle_t *handle, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    return iic_read_cmd(iic_addr, buf, len);        /* read data */
}
uint8_t mcp4725_info(mcp4725_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(mcp4725_info_t));                        /* initialize mcp4725 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
