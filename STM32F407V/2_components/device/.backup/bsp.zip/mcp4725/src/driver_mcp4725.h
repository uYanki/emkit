
#ifndef DRIVER_MCP4725_H
#define DRIVER_MCP4725_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MCP4725_ADDR_A0_GND = 0x00,  // A0 pin connected to GND
    MCP4725_ADDR_A0_VCC = 0x01,  // A0 pin connected to VCC
} mcp4725_address_t;
typedef enum {
    MCP4725_MODE_DAC    = 0x00,  // DAC mode
    MCP4725_MODE_EEPROM = 0x03,  // EEPROM mode
} mcp4725_mode_t;
typedef enum {
    MCP4725_POWER_DOWN_MODE_NORMAL   = 0x00,  // power down normal mode
    MCP4725_POWER_DOWN_MODE_1K_GND   = 0x01,  // power down 1K GND
    MCP4725_POWER_DOWN_MODE_100K_GND = 0x02,  // power down 100K GND
    MCP4725_POWER_DOWN_MODE_500K_GND = 0x03,  // power down 500K GND
} mcp4725_power_down_mode_t;
typedef struct mcp4725_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t inited;       // inited flag
    uint8_t mode;         // chip mode
    uint8_t power_mode;   // power mode
    float   ref_voltage;  // reference voltage
} mcp4725_handle_t;

uint8_t mcp4725_info(mcp4725_info_t* info);
uint8_t mcp4725_set_addr_pin(mcp4725_handle_t* handle, mcp4725_address_t addr_pin);
uint8_t mcp4725_get_addr_pin(mcp4725_handle_t* handle, mcp4725_address_t* addr_pin);
uint8_t mcp4725_init(mcp4725_handle_t* handle);
uint8_t mcp4725_deinit(mcp4725_handle_t* handle);
uint8_t mcp4725_write(mcp4725_handle_t* handle, uint16_t value);
uint8_t mcp4725_read(mcp4725_handle_t* handle, uint16_t* value);
uint8_t mcp4725_convert_to_register(mcp4725_handle_t* handle, float s, uint16_t* reg);
uint8_t mcp4725_convert_to_data(mcp4725_handle_t* handle, uint16_t reg, float* s);
uint8_t mcp4725_set_mode(mcp4725_handle_t* handle, mcp4725_mode_t mode);
uint8_t mcp4725_get_mode(mcp4725_handle_t* handle, mcp4725_mode_t* mode);
uint8_t mcp4725_set_power_mode(mcp4725_handle_t* handle, mcp4725_power_down_mode_t mode);
uint8_t mcp4725_get_power_mode(mcp4725_handle_t* handle, mcp4725_power_down_mode_t* mode);
uint8_t mcp4725_set_reference_voltage(mcp4725_handle_t* handle, float ref_voltage);
uint8_t mcp4725_get_reference_voltage(mcp4725_handle_t* handle, float* ref_voltage);
uint8_t mcp4725_set_reg(mcp4725_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t mcp4725_get_reg(mcp4725_handle_t* handle, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
