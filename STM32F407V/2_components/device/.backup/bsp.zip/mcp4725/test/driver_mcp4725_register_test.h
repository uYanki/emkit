
#ifndef DRIVER_MCP4725_REGISTER_TEST_H
#define DRIVER_MCP4725_REGISTER_TEST_H
#include "driver_mcp4725_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mcp4725_register_test(mcp4725_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
