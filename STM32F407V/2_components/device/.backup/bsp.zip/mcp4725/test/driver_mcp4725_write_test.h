
#ifndef DRIVER_MCP4725_WRITE_TEST_H
#define DRIVER_MCP4725_WRITE_TEST_H
#include "driver_mcp4725_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mcp4725_write_test(mcp4725_address_t addr, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
