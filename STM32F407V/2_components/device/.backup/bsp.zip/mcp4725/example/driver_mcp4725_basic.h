
#ifndef DRIVER_MCP4725_BASIC_H
#define DRIVER_MCP4725_BASIC_H
#include "driver_mcp4725_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MCP4725_BASIC_DEFAULT_POWER_DOWN_MODE     MCP4725_POWER_DOWN_MODE_NORMAL        // normal power down 
#define MCP4725_BASIC_DEFAULT_MODE                MCP4725_MODE_DAC                      // normal mode 
#define MCP4725_BASIC_DEFAULT_REFERENCE_VOLTAGE   3.3f                                  // 3.3v reference voltage 
uint8_t mcp4725_basic_init(mcp4725_address_t addr_pin);
uint8_t mcp4725_basic_deinit(void);
uint8_t mcp4725_basic_write(float voltage_v);
#ifdef __cplusplus
}
#endif
#endif
