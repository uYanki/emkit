
#ifndef DRIVER_BMP180_REGISTER_TEST_H
#define DRIVER_BMP180_REGISTER_TEST_H
#include "driver_bmp180_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t bmp180_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
