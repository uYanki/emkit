
#include "driver_bmp180_basic.h"
static bmp180_handle_t gs_handle;        // bmp180 handle
uint8_t bmp180_basic_init(void)
{
    uint8_t res;
    /* link interface function */
    DRIVER_BMP180_LINK_INIT(&gs_handle, bmp180_handle_t); 
    DRIVER_BMP180_LINK_IIC_INIT(&gs_handle, bmp180_interface_iic_init);
    DRIVER_BMP180_LINK_IIC_DEINIT(&gs_handle, bmp180_interface_iic_deinit);
    DRIVER_BMP180_LINK_IIC_READ(&gs_handle, bmp180_interface_iic_read);
    DRIVER_BMP180_LINK_IIC_WRITE(&gs_handle, bmp180_interface_iic_write);
    DRIVER_BMP180_LINK_DELAY_MS(&gs_handle, bmp180_interface_delay_ms);
    DRIVER_BMP180_LINK_DEBUG_PRINT(&gs_handle, bmp180_interface_debug_print);
    /* bmp180 init */
    res = bmp180_init(&gs_handle);
    if (res != 0)
    {
        bmp180_interface_debug_print("bmp180: init failed.\n");
        
        return 1;
    }
    /* set mode */
    res = bmp180_set_mode(&gs_handle, BMP180_BASIC_DEFAULT_MODE);
    if (res != 0)
    {
        bmp180_interface_debug_print("bmp180: set mode failed.\n");
        (void)bmp180_deinit(&gs_handle);
        
        return 1;
    }
    return 0;
}
uint8_t bmp180_basic_read(float *temperature, uint32_t *pressure)
{
    uint16_t temperature_yaw;
    uint32_t pressure_yaw;
    /* read temperature and pressure */
    if (bmp180_read_temperature_pressure(&gs_handle, (uint16_t *)&temperature_yaw, 
                                            temperature, (uint32_t *)&pressure_yaw, pressure) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t bmp180_basic_deinit(void)
{
    /* close bmp180 */
    if (bmp180_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
