
#ifndef DRIVER_BMP180_BASIC_H
#define DRIVER_BMP180_BASIC_H
#include "driver_bmp180_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define BMP180_BASIC_DEFAULT_MODE BMP180_MODE_STANDARD        // set standard mode 
uint8_t bmp180_basic_init(void);
uint8_t bmp180_basic_deinit(void);
uint8_t bmp180_basic_read(float *temperature, uint32_t *pressure);
#ifdef __cplusplus
}
#endif
#endif
