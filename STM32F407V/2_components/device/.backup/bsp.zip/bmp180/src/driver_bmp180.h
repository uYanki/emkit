
#ifndef DRIVER_BMP180_H
#define DRIVER_BMP180_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    BMP180_MODE_ULTRA_LOW  = 0x00,  // ultra low mode
    BMP180_MODE_STANDARD   = 0x01,  // standard mode
    BMP180_MODE_HIGH       = 0x02,  // high mode
    BMP180_MODE_ULTRA_HIGH = 0x03,  // ultra high mode
} bmp180_mode_t;
typedef struct bmp180_handle_s {
    uint8_t  inited;  // inited flag
    int16_t  ac1;     // ac1
    int16_t  ac2;     // ac2
    int16_t  ac3;     // ac3
    uint16_t ac4;     // ac4
    uint16_t ac5;     // ac5
    uint16_t ac6;     // ac6
    int16_t  b1;      // b1
    int16_t  b2;      // b2
    int16_t  mb;      // mb
    int16_t  mc;      // mc
    int16_t  md;      // md
    uint8_t  oss;     // oss param
} bmp180_handle_t;

uint8_t bmp180_info();
uint8_t bmp180_init();
uint8_t bmp180_deinit();
uint8_t bmp180_read_temperature_pressure(uint16_t* temperature_raw, float* temperature_c, uint32_t* pressure_raw, uint32_t* pressure_pa);
uint8_t bmp180_read_pressure(uint32_t* raw, uint32_t* pa);
uint8_t bmp180_read_temperature(uint16_t* raw, float* c);
uint8_t bmp180_set_mode(bmp180_mode_t mode);
uint8_t bmp180_get_mode(bmp180_mode_t* mode);
uint8_t bmp180_set_reg(uint8_t reg, uint8_t value);
uint8_t bmp180_get_reg(uint8_t reg, uint8_t* value);
#ifdef __cplusplus
}
#endif
#endif
