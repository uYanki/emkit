
#include "driver_bmp180.h"

#define MANUFACTURER_NAME  "Bosch"        // manufacturer name
#define SUPPLY_VOLTAGE_MIN 1.8f           // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f           // chip max supply voltage




#define BMP180_ADDRESS 0xEE // iic device address
#define BMP180_REG_AC1_MSB   0xAA // ac1 msb register
#define BMP180_REG_AC1_LSB   0xAB // ac1 lsb register
#define BMP180_REG_AC2_MSB   0xAC // ac2 msb register
#define BMP180_REG_AC2_LSB   0xAD // ac2 lsb register
#define BMP180_REG_AC3_MSB   0xAE // ac3 msb register
#define BMP180_REG_AC3_LSB   0xAF // ac3 lsb register
#define BMP180_REG_AC4_MSB   0xB0 // ac4 msb register
#define BMP180_REG_AC4_LSB   0xB1 // ac4 lsb register
#define BMP180_REG_AC5_MSB   0xB2 // ac5 msb register
#define BMP180_REG_AC5_LSB   0xB3 // ac5 lsb register
#define BMP180_REG_AC6_MSB   0xB4 // ac6 msb register
#define BMP180_REG_AC6_LSB   0xB5 // ac6 lsb register
#define BMP180_REG_B1_MSB    0xB6 // b1 msb register
#define BMP180_REG_B1_LSB    0xB7 // b1 lsb register
#define BMP180_REG_B2_MSB    0xB8 // b2 msb register
#define BMP180_REG_B2_LSB    0xB9 // b2 lsb register
#define BMP180_REG_MB_MSB    0xBA // mb msb register
#define BMP180_REG_MB_LSB    0xBB // mb lsb register
#define BMP180_REG_MC_MSB    0xBC // mc msb register
#define BMP180_REG_MC_LSB    0xBD // mc lsb register
#define BMP180_REG_MD_MSB    0xBE // md msb register
#define BMP180_REG_MD_LSB    0xBF // md lsb register
#define BMP180_REG_CTRL_MEAS 0xF4 // ctrl meas register
#define BMP180_REG_OUT_MSB   0xF6 // data out msb register
#define BMP180_REG_OUT_LSB   0xF7 // data out lsb register
#define BMP180_REG_OUT_XLSB  0xF8 // data xlsb register
#define BMP180_REG_SOFT      0xE0 // soft reset register
#define BMP180_REG_ID        0xD0 // chip id register
static uint8_t a_bmp180_iic_read( uint8_t addr, uint8_t reg, uint8_t* data)
{
    if (iic_read(addr, reg, data, 1) != 0) /* read */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_bmp180_iic_write( uint8_t addr, uint8_t reg, uint8_t data)
{
    if (iic_write(addr, reg, &data, 1) != 0) /* write */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t bmp180_init(bmp180_handle_t* handle)
{
    uint8_t  buf[22];
    int16_t  temp1 = 0;
    uint16_t temp2 = 0;
    uint8_t  id;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_ID, (uint8_t*)&id) != 0) /* read chip id */
    {
        
        
        
    }
    if (id != 0x55) /* check id */
    {
        
        
        
    }
    if (iic_read(BMP180_ADDRESS, BMP180_REG_AC1_MSB, (uint8_t*)buf, 22) != 0) /* read ac1-md */
    {
        
        (void)iic_deinit();                                   /* deinit iic */
        
    }
    temp1          = buf[0] << 8;     /* get MSB */
    temp1          = temp1 | buf[1];  /* get LSB */
    ac1    = temp1;           /* save ac1 */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[2] << 8;     /* get MSB */
    temp1          = temp1 | buf[3];  /* get LSB */
    ac2    = temp1;           /* save ac2 */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[4] << 8;     /* get MSB */
    temp1          = temp1 | buf[5];  /* get LSB */
    ac3    = temp1;           /* save ac3 */
    temp1          = 0;               /* reset temp1 */
    temp2          = buf[6] << 8;     /* get MSB */
    temp2          = temp2 | buf[7];  /* get LSB */
    ac4    = temp2;           /* save ac4 */
    temp2          = 0;               /* reset temp1 */
    temp2          = buf[8] << 8;     /* get MSB */
    temp2          = temp2 | buf[9];  /* get LSB */
    ac5    = temp2;           /* save ac5 */
    temp2          = 0;               /* reset temp2 */
    temp2          = buf[10] << 8;    /* get MSB */
    temp2          = temp2 | buf[11]; /* get LSB */
    ac6    = temp2;           /* save ac6 */
    temp1          = buf[12] << 8;    /* get MSB */
    temp1          = temp1 | buf[13]; /* get LSB */
    b1     = temp1;           /* save b1 */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[14] << 8;    /* get MSB */
    temp1          = temp1 | buf[15]; /* get LSB */
    b2     = temp1;           /* save b2 */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[16] << 8;    /* get MSB */
    temp1          = temp1 | buf[17]; /* get LSB */
    mb     = temp1;           /* save mb */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[18] << 8;    /* get MSB */
    temp1          = temp1 | buf[19]; /* get LSB */
    mc     = temp1;           /* save mc */
    temp1          = 0;               /* reset temp1 */
    temp1          = buf[20] << 8;    /* get MSB */
    temp1          = temp1 | buf[21]; /* get LSB */
    md     = temp1;           /* save md */
    inited = 1;               /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t bmp180_deinit(bmp180_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (iic_deinit() != 0) /* iic deinit */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t bmp180_set_mode( bmp180_mode_t mode)
{
    {
        
    }
    {
        
    }
    oss = (uint8_t)mode; /* set mode */
    return 0; /* success return 0 */
}
uint8_t bmp180_get_mode( bmp180_mode_t* mode)
{
    {
        
    }
    {
        
    }
    *mode = (bmp180_mode_t)oss; /* get mode */
    return 0; /* success return 0 */
}
uint8_t bmp180_read_pressure( uint32_t* raw, uint32_t* pa)
{
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t num;
    int32_t  ut = 0, up = 0, x1, x2, x3, b5, b6, b3, p;
    uint32_t b4, b7;
    {
        
    }
    {
        
    }
    num = 5000;                                                                      /* set timeout 5000 ms */
    if (a_bmp180_iic_write( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, 0x2E) != 0) /* write temperature measurement command */
    {
        
        
    }
    while (num != 0) /* check times */
    {
        delay_ms(1);                                                                         /* wait 1 ms */
        if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, (uint8_t*)&status) != 0) /* read ctrl status */
        {
            
            
        }
        status = status & 0x20; /* get finished flag */
        if (status == 0)        /* check flag */
        {
            goto t_read; /* goto next step */
        } else {
            num = num - 1; /* times-1 */
        }
    }
    
t_read:
    memset(buf, 0, sizeof(uint8_t) * 3);                                             /* clear the buffer */
    if (iic_read(BMP180_ADDRESS, BMP180_REG_OUT_MSB, (uint8_t*)buf, 2) != 0) /* read raw temperature */
    {
        
        
    }
    ut = buf[0] << 8;                                                                                     /* get MSB */
    ut = ut | buf[1];                                                                                     /* get LSB */
    ut = ut & 0x0000FFFFU;                                                                                /* get valid part */
    if (a_bmp180_iic_write( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, 0x34 + (oss << 6)) != 0) /* write pressure measurement command */
    {
        
        
    }
    num = 5000;      /* set timeout 5000 ms */
    while (num != 0) /* check times */
    {
        delay_ms(1);                                                                         /* wait 1 ms */
        if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, (uint8_t*)&status) != 0) /* read status */
        {
            
            
        }
        status = status & 0x20; /* get finished flag */
        if (status == 0)        /* check flag */
        {
            goto p_read; /* goto next step */
        } else {
            num = num - 1; /* times-1 */
        }
    }
    
p_read:
    memset(buf, 0, sizeof(uint8_t) * 3);                                             /* clear the buffer */
    if (iic_read(BMP180_ADDRESS, BMP180_REG_OUT_MSB, (uint8_t*)buf, 3) != 0) /* read pressure */
    {
        
        
    }
    up   = buf[0] << 8;             /* get MSB */
    up   = up | buf[1];             /* get LSB */
    up   = up << 8;                 /* left shift 8 */
    up   = up | buf[2];             /* get XLSB */
    *raw = up;                      /* get raw data */
    up   = up >> (8 - oss); /* shift */
    if (oss == 0)           /* ultra low */
    {
        up = up & 0x0000FFFFU;   /* set mask */
    } else if (oss == 1) /* standard */
    {
        up = up & 0x0001FFFFU;   /* set mask */
    } else if (oss == 2) /* high */
    {
        up = up & 0x0003FFFFU;   /* set mask */
    } else if (oss == 3) /* ultra high */
    {
        up = up & 0x0007FFFFU; /* set mask */
    } else {
        
        
    }
    x1 = (((ut - (int32_t)ac6) * (int32_t)ac5)) >> 15;          /* calculate x1 */
    x2 = (int32_t)((((int32_t)mc) << 11) / (x1 + (int32_t)md)); /* calculate x2 */
    b5 = x1 + x2;                                                               /* calculate b5 */
    b6 = b5 - 4000;                                                             /* calculate b6 */
    x1 = ((int32_t)b2 * ((b6 * b6) >> 12)) >> 11;                       /* calculate x1 */
    x2 = ((int32_t)ac2 * b6) >> 11;                                     /* calculate x2 */
    x3 = x1 + x2;                                                               /* calculate x3 */
    b3 = (((((int32_t)ac1) * 4 + x3) << oss) + 2) >> 2;         /* calculate b3 */
    x1 = ((int32_t)ac3 * b6) >> 13;                                     /* calculate x1 */
    x2 = ((int32_t)b1 * (((b6 * b6)) >> 12)) >> 16;                     /* calculate x2 */
    x3 = ((x1 + x2) + 2) >> 2;                                                  /* calculate x3 */
    b4 = (uint32_t)((((uint32_t)ac4 * (uint32_t)(x3 + 32768))) >> 15);  /* calculate b4 */
    b7 = (uint32_t)((uint32_t)(up - b3) * (50000 >> oss));              /* calculate b7 */
    if (b7 < 0x80000000U) {
        p = (int32_t)((b7 << 1) / b4); /* calculate p */
    } else {
        p = (int32_t)((b7 / b4) << 1); /* calculate p */
    }
    x1  = (p >> 8) * (p >> 8);         /* calculate x1 */
    x1  = (x1 * 3038) >> 16;           /* calculate x1 */
    x2  = (-7357 * p) >> 16;           /* calculate x2 */
    *pa = p + ((x1 + x2 + 3791) >> 4); /* calculate x2 */
    return 0; /* success return 0 */
}
uint8_t bmp180_read_temperature( uint16_t* raw, float* c)
{
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t num;
    int32_t  ut = 0, x1, x2, b5;
    {
        
    }
    {
        
    }
    num = 5000;                                                                      /* set timeout 5000 */
    if (a_bmp180_iic_write( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, 0x2E) != 0) /* write temperature measurement command */
    {
        
        
    }
    while (num != 0) /* check times */
    {
        delay_ms(1);                                                                         /* delay 1 ms */
        if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, (uint8_t*)&status) != 0) /* read status */
        {
            
            
        }
        status = status & 0x20; /* get finished flag */
        if (status == 0)        /* check flag */
        {
            goto t_read; /* goto next step */
        } else {
            num = num - 1; /* times-1 */
        }
    }
    
t_read:
    memset(buf, 0, sizeof(uint8_t) * 3);                                             /* clear the buffer */
    if (iic_read(BMP180_ADDRESS, BMP180_REG_OUT_MSB, (uint8_t*)buf, 2) != 0) /* read raw temperature */
    {
        
        
    }
    ut   = buf[0] << 8;                                                           /* get MSB */
    ut   = ut | buf[1];                                                           /* get LSB */
    ut   = ut & 0x0000FFFFU;                                                      /* set mask */
    *raw = (uint16_t)ut;                                                          /* get raw temperature */
    x1   = (((ut - (int32_t)ac6) * (int32_t)ac5)) >> 15;          /* calculate x1 */
    x2   = (int32_t)((((int32_t)mc) << 11) / (x1 + (int32_t)md)); /* calculate x2 */
    b5   = x1 + x2;                                                               /* calculate b5 */
    *c   = ((uint16_t)((b5 + 8) >> 4)) * 0.1f;                                    /* calculate temperature */
    return 0; /* success return 0 */
}
uint8_t bmp180_read_temperature_pressure( uint16_t* temperature_raw, float* temperature_c, uint32_t* pressure_raw, uint32_t* pressure_pa)
{
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t num;
    int32_t  ut = 0, up = 0, x1, x2, x3, b5, b6, b3, p;
    uint32_t b4, b7;
    {
        
    }
    {
        
    }
    num = 5000;                                                                      /* set timeout 5000 */
    if (a_bmp180_iic_write( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, 0x2E) != 0) /* write temperature measurement command */
    {
        
        
    }
    while (num != 0) /* check times */
    {
        delay_ms(1);                                                                         /* wait 1 ms */
        if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, (uint8_t*)&status) != 0) /* read status */
        {
            
            
        }
        status = status & 0x20; /* get finished flag */
        if (status == 0)        /* check flag */
        {
            goto t_read; /* goto next step */
        } else {
            num = num - 1; /* times-1 */
        }
    }
    
t_read:
    memset(buf, 0, sizeof(uint8_t) * 3);                                             /* clear the buffer */
    if (iic_read(BMP180_ADDRESS, BMP180_REG_OUT_MSB, (uint8_t*)buf, 2) != 0) /* read raw temperature */
    {
        
        
    }
    ut               = buf[0] << 8;                                                                       /* get MSB */
    ut               = ut | buf[1];                                                                       /* get LSB */
    ut               = ut & 0x0000FFFFU;                                                                  /* set mask */
    *temperature_raw = (uint16_t)ut;                                                                      /* get temperature */
    if (a_bmp180_iic_write( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, 0x34 + (oss << 6)) != 0) /* write pressure measurement command */
    {
        
        
    }
    num = 5000;      /* set timeout 5000 */
    while (num != 0) /* check times */
    {
        delay_ms(1);                                                                         /* wait 1 ms */
        if (a_bmp180_iic_read( BMP180_ADDRESS, BMP180_REG_CTRL_MEAS, (uint8_t*)&status) != 0) /* read status */
        {
            
            
        }
        status = status & 0x20; /* get finished flag */
        if (status == 0)        /* check flag */
        {
            goto p_read; /* goto next step */
        } else {
            num = num - 1; /* times-1 */
        }
    }
    
p_read:
    memset(buf, 0, sizeof(uint8_t) * 3);                                             /* clear the buffer */
    if (iic_read(BMP180_ADDRESS, BMP180_REG_OUT_MSB, (uint8_t*)buf, 3) != 0) /* read raw pressure */
    {
        
        
    }
    up            = buf[0] << 8;             /* get MSB */
    up            = up | buf[1];             /* get LSB */
    up            = up << 8;                 /* left shit */
    up            = up | buf[2];             /* get XLSB */
    *pressure_raw = up;                      /* get pressure */
    up            = up >> (8 - oss); /* right shift */
    if (oss == 0)                    /* ultra low */
    {
        up = up & 0x0000FFFFU;   /* set mask */
    } else if (oss == 1) /* standard */
    {
        up = up & 0x0001FFFFU;   /* set mask */
    } else if (oss == 2) /* high */
    {
        up = up & 0x0003FFFFU;   /* set mask */
    } else if (oss == 3) /* ultra high */
    {
        up = up & 0x0007FFFFU; /* set mask */
    } else {
        
        return 1; /* return errror */
    }
    x1             = (((ut - (int32_t)ac6) * (int32_t)ac5)) >> 15;          /* calculate x1 */
    x2             = (int32_t)((((int32_t)mc) << 11) / (x1 + (int32_t)md)); /* calculate x2 */
    b5             = x1 + x2;                                                               /* calculate b5 */
    *temperature_c = ((uint16_t)((b5 + 8) >> 4)) * 0.1f;                                    /* get temperature */
    b6             = b5 - 4000;                                                             /* calculate b6 */
    x1             = ((int32_t)b2 * ((b6 * b6) >> 12)) >> 11;                       /* calculate x1 */
    x2             = ((int32_t)ac2 * b6) >> 11;                                     /* calculate x2 */
    x3             = x1 + x2;                                                               /* calculate x3 */
    b3             = (((((int32_t)ac1) * 4 + x3) << oss) + 2) >> 2;         /* calculate b3 */
    x1             = ((int32_t)ac3 * b6) >> 13;                                     /* calculate x1 */
    x2             = ((int32_t)b1 * (((b6 * b6)) >> 12)) >> 16;                     /* calculate x2 */
    x3             = ((x1 + x2) + 2) >> 2;                                                  /* calculate x3 */
    b4             = (uint32_t)((((uint32_t)ac4 * (uint32_t)(x3 + 32768))) >> 15);  /* calculate b4 */
    b7             = (uint32_t)((uint32_t)(up - b3) * (50000 >> oss));              /* calculate b7 */
    if (b7 < 0x80000000U) {
        p = (int32_t)((b7 << 1) / b4); /* calculate p */
    } else {
        p = (int32_t)((b7 / b4) << 1); /* calculate p */
    }
    x1           = (p >> 8) * (p >> 8);         /* calculate x1 */
    x1           = (x1 * 3038) >> 16;           /* calculate x1 */
    x2           = (-7357 * p) >> 16;           /* calculate x2 */
    *pressure_pa = p + ((x1 + x2 + 3791) >> 4); /* set pressure */
    return 0; /* success return 0 */
}
uint8_t bmp180_set_reg( uint8_t reg, uint8_t value)
{
    {
        
    }
    {
        
    }
    return a_bmp180_iic_write( BMP180_ADDRESS, reg, value); /* write register */
}
uint8_t bmp180_get_reg( uint8_t reg, uint8_t* value)
{
    {
        
    }
    {
        
    }
    return a_bmp180_iic_read( BMP180_ADDRESS, reg, value); /* read register */
}
uint8_t bmp180_info(bmp180_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(bmp180_info_t));                  /* initialize bmp180 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
