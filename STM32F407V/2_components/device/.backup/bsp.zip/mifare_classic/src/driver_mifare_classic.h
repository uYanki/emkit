
#ifndef DRIVER_MIFARE_CLASSIC_H
#define DRIVER_MIFARE_CLASSIC_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MIFARE_CLASSIC_TYPE_INVALID = 0x00,  // invalid
    MIFARE_CLASSIC_TYPE_S50     = 0x01,  // s50
    MIFARE_CLASSIC_TYPE_S70     = 0x02,  // s70
} mifare_classic_type_t;
typedef enum {
    MIFARE_CLASSIC_LOAD_MODULATION_NORMAL = 0x00,  // normal load modulation
    MIFARE_CLASSIC_LOAD_MODULATION_STRONG = 0x01,  // strong load modulation
} mifare_classic_load_modulation_t;
typedef enum {
    MIFARE_CLASSIC_PERSONALIZED_UID_0 = 0x00, /**< anti-collision and selection with the double size UID according to ISO/IEC
                                                   14443-3 */
    MIFARE_CLASSIC_PERSONALIZED_UID_1 = 0x40, /**< anti-collision and selection with the double size UID according to ISO/IEC
                                                   14443-3 and optional usage of a selection process shortcut */
    MIFARE_CLASSIC_PERSONALIZED_UID_2 = 0x20, /**< anti-collision and selection with a single size random ID according to ISO/IEC
                                                   14443-3 */
    MIFARE_CLASSIC_PERSONALIZED_UID_3 = 0x60, /**< anti-collision and selection with a single size NUID according to ISO/IEC
                                                   14443-3 where the NUID is calculated out of the 7-byte UID */
} mifare_classic_personalized_uid_t;
typedef enum {
    MIFARE_CLASSIC_AUTHENTICATION_KEY_A = 0x00,  // authentication key a
    MIFARE_CLASSIC_AUTHENTICATION_KEY_B = 0x01,  // authentication key b
} mifare_classic_authentication_key_t;
typedef struct mifare_classic_handle_s {
    uint8_t (*contactless_transceiver)(uint8_t *in_buf, uint8_t in_len, 



    uint8_t type;                                                                  // classic type 
    uint8_t inited;                                                                // inited flag
} mifare_classic_handle_t;

uint8_t mifare_classic_info(mifare_classic_info_t* info);
uint8_t mifare_classic_init(mifare_classic_handle_t* handle);
uint8_t mifare_classic_deinit(mifare_classic_handle_t* handle);
uint8_t mifare_classic_request(mifare_classic_handle_t* handle, mifare_classic_type_t* type);
uint8_t mifare_classic_wake_up(mifare_classic_handle_t* handle, mifare_classic_type_t* type);
uint8_t mifare_classic_halt(mifare_classic_handle_t* handle);
uint8_t mifare_classic_set_modulation(mifare_classic_handle_t* handle, mifare_classic_load_modulation_t mod);
uint8_t mifare_classic_set_personalized_uid(mifare_classic_handle_t* handle, mifare_classic_personalized_uid_t type);
uint8_t mifare_classic_anticollision_cl1(mifare_classic_handle_t* handle, uint8_t id[4]);
uint8_t mifare_classic_anticollision_cl2(mifare_classic_handle_t* handle, uint8_t id[4]);
uint8_t mifare_classic_select_cl1(mifare_classic_handle_t* handle, uint8_t id[4]);
uint8_t mifare_classic_select_cl2(mifare_classic_handle_t* handle, uint8_t id[4]);
uint8_t mifare_classic_authentication(mifare_classic_handle_t* handle, uint8_t id[4], uint8_t block, mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_read(mifare_classic_handle_t* handle, uint8_t block, uint8_t data[16]);
uint8_t mifare_classic_write(mifare_classic_handle_t* handle, uint8_t block, uint8_t data[16]);
uint8_t mifare_classic_value_init(mifare_classic_handle_t* handle, uint8_t block, int32_t value, uint8_t addr);
uint8_t mifare_classic_value_write(mifare_classic_handle_t* handle, uint8_t block, int32_t value, uint8_t addr);
uint8_t mifare_classic_value_read(mifare_classic_handle_t* handle, uint8_t block, int32_t* value, uint8_t* addr);
uint8_t mifare_classic_increment(mifare_classic_handle_t* handle, uint8_t block, uint32_t value);
uint8_t mifare_classic_decrement(mifare_classic_handle_t* handle, uint8_t block, uint32_t value);
uint8_t mifare_classic_transfer(mifare_classic_handle_t* handle, uint8_t block);
uint8_t mifare_classic_restore(mifare_classic_handle_t* handle, uint8_t block);
uint8_t mifare_classic_block_to_sector(mifare_classic_handle_t* handle, uint8_t block, uint8_t* sector);
uint8_t mifare_classic_sector_block_count(mifare_classic_handle_t* handle, uint8_t sector, uint8_t* count);
uint8_t mifare_classic_sector_first_block(mifare_classic_handle_t* handle, uint8_t sector, uint8_t* block);
uint8_t mifare_classic_sector_last_block(mifare_classic_handle_t* handle, uint8_t sector, uint8_t* block);
uint8_t mifare_classic_set_sector_permission(mifare_classic_handle_t* handle,
                                             uint8_t                  sector,
                                             uint8_t                  key_a[6],
                                             uint8_t                  block_0_0_4,
                                             uint8_t                  block_1_5_9,
                                             uint8_t                  block_2_10_14,
                                             uint8_t                  block_3_15,
                                             uint8_t                  user_data,
                                             uint8_t                  key_b[6]);
uint8_t mifare_classic_get_sector_permission(mifare_classic_handle_t* handle,
                                             uint8_t                  sector,
                                             uint8_t*                 block_0_0_4,
                                             uint8_t*                 block_1_5_9,
                                             uint8_t*                 block_2_10_14,
                                             uint8_t*                 block_3_15,
                                             uint8_t*                 user_data,
                                             uint8_t                  key_b[6]);
uint8_t mifare_classic_transceiver(mifare_classic_handle_t* handle, uint8_t* in_buf, uint8_t in_len, uint8_t* out_buf, uint8_t* out_len);
#ifdef __cplusplus
}
#endif
#endif
