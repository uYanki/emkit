
#ifndef DRIVER_MIFARE_CLASSIC_CARD_TEST_H
#define DRIVER_MIFARE_CLASSIC_CARD_TEST_H
#include "driver_mifare_classic_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mifare_classic_card_test(void);
#ifdef __cplusplus
}
#endif
#endif
