
#include "driver_mifare_classic_basic.h"
static mifare_classic_handle_t gs_handle;        // mifare_classic handle
static uint8_t gs_id[4];                         // local id
static void s_debug_print(const char *const fmt, ...)
{
    (void)fmt;
    return;
}
uint8_t mifare_classic_basic_init(void)
{
    uint8_t res;
    /* link function */
    DRIVER_MIFARE_CLASSIC_LINK_INIT(&gs_handle, mifare_classic_handle_t);
    DRIVER_MIFARE_CLASSIC_LINK_CONTACTLESS_INIT(&gs_handle, mifare_classic_interface_contactless_init);
    DRIVER_MIFARE_CLASSIC_LINK_CONTACTLESS_DEINIT(&gs_handle, mifare_classic_interface_contactless_deinit);
    DRIVER_MIFARE_CLASSIC_LINK_CONTACTLESS_TRANSCEIVER(&gs_handle, mifare_classic_interface_contactless_transceiver);
    DRIVER_MIFARE_CLASSIC_LINK_DELAY_MS(&gs_handle, mifare_classic_interface_delay_ms);
#ifndef NO_DEBUG
    DRIVER_MIFARE_CLASSIC_LINK_DEBUG_PRINT(&gs_handle, mifare_classic_interface_debug_print);
#else
    DRIVER_MIFARE_CLASSIC_LINK_DEBUG_PRINT(&gs_handle, s_debug_print);
#endif
    /* init */
    res = mifare_classic_init(&gs_handle);
    if (res != 0)
    {
        mifare_classic_interface_debug_print("mifare_classic: init failed.\n");
        
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_deinit(void)
{
    uint8_t res;
    /* deinit */
    res = mifare_classic_deinit(&gs_handle);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_halt(void)
{
    uint8_t res;
    /* halt */
    res = mifare_classic_halt(&gs_handle);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_wake_up(void)
{
    uint8_t res;
    mifare_classic_type_t type;
    /* wake up */
    res = mifare_classic_wake_up(&gs_handle, &type);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_search(mifare_classic_type_t *type, uint8_t id[4], int32_t timeout)
{
    uint8_t res;
    /* loop */
    while (1)
    {
        /* request */
        res = mifare_classic_request(&gs_handle, type);
        if (res == 0)
        {
            /* anticollision_cl1 */
            res = mifare_classic_anticollision_cl1(&gs_handle, id);
            if (res == 0)
            {
                /* cl1 */
                res = mifare_classic_select_cl1(&gs_handle, id);
                if (res == 0)
                {
                    memcpy(gs_id, id, 4);
                    
                    return 0;
                }
            }
        }
        
        /* delay */
        mifare_classic_interface_delay_ms(MIFARE_CLASSIC_BASIC_DEFAULT_SEARCH_DELAY_MS);
        
        /* check the timeout */
        if (timeout < 0)
        {
            /* never timeout */
            continue;
        }
        else
        {
            /* timeout */
            if (timeout == 0)
            {
                return 1;
            }
            else
            {
                /* timout-- */
                timeout--;
            }
        }
    }
}
uint8_t mifare_classic_basic_read(uint8_t block, uint8_t data[16],
                                  mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* read */
    res = mifare_classic_read(&gs_handle, block, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_write(uint8_t block, uint8_t data[16],
                                   mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* write */
    res = mifare_classic_write(&gs_handle, block, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_value_init(uint8_t block, int32_t value, uint8_t addr,
                                        mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* value init */
    res  = mifare_classic_value_init(&gs_handle, block, value, addr);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_value_write(uint8_t block, int32_t value, uint8_t addr,
                                         mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* value write */
    res  = mifare_classic_value_write(&gs_handle, block, value, addr);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_value_read(uint8_t block, int32_t *value, uint8_t *addr,
                                         mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* value read */
    res  = mifare_classic_value_read(&gs_handle, block, value, addr);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_value_increment(uint8_t block, uint32_t value,
                                             mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* increment */
    res  = mifare_classic_increment(&gs_handle, block, value);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_transfer(&gs_handle, block);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_value_decrement(uint8_t block, uint32_t value,
                                             mifare_classic_authentication_key_t key_type, uint8_t key[6])
{
    uint8_t res;
    uint8_t sector;
    uint8_t block_check;
    /* check the block */
    res = mifare_classic_block_to_sector(&gs_handle, block, &sector);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block_check);
    if (res != 0)
    {
        return 1;
    }
    if (block == block_check)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* decrement */
    res  = mifare_classic_decrement(&gs_handle, block, value);
    if (res != 0)
    {
        return 1;
    }
    res = mifare_classic_transfer(&gs_handle, block);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_set_permission(mifare_classic_authentication_key_t key_type, uint8_t key[6],
                                            uint8_t sector, uint8_t key_a[6], uint8_t block_0_0_4, uint8_t block_1_5_9,
                                            uint8_t block_2_10_14, uint8_t block_3_15, uint8_t user_data, uint8_t key_b[6])
{
    uint8_t res;
    uint8_t block;
    /* get the last block */
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block);
    if (res != 0)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* set sector permission */
    res = mifare_classic_set_sector_permission(&gs_handle, sector, key_a, block_0_0_4, block_1_5_9, 
                                               block_2_10_14, block_3_15, user_data, key_b);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_classic_basic_get_permission(mifare_classic_authentication_key_t key_type, uint8_t key[6],
                                            uint8_t sector, uint8_t *block_0_0_4, uint8_t *block_1_5_9,
                                            uint8_t *block_2_10_14, uint8_t *block_3_15, uint8_t *user_data, uint8_t key_b[6])
{
    uint8_t res;
    uint8_t block;
    /* get the last block */
    res = mifare_classic_sector_last_block(&gs_handle, sector, &block);
    if (res != 0)
    {
        return 1;
    }
    /* authentication */
    res = mifare_classic_authentication(&gs_handle, gs_id, block, key_type, key);
    if (res != 0)
    {
        return 1;
    }
    /* set sector permission */
    res = mifare_classic_get_sector_permission(&gs_handle, sector, block_0_0_4, block_1_5_9, 
                                               block_2_10_14, block_3_15, user_data, key_b);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
