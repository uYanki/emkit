
#ifndef DRIVER_MIFARE_CLASSIC_BASIC_H
#define DRIVER_MIFARE_CLASSIC_BASIC_H
#include "driver_mifare_classic_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MIFARE_CLASSIC_BASIC_DEFAULT_SEARCH_DELAY_MS        200        // 5Hz 
uint8_t mifare_classic_basic_init(void);
uint8_t mifare_classic_basic_deinit(void);
uint8_t mifare_classic_basic_search(mifare_classic_type_t *type, uint8_t id[4], int32_t timeout);
uint8_t mifare_classic_basic_read(uint8_t block, uint8_t data[16],
                                  mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_write(uint8_t block, uint8_t data[16],
                                   mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_value_init(uint8_t block, int32_t value, uint8_t addr,
                                        mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_value_write(uint8_t block, int32_t value, uint8_t addr,
                                         mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_value_read(uint8_t block, int32_t *value, uint8_t *addr,
                                         mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_value_decrement(uint8_t block, uint32_t value,
                                             mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_value_increment(uint8_t block, uint32_t value,
                                             mifare_classic_authentication_key_t key_type, uint8_t key[6]);
uint8_t mifare_classic_basic_halt(void);
uint8_t mifare_classic_basic_wake_up(void);
uint8_t mifare_classic_basic_set_permission(mifare_classic_authentication_key_t key_type, uint8_t key[6],
                                            uint8_t sector, uint8_t key_a[6], uint8_t block_0_0_4, uint8_t block_1_5_9,
                                            uint8_t block_2_10_14, uint8_t block_3_15, uint8_t user_data, uint8_t key_b[6]);
uint8_t mifare_classic_basic_get_permission(mifare_classic_authentication_key_t key_type, uint8_t key[6],
                                            uint8_t sector, uint8_t *block_0_0_4, uint8_t *block_1_5_9,
                                            uint8_t *block_2_10_14, uint8_t *block_3_15, uint8_t *user_data, uint8_t key_b[6]);
#ifdef __cplusplus
}
#endif
#endif
