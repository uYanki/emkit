
#ifndef DRIVER_AT24CXX_READ_TEST_H
#define DRIVER_AT24CXX_READ_TEST_H
#include "driver_at24cxx_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t at24cxx_read_test(at24cxx_t type, at24cxx_address_t address);
#ifdef __cplusplus
}
#endif
#endif
