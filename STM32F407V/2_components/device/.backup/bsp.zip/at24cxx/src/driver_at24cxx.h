
#ifndef DRIVER_AT24CXX_H
#define DRIVER_AT24CXX_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    AT24C01  = 127,    // AT24C01 type
    AT24C02  = 255,    // AT24C02 type
    AT24C04  = 511,    // AT24C04 type
    AT24C08  = 1023,   // AT24C08 type
    AT24C16  = 2047,   // AT24C16 type
    AT24C32  = 4095,   // AT24C32 type
    AT24C64  = 8191,   // AT24C64 type
    AT24C128 = 16383,  // AT24C128 type
    AT24C256 = 32767,  // AT24C256 type
} at24cxx_t;
typedef enum {
    AT24CXX_ADDRESS_A000 = 0,  // A2A1A0 000
    AT24CXX_ADDRESS_A001 = 1,  // A2A1A0 001
    AT24CXX_ADDRESS_A010 = 2,  // A2A1A0 010
    AT24CXX_ADDRESS_A011 = 3,  // A2A1A0 011
    AT24CXX_ADDRESS_A100 = 4,  // A2A1A0 100
    AT24CXX_ADDRESS_A101 = 5,  // A2A1A0 101
    AT24CXX_ADDRESS_A110 = 6,  // A2A1A0 110
    AT24CXX_ADDRESS_A111 = 7,  // A2A1A0 111
} at24cxx_address_t;
typedef struct at24cxx_handle_s {
    uint8_t iic_addr;                                                                        // iic device address
    uint8_t (*iic_init)(void);                                                               // point to an iic_init function address
    uint8_t (*iic_deinit)(void);                                                             // point to an iic_deinit function address
    uint8_t (*iic_read)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);              // point to an iic_read function address
    uint8_t (*iic_write)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);             // point to an iic_write function address
    uint8_t (*iic_read_address16)(uint8_t addr, uint16_t reg, uint8_t* buf, uint16_t len);   // point to an iic_read_address16 function address
    uint8_t (*iic_write_address16)(uint8_t addr, uint16_t reg, uint8_t* buf, uint16_t len);  // point to an iic_write_address16 function address
    void (*delay_ms)(uint32_t ms);                                                           // point to a delay_ms function address
    void (*debug_print)(const char* const fmt, ...);                                         // point to a debug_print function address
    uint16_t id;                                                                             // chip id
    uint8_t  inited;                                                                         // inited flag
} at24cxx_handle_t;
typedef struct at24cxx_info_s {
    char     chip_name[32];          // chip name
    char     manufacturer_name[32];  // manufacturer name
    char     interface[8];           // chip interface name
    float    supply_voltage_min_v;   // chip min supply voltage
    float    supply_voltage_max_v;   // chip max supply voltage
    float    max_current_ma;         // chip max current
    float    temperature_min;        // chip min operating temperature
    float    temperature_max;        // chip max operating temperature
    uint32_t driver_version;         // driver version
} at24cxx_info_t;

uint8_t at24cxx_info(at24cxx_info_t* info);
uint8_t at24cxx_init(at24cxx_handle_t* handle);
uint8_t at24cxx_deinit(at24cxx_handle_t* handle);
uint8_t at24cxx_set_type(at24cxx_handle_t* handle, at24cxx_t type);
uint8_t at24cxx_get_type(at24cxx_handle_t* handle, at24cxx_t* type);
uint8_t at24cxx_set_addr_pin(at24cxx_handle_t* handle, at24cxx_address_t addr_pin);
uint8_t at24cxx_get_addr_pin(at24cxx_handle_t* handle, at24cxx_address_t* addr_pin);
uint8_t at24cxx_read(at24cxx_handle_t* handle, uint16_t address, uint8_t* buf, uint16_t len);
uint8_t at24cxx_write(at24cxx_handle_t* handle, uint16_t address, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
