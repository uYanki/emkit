
#ifndef DRIVER_AT24CXX_BASIC_H
#define DRIVER_AT24CXX_BASIC_H
#include "driver_at24cxx_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t at24cxx_basic_init(at24cxx_t type, at24cxx_address_t address);
uint8_t at24cxx_basic_deinit(void);
uint8_t at24cxx_basic_read(uint16_t address, uint8_t *buf, uint16_t len);
uint8_t at24cxx_basic_write(uint16_t address, uint8_t *buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
