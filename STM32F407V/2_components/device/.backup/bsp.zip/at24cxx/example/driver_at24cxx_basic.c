
#include "driver_at24cxx_basic.h"
static at24cxx_handle_t gs_handle; // at24cxx handle
uint8_t at24cxx_basic_init(at24cxx_t type, at24cxx_address_t address)
{
    uint8_t res;
    /* link interface function */
    DRIVER_AT24CXX_LINK_INIT(&gs_handle, at24cxx_handle_t);
    DRIVER_AT24CXX_LINK_IIC_INIT(&gs_handle, at24cxx_interface_iic_init);
    DRIVER_AT24CXX_LINK_IIC_DEINIT(&gs_handle, at24cxx_interface_iic_deinit);
    DRIVER_AT24CXX_LINK_IIC_READ(&gs_handle, at24cxx_interface_iic_read);
    DRIVER_AT24CXX_LINK_IIC_WRITE(&gs_handle, at24cxx_interface_iic_write);
    DRIVER_AT24CXX_LINK_IIC_READ_ADDRESS16(&gs_handle, at24cxx_interface_iic_read_address16);
    DRIVER_AT24CXX_LINK_IIC_WRITE_ADDRESS16(&gs_handle, at24cxx_interface_iic_write_address16);
    DRIVER_AT24CXX_LINK_DELAY_MS(&gs_handle, at24cxx_interface_delay_ms);
    DRIVER_AT24CXX_LINK_DEBUG_PRINT(&gs_handle, at24cxx_interface_debug_print);
    /* set chip type */
    res = at24cxx_set_type(&gs_handle, type);
    if (res != 0) {
        at24cxx_interface_debug_print("at24cxx: set type failed.\n");
        return 1;
    }
    /* set addr pin */
    res = at24cxx_set_addr_pin(&gs_handle, address);
    if (res != 0) {
        at24cxx_interface_debug_print("at24cxx: set address pin failed.\n");
        return 1;
    }
    /* at24cxx init */
    res = at24cxx_init(&gs_handle);
    if (res != 0) {
        at24cxx_interface_debug_print("at24cxx: init failed.\n");
        return 1;
    }
    return 0;
}
uint8_t at24cxx_basic_read(uint16_t address, uint8_t* buf, uint16_t len)
{
    /* read data */
    if (at24cxx_read(&gs_handle, address, buf, len) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t at24cxx_basic_write(uint16_t address, uint8_t* buf, uint16_t len)
{
    /* read data */
    if (at24cxx_write(&gs_handle, address, buf, len) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t at24cxx_basic_deinit(void)
{
    /* at24cxx deinit */
    if (at24cxx_deinit(&gs_handle) != 0) {
        return 1;
    } else {
        return 0;
    }
}
