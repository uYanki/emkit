
#ifndef DRIVER_MAX31865_REGISTER_TEST_H
#define DRIVER_MAX31865_REGISTER_TEST_H
#include "driver_max31865_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max31865_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
