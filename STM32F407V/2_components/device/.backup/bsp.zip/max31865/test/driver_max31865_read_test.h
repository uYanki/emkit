
#ifndef DRIVER_MAX31865_READ_TEST_H
#define DRIVER_MAX31865_READ_TEST_H
#include "driver_max31865_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max31865_read_test(max31865_wire_t wire, max31865_resistor_t type, float ref_resistor, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
