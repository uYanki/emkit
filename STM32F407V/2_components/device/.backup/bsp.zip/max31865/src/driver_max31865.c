
#include "driver_max31865.h"

#define MANUFACTURER_NAME         "Maxim Integrated"                 // manufacturer name
#define SUPPLY_VOLTAGE_MIN        3.0f                               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        3.6f                               // chip max supply voltage




#define MAX31856_REG_CONFIG                0x00        // config register
#define MAX31856_REG_RTD_MSB               0x01        // rtd msb register
#define MAX31856_REG_RTD_LSB               0x02        // rtd lsb register
#define MAX31856_REG_HIGH_FAULT_MSB        0x03        // high fault msb register
#define MAX31856_REG_HIGH_FAULT_LSB        0x04        // high fault lsb register
#define MAX31856_REG_LOW_FAULT_MSB         0x05        // low fault msb register
#define MAX31856_REG_LOW_FAULT_LSB         0x06        // low fault lsb register
#define MAX31856_REG_FAULT_STATUS          0x07        // fault status register
#define WRITE_ADDRESS_MASK        0x80             // spi write mask
#define RTD_A                     3.9083e-3f       // rtd a
#define RTD_B                     -5.775e-7f       // rtd b
static float a_max31865_temperature_conversion(float rt, float rtd_nominal, float ref_resistor)
{
    float z1, z2, z3, z4, temp;
    float rpoly = rt;
    rt /= 32768;                             /* div 32768 */
    rt *= ref_resistor;                      /* ref_resistor */
    z1 = -RTD_A;                             /* -RTD A */
    z2 = RTD_A * RTD_A - (4 * RTD_B);        /* get z2 */
    z3 = (4 * RTD_B) / rtd_nominal;          /* get z3 */
    z4 = 2 * RTD_B;                          /* get z4 */
    temp = z2 + (z3 * rt);                   /* calculate temp */
    temp = (sqrtf(temp) + z1) / z4;          /* sqrt */
    if (temp >= 0)                           /* check temp */
    {
        return temp;                         /* return temp */
    }
    rt /= rtd_nominal;                       /* nominal */
    rt *= 100;                               /* normalize to 100 ohm */
    temp = -242.02f;                         /* -242.02 */
    temp += 2.2228f * rpoly;                 /* add offset */
    rpoly *= rt;                             /* square */
    temp += 2.5859e-3f * rpoly;              /* add offset */
    rpoly *= rt;                             /* ^3 */
    temp -= 4.8260e-6f * rpoly;              /* add offset */
    rpoly *= rt;                             /* ^4 */
    temp -= 2.8183e-8f * rpoly;              /* add offset */
    rpoly *= rt;                             /* ^5 */
    temp += 1.5243e-10f * rpoly;             /* add offset */
    return temp;                             /* return error */
}
uint8_t max31865_init(max31865_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                   /* check debug_print */
    {
        
    }
    if (spi_init == NULL)                                      /* check spi_init */
    {
        
       
        
    }
    if (spi_deinit == NULL)                                    /* check spi_init */
    {
        
       
        
    }
    if (spi_read == NULL)                                      /* check spi_read */
    {
        
       
        
    }
    if (spi_write == NULL)                                     /* check spi_write */
    {
        
       
        
    }
    if (delay_ms == NULL)                                      /* check delay_ms */
    {
        
       
        
    }
    if (spi_init() != 0)                                       /* spi init */
    { 
        
       
        
    }
    inited = 1;                                                /* flag initialization */
    return 0;                                                          /* success return 0 */
}
uint8_t max31865_deinit(max31865_handle_t *handle)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                              /* read config */
    if (res != 0)                                                                                  /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                             /* clear flag */
    res = spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
    if (res != 0)                                                                                  /* check result */
    {
        
        
        
    }
    if (spi_deinit() != 0)                                                                 /* spi deinit */
    {
        
        
        
    }         
    inited = 0;                                                                            /* flag close */
    return 0;                                                                                      /* success return 0 */
}
uint8_t max31865_set_filter_select(max31865_handle_t *handle, max31865_filter_select_t filter)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 0);                                                                              /* clear filter bit */
    prev |= filter << 0;                                                                            /* set filter */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_get_filter_select(max31865_handle_t *handle, max31865_filter_select_t *filter)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);        /* read config */
    if (res != 0)                                                            /* check result */
    {
        
       
        
    }
    prev &= (1 << 0);                                                        /* get raw */
    *filter = (max31865_filter_select_t)(prev >> 0);                         /* get filter select */
    return 0;                                                                /* success return 0 */ 
}
uint8_t max31865_set_wire(max31865_handle_t *handle, max31865_wire_t wire)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 4);                                                                              /* clear wire bit */
    prev |= wire << 4;                                                                              /* set wire */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_get_wire(max31865_handle_t *handle, max31865_wire_t *wire)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);        /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
        
    }
    prev &= 1 << 4;                                                          /* get wire bit */
    *wire = (max31865_wire_t)(prev >> 4);                                    /* get wire */
    return 0;                                                                /* success return 0 */
}
uint8_t max31865_set_reference_resistor(max31865_handle_t *handle, float value)
{
    
    {
        
    }
    
    {
        
    }
    ref_resistor = value;        /* set reference resistor */
    return 0;                            /* success return 0 */
}
uint8_t max31865_get_reference_resistor(max31865_handle_t *handle, float *value) 
{
    
    {
        
    }
    
    {
        
    }
    *value = (float)(ref_resistor);        /* get reference resistor */
    return 0;                                      /* success return 0 */ 
}
uint8_t max31865_set_resistor(max31865_handle_t *handle, max31865_resistor_t resistor) 
{
    
    {
        
    }
    
    {
        
    }
    resistor = (uint8_t)resistor;        /* set resistor */
    return 0;                                    /* success return 0 */
}
uint8_t max31865_get_resistor(max31865_handle_t *handle, max31865_resistor_t *resistor) 
{
    
    {
        
    }
    
    {
        
    }
    *resistor = (max31865_resistor_t)(resistor);        /* get resistor */
    return 0;                                                   /* success return 0 */
}
uint8_t max31865_set_vbias(max31865_handle_t *handle, max31865_bool_t enable) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                              /* clear bias bit */
    prev |= enable << 7;                                                                            /* set bias enable */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_get_vbias(max31865_handle_t *handle, max31865_bool_t *enable) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);        /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
        
    }
    prev &= 1 << 7;                                                          /* get vbias bit */
    *enable = (max31865_bool_t)(prev >> 7);                                  /* get vbias */
    return 0;                                                                /* success return 0 */
}
uint8_t max31865_clear_fault_status(max31865_handle_t *handle) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 1);                                                                              /* clear bit */
    prev |= 1 << 1;                                                                                 /* set clear */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_get_fault_status(max31865_handle_t *handle, uint8_t *status) 
{
    
    {
        
    }
    
    {
        
    }
    return spi_read(MAX31856_REG_FAULT_STATUS, status, 1);        /* read status */
}
uint8_t max31865_set_high_fault_threshold(max31865_handle_t *handle, uint16_t threshold) 
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    threshold = threshold << 1;                                                                           /* left shift 1 */
    buf[0] = (uint8_t)((threshold >> 8) & 0xFF);                                                          /* set msb */
    buf[1] = (uint8_t)(threshold & 0xFF);                                                                 /* set lsb */
    return spi_write(MAX31856_REG_HIGH_FAULT_MSB | WRITE_ADDRESS_MASK, (uint8_t *)buf, 2);        /* write fault threshold */
}
uint8_t max31865_get_high_fault_threshold(max31865_handle_t *handle, uint16_t *threshold)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_HIGH_FAULT_MSB, (uint8_t *)buf, 2);          /* get fault msb */
    if (res != 0)                                                                    /* check result */
    {
        
       
        
    }
    *threshold = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                       /* get raw */
    *threshold = (*threshold) >> 1;                                                  /* get data */
    return 0;                                                                        /* success return 0 */
}
uint8_t max31865_set_low_fault_threshold(max31865_handle_t *handle, uint16_t threshold) 
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    threshold = threshold << 1;                                                                          /* left shift 1 */
    buf[0] = (uint8_t)((threshold >> 8) & 0xFF);                                                         /* set msb */
    buf[1] = (uint8_t)(threshold & 0xFF);                                                                /* set lsb */
    return spi_write(MAX31856_REG_LOW_FAULT_MSB | WRITE_ADDRESS_MASK, (uint8_t *)buf, 2);        /* write config */
}
uint8_t max31865_get_low_fault_threshold(max31865_handle_t *handle, uint16_t *threshold) 
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_LOW_FAULT_MSB, (uint8_t *)buf, 2);        /* write low fault msb */
    if (res != 0)                                                                 /* check result */
    {
        
        
        
    }
    *threshold = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                    /* get raw */
    *threshold = (*threshold) >> 1;                                               /* get data */
    return 0;                                                                     /* success return 0 */
}
uint8_t max31865_set_fault_detection_cycle_control(max31865_handle_t *handle, max31865_fault_detection_cycle_control_t control) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    prev &= ~(3 << 2);                                                                              /* clear control */
    prev |= control << 2;                                                                           /* set control */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_get_fault_detection_cycle_control(max31865_handle_t *handle, max31865_fault_detection_cycle_control_status_t *status)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);              /* read config */
    if (res != 0)                                                                  /* check result */
    {
        
       
        
    }
    prev &= 3 << 2;                                                                /* get control bits */
    *status = (max31865_fault_detection_cycle_control_status_t)(prev >> 2);        /* get control */
    return 0;                                                                      /* success return 0 */
}
uint8_t max31865_single_read(max31865_handle_t *handle, uint16_t *raw, float *temp)
{
    uint8_t res, prev;
    uint8_t buf[2];
    float resistor;
    uint16_t times;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                                 /* read config */
    if (res != 0)                                                                                     /* check result */
    {
        
       
        
    }
    prev |= 1 << 1;                                                                                   /* set fault detection */
    prev |= 1 << 7;                                                                                   /* enable vbias */
    prev &= ~(1 << 6);                                                                                /* set normally off */
    prev |= 1 << 5;                                                                                   /* set shot */
    res = spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);           /* write config */
    if (res != 0)                                                                                     /* check result */
    {
        
       
        
    }
    times = 5000;                                                                                     /* set retry times */
    while (((prev & (1 << 5)) != 0) && (times != 0))                                                  /* check retry times */
    {
        delay_ms(63);                                                                         /* delay 63 ms */
        res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                             /* read config */
        if (res != 0)                                                                                 /* check result */
        {
            
           
            
        }
        times--;                                                                                      /* retry times-- */
        if (times == 0)                                                                               /* if retry times == 0 */
        {
            
           
            
        }
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                              /* clear the buffer */
    res = spi_read(MAX31856_REG_RTD_MSB, (uint8_t *)buf, 2);                                  /* read rtd msb */
    if (res != 0)                                                                                     /* check result */
    {
        
       
        
    }
    *raw = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                                              /* get raw data */
    if (((*raw) & 0x01) != 0)
    {
        
       
        
    }
    else
    {
        (*raw) = (*raw) >> 1;                                                                         /* get raw data */
    }
    if (resistor == MAX31865_RESISTOR_100PT)                                                  /* if 100PT */
    {
        resistor = 100.0f;                                                                            /* set resistor type 100 */
    }
    else
    {
        resistor = 1000.0f;                                                                           /* set resistor type 1000 */
    }
    *temp = a_max31865_temperature_conversion((float)(*raw), resistor, ref_resistor);         /* calculate temperature */
    return 0;                                                                                         /* success return 0 */
}
uint8_t max31865_start_continuous_read(max31865_handle_t *handle)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    delay_ms(10);                                                                           /* delay 10 ms */
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    prev |= 1 << 1;                                                                                 /* set fault detection */
    prev |= 1 << 7;                                                                                 /* enable vbias */
    prev |= 1 << 6;                                                                                 /* set auto mode */
    prev &= ~(1 << 5);                                                                              /* disable shot */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_stop_continuous_read(max31865_handle_t *handle)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = spi_read(MAX31856_REG_CONFIG, (uint8_t *)&prev, 1);                               /* read config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    prev |= 1 << 1;                                                                                 /* set fault detection */
    prev &= ~(1 << 7);                                                                              /* disable vbias */
    prev &= ~(1 << 6);                                                                              /* disable auto mode */
    prev &= ~(1 << 5);                                                                              /* disable shot */
    return spi_write(MAX31856_REG_CONFIG | WRITE_ADDRESS_MASK, (uint8_t *)&prev, 1);        /* write config */
}
uint8_t max31865_continuous_read(max31865_handle_t *handle, uint16_t *raw, float *temp)
{
    uint8_t res;
    uint8_t buf[2];
    float resistor;
    
    {
        
    }
    
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                            /* clear the buffer */
    res = spi_read(MAX31856_REG_RTD_MSB, (uint8_t *)buf, 2);                                /* read rtd msb */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    *raw = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                                            /* get raw data */
    if (((*raw) & 0x01) != 0)                                                                       /* check error */
    {
        
       
        
    }
    else
    {
        (*raw) = (*raw) >> 1;                                                                       /* get raw data */
    }
    if (resistor == MAX31865_RESISTOR_100PT)                                                /* choose resistor type */
    {
        resistor = 100.0f;                                                                          /* set resistor type 100 */
    }
    else
    {
        resistor = 1000.0f;                                                                         /* set resistor type 1000 */
    }
    *temp = a_max31865_temperature_conversion((float)(*raw), resistor, ref_resistor);       /* calculate */
    return 0;                                                                                       /* success return 0 */
}
uint8_t max31865_set_reg(max31865_handle_t *handle, uint8_t reg, uint8_t value)
{
    
    {
        
    }
    
    {
        
    }
    return spi_write(reg | WRITE_ADDRESS_MASK, (uint8_t *)&value, 1);        /* write to reg */
}
uint8_t max31865_get_reg(max31865_handle_t *handle, uint8_t reg, uint8_t *value)
{
    
    {
        
    }
    
    {
        
    }
    return spi_read(reg, (uint8_t *)value, 1);        /* read from reg */
}
uint8_t max31865_info(max31865_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(max31865_info_t));                       /* initialize max31865 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "SPI", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
