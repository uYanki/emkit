
#ifndef DRIVER_MAX31865_H
#define DRIVER_MAX31865_H
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MAX31865_BOOL_FALSE = 0x00,  // disable function
    MAX31865_BOOL_TRUE  = 0x01,  // enable function
} max31865_bool_t;
typedef enum {
    MAX31865_WIRE_2 = 0x00,  // 2 wire mode
    MAX31865_WIRE_3 = 0x01,  // 3 wire mode
    MAX31865_WIRE_4 = 0x00,  // 4 wire mode
} max31865_wire_t;
typedef enum {
    MAX31865_RESISTOR_100PT  = 0x00,  // 100pt resistor type
    MAX31865_RESISTOR_1000PT = 0x01,  // 1000pt resisitor type
} max31865_resistor_t;
typedef enum {
    MAX31865_FILTER_SELECT_60HZ = 0x00,  // 60Hz noise filter
    MAX31865_FILTER_SELECT_50HZ = 0x01,  // 50Hz noise filter
} max31865_filter_select_t;
typedef enum {
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_NO_ACTION            = 0x00,  // no action
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_AUTOMATIC_DELAY      = 0x01,  // automatic delay
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_MANUAL_DELAY_CYCLE_1 = 0x02,  // manual delay cycle 1
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_MANUAL_DELAY_CYCLE_2 = 0x03,  // manual delay cycle 2
} max31865_fault_detection_cycle_control_t;
typedef enum {
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_STATUS_FINISHED                     = 0x00,  // finished status
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_STATUS_AUTOMATIC_RUNNING            = 0x01,  // automatic running status
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_STATUS_MANUAL_DELAY_CYCLE_1_RUNNING = 0x02,  // manual delay cycle 1 running status
    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_STATUS_MANUAL_DELAY_CYCLE_2_RUNNING = 0x03,  // manual delay cycle 2 running status
} max31865_fault_detection_cycle_control_status_t;
typedef enum {
    MAX31865_FAULT_STATUS_RTD_HIGH_THRESHOLD         = (1 << 7),  // rtd high threshold
    MAX31865_FAULT_STATUS_RTD_LOW_THRESHOLD          = (1 << 6),  // rtd low threshold
    MAX31865_FAULT_STATUS_REFIN_MORE_THAN_0P85_VBIAS = (1 << 5),  // ref more than 0.85 vbias
    MAX31865_FAULT_STATUS_REFIN_LESS_THAN_0P85_VBIAS = (1 << 4),  // ref less than 0.85 vbias
    MAX31865_FAULT_STATUS_RTDIN_LESS_THAN_0P85_VBIAS = (1 << 3),  // rtdin less than 0.85 vbias
    MAX31865_FAULT_STATUS_OVER_UNDER_VOLTAGE         = (1 << 2),  // over under voltage
} max31865_fault_status_t;
typedef struct max31865_handle_s {
    uint8_t inited;        // inited flag
    uint8_t resistor;      // resistor type
    float   ref_resistor;  // reference resistor value
} max31865_handle_t;

uint8_t max31865_info(max31865_info_t* info);
uint8_t max31865_init(max31865_handle_t* handle);
uint8_t max31865_deinit(max31865_handle_t* handle);
uint8_t max31865_single_read(max31865_handle_t* handle, uint16_t* raw, float* temp);
uint8_t max31865_start_continuous_read(max31865_handle_t* handle);
uint8_t max31865_stop_continuous_read(max31865_handle_t* handle);
uint8_t max31865_continuous_read(max31865_handle_t* handle, uint16_t* raw, float* temp);
uint8_t max31865_set_filter_select(max31865_handle_t* handle, max31865_filter_select_t filter);
uint8_t max31865_get_filter_select(max31865_handle_t* handle, max31865_filter_select_t* filter);
uint8_t max31865_set_wire(max31865_handle_t* handle, max31865_wire_t wire);
uint8_t max31865_get_wire(max31865_handle_t* handle, max31865_wire_t* wire);
uint8_t max31865_set_reference_resistor(max31865_handle_t* handle, float value);
uint8_t max31865_get_reference_resistor(max31865_handle_t* handle, float* value);
uint8_t max31865_set_resistor(max31865_handle_t* handle, max31865_resistor_t resistor);
uint8_t max31865_get_resistor(max31865_handle_t* handle, max31865_resistor_t* resistor);
uint8_t max31865_set_vbias(max31865_handle_t* handle, max31865_bool_t enable);
uint8_t max31865_get_vbias(max31865_handle_t* handle, max31865_bool_t* enable);
uint8_t max31865_clear_fault_status(max31865_handle_t* handle);
uint8_t max31865_get_fault_status(max31865_handle_t* handle, uint8_t* status);
uint8_t max31865_set_high_fault_threshold(max31865_handle_t* handle, uint16_t threshold);
uint8_t max31865_get_high_fault_threshold(max31865_handle_t* handle, uint16_t* threshold);
uint8_t max31865_set_low_fault_threshold(max31865_handle_t* handle, uint16_t threshold);
uint8_t max31865_get_low_fault_threshold(max31865_handle_t* handle, uint16_t* threshold);
uint8_t max31865_set_fault_detection_cycle_control(max31865_handle_t* handle, max31865_fault_detection_cycle_control_t control);
uint8_t max31865_get_fault_detection_cycle_control(max31865_handle_t* handle, max31865_fault_detection_cycle_control_status_t* status);
uint8_t max31865_set_reg(max31865_handle_t* handle, uint8_t reg, uint8_t value);
uint8_t max31865_get_reg(max31865_handle_t* handle, uint8_t reg, uint8_t* value);
#ifdef __cplusplus
}
#endif
#endif
