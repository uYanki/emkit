
#ifndef DRIVER_MAX31865_SHOT_H
#define DRIVER_MAX31865_SHOT_H
#include "driver_max31865_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MAX31865_SHOT_DEFAULT_FILTER_SELECT                    MAX31865_FILTER_SELECT_50HZ                                   // filter select 50Hz 
#define MAX31865_SHOT_DEFAULT_FAULT_DETECTION_CYCLE_CONTROL    MAX31865_FAULT_DETECTION_CYCLE_CONTROL_AUTOMATIC_DELAY        // automatic delay 
#define MAX31865_SHOT_DEFAULT_HIGH_FAULT_THRESHOLD             0xFFFEU                                                       // high fault threshold 
#define MAX31865_SHOT_DEFAULT_LOW_FAULT_THRESHOLD              0x0000U                                                       // low fault threshold 
uint8_t max31865_shot_init(max31865_wire_t wire, max31865_resistor_t type, float ref_resistor);
uint8_t max31865_shot_deinit(void);
uint8_t max31865_shot_read(float *temp);
#ifdef __cplusplus
}
#endif
#endif
