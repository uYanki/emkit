
#ifndef DRIVER_MAX6675_READ_TEST_H
#define DRIVER_MAX6675_READ_TEST_H
#include "driver_max6675_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max6675_read_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
