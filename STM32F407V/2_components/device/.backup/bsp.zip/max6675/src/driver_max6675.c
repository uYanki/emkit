
#include "driver_max6675.h"

#define MANUFACTURER_NAME         "Maxim Integrated"                // manufacturer name
#define SUPPLY_VOLTAGE_MIN        3.0f                              // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f                              // chip max supply voltage




static uint8_t a_max6675_spi_read(max6675_handle_t *handle, uint16_t *data)
{
    uint8_t buf[2];
    if (spi_read_cmd(buf, 2) != 0)                 /* spi read */
    {
        
    }
    else
    {
        *data = (((uint16_t)buf[0]) << 8) | buf[1];        /* get the data */
        
        return 0;                                          /* success return 0 */
    }
}
uint8_t max6675_init(max6675_handle_t *handle)
{
    uint16_t data;
    
    {
        
    }
    if (debug_print == NULL)                                    /* check debug_print */
    {
        
    }
    if (spi_init == NULL)                                       /* check spi_init */
    {
        
       
        
    }
    if (spi_deinit == NULL)                                     /* check spi_deinit */
    {
        
       
        
    }
    if (spi_read_cmd == NULL)                                   /* check spi_read_cmd */
    {
        
       
        
    }
    if (delay_ms == NULL)                                       /* check delay_ms */
    {
        
       
        
    }
    if (spi_init() != 0)                                        /* spi init */
    {
        
        
        
    }
    if (a_max6675_spi_read( &data) != 0)                         /* read data */
    {
        
       
        
    }
    inited = 1;                                                 /* flag finish initialization */
    return 0;                                                           /* success return 0 */
}
uint8_t max6675_deinit(max6675_handle_t *handle)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = spi_deinit();                                      /* spi deinit */
    if (res != 0)                                                    /* check result */
    {
        
       
        
    }
    inited = 0;                                              /* flag close */
    return 0;                                                        /* success return 0 */
}
uint8_t max6675_read(max6675_handle_t *handle,uint16_t *raw, float *temp)
{
    uint8_t res;
    uint16_t data;
    
    {
        
    }
    
    {
        
    }
    res = a_max6675_spi_read( &data);                                  /* read data */
    if (res != 0)                                                             /* check result */
    {
        
       
        
    }
    if ((data & (1 << 2)) != 0)                                               /* check the error */
    {
        
       
        
    }
    *raw = data >> 3;                                                         /* get the raw data */
    *temp = (float)(*raw) * 0.25f;                                            /* convert data */
    return 0;                                                                 /* success return 0 */
}
uint8_t max6675_get_reg(max6675_handle_t *handle, uint16_t *data)
{
    
    {
        
    }
    
    {
        
    }
    return a_max6675_spi_read( data);       /* read data */
}
uint8_t max6675_info(max6675_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(max6675_info_t));                        /* initialize max6675 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "SPI", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
