
#ifndef DRIVER_MAX6675_H
#define DRIVER_MAX6675_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct max6675_handle_s {
    uint8_t inited;  // inited flag
} max6675_handle_t;

uint8_t max6675_info(max6675_info_t* info);
uint8_t max6675_init(max6675_handle_t* handle);
uint8_t max6675_deinit(max6675_handle_t* handle);
uint8_t max6675_read(max6675_handle_t* handle, uint16_t* raw, float* temp);
uint8_t max6675_get_reg(max6675_handle_t* handle, uint16_t* data);
#ifdef __cplusplus
}
#endif
#endif
