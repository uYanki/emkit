
#ifndef DRIVER_MAX6675_BASIC_H
#define DRIVER_MAX6675_BASIC_H
#include "driver_max6675_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max6675_basic_init(void);
uint8_t max6675_basic_deinit(void);
uint8_t max6675_basic_read(uint16_t *raw, float *temp);
#ifdef __cplusplus
}
#endif
#endif
