
#include "driver_max6675_basic.h"
static max6675_handle_t gs_handle;        // max6675 handle
uint8_t max6675_basic_init(void)
{
    uint8_t res;
    /* link functions */
    DRIVER_MAX6675_LINK_INIT(&gs_handle, max6675_handle_t);
    DRIVER_MAX6675_LINK_SPI_INIT(&gs_handle, max6675_interface_spi_init);
    DRIVER_MAX6675_LINK_SPI_DEINIT(&gs_handle, max6675_interface_spi_deinit);
    DRIVER_MAX6675_LINK_SPI_READ_COMMAND(&gs_handle, max6675_interface_spi_read_cmd);
    DRIVER_MAX6675_LINK_DELAY_MS(&gs_handle, max6675_interface_delay_ms);
    DRIVER_MAX6675_LINK_DEBUG_PRINT(&gs_handle, max6675_interface_debug_print);
    /* max6675 init */
    res = max6675_init(&gs_handle);
    if (res != 0)
    {
        max6675_interface_debug_print("max6675: init failed.\n");
        
        return 1;
    }
    return 0;
}
uint8_t max6675_basic_deinit(void)
{
    /* close max6675 */
    if (max6675_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t max6675_basic_read(uint16_t *raw, float *temp)
{
    /* read data */
    if (max6675_read(&gs_handle, raw, temp) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
