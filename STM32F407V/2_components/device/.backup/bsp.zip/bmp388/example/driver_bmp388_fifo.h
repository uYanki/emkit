
#ifndef DRIVER_BMP388_FIFO_H
#define DRIVER_BMP388_FIFO_H
#include "driver_bmp388_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define BMP388_FIFO_DEFAULT_SPI_WIRE                 BMP388_SPI_WIRE_4                        // 4 wire spi 
#define BMP388_FIFO_DEFAULT_IIC_WATCHDOG_TIMER       BMP388_BOOL_TRUE                         // enable iic watchdog timer 
#define BMP388_FIFO_DEFAULT_IIC_WATCHDOG_PERIOD      BMP388_IIC_WATCHDOG_PERIOD_40_MS         // set watchdog timer period 40ms 
#define BMP388_FIFO_DEFAULT_FIFO_STOP_ON_FULL        BMP388_BOOL_FALSE                        // disable fifo stop on full 
#define BMP388_FIFO_DEFAULT_FIFO_WATERMARK           256                                      // 256 fifo watermark 
#define BMP388_FIFO_DEFAULT_FIFO_SENSORTIME_ON       BMP388_BOOL_TRUE                         // enable fifo sensortime on 
#define BMP388_FIFO_DEFAULT_FIFO_PRESSURE_ON         BMP388_BOOL_TRUE                         // enable fifo pressure on 
#define BMP388_FIFO_DEFAULT_FIFO_TEMPERATURE_ON      BMP388_BOOL_TRUE                         // enable fifo temperature on 
#define BMP388_FIFO_DEFAULT_FIFO_SUBSAMPLING         0                                        // fifo subsamping 
#define BMP388_FIFO_DEFAULT_FIFO_DATA_SOURCE         BMP388_FIFO_DATA_SOURCE_FILTERED         // fifo data source filtered 
#define BMP388_FIFO_DEFAULT_INTERRUPT_PIN_TYPE       BMP388_INTERRUPT_PIN_TYPE_PUSH_PULL      // interrupt pin type push pull 
#define BMP388_FIFO_DEFAULT_INTERRUPT_ACTIVE_LEVEL   BMP388_INTERRUPT_ACTIVE_LEVEL_HIGHER     // interrupt pin active level higher 
#define BMP388_FIFO_DEFAULT_INTERRUPT_WATERMARK      BMP388_BOOL_TRUE                         // enable interrupt watermark 
#define BMP388_FIFO_DEFAULT_INTERRUPT_FIFO_FULL      BMP388_BOOL_FALSE                        // disable interrupt fifo full 
#define BMP388_FIFO_DEFAULT_INTERRUPT_DATA_READY     BMP388_BOOL_FALSE                        // disable interrupt data ready 
#define BMP388_FIFO_DEFAULT_LATCH_INTERRUPT          BMP388_BOOL_TRUE                         // latch interrupt pin and interrupt status 
#define BMP388_FIFO_DEFAULT_PRESSURE                 BMP388_BOOL_TRUE                         // enable pressure 
#define BMP388_FIFO_DEFAULT_TEMPERATURE              BMP388_BOOL_TRUE                         // enable temperature 
#define BMP388_FIFO_DEFAULT_PRESSURE_OVERSAMPLING    BMP388_OVERSAMPLING_x32                  // pressure oversampling x32 
#define BMP388_FIFO_DEFAULT_TEMPERATURE_OVERSAMPLING BMP388_OVERSAMPLING_x2                   // temperature oversampling x2 
#define BMP388_FIFO_DEFAULT_ODR                      BMP388_ODR_12P5_HZ                       // output data rate 12.5Hz 
#define BMP388_FIFO_DEFAULT_FILTER_COEFFICIENT       BMP388_FILTER_COEFFICIENT_15             // set filter coefficient 15 
uint8_t bmp388_fifo_irq_handler(void);
uint8_t bmp388_fifo_init(bmp388_interface_t interface, bmp388_address_t addr_pin,
                         void (*fifo_receive_callback)(uint8_t type));
uint8_t bmp388_fifo_deinit(void);
uint8_t bmp388_fifo_read(uint8_t *buf, uint16_t buf_len, bmp388_frame_t *frame, uint16_t *frame_len);
#ifdef __cplusplus
}
#endif
#endif
