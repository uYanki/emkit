
#ifndef DRIVER_BMP388_INTERRUPT_TEST_H
#define DRIVER_BMP388_INTERRUPT_TEST_H
#include "driver_bmp388_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t bmp388_interrupt_test_irq_handler(void);
uint8_t bmp388_interrupt_test(bmp388_interface_t interface, bmp388_address_t addr_pin, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
