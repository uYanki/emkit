
#ifndef DRIVER_BMP388_REGISTER_TEST_H
#define DRIVER_BMP388_REGISTER_TEST_H
#include "driver_bmp388_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t bmp388_register_test(bmp388_interface_t interface, bmp388_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
