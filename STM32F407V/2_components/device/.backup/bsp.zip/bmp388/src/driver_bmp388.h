
#ifndef DRIVER_BMP388_H
#define DRIVER_BMP388_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    BMP388_INTERFACE_IIC = 0x00,  // iic interface
    BMP388_INTERFACE_SPI = 0x01,  // spi interface
} bmp388_interface_t;
typedef enum {
    BMP388_ADDRESS_ADO_LOW  = (0x76 << 1),  // ADO is low
    BMP388_ADDRESS_ADO_HIGH = (0x77 << 1),  // ADO is HIGH
} bmp388_address_t;
typedef enum {
    BMP388_BOOL_FALSE = 0x00,  // false
    BMP388_BOOL_TRUE  = 0x01,  // true
} bmp388_bool_t;
typedef enum {
    BMP388_ERROR_FATAL = (1 << 0),  // fatal error
    BMP388_ERROR_CMD   = (1 << 1),  // command error
    BMP388_ERROR_CONF  = (1 << 2),  // conf error
} bmp388_error_t;
typedef enum {
    BMP388_STATUS_COMMAND_READY = (1 << 4),  // command ready status
    BMP388_STATUS_PRESS_READY   = (1 << 5),  // press ready status
    BMP388_STATUS_TEMP_READY    = (1 << 6),  // temp ready status
} bmp388_status_t;
typedef enum {
    BMP388_EVENT_NONE                  = (0 << 0),  // event none
    BMP388_EVENT_POWER_UP_OR_SOFTRESET = (1 << 0),  // event power up or soft reset
} bmp388_event_t;
typedef enum {
    BMP388_FIFO_DATA_SOURCE_UNFILTERED = 0,  // fifo data source unfiltered
    BMP388_FIFO_DATA_SOURCE_FILTERED   = 1,  // fifo data source filtered
} bmp388_fifo_data_source_t;
typedef enum {
    BMP388_INTERRUPT_STATUS_FIFO_WATERMARK = (1 << 0),  // fifo watermark interrupt status
    BMP388_INTERRUPT_STATUS_FIFO_FULL      = (1 << 1),  // fifo full interrupt status
    BMP388_INTERRUPT_STATUS_DATA_READY     = (1 << 3),  // data ready interrupt status
} bmp388_interrupt_status_t;
typedef enum {
    BMP388_INTERRUPT_ACTIVE_LEVEL_LOWER  = 0x00,  // active level lower
    BMP388_INTERRUPT_ACTIVE_LEVEL_HIGHER = 0x01,  // active level higher
} bmp388_interrupt_active_level_t;
typedef enum {
    BMP388_INTERRUPT_PIN_TYPE_PUSH_PULL  = 0x00,  // push pull pin type
    BMP388_INTERRUPT_PIN_TYPE_OPEN_DRAIN = 0x01,  // open drain pin type
} bmp388_interrupt_pin_type_t;
typedef enum {
    BMP388_SPI_WIRE_4 = 0x00,  // 4 wire
    BMP388_SPI_WIRE_3 = 0x01,  // 3 wire
} bmp388_spi_wire_t;
typedef enum {
    BMP388_IIC_WATCHDOG_PERIOD_1P25_MS = 0x00,  // iic watchdog period 1.25 ms
    BMP388_IIC_WATCHDOG_PERIOD_40_MS   = 0x01,  // iic watchdog period 40 ms
} bmp388_iic_watchdog_period_t;
typedef enum {
    BMP388_MODE_SLEEP_MODE  = 0x00,  // sleep mode
    BMP388_MODE_FORCED_MODE = 0x01,  // forced mode
    BMP388_MODE_NORMAL_MODE = 0x03,  // normal mode
} bmp388_mode_t;
typedef enum {
    BMP388_OVERSAMPLING_x1  = 0x00,  // oversampling x1
    BMP388_OVERSAMPLING_x2  = 0x01,  // oversampling x2
    BMP388_OVERSAMPLING_x4  = 0x02,  // oversampling x4
    BMP388_OVERSAMPLING_x8  = 0x03,  // oversampling x8
    BMP388_OVERSAMPLING_x16 = 0x04,  // oversampling x16
    BMP388_OVERSAMPLING_x32 = 0x05,  // oversampling x32
} bmp388_oversampling_t;
typedef enum {
    BMP388_ODR_200_HZ    = 0x00,  // 200Hz
    BMP388_ODR_100_HZ    = 0x01,  // 100Hz
    BMP388_ODR_50_HZ     = 0x02,  // 50Hz
    BMP388_ODR_25_HZ     = 0x03,  // 25Hz
    BMP388_ODR_12P5_HZ   = 0x04,  // 12.5Hz
    BMP388_ODR_6P25_HZ   = 0x05,  // 6.25Hz
    BMP388_ODR_3P1_HZ    = 0x06,  // 3.1Hz
    BMP388_ODR_1P5_HZ    = 0x07,  // 1.5Hz
    BMP388_ODR_0P78_HZ   = 0x08,  // 0.78Hz
    BMP388_ODR_0P39_HZ   = 0x09,  // 0.39Hz
    BMP388_ODR_0P2_HZ    = 0x0A,  // 0.2Hz
    BMP388_ODR_0P1_HZ    = 0x0B,  // 0.1Hz
    BMP388_ODR_0P05_HZ   = 0x0C,  // 0.05Hz
    BMP388_ODR_0P02_HZ   = 0x0D,  // 0.02Hz
    BMP388_ODR_0P01_HZ   = 0x0E,  // 0.01Hz
    BMP388_ODR_0P006_HZ  = 0x0F,  // 0.006Hz
    BMP388_ODR_0P003_HZ  = 0x10,  // 0.003Hz
    BMP388_ODR_0P0015_HZ = 0x11,  // 0.0015Hz
} bmp388_odr_t;
typedef enum {
    BMP388_FILTER_COEFFICIENT_0   = 0x00,  // coefficient 0
    BMP388_FILTER_COEFFICIENT_1   = 0x01,  // coefficient 1
    BMP388_FILTER_COEFFICIENT_3   = 0x02,  // coefficient 3
    BMP388_FILTER_COEFFICIENT_7   = 0x03,  // coefficient 7
    BMP388_FILTER_COEFFICIENT_15  = 0x04,  // coefficient 15
    BMP388_FILTER_COEFFICIENT_31  = 0x05,  // coefficient 31
    BMP388_FILTER_COEFFICIENT_63  = 0x06,  // coefficient 63
    BMP388_FILTER_COEFFICIENT_127 = 0x07,  // coefficient 127
} bmp388_filter_coefficient_t;
typedef enum {
    BMP388_FRAME_TYPE_TEMPERATURE = 0x01,  // temperature frame type
    BMP388_FRAME_TYPE_PRESSURE    = 0x02,  // pressure frame type
    BMP388_FRAME_TYPE_SENSORTIME  = 0x03,  // sensortime frame type
} bmp388_frame_type_t;
typedef struct bmp388_frame_s {
    bmp388_frame_type_t type;  // frame type
    uint32_t            raw;   // raw data
    float               data;  // converted data
} bmp388_frame_t;
typedef struct bmp388_handle_s {
    uint8_t iic_addr;                                                             // iic device address
    uint8_t buf[512 + 1];                                                         // inner buffer
    uint8_t (*iic_init)(void);                                                    // point to an iic_init function address
    uint8_t (*iic_deinit)(void);                                                  // point to an iic_deinit function address
    uint8_t (*iic_read)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);   // point to an iic_read function address
    uint8_t (*iic_write)(uint8_t addr, uint8_t reg, uint8_t* buf, uint16_t len);  // point to an iic_write function address
    uint8_t (*spi_init)(void);                                                    // point to a spi_init function address
    uint8_t (*spi_deinit)(void);                                                  // point to a spi_deinit function address
    uint8_t (*spi_read)(uint8_t reg, uint8_t* buf, uint16_t len);                 // point to a spi_read function address
    uint8_t (*spi_write)(uint8_t reg, uint8_t* buf, uint16_t len);                // point to a spi_write function address
    void (*receive_callback)(uint8_t type);                                       // point to a receive_callback function address
    void (*delay_ms)(uint32_t ms);                                                // point to a delay_ms function address
    void (*debug_print)(const char* const fmt, ...);                              // point to a debug_print function address
    uint8_t  inited;                                                              // inited flag
    uint8_t  iic_spi;                                                             // iic spi interface
    uint16_t t1;                                                                  // t1 register
    uint16_t t2;                                                                  // t2 register
    int8_t   t3;                                                                  // t3 register
    int16_t  p1;                                                                  // p1 register
    int16_t  p2;                                                                  // p2 register
    int8_t   p3;                                                                  // p3 register
    int8_t   p4;                                                                  // p4 register
    uint16_t p5;                                                                  // p5 register
    uint16_t p6;                                                                  // p6 register
    int8_t   p7;                                                                  // p7 register
    int8_t   p8;                                                                  // p8 register
    int16_t  p9;                                                                  // p9 register
    int8_t   p10;                                                                 // p10 register
    int8_t   p11;                                                                 // p11 register
    int64_t  t_fine;                                                              // t_fine register
} bmp388_handle_t;

uint8_t bmp388_info(bmp388_info_t* info);
uint8_t bmp388_set_addr_pin(bmp388_handle_t* handle, bmp388_address_t addr_pin);
uint8_t bmp388_get_addr_pin(bmp388_handle_t* handle, bmp388_address_t* addr_pin);
uint8_t bmp388_set_interface(bmp388_handle_t* handle, bmp388_interface_t interface);
uint8_t bmp388_get_interface(bmp388_handle_t* handle, bmp388_interface_t* interface);
uint8_t bmp388_irq_handler(bmp388_handle_t* handle);
uint8_t bmp388_init(bmp388_handle_t* handle);
uint8_t bmp388_deinit(bmp388_handle_t* handle);
uint8_t bmp388_read_temperature_pressure(bmp388_handle_t* handle, uint32_t* temperature_raw, float* temperature_c, uint32_t* pressure_raw, float* pressure_pa);
uint8_t bmp388_read_temperature(bmp388_handle_t* handle, uint32_t* raw, float* c);
uint8_t bmp388_read_pressure(bmp388_handle_t* handle, uint32_t* raw, float* pa);
uint8_t bmp388_get_error(bmp388_handle_t* handle, uint8_t* err);
uint8_t bmp388_get_status(bmp388_handle_t* handle, uint8_t* status);
uint8_t bmp388_get_sensortime(bmp388_handle_t* handle, uint32_t* t);
uint8_t bmp388_get_event(bmp388_handle_t* handle, bmp388_event_t* event);
uint8_t bmp388_set_spi_wire(bmp388_handle_t* handle, bmp388_spi_wire_t wire);
uint8_t bmp388_get_spi_wire(bmp388_handle_t* handle, bmp388_spi_wire_t* wire);
uint8_t bmp388_set_iic_watchdog_timer(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_iic_watchdog_timer(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_iic_watchdog_period(bmp388_handle_t* handle, bmp388_iic_watchdog_period_t period);
uint8_t bmp388_get_iic_watchdog_period(bmp388_handle_t* handle, bmp388_iic_watchdog_period_t* period);
uint8_t bmp388_set_pressure(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_pressure(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_temperature(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_temperature(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_mode(bmp388_handle_t* handle, bmp388_mode_t mode);
uint8_t bmp388_get_mode(bmp388_handle_t* handle, bmp388_mode_t* mode);
uint8_t bmp388_set_pressure_oversampling(bmp388_handle_t* handle, bmp388_oversampling_t oversampling);
uint8_t bmp388_get_pressure_oversampling(bmp388_handle_t* handle, bmp388_oversampling_t* oversampling);
uint8_t bmp388_set_temperature_oversampling(bmp388_handle_t* handle, bmp388_oversampling_t oversampling);
uint8_t bmp388_get_temperature_oversampling(bmp388_handle_t* handle, bmp388_oversampling_t* oversampling);
uint8_t bmp388_set_odr(bmp388_handle_t* handle, bmp388_odr_t odr);
uint8_t bmp388_get_odr(bmp388_handle_t* handle, bmp388_odr_t* odr);
uint8_t bmp388_set_filter_coefficient(bmp388_handle_t* handle, bmp388_filter_coefficient_t coefficient);
uint8_t bmp388_get_filter_coefficient(bmp388_handle_t* handle, bmp388_filter_coefficient_t* coefficient);
uint8_t bmp388_softreset(bmp388_handle_t* handle);
uint8_t bmp388_extmode_en_middle(bmp388_handle_t* handle);
uint8_t bmp388_get_interrupt_status(bmp388_handle_t* handle, uint8_t* status);
uint8_t bmp388_set_interrupt_pin_type(bmp388_handle_t* handle, bmp388_interrupt_pin_type_t pin_type);
uint8_t bmp388_get_interrupt_pin_type(bmp388_handle_t* handle, bmp388_interrupt_pin_type_t* pin_type);
uint8_t bmp388_set_interrupt_active_level(bmp388_handle_t* handle, bmp388_interrupt_active_level_t level);
uint8_t bmp388_get_interrupt_active_level(bmp388_handle_t* handle, bmp388_interrupt_active_level_t* level);
uint8_t bmp388_set_latch_interrupt_pin_and_interrupt_status(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_latch_interrupt_pin_and_interrupt_status(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_interrupt_fifo_watermark(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_interrupt_fifo_watermark(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_interrupt_fifo_full(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_interrupt_fifo_full(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_interrupt_data_ready(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_interrupt_data_ready(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_get_fifo_length(bmp388_handle_t* handle, uint16_t* length);
uint8_t bmp388_get_fifo_data(bmp388_handle_t* handle, uint8_t* data, uint16_t length);
uint8_t bmp388_set_fifo_watermark(bmp388_handle_t* handle, uint16_t watermark);
uint8_t bmp388_get_fifo_watermark(bmp388_handle_t* handle, uint16_t* watermark);
uint8_t bmp388_set_fifo(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_fifo(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_fifo_stop_on_full(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_fifo_stop_on_full(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_fifo_sensortime_on(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_fifo_sensortime_on(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_fifo_pressure_on(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_fifo_pressure_on(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_fifo_temperature_on(bmp388_handle_t* handle, bmp388_bool_t enable);
uint8_t bmp388_get_fifo_temperature_on(bmp388_handle_t* handle, bmp388_bool_t* enable);
uint8_t bmp388_set_fifo_subsampling(bmp388_handle_t* handle, uint8_t subsample);
uint8_t bmp388_get_fifo_subsampling(bmp388_handle_t* handle, uint8_t* subsample);
uint8_t bmp388_set_fifo_data_source(bmp388_handle_t* handle, bmp388_fifo_data_source_t source);
uint8_t bmp388_get_fifo_data_source(bmp388_handle_t* handle, bmp388_fifo_data_source_t* source);
uint8_t bmp388_flush_fifo(bmp388_handle_t* handle);
uint8_t bmp388_read_fifo(bmp388_handle_t* handle, uint8_t* buf, uint16_t* len);
uint8_t bmp388_fifo_parse(bmp388_handle_t* handle, uint8_t* buf, uint16_t buf_len, bmp388_frame_t* frame, uint16_t* frame_len);
uint8_t bmp388_set_reg(bmp388_handle_t* handle, uint8_t reg, uint8_t value);
uint8_t bmp388_get_reg(bmp388_handle_t* handle, uint8_t reg, uint8_t* value);
#ifdef __cplusplus
}
#endif
#endif
