
#include "driver_bmp388.h"

#define MANUFACTURER_NAME  "Bosch"        // manufacturer name
#define SUPPLY_VOLTAGE_MIN 1.65f          // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f           // chip max supply voltage




#define BMP388_REG_CMD           0x7E // command register
#define BMP388_REG_NVM_PAR_T1_L  0x31 // NVM PAR T1 low register
#define BMP388_REG_NVM_PAR_T1_H  0x32 // NVM PAR T1 high register
#define BMP388_REG_NVM_PAR_T2_L  0x33 // NVM PAR T2 low register
#define BMP388_REG_NVM_PAR_T2_H  0x34 // NVM PAR T2 high register
#define BMP388_REG_NVM_PAR_T3    0x35 // NVM PAR T3 register
#define BMP388_REG_NVM_PAR_P1_L  0x36 // NVM PAR P1 low register
#define BMP388_REG_NVM_PAR_P1_H  0x37 // NVM PAR P1 hgih register
#define BMP388_REG_NVM_PAR_P2_L  0x38 // NVM PAR P2 low register
#define BMP388_REG_NVM_PAR_P2_H  0x39 // NVM PAR P2 hgih register
#define BMP388_REG_NVM_PAR_P3    0x3A // NVM PAR P3 register
#define BMP388_REG_NVM_PAR_P4    0x3B // NVM PAR P4 register
#define BMP388_REG_NVM_PAR_P5_L  0x3C // NVM PAR P5 low register
#define BMP388_REG_NVM_PAR_P5_H  0x3D // NVM PAR P5 hgih register
#define BMP388_REG_NVM_PAR_P6_L  0x3E // NVM PAR P6 low register
#define BMP388_REG_NVM_PAR_P6_H  0x3F // NVM PAR P6 hgih register
#define BMP388_REG_NVM_PAR_P7    0x40 // NVM PAR P7 register
#define BMP388_REG_NVM_PAR_P8    0x41 // NVM PAR P8 register
#define BMP388_REG_NVM_PAR_P9_L  0x42 // NVM PAR P9 low register
#define BMP388_REG_NVM_PAR_P9_H  0x43 // NVM PAR P9 hgih register
#define BMP388_REG_NVM_PAR_P10   0x44 // NVM PAR P10 register
#define BMP388_REG_NVM_PAR_P11   0x45 // NVM PAR P11 register
#define BMP388_REG_CONFIG        0x1F // configure register
#define BMP388_REG_ODR           0x1D // odr register
#define BMP388_REG_OSR           0x1C // osr register
#define BMP388_REG_PWR_CTRL      0x1B // power control register
#define BMP388_REG_IF_CONF       0x1A // if configure register
#define BMP388_REG_INT_CTRL      0x19 // interrupt control register
#define BMP388_REG_FIFO_CONFIG_2 0x18 // fifo configure 2 register
#define BMP388_REG_FIFO_CONFIG_1 0x17 // fifo configure 1 register
#define BMP388_REG_FIFO_WTM_1    0x16 // fifo watermark 1 register
#define BMP388_REG_FIFO_WTM_0    0x15 // fifo watermark 2 register
#define BMP388_REG_FIFO_DATA     0x14 // fifo data register
#define BMP388_REG_FIFO_LENGTH_1 0x13 // fifo length 1 register
#define BMP388_REG_FIFO_LENGTH_0 0x12 // fifo length 0 register
#define BMP388_REG_INT_STATUS    0x11 // interrupt status register
#define BMP388_REG_EVENT         0x10 // event register
#define BMP388_REG_SENSORTIME_2  0x0E // sensortime 2 register
#define BMP388_REG_SENSORTIME_1  0x0D // sensortime 1 register
#define BMP388_REG_SENSORTIME_0  0x0C // sensortime 0 register
#define BMP388_REG_DATA_5        0x09 // data 5 register
#define BMP388_REG_DATA_4        0x08 // data 4 register
#define BMP388_REG_DATA_3        0x07 // data 3 register
#define BMP388_REG_DATA_2        0x06 // data 2 register
#define BMP388_REG_DATA_1        0x05 // data 1 register
#define BMP388_REG_DATA_0        0x04 // data 0 register
#define BMP388_REG_STATUS        0x03 // status register
#define BMP388_REG_ERR_REG       0x02 // error register
#define BMP388_REG_CHIP_ID       0x00 // chip id register
static uint8_t a_bmp388_iic_spi_read( uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (iic_spi == BMP388_INTERFACE_IIC) /* iic interface */
    {
        if (iic_read(iic_addr, reg, buf, len) != 0) /* iic read */
        {
            
        } else {
            return 0; /* success return 0 */
        }
    } else /* spi interface */
    {
        reg |= 1 << 7; /* set read mode */
        if (spi_read(reg, buf,
                             len > 512 ? (512 + 1) : (len + 1)) != 0) /* spi read */
        {
            
        }
        memcpy(buf, buf + 1, (len > 512) ? 512 : len); /* copy data */
        return 0; /* success return 0 */
    }
}
static uint8_t a_bmp388_iic_spi_write( uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (iic_spi == BMP388_INTERFACE_IIC) /* iic interface */
    {
        uint16_t i;
        for (i = 0; i < len; i++) /* write data one byte by one byte */
        {
            if (iic_write(iic_addr,
                                  (uint8_t)(reg + i), buf + i, 1) != 0) /* iic write */
            {
                
            }
        }
        return 0; /* success return 0 */
    } else {
        uint16_t i;
        reg &= ~(1 << 7);         /* write mode */
        for (i = 0; i < len; i++) /* write data one byte by one byte */
        {
            if (spi_write((uint8_t)(reg + i), buf + i, 1) != 0) /* spi write */
            {
                
            }
        }
        return 0; /* success return 0 */
    }
}
static uint8_t a_bmp388_get_calibration_data(bmp388_handle_t* handle)
{
    uint8_t buf[2];
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_T1_L, (uint8_t*)buf, 2) != 0) /* read t1 */
    {
        
        
    }
    t1 = (uint16_t)buf[1] << 8 | buf[0];                                       /* set t1 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_T2_L, (uint8_t*)buf, 2) != 0) /* read t2 */
    {
        
        
    }
    t2 = (uint16_t)buf[1] << 8 | buf[0];                                     /* set t2 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_T3, (uint8_t*)buf, 1) != 0) /* read t3 */
    {
        
        
    }
    t3 = (int8_t)(buf[0]);                                                     /* set t3 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P1_L, (uint8_t*)buf, 2) != 0) /* read p1 */
    {
        
        
    }
    p1 = (int16_t)((uint16_t)buf[1] << 8 | buf[0]);                            /* set p1 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P2_L, (uint8_t*)buf, 2) != 0) /* read p2 */
    {
        
        
    }
    p2 = (int16_t)((uint16_t)buf[1] << 8 | buf[0]);                          /* set p2 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P3, (uint8_t*)buf, 1) != 0) /* read p3 */
    {
        
        
    }
    p3 = (int8_t)(buf[0]);                                                   /* set p3 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P4, (uint8_t*)buf, 1) != 0) /* read p4 */
    {
        
        
    }
    p4 = (int8_t)(buf[0]);                                                     /* set p4 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P5_L, (uint8_t*)buf, 2) != 0) /* read p5 */
    {
        
        
    }
    p5 = (uint16_t)buf[1] << 8 | buf[0];                                       /* set p5 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P6_L, (uint8_t*)buf, 2) != 0) /* read p6l */
    {
        
        
    }
    p6 = (uint16_t)buf[1] << 8 | buf[0];                                     /* set p6 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P7, (uint8_t*)buf, 1) != 0) /* read p7 */
    {
        
        
    }
    p7 = (int8_t)(buf[0]);                                                   /* set p7 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P8, (uint8_t*)buf, 1) != 0) /* read p8 */
    {
        
        
    }
    p8 = (int8_t)(buf[0]);                                                     /* set p8 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P9_L, (uint8_t*)buf, 2) != 0) /* read p9l */
    {
        
        
    }
    p9 = (int16_t)((uint16_t)buf[1] << 8 | buf[0]);                           /* set p9 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P10, (uint8_t*)buf, 1) != 0) /* read p10 */
    {
        
        
    }
    p10 = (int8_t)(buf[0]);                                                   /* set p10 */
    if (a_bmp388_iic_spi_read( BMP388_REG_NVM_PAR_P11, (uint8_t*)buf, 1) != 0) /* read p11 */
    {
        
        
    }
    p11 = (int8_t)(buf[0]); /* set p11 */
    return 0; /* success return 0 */
}
static int64_t a_bmp388_compensate_temperature( uint32_t data)
{
    uint64_t partial_data1;
    uint64_t partial_data2;
    uint64_t partial_data3;
    int64_t  partial_data4;
    int64_t  partial_data5;
    int64_t  partial_data6;
    int64_t  comp_temp;
    /* calculate compensate temperature */
    partial_data1  = (uint64_t)(data - (256 * (uint64_t)(t1)));
    partial_data2  = (uint64_t)(t2 * partial_data1);
    partial_data3  = (uint64_t)(partial_data1 * partial_data1);
    partial_data4  = (int64_t)(((int64_t)partial_data3) * ((int64_t)t3));
    partial_data5  = ((int64_t)(((int64_t)partial_data2) * 262144) + (int64_t)partial_data4);
    partial_data6  = (int64_t)(((int64_t)partial_data5) / 4294967296U);
    t_fine = partial_data6;
    comp_temp      = (int64_t)((partial_data6 * 25) / 16384);
    return comp_temp;
}
static int64_t a_bmp388_compensate_pressure( uint32_t data)
{
    int64_t  partial_data1;
    int64_t  partial_data2;
    int64_t  partial_data3;
    int64_t  partial_data4;
    int64_t  partial_data5;
    int64_t  partial_data6;
    int64_t  offset;
    int64_t  sensitivity;
    uint64_t comp_press;
    /* calculate compensate pressure */
    partial_data1 = t_fine * t_fine;
    partial_data2 = partial_data1 / 64;
    partial_data3 = (partial_data2 * t_fine) / 256;
    partial_data4 = (p8 * partial_data3) / 32;
    partial_data5 = (p7 * partial_data1) * 16;
    partial_data6 = (p6 * t_fine) * 4194304;
    offset        = (int64_t)((int64_t)(p5) * (int64_t)140737488355328U) + partial_data4 + partial_data5 + partial_data6;
    partial_data2 = (((int64_t)p4) * partial_data3) / 32;
    partial_data4 = (p3 * partial_data1) * 4;
    partial_data5 = ((int64_t)(p2) - 16384) * ((int64_t)t_fine) * 2097152;
    sensitivity   = (((int64_t)(p1) - 16384) * (int64_t)70368744177664U) + partial_data2 + partial_data4 + partial_data5;
    partial_data1 = (sensitivity / 16777216) * data;
    partial_data2 = (int64_t)(p10) * (int64_t)(t_fine);
    partial_data3 = partial_data2 + (65536 * (int64_t)(p9));
    partial_data4 = (partial_data3 * data) / 8192;
    partial_data5 = (partial_data4 * data) / 512;
    partial_data6 = (int64_t)((uint64_t)data * (uint64_t)data);
    partial_data2 = ((int64_t)(p11) * (int64_t)(partial_data6)) / 65536;
    partial_data3 = (partial_data2 * data) / 128;
    partial_data4 = (offset / 4) + partial_data1 + partial_data5 + partial_data3;
    comp_press    = (((uint64_t)partial_data4 * 25) / (uint64_t)1099511627776U);
    return comp_press;
}
uint8_t bmp388_get_error( uint8_t* err)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_ERR_REG, (uint8_t*)err, 1); /* read config */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_status( uint8_t* status)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)status, 1); /* read status */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_sensortime( uint32_t* t)
{
    uint8_t res;
    uint8_t buf[3];
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_SENSORTIME_0, (uint8_t*)buf, 3); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    *t = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get time */
    return 0; /* success return 0 */
}
uint8_t bmp388_get_event( bmp388_event_t* event)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_EVENT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *event = (bmp388_event_t)(prev & (1 << 0)); /* get event */
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_status( uint8_t* status)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_STATUS, (uint8_t*)status, 1); /* read status */
    if (res != 0)                                                                    /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_length( uint16_t* length)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_LENGTH_0, (uint8_t*)buf, 2); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
        
    }
    *length = ((uint16_t)(buf[1] & 0x01) << 8) | buf[0]; /* get data */
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_data( uint8_t* data, uint16_t length)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_DATA, (uint8_t*)data, length); /* read data */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_watermark( uint16_t watermark)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = watermark & 0xFF;                                                        /* set low part */
    buf[1] = (watermark >> 8) & 0x01;                                                 /* set high part */
    res    = a_bmp388_iic_spi_write( BMP388_REG_FIFO_WTM_0, (uint8_t*)buf, 2); /* write config */
    if (res != 0)                                                                     /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_watermark( uint16_t* watermark)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_WTM_0, (uint8_t*)buf, 2); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *watermark = ((uint16_t)(buf[1] & 0x01) << 8) | buf[0]; /* get data */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                                  /* clear config */
    prev |= enable << 0;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)(prev & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_stop_on_full( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                                  /* clear config */
    prev |= enable << 1;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_stop_on_full( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 1) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_sensortime_on( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(1 << 2);                                                                  /* clear config */
    prev |= enable << 2;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_sensortime_on( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 2) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_pressure_on( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(1 << 3);                                                                  /* clear config */
    prev |= enable << 3;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_pressure_on( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 3) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_temperature_on( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(1 << 4);                                                                  /* clear config */
    prev |= enable << 4;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_temperature_on( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 4) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_subsampling( uint8_t subsample)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (subsample > 7) /* check subsample */
    {
        
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(7 << 0);                                                                  /* clear config */
    prev |= subsample << 0;                                                             /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_subsampling( uint8_t* subsample)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *subsample = (bmp388_bool_t)((prev >> 0) & 0x07); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_fifo_data_source( bmp388_fifo_data_source_t source)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    prev &= ~(3 << 3);                                                                  /* clear config */
    prev |= source << 3;                                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                       /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_fifo_data_source( bmp388_fifo_data_source_t* source)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_2, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    *source = (bmp388_fifo_data_source_t)((prev >> 3) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interrupt_pin_type( bmp388_interrupt_pin_type_t pin_type)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                             /* clear config */
    prev |= pin_type << 0;                                                         /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_pin_type( bmp388_interrupt_pin_type_t* pin_type)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *pin_type = (bmp388_interrupt_pin_type_t)(prev & 0x01); /* get interrupt pin type */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interrupt_active_level( bmp388_interrupt_active_level_t level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                             /* clear config */
    prev |= level << 1;                                                            /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_active_level( bmp388_interrupt_active_level_t* level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *level = (bmp388_interrupt_active_level_t)((prev >> 1) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_latch_interrupt_pin_and_interrupt_status( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 2);                                                             /* clear config */
    prev |= enable << 2;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_latch_interrupt_pin_and_interrupt_status( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 2) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interrupt_fifo_watermark( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 3);                                                             /* clear config */
    prev |= enable << 3;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_fifo_watermark( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 3) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interrupt_fifo_full( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 4);                                                             /* clear config */
    prev |= enable << 4;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_fifo_full( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 4) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interrupt_data_ready( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 6);                                                             /* clear config */
    prev |= enable << 6;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interrupt_data_ready( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 6) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_spi_wire( bmp388_spi_wire_t wire)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                            /* clear config */
    prev |= wire << 0;                                                            /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_spi_wire( bmp388_spi_wire_t* wire)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *wire = (bmp388_spi_wire_t)(prev & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_iic_watchdog_timer( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                            /* clear config */
    prev |= enable << 1;                                                          /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_iic_watchdog_timer( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 1) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_iic_watchdog_period( bmp388_iic_watchdog_period_t period)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 2);                                                            /* clear config */
    prev |= period << 2;                                                          /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_iic_watchdog_period( bmp388_iic_watchdog_period_t* period)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_IF_CONF, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *period = (bmp388_iic_watchdog_period_t)((prev >> 2) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_pressure( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                             /* clear config */
    prev |= enable << 0;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_pressure( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 0) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_temperature( bmp388_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                             /* clear config */
    prev |= enable << 1;                                                           /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_temperature( bmp388_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *enable = (bmp388_bool_t)((prev >> 1) & 0x01); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_mode( bmp388_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(3 << 4);                                                             /* clear config */
    prev |= mode << 4;                                                             /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_mode( bmp388_mode_t* mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *mode = (bmp388_mode_t)((prev >> 4) & 0x03); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_pressure_oversampling( bmp388_oversampling_t oversampling)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    prev &= ~(7 << 0);                                                        /* clear config */
    prev |= oversampling << 0;                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_pressure_oversampling( bmp388_oversampling_t* oversampling)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    *oversampling = (bmp388_oversampling_t)((prev >> 0) & 0x07); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_temperature_oversampling( bmp388_oversampling_t oversampling)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    prev &= ~(7 << 3);                                                        /* clear config */
    prev |= oversampling << 3;                                                /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_temperature_oversampling( bmp388_oversampling_t* oversampling)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_OSR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    *oversampling = (bmp388_oversampling_t)((prev >> 3) & 0x07); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_odr( bmp388_odr_t odr)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_ODR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    prev &= ~(31 << 0);                                                       /* clear config */
    prev |= odr << 0;                                                         /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_ODR, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_odr( bmp388_odr_t* odr)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_ODR, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    *odr = (bmp388_odr_t)((prev >> 0) & 31); /* get config */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_filter_coefficient( bmp388_filter_coefficient_t coefficient)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_CONFIG, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x7 << 1);                                                         /* clear config */
    prev |= coefficient << 1;                                                    /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_CONFIG, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_get_filter_coefficient( bmp388_filter_coefficient_t* coefficient)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_CONFIG, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *coefficient = (bmp388_filter_coefficient_t)((prev >> 1) & 0x07); /* get coefficient */
    return 0; /* success return 0 */
}
uint8_t bmp388_flush_fifo(bmp388_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xB0;                                                               /* command */
    res  = a_bmp388_iic_spi_write( BMP388_REG_CMD, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_softreset(bmp388_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xB6;                                                               /* command */
    res  = a_bmp388_iic_spi_write( BMP388_REG_CMD, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_extmode_en_middle(bmp388_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0x34;                                                               /* command */
    res  = a_bmp388_iic_spi_write( BMP388_REG_CMD, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
static uint8_t a_bmp388_close(bmp388_handle_t* handle)
{
    if (iic_spi == BMP388_INTERFACE_IIC) /* if iic interface */
    {
        if (iic_deinit() != 0) /* close iic */
        {
            
            
        } else {
            return 0; /* success return 0 */
        }
    } else {
        if (spi_deinit() != 0) /* close spi */
        {
            
            
        } else {
            return 0; /* success return 0 */
        }
    }
}
uint8_t bmp388_init(bmp388_handle_t* handle)
{
    uint8_t id;
    uint8_t reg;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (spi_init == NULL) /* check spi_init */
    {
        
        
    }
    if (spi_deinit == NULL) /* check spi_deinit */
    {
        
        
    }
    if (spi_read == NULL) /* check spi_read */
    {
        
        
    }
    if (spi_write == NULL) /* check spi_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_spi == BMP388_INTERFACE_IIC) /* if iic interface */
    {
        if (iic_init() != 0) /* initialize iic bus */
        {
            
            
        }
    } else {
        if (spi_init() != 0) /* initialize spi bus */
        {
            
            
        }
    }
    if (a_bmp388_iic_spi_read( BMP388_REG_CHIP_ID, (uint8_t*)&id, 1) != 0) /* read chip id */
    {
        
        (void)a_bmp388_close(handle);                          /* close bmp388 */
        
    }
    if (id != 0x50) /* check chip id */
    {
        
        (void)a_bmp388_close(handle);                    /* close bmp388 */
        return 4;
    }                                                                           /* return error */
    reg = 0xB6;                                                                 /* set command */
    if (a_bmp388_iic_spi_write( BMP388_REG_CMD, (uint8_t*)&reg, 1) != 0) /* write command */
    {
        
        (void)a_bmp388_close(handle);                       /* close bmp388 */
        
    }
    delay_ms(10);                                                          /* delay 10 ms */
    if (a_bmp388_iic_spi_read( BMP388_REG_ERR_REG, (uint8_t*)&reg, 1) != 0) /* read reg */
    {
        
        (void)a_bmp388_close(handle);                         /* close bmp388 */
        
    }
    if ((reg & 0x07) != 0) /* check running status */
    {
        
        (void)a_bmp388_close(handle);                         /* close bmp388 */
        
    }
    if (a_bmp388_get_calibration_data(handle) != 0) /* get calibration data */
    {
        
        (void)a_bmp388_close(handle);                                 /* close bmp388 */
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t bmp388_deinit(bmp388_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    prev &= ~(3 << 0);                                                             /* clear config */
    prev &= ~(3 << 4);                                                             /* set config */
    res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    if (a_bmp388_close(handle) != 0) /* close bmp388 */
    {
        
    } else {
        inited = 0; /* flag close */
        return 0; /* success return 0 */
    }
}
uint8_t bmp388_read_temperature( uint32_t* raw, float* c)
{
    uint8_t res;
    uint8_t prev;
    uint8_t buf[3];
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    if ((prev & 0x01) != 0) /* check mode */
    {
        
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read pwr ctrl */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    if (((prev >> 4) & 0x03) == 0x03) /* normal mode */
    {
        res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                               /* check result */
        {
            
            
        }
        if ((prev & (1 << 6)) != 0) /* data is ready */
        {
            int64_t output;
            res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read raw data */
            if (res != 0)                                                             /* check result */
            {
                
                
            }
            *raw   = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
            output = a_bmp388_compensate_temperature( *raw);           /* compensate temperature */
            *c     = (float)((double)output / 100.0);                         /* get converted temperature */
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else if (((prev >> 4) & 0x03) == 0x00) /* force mode */
    {
        uint16_t cnt = 5000;
        res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                                 /* check result */
        {
            
            
        }
        prev &= ~(0x03 << 4);                                                          /* clear 4-5 bits */
        prev |= 0x01 << 4;                                                             /* set bit 4 */
        res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                                  /* check result */
        {
            
            
        }
        while (1) /* loop */
        {
            res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read status */
            if (res != 0)                                                               /* check result */
            {
                
                
            }
            if ((prev & (1 << 6)) != 0) /* data is ready */
            {
                int64_t output;
                res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read raw data */
                if (res != 0)                                                             /* check result */
                {
                    
                    
                }
                *raw   = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
                output = a_bmp388_compensate_temperature( *raw);           /* compensate temperature */
                *c     = (float)((double)output / 100.0);                         /* get converted temperature */
                return 0; /* success return 0 */
            } else {
                if (cnt != 0) /* check cnt */
                {
                    cnt--;               /* cnt-- */
                    delay_ms(1); /* delay 1 ms */
                    continue; /* continue */
                }
                
                
            }
        }
    } else {
        
        return 1; /* retun error */
    }
}
uint8_t bmp388_read_pressure( uint32_t* raw, float* pa)
{
    uint8_t  res;
    uint8_t  prev;
    uint8_t  buf[3];
    uint32_t temperature_yaw;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    if ((prev & 0x01) != 0) /* check mode */
    {
        
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    if (((prev >> 4) & 0x03) == 0x03) /* normal mode */
    {
        res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read status */
        if (res != 0)                                                               /* check result */
        {
            
            
        }
        if ((prev & (1 << 6)) != 0) /* data is ready */
        {
            res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read config */
            if (res != 0)                                                             /* check result */
            {
                
                
            }
            temperature_yaw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
            (void)a_bmp388_compensate_temperature( temperature_yaw);            /* compensate temperature */
        } else {
            
            
        }
        if ((prev & (1 << 5)) != 0) /* data is ready */
        {
            int64_t output;
            res = a_bmp388_iic_spi_read( BMP388_REG_DATA_0, (uint8_t*)buf, 3); /* read config */
            if (res != 0)                                                             /* check result */
            {
                
                
            }
            *raw   = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
            output = a_bmp388_compensate_pressure( *raw);              /* compensate pressure */
            *pa    = (float)((double)output / 100.0);                         /* get converted pressure */
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else if (((prev >> 4) & 0x03) == 0x00) /* force mode */
    {
        uint16_t cnt = 5000;
        res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                                 /* check result */
        {
            
            
        }
        prev &= ~(0x03 << 4);                                                          /* clear 4-5 bits */
        prev |= 0x01 << 4;                                                             /* set 4 bit */
        res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                                  /* check result */
        {
            
            
        }
        while (1) /* loop */
        {
            res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read config */
            if (res != 0)                                                               /* check result */
            {
                
                
            }
            if ((prev & (1 << 6)) != 0) /* data is ready */
            {
                res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read raw data */
                if (res != 0)                                                             /* check result */
                {
                    
                    
                }
                temperature_yaw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
                (void)a_bmp388_compensate_temperature( temperature_yaw);            /* compensate temperature */
                goto press; /* goto press */
            } else {
                if (cnt != 0) /* check cnt */
                {
                    cnt--;               /* cnt-- */
                    delay_ms(1); /* delay 1 ms */
                    continue; /* continue */
                }
                
                
            }
        press:
            cnt = 5000;                 /* set cnt 5000 */
            if ((prev & (1 << 5)) != 0) /* data is ready */
            {
                int64_t output;
                res = a_bmp388_iic_spi_read( BMP388_REG_DATA_0, (uint8_t*)buf, 3); /* read config */
                if (res != 0)                                                             /* check result */
                {
                    
                    
                }
                *raw   = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
                output = a_bmp388_compensate_pressure( *raw);              /* compensate pressure */
                *pa    = (float)((double)output / 100.0);                         /* get converted pressure */
                return 0; /* success return 0 */
            } else {
                if (cnt != 0) /* check cnt */
                {
                    cnt--;               /* cnt-- */
                    delay_ms(1); /* delay 1 ms */
                    continue; /* continue */
                }
                
                
            }
        }
    } else {
        
        
    }
}
uint8_t bmp388_read_temperature_pressure( uint32_t* temperature_raw, float* temperature_c, uint32_t* pressure_raw, float* pressure_pa)
{
    uint8_t res;
    uint8_t prev;
    uint8_t buf[3];
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    if ((prev & 0x01) != 0) /* check fifo mode */
    {
        
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    if (((prev >> 4) & 0x03) == 0x03) /* normal mode */
    {
        res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                               /* check result */
        {
            
            
        }
        if ((prev & (1 << 6)) != 0) /* data is ready */
        {
            int64_t output;
            res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read raw data */
            if (res != 0)                                                             /* check result */
            {
                
                
            }
            *temperature_raw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0];   /* get data */
            output           = a_bmp388_compensate_temperature( *temperature_raw); /* compensate temperature */
            *temperature_c   = (float)((double)output / 100.0);                           /* get converted temperature */
        } else {
            
            
        }
        if ((prev & (1 << 5)) != 0) /* data is ready */
        {
            int64_t output;
            res = a_bmp388_iic_spi_read( BMP388_REG_DATA_0, (uint8_t*)buf, 3); /* read data */
            if (res != 0)                                                             /* check result */
            {
                
                
            }
            *pressure_raw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
            output        = a_bmp388_compensate_pressure( *pressure_raw);     /* compensate pressure */
            *pressure_pa  = (float)((double)output / 100.0);                         /* get converted pressure */
            return 0; /* success return 0 */
        } else {
            
            
        }
    } else if (((prev >> 4) & 0x03) == 0x00) /* force mode */
    {
        uint16_t cnt = 5000;
        res = a_bmp388_iic_spi_read( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* read config */
        if (res != 0)                                                                 /* check result */
        {
            
            
        }
        prev &= ~(0x03 << 4);                                                          /* clear 4-5 bits */
        prev |= 0x01 << 4;                                                             /* set bit 4 */
        res = a_bmp388_iic_spi_write( BMP388_REG_PWR_CTRL, (uint8_t*)&prev, 1); /* write config */
        if (res != 0)                                                                  /* check result */
        {
            
            
        }
        while (1) /* loop */
        {
            res = a_bmp388_iic_spi_read( BMP388_REG_STATUS, (uint8_t*)&prev, 1); /* read config */
            if (res != 0)                                                               /* check result */
            {
                
                
            }
            if ((prev & (1 << 6)) != 0) /* data is ready */
            {
                int64_t output;
                res = a_bmp388_iic_spi_read( BMP388_REG_DATA_3, (uint8_t*)buf, 3); /* read raw data */
                if (res != 0)                                                             /* check result */
                {
                    
                    
                }
                *temperature_raw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0];   /* get data */
                output           = a_bmp388_compensate_temperature( *temperature_raw); /* compensate temperature */
                *temperature_c   = (float)((double)output / 100.0);                           /* get converted temperature */
                break; /* break */
            } else {
                if (cnt != 0) /* check cnt */
                {
                    cnt--;               /* cnt-- */
                    delay_ms(1); /* delay 1 ms */
                    continue; /* continue */
                }
                
                
            }
        }
        cnt = 5000; /* set cnt */
        while (1) /* loop */
        {
            if ((prev & (1 << 5)) != 0) /* data is ready */
            {
                int64_t output;
                res = a_bmp388_iic_spi_read( BMP388_REG_DATA_0, (uint8_t*)buf, 3); /* read raw data */
                if (res != 0)                                                             /* check result */
                {
                    
                    
                }
                *pressure_raw = (uint32_t)buf[2] << 16 | (uint32_t)buf[1] << 8 | buf[0]; /* get data */
                output        = a_bmp388_compensate_pressure( *pressure_raw);     /* compensate pressure */
                *pressure_pa  = (float)((double)output / 100.0);                         /* get converted pressure */
                return 0; /* success return 0 */
            } else {
                if (cnt != 0) /* check cnt */
                {
                    cnt--;               /* cnt-- */
                    delay_ms(1); /* delay 1 ms */
                    continue; /* continue */
                }
                
                
            }
        }
    } else {
        
        
    }
}
uint8_t bmp388_irq_handler(bmp388_handle_t* handle)
{
    uint8_t res;
    uint8_t status;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_INT_STATUS, (uint8_t*)&status, 1); /* read config */
    if (res != 0)                                                                     /* check result */
    {
        
        
    }
    if ((status & (1 << 1)) != 0) /* if fifo full */
    {
        if (receive_callback != NULL) /* if receive callback is valid */
        {
            receive_callback(BMP388_INTERRUPT_STATUS_FIFO_FULL); /* run receive callback */
        }
    }
    if ((status & (1 << 0)) != 0) /* if fifo watermark */
    {
        if (receive_callback != NULL) /* if receive callback is valid */
        {
            receive_callback(BMP388_INTERRUPT_STATUS_FIFO_WATERMARK); /* run receive callback */
        }
    }
    if ((status & (1 << 3)) != 0) /* if data ready */
    {
        if (receive_callback != NULL) /* if receive callback is valid */
        {
            receive_callback(BMP388_INTERRUPT_STATUS_DATA_READY); /* run receive callback */
        }
    }
    return 0; /* success return 0 */
}
uint8_t bmp388_set_addr_pin( bmp388_address_t addr_pin)
{
    {
        
    }
    iic_addr = (uint8_t)addr_pin; /* set iic address */
    return 0; /* success return 0 */
}
uint8_t bmp388_get_addr_pin( bmp388_address_t* addr_pin)
{
    {
        
    }
    *addr_pin = (bmp388_address_t)iic_addr; /* get iic address */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_interface( bmp388_interface_t interface)
{
    {
        
    }
    iic_spi = (uint8_t)interface; /* set interface */
    return 0; /* success return 0 */
}
uint8_t bmp388_get_interface( bmp388_interface_t* interface)
{
    {
        
    }
    *interface = (bmp388_interface_t)(iic_spi); /* get interface */
    return 0; /* success return 0 */
}
uint8_t bmp388_read_fifo( uint8_t* buf, uint16_t* len)
{
    uint8_t  res;
    uint8_t  prev;
    uint8_t  tmp_buf[2];
    uint16_t length;
    {
        
    }
    {
        
    }
    res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_CONFIG_1, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    if ((prev & 0x01) != 0) /* check mode */
    {
        res = a_bmp388_iic_spi_read( BMP388_REG_FIFO_LENGTH_0, (uint8_t*)tmp_buf, 2); /* read config */
        if (res != 0)                                                                        /* check result */
        {
            
            
        }
        length = ((uint16_t)(tmp_buf[1] & 0x01) << 8) | tmp_buf[0]; /* get data */
        if ((prev & (1 << 2)) != 0)                                 /* if include sensorttime */
        {
            length += 4; /* add sensortime length */
        }
        *len = (*len) < length ? (*len) : length;                                        /* get real length */
        res  = a_bmp388_iic_spi_read( BMP388_REG_FIFO_DATA, (uint8_t*)buf, *len); /* read config */
        if (res != 0)                                                                    /* check result */
        {
            
            
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t bmp388_fifo_parse( uint8_t* buf, uint16_t buf_len, bmp388_frame_t* frame, uint16_t* frame_len)
{
    uint8_t  res;
    uint16_t i;
    uint16_t frame_total;
    {
        
    }
    {
        
    }
    if (buf_len == 0) /* check buffer length */
    {
        
        
    }
    frame_total = 0;    /* clear total frame */
    res         = 0;    /* set 0 */
    i           = 0;    /* set 0 */
    while (i < buf_len) /* loop */
    {
        switch ((uint8_t)buf[i]) {
            case 0x90: {
                if (frame_total > ((*frame_len) - 1)) /* check length */
                {
                    return 0; /* return success */
                }
                frame[frame_total].type = BMP388_FRAME_TYPE_TEMPERATURE;                                                            /* set temperature type */
                frame[frame_total].raw  = (uint32_t)buf[i + 2 + 1] << 16 | (uint32_t)buf[i + 1 + 1] << 8 | buf[i + 0 + 1];          /* set raw */
                frame[frame_total].data = (float)((double)a_bmp388_compensate_temperature( frame[frame_total].raw) / 100.0); /* set compensate temerature */
                frame_total++;                                                                                                      /* frame++ */
                i += 4;                                                                                                             /* index + 4 */
                break; /* break */
            }
            case 0x94: {
                if ((frame_total) > ((*frame_len) - 1)) /* check length */
                {
                    return 0; /* return success */
                }
                frame[frame_total].type = BMP388_FRAME_TYPE_TEMPERATURE;                                                            /* set temperature type */
                frame[frame_total].raw  = (uint32_t)buf[i + 2 + 1] << 16 | (uint32_t)buf[i + 1 + 1] << 8 | buf[i + 0 + 1];          /* set raw */
                frame[frame_total].data = (float)((double)a_bmp388_compensate_temperature( frame[frame_total].raw) / 100.0); /* set compensate temerature */
                frame_total++;                                                                                                      /* frame++ */
                if (frame_total > ((*frame_len) - 1))                                                                               /* check length */
                {
                    return 0; /* return success */
                }
                frame[frame_total].type = BMP388_FRAME_TYPE_PRESSURE;                                                            /* set pressure type */
                frame[frame_total].raw  = (uint32_t)buf[i + 5 + 1] << 16 | (uint32_t)buf[i + 4 + 1] << 8 | buf[i + 3 + 1];       /* set raw */
                frame[frame_total].data = (float)((double)a_bmp388_compensate_pressure( frame[frame_total].raw) / 100.0); /* set compensate pressure */
                frame_total++;                                                                                                   /* frame++ */
                i += 7;                                                                                                          /* index + 7 */
                break; /* break */
            }
            case 0xA0: {
                if (frame_total > ((*frame_len) - 1)) /* check length */
                {
                    return 0; /* return success */
                }
                frame[frame_total].type = BMP388_FRAME_TYPE_SENSORTIME;                                                    /* set sensortime type */
                frame[frame_total].raw  = (uint32_t)buf[i + 2 + 1] << 16 | (uint32_t)buf[i + 1 + 1] << 8 | buf[i + 0 + 1]; /* set raw */
                frame[frame_total].data = 0;                                                                               /* set data */
                frame_total++;                                                                                             /* frame++ */
                i += 4;                                                                                                    /* index+4 */
                break; /* break */
            }
            default: {
                
                res = 1;                                             /* set 1 */
                break; /* break */
            }
        }
        if (res == 1) /* check the result */
        {
            
        }
    }
    *frame_len = frame_total; /* set frame length */
    return 0; /* success return 0 */
}
uint8_t bmp388_set_reg( uint8_t reg, uint8_t value)
{
    {
        
    }
    {
        
    }
    return a_bmp388_iic_spi_write( reg, &value, 1); /* write register */
}
uint8_t bmp388_get_reg( uint8_t reg, uint8_t* value)
{
    {
        
    }
    {
        
    }
    return a_bmp388_iic_spi_read( reg, value, 1); /* read register */
}
uint8_t bmp388_info(bmp388_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(bmp388_info_t));                  /* initialize bmp388 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC SPI", 8);                  /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
