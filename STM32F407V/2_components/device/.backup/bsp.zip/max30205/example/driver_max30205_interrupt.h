
#ifndef DRIVER_MAX30205_INTERRUPT_H
#define DRIVER_MAX30205_INTERRUPT_H
#include "driver_max30205_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MAX30205_INTERRUPT_DEFAULT_DATA_FORMAT                MAX30205_DATA_FORMAT_NORMAL               // normal data format 
#define MAX30205_INTERRUPT_DEFAULT_FAULT_QUEUE                MAX30205_FAULT_QUEUE_2                    // fault queue 2 
#define MAX30205_INTERRUPT_DEFAULT_PIN_POLARITY               MAX30205_PIN_POLARITY_LOW                 // polarity low 
#define MAX30205_INTERRUPT_DEFAULT_BUS_TIMEOUT                MAX30205_BUS_TIMEOUT_DISABLE              // disable bus timeout 
uint8_t max30205_interrupt_init(max30205_address_t addr_pin, max30205_interrupt_mode_t mode, float low, float high);
uint8_t max30205_interrupt_deinit(void);
uint8_t max30205_interrupt_read(float *s);
#ifdef __cplusplus
}
#endif
#endif
