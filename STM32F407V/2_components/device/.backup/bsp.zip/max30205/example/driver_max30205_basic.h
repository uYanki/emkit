
#ifndef DRIVER_MAX30205_BASIC_H
#define DRIVER_MAX30205_BASIC_H
#include "driver_max30205_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MAX30205_BASIC_DEFAULT_DATA_FORMAT                MAX30205_DATA_FORMAT_NORMAL               // normal data format 
#define MAX30205_BASIC_DEFAULT_INTERRUPT_MODE             MAX30205_INTERRUPT_MODE_COMPARATOR        // comparator mode 
#define MAX30205_BASIC_DEFAULT_FAULT_QUEUE                MAX30205_FAULT_QUEUE_1                    // fault queue 1 
#define MAX30205_BASIC_DEFAULT_PIN_POLARITY               MAX30205_PIN_POLARITY_LOW                 // polarity low 
#define MAX30205_BASIC_DEFAULT_BUS_TIMEOUT                MAX30205_BUS_TIMEOUT_DISABLE              // disable bus timeout 
#define MAX30205_BASIC_DEFAULT_INTERRUPT_LOW_THRESHOLD    35.0f                                     // 35.0 low threshold interrupt 
#define MAX30205_BASIC_DEFAULT_INTERRUPT_HIGH_THRESHOLD   39.0f                                     // 39.0 high threshold interrupt 
uint8_t max30205_basic_init(max30205_address_t addr_pin);
uint8_t max30205_basic_deinit(void);
uint8_t max30205_basic_read(float *s);
#ifdef __cplusplus
}
#endif
#endif
