
#include "driver_max30205_shot.h"
static max30205_handle_t gs_handle;        // max30205 handle
uint8_t max30205_shot_init(max30205_address_t addr_pin)
{
    uint8_t res;
    int16_t low_threshold;
    int16_t high_threshold;
    /* link interface function */
    DRIVER_MAX30205_LINK_INIT(&gs_handle, max30205_handle_t);
    DRIVER_MAX30205_LINK_IIC_INIT(&gs_handle, max30205_interface_iic_init);
    DRIVER_MAX30205_LINK_IIC_DEINIT(&gs_handle, max30205_interface_iic_deinit);
    DRIVER_MAX30205_LINK_IIC_READ(&gs_handle, max30205_interface_iic_read);
    DRIVER_MAX30205_LINK_IIC_WRITE(&gs_handle, max30205_interface_iic_write);
    DRIVER_MAX30205_LINK_DELAY_MS(&gs_handle, max30205_interface_delay_ms);
    DRIVER_MAX30205_LINK_DEBUG_PRINT(&gs_handle, max30205_interface_debug_print);
    /* set max30205 iic address */
    res = max30205_set_addr_pin(&gs_handle, addr_pin);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set addr pin failed.\n");
        
        return 1;
    }
    /* max30205 init */
    res = max30205_init(&gs_handle);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: init failed.\n");
        
        return 1;
    }
    /* set data format */
    res = max30205_set_data_format(&gs_handle, MAX30205_SHOT_DEFAULT_DATA_FORMAT);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set data format failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* set interrupt mode */
    res = max30205_set_interrupt_mode(&gs_handle, MAX30205_SHOT_DEFAULT_INTERRUPT_MODE);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set interrupt mode failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* set fault queue */
    res = max30205_set_fault_queue(&gs_handle, MAX30205_SHOT_DEFAULT_FAULT_QUEUE);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set fault queue failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* set pin polarity */
    res = max30205_set_pin_polarity(&gs_handle, MAX30205_SHOT_DEFAULT_PIN_POLARITY);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set pin polarity failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* set bus timeout */
    res = max30205_set_bus_timeout(&gs_handle, MAX30205_SHOT_DEFAULT_BUS_TIMEOUT);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set bus timeout failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* convert to register */
    res= max30205_convert_to_register(&gs_handle, MAX30205_SHOT_DEFAULT_INTERRUPT_LOW_THRESHOLD, (int16_t *)&low_threshold);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: convert to register failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1; 
    }
    /* set interrupt low threshold */
    res = max30205_set_interrupt_low_threshold(&gs_handle, low_threshold);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set low threshold failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* convert to register */
    res = max30205_convert_to_register(&gs_handle, MAX30205_SHOT_DEFAULT_INTERRUPT_HIGH_THRESHOLD, (int16_t *)&high_threshold);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: convert to register failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    /* set interrupt high threshold */
    res = max30205_set_interrupt_high_threshold(&gs_handle, high_threshold);
    if (res != 0)
    {
        max30205_interface_debug_print("max30205: set high threshold failed.\n");
        (void)max30205_deinit(&gs_handle);
        
        return 1;
    }
    return 0;
}
uint8_t max30205_shot_read(float *s)
{
    int16_t raw;
    /* single read */
    if (max30205_single_read(&gs_handle, (int16_t *)&raw, s) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t max30205_shot_deinit(void)
{
    /* close max30205 */
    if (max30205_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
