
#ifndef DRIVER_MAX30205_REGISTER_TEST_H
#define DRIVER_MAX30205_REGISTER_TEST_H
#include "driver_max30205_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max30205_register_test(max30205_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
