
#ifndef DRIVER_MAX30205_INTERRUPT_TEST_H
#define DRIVER_MAX30205_INTERRUPT_TEST_H
#include "driver_max30205_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max30205_interrupt_test(max30205_address_t addr, max30205_interrupt_mode_t mode, 
                                float f_low_threshold, float f_high_threshold, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
