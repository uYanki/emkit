
#include "driver_max30205.h"

#define MANUFACTURER_NAME         "Maxim Integrated"                 // manufacturer name
#define SUPPLY_VOLTAGE_MIN        2.7f                               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        3.3f                               // chip max supply voltage




#define MAX30205_REG_TEMP         0x00        // temperature register
#define MAX30205_REG_CONF         0x01        // configure register
#define MAX30205_REG_THYST        0x02        // thyst register
#define MAX30205_REG_TOS          0x03        // tos register
uint8_t max30205_init(max30205_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                   /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                      /* check iic_init */
    {
        
        
        
    }
    if (iic_deinit == NULL)                                    /* check iic_deinit */
    {
        
        
        
    }
    if (iic_read == NULL)                                      /* check iic_read */
    {
        
        
        
    }
    if (iic_write == NULL)                                     /* check iic_write */
    {
        
        
        
    }
    if (delay_ms == NULL)                                      /* check delay_ms */
    {
        
        
        
    }
    if (iic_init() != 0)                                       /* init iic */
    {
        
        
        
    }
    inited = 1;                                                /* flag finish initialization */
    reg = 0;                                                   /* initialize register */
    return 0;                                                          /* success return 0 */
}
uint8_t max30205_deinit(max30205_handle_t *handle)
{
    uint8_t reg;
    
    {
        
    }
    
    {
        
    }
    reg = reg | 0x01;                                                              /* power down */
    if (iic_write(iic_addr, MAX30205_REG_CONF, (uint8_t *)&reg, 1) != 0)   /* write to conf register */
    {
        
        
        
    }
    if (iic_deinit() != 0)                                                         /* iic deinit */
    {
        
        
        
    }   
    inited = 0;                                                                    /* flag close */
    return 0;                                                                              /* success return 0 */
}
uint8_t max30205_set_addr_pin(max30205_handle_t *handle, max30205_address_t addr_pin)
{
    
    {
        
    }
    iic_addr = (uint8_t)addr_pin;        /* set iic address */
    return 0;                                    /* success return 0 */
}
uint8_t max30205_get_addr_pin(max30205_handle_t *handle, max30205_address_t *addr_pin)
{
    
    {
        
    }
    *addr_pin = (max30205_address_t)iic_addr;        /* get iic address */
    return 0;                                                /* success return 0 */
}
uint8_t max30205_set_data_format(max30205_handle_t *handle, max30205_data_format_t format)
{
    
    {
        
    }
    
    {
        
    }
    if (format != 0)                                  /* if extended format */
    {
        reg = reg | (1 << 5);         /* set extended format */
    }
    else
    {
        reg = reg & (~(1 << 5));      /* set normal format */
    }
    return 0;                                         /* success return 0 */
}
uint8_t max30205_get_data_format(max30205_handle_t *handle, max30205_data_format_t *format)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 5)) != 0)                  /* get format */
    {
        *format = MAX30205_DATA_FORMAT_EXTENDED;        /* get format extended */
    }
    else
    {
        *format = MAX30205_DATA_FORMAT_NORMAL;          /* get format normal */
    }
 
    return 0;                                           /* success return 0 */
}
uint8_t max30205_set_interrupt_mode(max30205_handle_t *handle, max30205_interrupt_mode_t mode)
{
    
    {
        
    }
    
    {
        
    }
    if (mode != 0)                                    /* check the mode */
    {
        reg = reg | (1 << 1);         /* set interrupt mode */
    }
    else
    {
        reg = reg & (~(1 << 1));      /* set comparator mode */
    }
    return 0;                                         /* success return 0 */
}
uint8_t max30205_get_interrupt_mode(max30205_handle_t *handle, max30205_interrupt_mode_t *mode)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 1)) != 0)                     /* get interrupt mode */
    {
        *mode = MAX30205_INTERRUPT_MODE_INTERRUPT;         /* interrupt mode */
    }
    else
    {
        *mode = MAX30205_INTERRUPT_MODE_COMPARATOR;        /* comparator mode */
    }
    return 0;                                              /* success return 0 */
}
uint8_t max30205_set_fault_queue(max30205_handle_t *handle, max30205_fault_queue_t fault_queue)
{
    
    {
        
    }
    
    {
        
    }
    reg = reg & (~(3 << 3));               /* clear fault queue */
    reg = (uint8_t)(reg | 
                  (fault_queue << 3));                     /* set fault queue */
    return 0;                                              /* success return 0 */
}
uint8_t max30205_get_fault_queue(max30205_handle_t *handle, max30205_fault_queue_t *fault_queue)
{
    
    {
        
    }
    
    {
        
    }
    *fault_queue = (max30205_fault_queue_t)((reg >> 3) & 0x03);        /* get fault queue */
    return 0;                                                                  /* success return 0 */
}
uint8_t max30205_set_pin_polarity(max30205_handle_t *handle, max30205_pin_polarity_t polarity)
{
    
    {
        
    }
    
    {
        
    }
    if (polarity != 0)                                /* check the polarity */
    {
        reg = reg | (1 << 2);         /* set active high */
    }
    else
    {
        reg = reg & (~(1 << 2));      /* set active low */
    }
    return 0;                                         /* success return 0 */
}
uint8_t max30205_get_pin_polarity(max30205_handle_t *handle, max30205_pin_polarity_t *polarity)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 2)) != 0)                 /* active high */
    {
        *polarity = MAX30205_PIN_POLARITY_HIGH;        /* high polarity */
    }
    else                                               /* active low */
    {
        *polarity = MAX30205_PIN_POLARITY_LOW;         /* low polarity */
    }
    return 0;                                          /* success return 0 */
}
uint8_t max30205_set_bus_timeout(max30205_handle_t *handle, max30205_bus_timeout_t bus_timeout)
{
    
    {
        
    }
    
    {
        
    }
    if (bus_timeout != 0)                             /* check the bus timeout */
    {
        reg = reg | (1 << 6);         /* disable bus timeout */
    }
    else
    {
        reg = reg & (~(1 << 6));      /* enable bus timeout */
    }
    return 0;                                         /* success return 0 */
}
uint8_t max30205_get_bus_timeout(max30205_handle_t *handle, max30205_bus_timeout_t *bus_timeout)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 6)) != 0)                      /* disable bus timeout */
    {
        *bus_timeout = MAX30205_BUS_TIMEOUT_DISABLE;        /* bus timeout disable */
    }
    else                                                    /* enable bus timeout */
    {
        *bus_timeout = MAX30205_BUS_TIMEOUT_ENABLE;         /* bus timeout enable */
    }
    return 0;                                               /* success return 0 */
}
uint8_t max30205_start_continuous_read(max30205_handle_t *handle)
{
    uint8_t reg;
    
    {
        
    }
    
    {
        
    }
    reg = reg & (~(1 << 0));                                                          /* exit shutdown mode */
    reg = reg & (~(1 << 7));                                                                  /* set continuous read bit */
    if (iic_write(iic_addr, MAX30205_REG_CONF, (uint8_t *)&reg, 1) != 0)      /* write conf register */
    {
        
        
        
    }
    else
    {
        return 0;                                                                             /* success return 0 */
    }
}
uint8_t max30205_stop_continuous_read(max30205_handle_t *handle)
{
    uint8_t reg;
    
    {
        
    }
    
    {
        
    }
    reg = reg | (1 << 0);                                                             /* enter shutdown mode */
    reg = reg | (1 << 7);                                                                     /* set continuous read bit */
    if (iic_write(iic_addr, MAX30205_REG_CONF, (uint8_t *)&reg, 1) != 0)      /* write conf register */
    {
        
        
        
    }
    else
    {
        return 0;                                                                             /* success return 0 */
    }
}
uint8_t max30205_continuous_read(max30205_handle_t *handle, int16_t *raw, float *s)
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                 /* clear the buffer */
    if (iic_read(iic_addr, MAX30205_REG_TEMP, (uint8_t *)buf, 2) != 0)   /* read two bytes */
    {
        
        
        
    }
    if ((reg & (1 << 5)) != 0)                                                   /* extended format */
    {
        *raw = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                              /* get raw data */
        *s = (float)(*raw) * 0.00390625f + 64.0f;                                        /* convert raw data to real data */
    }
    else                                                                                 /* normal format */
    {
        *raw = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                              /* get raw data */
        *s = (float)(*raw) * 0.00390625f;                                                /* convert raw data to real data */
    }
    return 0;                                                                            /* success return 0 */
}
uint8_t max30205_single_read(max30205_handle_t *handle, int16_t *raw, float *s)
{
    uint8_t buf[2];
    uint8_t reg;
    
    {
        
    }
    
    {
        
    }
    reg = reg | (1 << 0);                                                          /* enter shutdown mode */
    reg = reg | (1 << 7);                                                                  /* set single read bit */
    if (iic_write(iic_addr, MAX30205_REG_CONF, (uint8_t *)&reg, 1) != 0)   /* write conf */
    {
        
       
        
    }
    delay_ms(50);                                                                  /* delay 50 ms */
    memset(buf, 0, sizeof(uint8_t) * 2);                                                   /* clear the buffer */
    if (iic_read(iic_addr, MAX30205_REG_TEMP, (uint8_t *)buf, 2) != 0)     /* read two bytes */
    {
        
       
        
    }
    if ((reg & (1 << 5)) != 0)                                                     /* extended format */
    {
        *raw = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                                /* get raw data */
        *s = (float)(*raw) * 0.00390625f + 64.0f;                                          /* convert raw data to real data */
    }
    else                                                                                   /* normal format */
    {
        *raw = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                                /* get raw data */
        *s = (float)(*raw) * 0.00390625f;                                                  /* convert raw data to real data */
    }
    return 0;                                                                              /* success return 0 */
}
uint8_t max30205_set_interrupt_low_threshold(max30205_handle_t *handle, int16_t threshold)
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    buf[0] = (threshold >> 8) & 0xFF;                                                         /* MSB */
    buf[1] = threshold & 0xFF;                                                                /* LSB */
    if (iic_write(iic_addr, MAX30205_REG_THYST, (uint8_t *)buf, 2) != 0)      /* write to register */
    {
        
        
        
    }
    else
    {
        return 0;                                                                             /* success return 0 */
    }
}
uint8_t max30205_get_interrupt_low_threshold(max30205_handle_t *handle, int16_t *threshold)
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                  /* clear the buffer */
    if (iic_read(iic_addr, MAX30205_REG_THYST, (uint8_t *)buf, 2) != 0)   /* read 2 bytes */
    {
        
        
        
    }
    *threshold = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                             /* get raw data */
    return 0;                                                                             /* success return 0 */
}
uint8_t max30205_set_interrupt_high_threshold(max30205_handle_t *handle, int16_t threshold)
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    buf[0] = (threshold >> 8) & 0xFF;                                                       /* MSB */
    buf[1] = threshold & 0xFF;                                                              /* LSB */
    if (iic_write(iic_addr, MAX30205_REG_TOS, (uint8_t *)buf, 2) != 0)      /* write to register */
    {
        
        
        
    }
    else
    {
        return 0;                                                                           /* success return 0 */
    }
}
uint8_t max30205_get_interrupt_high_threshold(max30205_handle_t *handle, int16_t *threshold)
{
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                /* clear the buffer */
    if (iic_read(iic_addr, MAX30205_REG_TOS, (uint8_t *)buf, 2) != 0)   /* read 2 bytes */
    {
        
        
        
    }
    *threshold = (int16_t)(((uint16_t)buf[0]) << 8 | buf[1]);                           /* get raw data */
    return 0;                                                                           /* success return 0 */
}
uint8_t max30205_convert_to_register(max30205_handle_t *handle, float s, int16_t *reg)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 5)) != 0)                    /* extended format */
    {
        *reg = (int16_t)((s - 64.0f) / 0.00390625f);      /* convert real data to register data */
    }
    else                                                  /* normal format */
    {
        *reg = (int16_t)(s / 0.00390625f);                /* convert real data to register data */
    }
    return 0;                                             /* success return 0 */
}
uint8_t max30205_convert_to_data(max30205_handle_t *handle, int16_t reg, float *s)
{
    
    {
        
    }
    
    {
        
    }
    if ((reg & (1 << 5)) != 0)                  /* extended format */
    {
        *s = (float)(reg) * 0.00390625f + 64.0f;        /* convert raw data to real data */
    }
    else                                                /* normal format */
    {
        *s = (float)(reg) * 0.00390625f;                /* convert raw data to real data */
    }
    return 0;                                           /* success return 0 */
}
uint8_t max30205_power_down(max30205_handle_t *handle)
{
    uint8_t reg;
    
    {
        
    }
    
    {
        
    }
    reg = reg | 0x01;                                                                 /* set shutdown bit */
    if (iic_write(iic_addr, MAX30205_REG_CONF, (uint8_t *)&reg, 1) != 0)      /* write to conf register */
    {
        
        
        
    }
    else
    {
        return 0;                                                                             /* success return 0 */
    }
}
uint8_t max30205_set_reg(max30205_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    if (iic_write(iic_addr, reg, buf, len) != 0)      /* write data */
    {
        
        
        
    }
    else
    {
        return 0;                                                     /* success return 0 */
    }
}
uint8_t max30205_get_reg(max30205_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
   if (iic_read(iic_addr, reg, buf, len) != 0)       /* read data */
    {
        
        
        
    }
    else
    {
        return 0;                                                    /* success return 0 */
    }
}
uint8_t max30205_info(max30205_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(max30205_info_t));                       /* initialize max30205 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
