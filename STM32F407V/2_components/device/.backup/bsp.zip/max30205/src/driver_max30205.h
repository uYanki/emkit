
#ifndef DRIVER_MAX30205_H
#define DRIVER_MAX30205_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MAX30205_ADDRESS_0  = (uint8_t)(0x90),  // A2 = GND, A1 = GND, A0 = GND
    MAX30205_ADDRESS_1  = (uint8_t)(0x92),  // A2 = GND, A1 = GND, A0 = VDD
    MAX30205_ADDRESS_2  = (uint8_t)(0x82),  // A2 = GND, A1 = GND, A0 = SCL
    MAX30205_ADDRESS_3  = (uint8_t)(0x80),  // A2 = GND, A1 = GND, A0 = SDA
    MAX30205_ADDRESS_4  = (uint8_t)(0x94),  // A2 = GND, A1 = VDD, A0 = GND
    MAX30205_ADDRESS_5  = (uint8_t)(0x96),  // A2 = GND, A1 = VDD, A0 = VDD
    MAX30205_ADDRESS_6  = (uint8_t)(0x86),  // A2 = GND, A1 = VDD, A0 = SCL
    MAX30205_ADDRESS_7  = (uint8_t)(0x84),  // A2 = GND, A1 = VDD, A0 = SDA
    MAX30205_ADDRESS_8  = (uint8_t)(0xB4),  // A2 = GND, A1 = SCL, A0 = GND
    MAX30205_ADDRESS_9  = (uint8_t)(0xB6),  // A2 = GND, A1 = SCL, A0 = VDD
    MAX30205_ADDRESS_A  = (uint8_t)(0xA6),  // A2 = GND, A1 = SCL, A0 = SCL
    MAX30205_ADDRESS_B  = (uint8_t)(0xA4),  // A2 = GND, A1 = SCL, A0 = SDA
    MAX30205_ADDRESS_C  = (uint8_t)(0xB0),  // A2 = GND, A1 = SDA, A0 = GND
    MAX30205_ADDRESS_D  = (uint8_t)(0xB2),  // A2 = GND, A1 = SDA, A0 = VDD
    MAX30205_ADDRESS_E  = (uint8_t)(0xA2),  // A2 = GND, A1 = SDA, A0 = SCL
    MAX30205_ADDRESS_F  = (uint8_t)(0xA0),  // A2 = GND, A1 = SDA, A0 = SDA
    MAX30205_ADDRESS_10 = (uint8_t)(0x98),  // A2 = VDD, A1 = GND, A0 = GND
    MAX30205_ADDRESS_11 = (uint8_t)(0x9A),  // A2 = VDD, A1 = GND, A0 = VDD
    MAX30205_ADDRESS_12 = (uint8_t)(0x8A),  // A2 = VDD, A1 = GND, A0 = SCL
    MAX30205_ADDRESS_13 = (uint8_t)(0x88),  // A2 = VDD, A1 = GND, A0 = SDA
    MAX30205_ADDRESS_14 = (uint8_t)(0x9C),  // A2 = VDD, A1 = VDD, A0 = GND
    MAX30205_ADDRESS_15 = (uint8_t)(0x9E),  // A2 = VDD, A1 = VDD, A0 = VDD
    MAX30205_ADDRESS_16 = (uint8_t)(0x8E),  // A2 = VDD, A1 = VDD, A0 = SCL
    MAX30205_ADDRESS_17 = (uint8_t)(0x8C),  // A2 = VDD, A1 = GND, A0 = SDA
    MAX30205_ADDRESS_18 = (uint8_t)(0xBC),  // A2 = VDD, A1 = SCL, A0 = GND
    MAX30205_ADDRESS_19 = (uint8_t)(0xBE),  // A2 = VDD, A1 = SCL, A0 = VDD
    MAX30205_ADDRESS_1A = (uint8_t)(0xAE),  // A2 = VDD, A1 = SCL, A0 = SCL
    MAX30205_ADDRESS_1B = (uint8_t)(0xAC),  // A2 = VDD, A1 = SCL, A0 = SDA
    MAX30205_ADDRESS_1C = (uint8_t)(0xB8),  // A2 = VDD, A1 = SDA, A0 = GND
    MAX30205_ADDRESS_1D = (uint8_t)(0xBA),  // A2 = VDD, A1 = SDA, A0 = VDD
    MAX30205_ADDRESS_1E = (uint8_t)(0xAA),  // A2 = VDD, A1 = SDA, A0 = SCL
    MAX30205_ADDRESS_1F = (uint8_t)(0xA8),  // A2 = VDD, A1 = SDA, A0 = SDA
} max30205_address_t;
typedef enum {
    MAX30205_DATA_FORMAT_NORMAL   = 0x00,  // normal format
    MAX30205_DATA_FORMAT_EXTENDED = 0x01,  // extended format
} max30205_data_format_t;
typedef enum {
    MAX30205_BUS_TIMEOUT_ENABLE  = 0x00,  // enable bus timeout
    MAX30205_BUS_TIMEOUT_DISABLE = 0x01,  // disable bus timeout
} max30205_bus_timeout_t;
typedef enum {
    MAX30205_INTERRUPT_MODE_COMPARATOR = 0x00,  // comparator mode
    MAX30205_INTERRUPT_MODE_INTERRUPT  = 0x01,  // interrupt mode
} max30205_interrupt_mode_t;
typedef enum {
    MAX30205_FAULT_QUEUE_1 = 0x00,  // fault queue 1
    MAX30205_FAULT_QUEUE_2 = 0x01,  // fault queue 2
    MAX30205_FAULT_QUEUE_4 = 0x02,  // fault queue 4
    MAX30205_FAULT_QUEUE_6 = 0x03,  // fault queue 6
} max30205_fault_queue_t;
typedef enum {
    MAX30205_PIN_POLARITY_LOW  = 0x00,  // polarity low
    MAX30205_PIN_POLARITY_HIGH = 0x01,  // polarity high
} max30205_pin_polarity_t;
typedef struct max30205_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t inited;  // inited flag
    uint8_t reg;     // register
} max30205_handle_t;

uint8_t max30205_info(max30205_info_t* info);
uint8_t max30205_set_addr_pin(max30205_handle_t* handle, max30205_address_t addr_pin);
uint8_t max30205_get_addr_pin(max30205_handle_t* handle, max30205_address_t* addr_pin);
uint8_t max30205_init(max30205_handle_t* handle);
uint8_t max30205_deinit(max30205_handle_t* handle);
uint8_t max30205_start_continuous_read(max30205_handle_t* handle);
uint8_t max30205_stop_continuous_read(max30205_handle_t* handle);
uint8_t max30205_continuous_read(max30205_handle_t* handle, int16_t* raw, float* s);
uint8_t max30205_single_read(max30205_handle_t* handle, int16_t* raw, float* s);
uint8_t max30205_set_data_format(max30205_handle_t* handle, max30205_data_format_t format);
uint8_t max30205_get_data_format(max30205_handle_t* handle, max30205_data_format_t* format);
uint8_t max30205_set_bus_timeout(max30205_handle_t* handle, max30205_bus_timeout_t bus_timeout);
uint8_t max30205_get_bus_timeout(max30205_handle_t* handle, max30205_bus_timeout_t* bus_timeout);
uint8_t max30205_power_down(max30205_handle_t* handle);
uint8_t max30205_set_interrupt_mode(max30205_handle_t* handle, max30205_interrupt_mode_t mode);
uint8_t max30205_get_interrupt_mode(max30205_handle_t* handle, max30205_interrupt_mode_t* mode);
uint8_t max30205_set_fault_queue(max30205_handle_t* handle, max30205_fault_queue_t fault_queue);
uint8_t max30205_get_fault_queue(max30205_handle_t* handle, max30205_fault_queue_t* fault_queue);
uint8_t max30205_set_pin_polarity(max30205_handle_t* handle, max30205_pin_polarity_t polarity);
uint8_t max30205_get_pin_polarity(max30205_handle_t* handle, max30205_pin_polarity_t* polarity);
uint8_t max30205_set_interrupt_low_threshold(max30205_handle_t* handle, int16_t threshold);
uint8_t max30205_get_interrupt_low_threshold(max30205_handle_t* handle, int16_t* threshold);
uint8_t max30205_set_interrupt_high_threshold(max30205_handle_t* handle, int16_t threshold);
uint8_t max30205_get_interrupt_high_threshold(max30205_handle_t* handle, int16_t* threshold);
uint8_t max30205_convert_to_register(max30205_handle_t* handle, float s, int16_t* reg);
uint8_t max30205_convert_to_data(max30205_handle_t* handle, int16_t reg, float* s);
uint8_t max30205_set_reg(max30205_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t max30205_get_reg(max30205_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
