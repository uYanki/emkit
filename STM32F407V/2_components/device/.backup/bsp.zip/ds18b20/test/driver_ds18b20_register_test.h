
#ifndef DRIVER_DS18B20_REGISTER_TEST_H
#define DRIVER_DS18B20_REGISTER_TEST_H
#include "driver_ds18b20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds18b20_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
