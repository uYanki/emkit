
  
#ifndef DRIVER_DS18B20_BASIC_H
#define DRIVER_DS18B20_BASIC_H
#include "driver_ds18b20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define DS18B20_BASIC_DEFAULT_RESOLUTION       DS18B20_RESOLUTION_12BIT        // resolution 12bit 
uint8_t ds18b20_basic_init(void);
uint8_t ds18b20_basic_read(float *temperature);
uint8_t ds18b20_basic_deinit(void);
#ifdef __cplusplus
}
#endif
#endif
