
  
#ifndef DRIVER_DS18B20_SEARCH_H
#define DRIVER_DS18B20_SEARCH_H
#include "driver_ds18b20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds18b20_search_init(void);
uint8_t ds18b20_search(uint8_t (*rom)[8], uint8_t *num);
uint8_t ds18b20_search_deinit(void);
#ifdef __cplusplus
}
#endif
#endif
