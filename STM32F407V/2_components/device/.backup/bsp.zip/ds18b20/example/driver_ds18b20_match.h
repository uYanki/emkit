
  
#ifndef DRIVER_DS18B20_MATCH_H
#define DRIVER_DS18B20_MATCH_H
#include "driver_ds18b20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds18b20_match_init(void);
uint8_t ds18b20_match_deinit(void);
uint8_t ds18b20_match_read(uint8_t rom[8], float *temperature);
#ifdef __cplusplus
}
#endif
#endif
