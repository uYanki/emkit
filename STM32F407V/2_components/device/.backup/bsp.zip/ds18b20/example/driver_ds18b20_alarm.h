
  
#ifndef DRIVER_DS18B20_ALARM_H
#define DRIVER_DS18B20_ALARM_H
#include "driver_ds18b20_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ds18b20_alarm_init(void);
uint8_t ds18b20_alarm_deinit(void);
uint8_t ds18b20_alarm_set_threshold(uint8_t rom[8], float low, float high);
uint8_t ds18b20_alarm_get_threshold(uint8_t rom[8], float *low, float *high);
uint8_t ds18b20_alarm_search(uint8_t (*rom)[8], uint8_t *num);
#ifdef __cplusplus
}
#endif
#endif
