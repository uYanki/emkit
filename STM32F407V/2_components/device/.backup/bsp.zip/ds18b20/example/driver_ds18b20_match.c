
#include "driver_ds18b20_match.h"
static ds18b20_handle_t gs_handle; // ds18b20 handle
uint8_t ds18b20_match_init(void)
{
    uint8_t res;
    /* link interface function */
    DRIVER_DS18B20_LINK_INIT(&gs_handle, ds18b20_handle_t);
    DRIVER_DS18B20_LINK_BUS_INIT(&gs_handle, ds18b20_interface_init);
    DRIVER_DS18B20_LINK_BUS_DEINIT(&gs_handle, ds18b20_interface_deinit);
    DRIVER_DS18B20_LINK_BUS_READ(&gs_handle, ds18b20_interface_read);
    DRIVER_DS18B20_LINK_BUS_WRITE(&gs_handle, ds18b20_interface_write);
    DRIVER_DS18B20_LINK_DELAY_MS(&gs_handle, ds18b20_interface_delay_ms);
    DRIVER_DS18B20_LINK_DELAY_US(&gs_handle, ds18b20_interface_delay_us);
    DRIVER_DS18B20_LINK_ENABLE_IRQ(&gs_handle, ds18b20_interface_enable_irq);
    DRIVER_DS18B20_LINK_DISABLE_IRQ(&gs_handle, ds18b20_interface_disable_irq);
    DRIVER_DS18B20_LINK_DEBUG_PRINT(&gs_handle, ds18b20_interface_debug_print);
    /* ds18b20 init */
    res = ds18b20_init(&gs_handle);
    if (res != 0) {
        ds18b20_interface_debug_print("ds18b20: init failed.\n");
        return 1;
    }
    /* set match rom mode */
    res = ds18b20_set_mode(&gs_handle, DS18B20_MODE_MATCH_ROM);
    if (res != 0) {
        ds18b20_interface_debug_print("ds18b20: set mode failed.\n");
        (void)ds18b20_deinit(&gs_handle);
        return 1;
    }
    return 0;
}
uint8_t ds18b20_match_read(uint8_t rom[8], float* temperature)
{
    uint8_t res;
    int16_t raw;
    /* set rom */
    res = ds18b20_set_rom(&gs_handle, (uint8_t*)rom);
    if (res != 0) {
        return 1;
    }
    /* read temperature */
    if (ds18b20_read(&gs_handle, (int16_t*)&raw, temperature) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t ds18b20_match_deinit(void)
{
    /* ds18b20 close */
    if (ds18b20_deinit(&gs_handle) != 0) {
        return 1;
    } else {
        return 0;
    }
}
