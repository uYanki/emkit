
#include "driver_ds18b20.h"

#define MANUFACTURER_NAME  "Maxim Integrated"         // manufacturer name
#define SUPPLY_VOLTAGE_MIN 3.0f                       // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.5f                       // chip max supply voltage




#define DS18B20_CMD_SEARCH_ROM        0xF0 // search rom command
#define DS18B20_CMD_READ_ROM          0x33 // read rom command
#define DS18B20_CMD_MATCH_ROM         0x55 // match rom command
#define DS18B20_CMD_SKIP_ROM          0xCC // skip rom command
#define DS18B20_CMD_ALARM_SEARCH      0xEC // alarm search command
#define DS18B20_CMD_CONVERT_T         0x44 // convert command
#define DS18B20_CMD_WRITE_SCRATCHPAD  0x4E // write scrachpad command
#define DS18B20_CMD_READ_SCRATCHPAD   0xBE // read scrachpad command
#define DS18B20_CMD_COPY_SCRATCHPAD   0x48 // copy scrachpad command
#define DS18B20_CMD_RECALL_EE         0xB8 // recall ee command
#define DS18B20_CMD_READ_POWER_SUPPLY 0xB4 // read power supply command
const uint8_t gc_ds18b20_crc_table[256] =
    {
        0X00,
        0X5E,
        0XBC,
        0XE2,
        0X61,
        0X3F,
        0XDD,
        0X83,
        0XC2,
        0X9C,
        0X7E,
        0X20,
        0XA3,
        0XFD,
        0X1F,
        0X41,
        0X9D,
        0XC3,
        0X21,
        0X7F,
        0XFC,
        0XA2,
        0X40,
        0X1E,
        0X5F,
        0X01,
        0XE3,
        0XBD,
        0X3E,
        0X60,
        0X82,
        0XDC,
        0X23,
        0X7D,
        0X9F,
        0XC1,
        0X42,
        0X1C,
        0XFE,
        0XA0,
        0XE1,
        0XBF,
        0X5D,
        0X03,
        0X80,
        0XDE,
        0X3C,
        0X62,
        0XBE,
        0XE0,
        0X02,
        0X5C,
        0XDF,
        0X81,
        0X63,
        0X3D,
        0X7C,
        0X22,
        0XC0,
        0X9E,
        0X1D,
        0X43,
        0XA1,
        0XFF,
        0X46,
        0X18,
        0XFA,
        0XA4,
        0X27,
        0X79,
        0X9B,
        0XC5,
        0X84,
        0XDA,
        0X38,
        0X66,
        0XE5,
        0XBB,
        0X59,
        0X07,
        0XDB,
        0X85,
        0X67,
        0X39,
        0XBA,
        0XE4,
        0X06,
        0X58,
        0X19,
        0X47,
        0XA5,
        0XFB,
        0X78,
        0X26,
        0XC4,
        0X9A,
        0X65,
        0X3B,
        0XD9,
        0X87,
        0X04,
        0X5A,
        0XB8,
        0XE6,
        0XA7,
        0XF9,
        0X1B,
        0X45,
        0XC6,
        0X98,
        0X7A,
        0X24,
        0XF8,
        0XA6,
        0X44,
        0X1A,
        0X99,
        0XC7,
        0X25,
        0X7B,
        0X3A,
        0X64,
        0X86,
        0XD8,
        0X5B,
        0X05,
        0XE7,
        0XB9,
        0X8C,
        0XD2,
        0X30,
        0X6E,
        0XED,
        0XB3,
        0X51,
        0X0F,
        0X4E,
        0X10,
        0XF2,
        0XAC,
        0X2F,
        0X71,
        0X93,
        0XCD,
        0X11,
        0X4F,
        0XAD,
        0XF3,
        0X70,
        0X2E,
        0XCC,
        0X92,
        0XD3,
        0X8D,
        0X6F,
        0X31,
        0XB2,
        0XEC,
        0X0E,
        0X50,
        0XAF,
        0XF1,
        0X13,
        0X4D,
        0XCE,
        0X90,
        0X72,
        0X2C,
        0X6D,
        0X33,
        0XD1,
        0X8F,
        0X0C,
        0X52,
        0XB0,
        0XEE,
        0X32,
        0X6C,
        0X8E,
        0XD0,
        0X53,
        0X0D,
        0XEF,
        0XB1,
        0XF0,
        0XAE,
        0X4C,
        0X12,
        0X91,
        0XCF,
        0X2D,
        0X73,
        0XCA,
        0X94,
        0X76,
        0X28,
        0XAB,
        0XF5,
        0X17,
        0X49,
        0X08,
        0X56,
        0XB4,
        0XEA,
        0X69,
        0X37,
        0XD5,
        0X8B,
        0X57,
        0X09,
        0XEB,
        0XB5,
        0X36,
        0X68,
        0X8A,
        0XD4,
        0X95,
        0XCB,
        0X29,
        0X77,
        0XF4,
        0XAA,
        0X48,
        0X16,
        0XE9,
        0XB7,
        0X55,
        0X0B,
        0X88,
        0XD6,
        0X34,
        0X6A,
        0X2B,
        0X75,
        0X97,
        0XC9,
        0X4A,
        0X14,
        0XF6,
        0XA8,
        0X74,
        0X2A,
        0XC8,
        0X96,
        0X15,
        0X4B,
        0XA9,
        0XF7,
        0XB6,
        0XE8,
        0X0A,
        0X54,
        0XD7,
        0X89,
        0X6B,
        0X35,
};
static uint8_t a_ds18b20_check_crc(uint8_t* buf, uint8_t len, uint8_t crc)
{
    uint8_t i;
    uint8_t crc8 = 0;
    for (i = 0; i < len; i++) {
        crc8 = gc_ds18b20_crc_table[crc8 ^ buf[i]]; /* calculate crc */
    }
    if (crc8 == crc) /* check crc */
    {
        return 0; /* return right */
    } else {
        return 1; /* return wrong */
    }
}
static uint8_t a_ds18b20_reset(ds18b20_handle_t* handle)
{
    uint8_t retry = 0;
    uint8_t res;
    disable_irq();         /* disable irq */
    if (bus_write(0) != 0) /* write 0 */
    {
        enable_irq();                                /* enable irq */
        
        
    }
    delay_us(750);         /* wait 750 us */
    if (bus_write(1) != 0) /* write 1 */
    {
        enable_irq();                                /* enable irq */
        
        
    }
    delay_us(15);               /* wait 15 us */
    res = 1;                            /* reset res */
    while ((res != 0) && (retry < 200)) /* wait 200 us */
    {
        if (bus_read((uint8_t*)&res) != 0) /* read 1 bit */
        {
            enable_irq();                               /* enable irq */
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* delay 1 us */
    }
    if (retry >= 200) /* if retry times is over 200 times */
    {
        enable_irq();                                    /* enable irq */
        
        
    } else {
        retry = 0; /* reset retry */
    }
    res = 0;                            /* reset res */
    while ((res == 0) && (retry < 240)) /* wait 240 us */
    {
        if (bus_read((uint8_t*)&res) != 0) /* read one bit */
        {
            enable_irq();                               /* enable irq */
            
            
        }
        retry++;             /* retry times++ */
        delay_us(1); /* delay 1 us */
    }
    if (retry >= 240) /* if retry times is over 240 times */
    {
        enable_irq();                                    /* enable irq */
        
        
    }
    enable_irq(); /* enable irq */
    return 0; /* success return 0 */
}
static uint8_t a_ds18b20_read_bit( uint8_t* data)
{
    if (bus_write(0) != 0) /* write 0 */
    {
        
        
    }
    delay_us(2);           /* wait 2 us */
    if (bus_write(1) != 0) /* write 1 */
    {
        
        
    }
    delay_us(12);            /* wait 12 us */
    if (bus_read(data) != 0) /* read 1 bit */
    {
        
        
    }
    delay_us(50); /* wait 50 us */
    return 0; /* success return 0 */
}
static uint8_t a_ds18b20_read_byte( uint8_t* byte)
{
    uint8_t i, j;
    *byte = 0;             /* set byte 0 */
    disable_irq(); /* disable irq */
    for (i = 1; i <= 8; i++) {
        if (a_ds18b20_read_bit( (uint8_t*)&j) != 0) /* read 1 bit */
        {
            enable_irq();                                    /* enable irq */
            
            
        }
        *byte = (j << 7) | ((*byte) >> 1); /* set MSB */
    }
    enable_irq(); /* enable irq */
    return 0; /* success return 0 */
}
static uint8_t a_ds18b20_write_byte( uint8_t byte)
{
    uint8_t j;
    uint8_t test_b;
    disable_irq();   /* disable irq */
    for (j = 1; j <= 8; j++) /* run 8 times, 8 bist = 1 Byte */
    {
        test_b = byte & 0x01; /* get 1 bit */
        byte   = byte >> 1;   /* right shift 1 bit */
        if (test_b != 0)      /* write 1 */
        {
            if (bus_write(0) != 0) /* write 0 */
            {
                enable_irq();                                /* enable irq */
                
                
            }
            delay_us(2);           /* wait 2 us */
            if (bus_write(1) != 0) /* write 1 */
            {
                enable_irq();                                /* enable irq */
                
                
            }
            delay_us(60); /* wait 60 us */
        } else                    /* write 0 */
        {
            if (bus_write(0) != 0) /* write 0 */
            {
                enable_irq();                                /* enable irq */
                
                
            }
            delay_us(60);          /* wait 60 us */
            if (bus_write(1) != 0) /* write 1 */
            {
                enable_irq();                                /* enable irq */
                
                
            }
            delay_us(2); /* wait 2 us */
        }
    }
    enable_irq(); /* enable irq */
    return 0; /* success return 0 */
}
uint8_t ds18b20_set_mode( ds18b20_mode_t mode)
{
    {
        
    }
    {
        
    }
    mode = (uint8_t)mode; /* set mode */
    return 0; /* success return 0 */
}
uint8_t ds18b20_get_mode( ds18b20_mode_t* mode)
{
    {
        
    }
    {
        
    }
    *mode = (ds18b20_mode_t)(mode); /* get mode */
    return 0; /* success return 0 */
}
uint8_t ds18b20_set_rom( uint8_t rom[8])
{
    {
        
    }
    {
        
    }
    memcpy(rom, rom, 8); /* copy rom */
    return 0; /* success return 0 */
}
uint8_t ds18b20_get_rom( uint8_t rom[8])
{
    uint8_t i;
    {
        
    }
    {
        
    }
    if (a_ds18b20_reset(handle) != 0) /* reset bus */
    {
        
        
    }
    if (a_ds18b20_write_byte( DS18B20_CMD_READ_ROM) != 0) /* write read rom command */
    {
        
        
    }
    for (i = 0; i < 8; i++) /* read 8 bytes */
    {
        if (a_ds18b20_read_byte( (uint8_t*)&rom[i]) != 0) /* read 1 byte */
        {
            
            
        }
    }
    return 0; /* success return 0 */
}
uint8_t ds18b20_scratchpad_set_resolution( ds18b20_resolution_t resolution)
{
    uint8_t i, buf[9];
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scratchpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* write skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_WRITE_SCRATCHPAD) != 0) /* write scratchpad command */
        {
            
            
        }
        buf[4] &= ~(3 << 5);       /* clear resolution bits */
        buf[4] |= resolution << 5; /* set resolution bits */
        for (i = 0; i < 3; i++) {
            if (a_ds18b20_write_byte( buf[2 + i]) != 0) /* write command */
            {
                
                
            }
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* send match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* send read scratchpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* match rom */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_WRITE_SCRATCHPAD) != 0) /* write scratchpad command */
        {
            
            
        }
        buf[4] &= ~(3 << 5);       /* clear resolution bits */
        buf[4] |= resolution << 5; /* set resolution bits */
        for (i = 0; i < 3; i++) {
            if (a_ds18b20_write_byte( buf[2 + i]) != 0) /* write command */
            {
                
                
            }
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_scratchpad_get_resolution( ds18b20_resolution_t* resolution)
{
    uint8_t i, buf[9];
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* write read scratchpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) /* read 9 bytes */
        {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *resolution = (ds18b20_resolution_t)(buf[4] >> 5); /* get resolution */
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scratchpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *resolution = (ds18b20_resolution_t)(buf[4] >> 5); /* get resolution */
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_scratchpad_set_alarm_threshold( int8_t threshold_high, int8_t threshold_low)
{
    uint8_t i, buf[9];
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom commmand */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scrachpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_WRITE_SCRATCHPAD) != 0) /* sent write scratchpad command */
        {
            
            
        }
        buf[2] = (uint8_t)threshold_high; /* set high threshold */
        buf[3] = (uint8_t)threshold_low;  /* set low threshold */
        for (i = 0; i < 3; i++) {
            if (a_ds18b20_write_byte( buf[2 + i]) != 0) /* write command */
            {
                
                
            }
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scrachpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 byte */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_WRITE_SCRATCHPAD) != 0) /* write scratchpad command */
        {
            
            
        }
        buf[2] = (uint8_t)threshold_high; /* set high threshold */
        buf[3] = (uint8_t)threshold_low;  /* set low threshold */
        for (i = 0; i < 3; i++) {
            if (a_ds18b20_write_byte( buf[2 + i]) != 0) /* write command */
            {
                
                
            }
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_scrachpad_get_alarm_threshold( int8_t* threshold_high, int8_t* threshold_low)
{
    uint8_t i, buf[9];
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scrachpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read 9 bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *threshold_high = (int8_t)(buf[2]); /* get high threshold */
        *threshold_low  = (int8_t)(buf[3]); /* get low threshold */
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* write match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* sent read scratchpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) /* read 9 bytes */
        {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *threshold_high = (int8_t)(buf[2]); /* get high threshold */
        *threshold_low  = (int8_t)(buf[3]); /* get low threshold */
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_copy_scratchpad_to_eeprom(ds18b20_handle_t* handle)
{
    uint8_t i;
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_COPY_SCRATCHPAD) != 0) /* write copy scratchpad command */
        {
            
            
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* write match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_COPY_SCRATCHPAD) != 0) /* write copy scratchpad command */
        {
            
            
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_copy_eeprom_to_scratchpad(ds18b20_handle_t* handle)
{
    uint8_t i;
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use in skip rom */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_RECALL_EE) != 0) /* write recall ee command */
        {
            
            
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_RECALL_EE) != 0) /* sent recall ee command */
        {
            
            
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_alarm_convert_to_register( float temp, int8_t* reg)
{
    {
        
    }
    {
        
    }
    *reg = (int8_t)(temp); /* convert real data to register data */
    return 0; /* success return 0 */
}
uint8_t ds18b20_alarm_convert_to_data( int8_t reg, float* temp)
{
    {
        
    }
    {
        
    }
    *temp = (float)(reg); /* convert raw data to real data */
    return 0; /* success return 0 */
}
uint8_t ds18b20_init(ds18b20_handle_t* handle)
{
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (bus_init == NULL) /* check bus_init */
    {
        
        
    }
    if (bus_deinit == NULL) /* check bus_deinit */
    {
        
        
    }
    if (bus_read == NULL) /* check bus_read */
    {
        
        
    }
    if (bus_write == NULL) /* check bus_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (delay_us == NULL) /* check delay_us */
    {
        
        
    }
    if (enable_irq == NULL) /* check enable_irq */
    {
        
        
    }
    if (disable_irq == NULL) /* check disable_irq */
    {
        
        
    }
    if (bus_init() != 0) /* initialize bus */
    {
        
        
    }
    if (a_ds18b20_reset(handle) != 0) /* reset chip */
    {
        
        (void)bus_deinit();                      /* close bus */
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t ds18b20_deinit(ds18b20_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (bus_deinit() != 0) /* close bus */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t ds18b20_read( int16_t* raw, float* temp)
{
    uint8_t  i, buf[9];
    uint8_t  res;
    uint32_t cnt;
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_CONVERT_T) != 0) /* sent convert temp command */
        {
            
            
        }
        cnt = 0;                          /* reset cnt */
        res = 0;                          /* reset res */
        while ((res == 0) && (cnt < 100)) /* wait 1 s */
        {
            if (a_ds18b20_read_bit( (uint8_t*)&res) != 0) /* read 1 bit */
            {
                
                
            }
            delay_ms(10); /* delay 10 ms */
            cnt++;                /* cnt++ */
        }
        if (cnt >= 100) /* if cnt is over 100 times */
        {
            
            return 1; /* reset error */
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* send skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* write read scrachpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) /* read 9 bytes */
        {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read bytes */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *raw = (int16_t)(((uint16_t)buf[1]) << 8) | buf[0];    /* get raw data */
        if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_9BIT) /* if 9 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 3;      /* right shift 3 */
                *raw = (*raw) | 0xE000U; /* set negtive part */
            } else                       /* if positive */
            {
                *raw = (*raw) >> 3; /* right shift 3 */
            }
            *temp = (float)(*raw) * 0.5f;                              /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_10BIT) /* if 10 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 2;      /* right shift 2 */
                *raw = (*raw) | 0xC000U; /* set negtive part */
            } else {
                *raw = (*raw) >> 2; /* right shift 2 */
            }
            *temp = (float)(*raw) * 0.25f;                             /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_11BIT) /* if 11 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 1;      /* right shift 1 */
                *raw = (*raw) | 0x8000U; /* set negtive part */
            } else {
                *raw = (*raw) >> 1; /* right shift 1 */
            }
            *temp = (float)(*raw) * 0.125f;                            /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_12BIT) /* if 12 bit resolution */
        {
            *raw  = (*raw) >> 0;             /* right shift 0 */
            *temp = (float)(*raw) * 0.0625f; /* convert to real data */
        } else {
            
            
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_CONVERT_T) != 0) /* sent convert temp command */
        {
            
            
        }
        cnt = 0;                          /* reset cnt */
        res = 0;                          /* reset res */
        while ((res == 0) && (cnt < 100)) /* read max 1s */
        {
            if (a_ds18b20_read_bit( (uint8_t*)&res) != 0) /* read 1 bit */
            {
                
                
            }
            delay_ms(10); /* delay 10 ms */
            cnt++;                /* cnt++ */
        }
        if (cnt >= 100) /* if cnt is over 100 times */
        {
            
            
        }
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_SCRATCHPAD) != 0) /* send read scrachpad command */
        {
            
            
        }
        for (i = 0; i < 9; i++) /* read 9 bytes */
        {
            if (a_ds18b20_read_byte( (uint8_t*)&buf[i]) != 0) /* read byte */
            {
                
                
            }
        }
        if (a_ds18b20_check_crc((uint8_t*)buf, 8, buf[8]) != 0) /* check crc */
        {
            
            
        }
        *raw = (int16_t)(((uint16_t)buf[1]) << 8) | buf[0];    /* get raw data */
        if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_9BIT) /* if 9 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 3;      /* right shift 3 */
                *raw = (*raw) | 0xE000U; /* set negtive part */
            } else                       /* if positive */
            {
                *raw = (*raw) >> 3; /* right shift 3 */
            }
            *temp = (float)(*raw) * 0.5f;                              /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_10BIT) /* if 10 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 2;      /* right shift 2 */
                *raw = (*raw) | 0xC000U; /* set negtive part */
            } else {
                *raw = (*raw) >> 2; /* right shift 2 */
            }
            *temp = (float)(*raw) * 0.25f;                             /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_11BIT) /* if 11 bit resolution */
        {
            if ((((uint16_t)(*raw)) & (1 << 15)) != 0) /* if negtive */
            {
                *raw = (*raw) >> 1;      /* right shift 1 */
                *raw = (*raw) | 0x8000U; /* set negtive part */
            } else {
                *raw = (*raw) >> 1; /* right shift 1 */
            }
            *temp = (float)(*raw) * 0.125f;                            /* convert to real data */
        } else if (((buf[4] >> 5) & 0x03) == DS18B20_RESOLUTION_12BIT) /* if 12 bit resolution */
        {
            *raw  = (*raw) >> 0;             /* right shift 0 */
            *temp = (float)(*raw) * 0.0625f; /* convert to real data */
        } else {
            
            
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
static uint8_t a_ds18b20_read_2bit( uint8_t* data)
{
    uint8_t i;
    uint8_t res;
    *data = 0;              /* reset data */
    disable_irq();  /* disable irq */
    for (i = 0; i < 2; i++) /* read 2 bit */
    {
        *data <<= 1;                                         /* left shift 1 */
        if (a_ds18b20_read_bit( (uint8_t*)&res) != 0) /* read one bit */
        {
            enable_irq();                               /* enable irq */
            
            
        }
        *data = (*data) | res; /* get 1 bit */
    }
    enable_irq(); /* enable irq */
    return 0; /* success return 0 */
}
static uint8_t a_ds18b20_write_bit( uint8_t bit)
{
    disable_irq();         /* disable irq */
    if (bus_write(0) != 0) /* write 0 */
    {
        enable_irq();                                /* enable irq */
        
        
    }
    delay_us(12);            /* wait 12 us */
    if (bus_write(bit) != 0) /* write bit */
    {
        enable_irq();                                /* enable irq */
        
        
    }
    delay_us(30);          /* wait 30 us */
    if (bus_write(1) != 0) /* write 1 */
    {
        enable_irq();                                /* enable irq */
        
        
    }
    delay_us(5);  /* wait 5 us */
    enable_irq(); /* enable irq */
    return 0; /* success return 0 */
}
static uint8_t a_ds18b20_search( uint8_t (*pid)[8], uint8_t cmd, uint8_t* number)
{
    uint8_t k, l = 0, conflict_bit, m, n;
    uint8_t buffer[DS18B20_MAX_SEARCH_SIZE];
    uint8_t ss[64];
    uint8_t s   = 0;
    uint8_t num = 0;
    if ((*number) > DS18B20_MAX_SEARCH_SIZE) /* check number */
    {
        
        
    }
    memset((uint8_t*)buffer, 0, DS18B20_MAX_SEARCH_SIZE); /* clear buffer */
    memset((uint8_t*)ss, 0, sizeof(uint8_t) * 64);        /* clear buffer */
    do {
        if (a_ds18b20_reset(handle) != 0) /* reset bus */
        {
            
            
        }
        if (a_ds18b20_write_byte( cmd) != 0) /* write 1 byte */
        {
            
            
        }
        for (m = 0; m < 8; m++) /* read 8 byte */
        {
            for (n = 0; n < 8; n++) /* read 8 bit */
            {
                if (a_ds18b20_read_2bit( (uint8_t*)&k) != 0) /* read 2 bit */
                {
                    
                    
                }
                k = k & 0x03;  /* get valid bits */
                s = s >> 1;    /* right shift 1 bit */
                if (k == 0x01) /* 0000 0001 */
                {
                    if (a_ds18b20_write_bit( 0) != 0) /* write 0 */
                    {
                        
                        
                    }
                    ss[(m * 8 + n)] = 0; /* set 0 */
                } else if (k == 0x02)    /* 0000 0010 */
                {
                    s = s | 0x80;                            /* set 7 bit */
                    if (a_ds18b20_write_bit( 1) != 0) /* write 1 */
                    {
                        
                        
                    }
                    ss[(m * 8 + n)] = 1; /* set 1 */
                } else if (k == 0x00)    /* if 0000 */
                {
                    conflict_bit = (uint8_t)(m * 8 + n + 1); /* flag conflict bit */
                    if (conflict_bit > buffer[l])            /* check buffer */
                    {
                        if (a_ds18b20_write_bit( 0) != 0) /* write 0 */
                        {
                            
                            
                        }
                        ss[(m * 8 + n)] = 0;             /* set 0 */
                        buffer[++l]     = conflict_bit;  /* set conflict bit */
                    } else if (conflict_bit < buffer[l]) /* if > buffer */
                    {
                        s = s | ((ss[(m * 8 + n)] & 0x01) << 7);               /* get s */
                        if (a_ds18b20_write_bit( ss[(m * 8 + n)]) != 0) /* write data */
                        {
                            
                            
                        }
                    } else if (conflict_bit == buffer[l]) /* if == buffer */
                    {
                        s = s | 0x80;                            /* set 7 bit */
                        if (a_ds18b20_write_bit( 1) != 0) /* write 1 */
                        {
                            
                            
                        }
                        ss[(m * 8 + n)] = 1;     /* set 1 */
                        l               = l - 1; /* l-- */
                    } else {
                    }
                } else {
                    *number = num; /* save num */
                    return 0; /* success return 0 */
                }
                delay_us(5); /* delay 5 us */
            }
            pid[num][m] = s; /* save s */
            s           = 0; /* reset s */
        }
        num++;               /* num++ */
        if (num > (*number)) /* check num range */
        {
            break; /* break */
        }
    } while (buffer[l] != 0); /* check buffer[l] */
    *number = num;            /* set number */
    return 0; /* success return 0 */
}
uint8_t ds18b20_search_rom( uint8_t (*rom)[8], uint8_t* num)
{
    {
        
    }
    {
        
    }
    return a_ds18b20_search( rom, DS18B20_CMD_SEARCH_ROM, num); /* return search result */
}
uint8_t ds18b20_search_alarm( uint8_t (*rom)[8], uint8_t* num)
{
    {
        
    }
    {
        
    }
    return a_ds18b20_search( rom, DS18B20_CMD_ALARM_SEARCH, num); /* return search result */
}
uint8_t ds18b20_get_power_mode( ds18b20_power_mode_t* power_mode)
{
    uint8_t i;
    {
        
    }
    {
        
    }
    if (mode == DS18B20_MODE_SKIP_ROM) /* if use skip rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* bus reset */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_SKIP_ROM) != 0) /* sent skip rom command */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_POWER_SUPPLY) != 0) /* write read power supply command */
        {
            
            
        }
        if (a_ds18b20_read_bit( (uint8_t*)power_mode) != 0) /* get power mode */
        {
            
            
        }
        return 0;                                      /* success return 0 */
    } else if (mode == DS18B20_MODE_MATCH_ROM) /* if use match rom mode */
    {
        if (a_ds18b20_reset(handle) != 0) /* bus reset */
        {
            
            
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_MATCH_ROM) != 0) /* sent match rom command */
        {
            
            
        }
        for (i = 0; i < 8; i++) {
            if (a_ds18b20_write_byte( rom[i]) != 0) /* send rom */
            {
                
                
            }
        }
        if (a_ds18b20_write_byte( DS18B20_CMD_READ_POWER_SUPPLY) != 0) /* write read power supply */
        {
            
            
        }
        if (a_ds18b20_read_bit( (uint8_t*)power_mode) != 0) /* get power mode */
        {
            
            
        }
        return 0; /* success return 0 */
    } else {
        
        
    }
}
uint8_t ds18b20_info(ds18b20_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(ds18b20_info_t));                 /* initialize ds18b20 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "GPIO", 8);                     /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
