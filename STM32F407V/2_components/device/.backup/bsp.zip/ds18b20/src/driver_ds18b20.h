
#ifndef DRIVER_DS18B20_H
#define DRIVER_DS18B20_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
#define DS18B20_MAX_SEARCH_SIZE 64  // max 64 devices
typedef enum {
    DS18B20_MODE_SKIP_ROM  = 0x00,  // skip rom mode
    DS18B20_MODE_MATCH_ROM = 0x01,  // match rom mode
} ds18b20_mode_t;
typedef enum {
    DS18B20_POWER_MODE_PARASITE   = 0x00,  // parasite power mode
    DS18B20_POWER_MODE_EXTERNALLY = 0x01,  // externally power mode
} ds18b20_power_mode_t;
typedef enum {
    DS18B20_RESOLUTION_9BIT  = 0x00,  // 9 bit resolution
    DS18B20_RESOLUTION_10BIT = 0x01,  // 10 bit resolution
    DS18B20_RESOLUTION_11BIT = 0x02,  // 11 bit resolution
    DS18B20_RESOLUTION_12BIT = 0x03,  // 12 bit resolution
} ds18b20_resolution_t;

uint8_t ds18b20_info();
uint8_t ds18b20_init();
uint8_t ds18b20_deinit();
uint8_t ds18b20_read(int16_t* raw, float* temp);
uint8_t ds18b20_set_mode(ds18b20_mode_t mode);
uint8_t ds18b20_get_mode(ds18b20_mode_t* mode);
uint8_t ds18b20_set_rom(uint8_t rom[8]);
uint8_t ds18b20_get_rom(uint8_t rom[8]);
uint8_t ds18b20_scratchpad_set_resolution(ds18b20_resolution_t resolution);
uint8_t ds18b20_scratchpad_get_resolution(ds18b20_resolution_t* resolution);
uint8_t ds18b20_copy_scratchpad_to_eeprom();
uint8_t ds18b20_copy_eeprom_to_scratchpad();
uint8_t ds18b20_scratchpad_set_alarm_threshold(int8_t threshold_high, int8_t threshold_low);
uint8_t ds18b20_scrachpad_get_alarm_threshold(int8_t* threshold_high, int8_t* threshold_low);
uint8_t ds18b20_alarm_convert_to_register(float temp, int8_t* reg);
uint8_t ds18b20_alarm_convert_to_data(int8_t reg, float* temp);
uint8_t ds18b20_search_rom(uint8_t (*rom)[8], uint8_t* num);
uint8_t ds18b20_search_alarm(uint8_t (*rom)[8], uint8_t* num);
uint8_t ds18b20_get_power_mode(ds18b20_power_mode_t* power_mode);
#ifdef __cplusplus
}
#endif
#endif
