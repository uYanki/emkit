
#ifndef DRIVER_HTU21D_BASIC_H
#define DRIVER_HTU21D_BASIC_H
#include "driver_htu21d_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define HTU21D_BASIC_DEFAULT_MODE              HUT21D_MODE_NO_HOLD_MASTER                       // no hold master mode 
#define HTU21D_BASIC_DEFAULT_RESOLUTION        HTU21D_RESOLUTION_TEMP_14_BITS_RH_12_BITS        // temp 14 bits and rh 12 bits 
#define HTU21D_BASIC_DEFAULT_HEATER            HUT21D_BOOL_TRUE                                 // enable heater 
#define HTU21D_BASIC_DEFAULT_OTP_RELOAD        HTU21D_BOOL_FALSE                                // enable otp reload 
uint8_t htu21d_basic_init(void);
uint8_t htu21d_basic_read(float *temperature, float *humidity);
uint8_t htu21d_basic_deinit(void);
uint8_t htu21d_basic_get_serial_number(uint64_t *number);
#ifdef __cplusplus
}
#endif
#endif
