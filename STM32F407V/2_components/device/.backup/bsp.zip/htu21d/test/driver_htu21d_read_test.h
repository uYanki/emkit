
#ifndef DRIVER_HTU21D_READ_TEST_H
#define DRIVER_HTU21D_READ_TEST_H
#include "driver_htu21d_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t htu21d_read_test(htu21d_bool_t hold_master_enable, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
