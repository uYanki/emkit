
#ifndef DRIVER_HTU21D_REGISTER_TEST_H
#define DRIVER_HTU21D_REGISTER_TEST_H
#include "driver_htu21d_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t htu21d_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
