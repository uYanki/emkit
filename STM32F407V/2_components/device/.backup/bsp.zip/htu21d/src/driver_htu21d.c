
#include "driver_htu21d.h"

#define MANUFACTURER_NAME  "TE"  // manufacturer name
#define SUPPLY_VOLTAGE_MIN 1.5f  // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f  // chip max supply voltage

#define HTU21D_ADDRESS                          0x80  // iic device address
#define HTU21D_COMMAND_TRIG_TEMP_HOLD_MASTER    0xE3  // trigger temperature measurement with hold master command
#define HTU21D_COMMAND_TRIG_HUMI_HOLD_MASTER    0xE5  // trigger humidity measurement with hold master command
#define HTU21D_COMMAND_TRIG_TEMP_NO_HOLD_MASTER 0xF3  // trigger temperature measurement command
#define HTU21D_COMMAND_TRIG_HUMI_NO_HOLD_MASTER 0xF5  // trigger humidity measurement command
#define HTU21D_COMMAND_WRITE_USER_REGISTER      0xE6  // write user register command
#define HTU21D_COMMAND_READ_USER_REGISTER       0xE7  // read user register command
#define HTU21D_COMMAND_SOFT_RESET               0xFE  // soft reset command
static uint8_t a_htu21d_write_cmd(htu21d_handle_t* handle, uint8_t* buf, uint16_t len)
{
    if (iic_write_cmd(HTU21D_ADDRESS, buf, len) != 0) /* iic write */
        else
        {
            return 0; /* success return 0 */
        }
}
static uint8_t a_htu21d_read_cmd(htu21d_handle_t* handle, uint8_t* buf, uint16_t len)
{
    if (iic_read_cmd(HTU21D_ADDRESS, buf, len) != 0) /* iic read */
        else
        {
            return 0; /* success return 0 */
        }
}
static uint8_t a_htu21d_write(htu21d_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (iic_write(HTU21D_ADDRESS, reg, buf, len) != 0) /* iic write */
        else
        {
            return 0; /* success return 0 */
        }
}
static uint8_t a_htu21d_read(htu21d_handle_t* handle, uint8_t mode, uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (mode == HTU21D_MODE_HOLD_MASTER) /* hold master */
    {
        if (iic_read_with_scl(HTU21D_ADDRESS, reg, buf, len) != 0) /* iic read */
            else
            {
                return 0; /* success return 0 */
            }
    } else /* no hold master */
    {
        if (iic_read(HTU21D_ADDRESS, reg, buf, len) != 0) /* iic read */
            else
            {
                return 0; /* success return 0 */
            }
    }
}
static uint8_t a_htu21d_crc(uint16_t value, uint32_t crc)
{
    uint32_t polynom = 0x988000U;
    uint32_t msb     = 0x800000U;
    uint32_t mask    = 0xFF8000U;
    uint32_t result  = (uint32_t)value << 8;
    while (msb != 0x80) /* check the msb */
    {
        if ((result & msb) != 0) /* check the result */
        {
            result = ((result ^ polynom) & mask) | (result & (~mask)); /* get the new result */
        }
        msb >>= 1;     /* right shift 1 */
        mask >>= 1;    /* right shift 1 */
        polynom >>= 1; /* right shift 1 */
    }
    if (result == crc) /* check the result */
    {
        return 0; /* success return 0 */
    } else {
    }
}
uint8_t htu21d_set_mode(htu21d_handle_t* handle, htu21d_mode_t mode)
{
    mode = mode; /* set the mode */
    return 0;    /* success return 0 */
}
uint8_t htu21d_get_mode(htu21d_handle_t* handle, htu21d_mode_t* mode)
{
    {

    }

    {

    }* mode = (htu21d_mode_t)(mode); /* get the mode */
    return 0;                        /* success return 0 */
}
uint8_t htu21d_soft_reset(htu21d_handle_t* handle)
{
    uint8_t res;

    res = a_htu21d_write(HTU21D_COMMAND_SOFT_RESET, NULL, 0); /* soft reset */

    delay_ms(15); /* delay 15 ms */
    return 0;     /* success return 0 */
}
uint8_t htu21d_read_temperature_humidity(htu21d_handle_t* handle,
                                         uint16_t*        temperature_raw,
                                         float*           temperature_s,
                                         uint16_t*        humidity_raw,
                                         float*           humidity_s)
{
    uint8_t  res;
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t data;

    if (mode == HTU21D_MODE_HOLD_MASTER) /* hold master mode */
    {
        res = a_htu21d_read(HTU21D_MODE_HOLD_MASTER,
                            HTU21D_COMMAND_TRIG_TEMP_HOLD_MASTER, buf, 3); /* read temperature */

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x00)      /* check the status */

            *temperature_raw = data; /* copy data */

        res = a_htu21d_read(HTU21D_MODE_HOLD_MASTER,
                            HTU21D_COMMAND_TRIG_HUMI_HOLD_MASTER, buf, 3); /* read humidity */

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x02)      /* check the status */

            *humidity_raw = data; /* copy data */
    } else                        /* no hold master mode */
    {
        uint8_t cmd;

        cmd = HTU21D_COMMAND_TRIG_TEMP_NO_HOLD_MASTER; /* read temperature */
        res = a_htu21d_write_cmd(&cmd, 1);             /* write the command */

        if (resolution == HTU21D_RESOLUTION_TEMP_11_BITS_RH_11_BITS) /* temp 11 bits and rh 11 bits */
        {
            delay_ms(7);                                                   /* delay 7 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_12_BITS_RH_8_BITS) /* temp 12 bits and rh 8 bits */
        {
            delay_ms(13);                                                   /* delay 13 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_13_BITS_RH_10_BITS) /* temp 13 bits and rh 10 bits */
        {
            delay_ms(25); /* delay 25 ms */
        } else            /* temp 14 bits and rh 12 bits */
        {
            delay_ms(50); /* delay 50 ms */
        }
        res = a_htu21d_read_cmd(buf, 3);

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x00)      /* check the status */

            *temperature_raw = data; /* copy data */

        cmd = HTU21D_COMMAND_TRIG_HUMI_NO_HOLD_MASTER; /* read humidity */
        res = a_htu21d_write_cmd(&cmd, 1);             /* write the command */

        if (resolution == HTU21D_RESOLUTION_TEMP_11_BITS_RH_11_BITS) /* temp 11 bits and rh 11 bits */
        {
            delay_ms(7);                                                   /* delay 7 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_12_BITS_RH_8_BITS) /* temp 12 bits and rh 8 bits */
        {
            delay_ms(13);                                                   /* delay 13 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_13_BITS_RH_10_BITS) /* temp 13 bits and rh 10 bits */
        {
            delay_ms(25); /* delay 25 ms */
        } else            /* temp 14 bits and rh 12 bits */
        {
            delay_ms(50); /* delay 50 ms */
        }
        res = a_htu21d_read_cmd(buf, 3);

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x02)      /* check the status */

            *humidity_raw = data; /* copy data */
    }
    *temperature_s = (float)(*temperature_raw) / 65536.0f * 175.72f - 46.85f; /* convert raw temperature */
    *humidity_s    = (float)(*humidity_raw) / 65536.0f * 125.0f - 6.0f;       /* convert raw humidity */
    return 0;                                                                 /* success return 0 */
}
uint8_t htu21d_read_temperature(htu21d_handle_t* handle, uint16_t* temperature_raw, float* temperature_s)
{
    uint8_t  res;
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t data;

    if (mode == HTU21D_MODE_HOLD_MASTER) /* hold master mode */
    {
        res = a_htu21d_read(HTU21D_MODE_HOLD_MASTER,
                            HTU21D_COMMAND_TRIG_TEMP_HOLD_MASTER, buf, 3); /* read temperature */

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x00)      /* check the status */

            *temperature_raw = data; /* copy data */
    } else                           /* no hold master mode */
    {
        uint8_t cmd;

        cmd = HTU21D_COMMAND_TRIG_TEMP_NO_HOLD_MASTER; /* read temperature */
        res = a_htu21d_write_cmd(&cmd, 1);             /* write the command */

        if (resolution == HTU21D_RESOLUTION_TEMP_11_BITS_RH_11_BITS) /* temp 11 bits and rh 11 bits */
        {
            delay_ms(7);                                                   /* delay 7 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_12_BITS_RH_8_BITS) /* temp 12 bits and rh 8 bits */
        {
            delay_ms(13);                                                   /* delay 13 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_13_BITS_RH_10_BITS) /* temp 13 bits and rh 10 bits */
        {
            delay_ms(25); /* delay 25 ms */
        } else            /* temp 14 bits and rh 12 bits */
        {
            delay_ms(50); /* delay 50 ms */
        }
        res = a_htu21d_read_cmd(buf, 3);

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x00)      /* check the status */

            *temperature_raw = data; /* copy data */
    }
    *temperature_s = (float)(*temperature_raw) / 65536.0f * 175.72f - 46.85f; /* convert raw temperature */
    return 0;                                                                 /* success return 0 */
}
uint8_t htu21d_read_humidity(htu21d_handle_t* handle, uint16_t* humidity_raw, float* humidity_s)
{
    uint8_t  res;
    uint8_t  buf[3];
    uint8_t  status;
    uint16_t data;

    if (mode == HTU21D_MODE_HOLD_MASTER) /* hold master mode */
    {
        res = a_htu21d_read(HTU21D_MODE_HOLD_MASTER,
                            HTU21D_COMMAND_TRIG_HUMI_HOLD_MASTER, buf, 3); /* read humidity */

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x02)      /* check the status */

            *humidity_raw = data; /* copy data */
    } else                        /* no hold master mode */
    {
        uint8_t cmd;

        cmd = HTU21D_COMMAND_TRIG_HUMI_NO_HOLD_MASTER; /* read humidity */
        res = a_htu21d_write_cmd(&cmd, 1);             /* write the command */

        if (resolution == HTU21D_RESOLUTION_TEMP_11_BITS_RH_11_BITS) /* temp 11 bits and rh 11 bits */
        {
            delay_ms(7);                                                   /* delay 7 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_12_BITS_RH_8_BITS) /* temp 12 bits and rh 8 bits */
        {
            delay_ms(13);                                                   /* delay 13 ms */
        } else if (resolution == HTU21D_RESOLUTION_TEMP_13_BITS_RH_10_BITS) /* temp 13 bits and rh 10 bits */
        {
            delay_ms(25); /* delay 25 ms */
        } else            /* temp 14 bits and rh 12 bits */
        {
            delay_ms(50); /* delay 50 ms */
        }
        res = a_htu21d_read_cmd(buf, 3);

        data = ((uint16_t)buf[0] << 8) | buf[1]; /* get the raw data */
        if (a_htu21d_crc(data, buf[2]) != 0)     /* check the crc */

            status = data & 0x3; /* get the status */
        if (status != 0x02)      /* check the status */

            *humidity_raw = data; /* copy data */
    }
    *humidity_s = (float)(*humidity_raw) / 65536.0f * 125.0f - 6.0f; /* convert raw humidity */
    return 0;                                                        /* success return 0 */
}
uint8_t htu21d_set_resolution(htu21d_handle_t* handle, htu21d_resolution_t resolution)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    prev &= ~(1 << 7);                                                  /* clear bit 7 */
    prev &= ~(1 << 0);                                                  /* clear bit 0 */
    prev |= ((resolution >> 1) & 0x01) << 7;                            /* set bit 7 */
    prev |= ((resolution >> 0) & 0x01) << 0;                            /* set bit 0 */
    res = a_htu21d_write(HTU21D_COMMAND_WRITE_USER_REGISTER, &prev, 1); /* write config */

    return 0; /* success return 0 */
}
uint8_t htu21d_get_resolution(htu21d_handle_t* handle, htu21d_resolution_t* resolution)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    {

    }* resolution = (htu21d_resolution_t)((((prev >> 7) & 0x01) << 1) | (((prev >> 0) & 0x01) << 0)); /* get the resolution */
    resolution    = *resolution;                                                                      /* save the resolution */
    return 0;                                                                                         /* success return 0 */
}
uint8_t htu21d_get_battery_status(htu21d_handle_t* handle, htu21d_status_t* status)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    {

    }* status = (htu21d_status_t)((prev >> 6) & 0x01); /* get the status */
    return 0;                                          /* success return 0 */
}
uint8_t htu21d_set_heater(htu21d_handle_t* handle, htu21d_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    prev &= ~(1 << 2);                                                  /* clear bit 2 */
    prev |= enable << 2;                                                /* set the bool */
    res = a_htu21d_write(HTU21D_COMMAND_WRITE_USER_REGISTER, &prev, 1); /* write config */

    return 0; /* success return 0 */
}
uint8_t htu21d_get_heater(htu21d_handle_t* handle, htu21d_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    {

    }* enable = (htu21d_bool_t)((prev >> 2) & 0x01); /* set the bool */
    return 0;                                        /* success return 0 */
}
uint8_t htu21d_set_disable_otp_reload(htu21d_handle_t* handle, htu21d_bool_t enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    prev &= ~(1 << 1);                                                  /* clear bit 1 */
    prev |= enable << 1;                                                /* set the bool */
    res = a_htu21d_write(HTU21D_COMMAND_WRITE_USER_REGISTER, &prev, 1); /* write config */

    return 0; /* success return 0 */
}
uint8_t htu21d_get_disable_otp_reload(htu21d_handle_t* handle, htu21d_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    {

    }* enable = (htu21d_bool_t)((prev >> 1) & 0x01); /* set the bool */
    return 0;                                        /* success return 0 */
}
uint8_t htu21d_get_serial_number(htu21d_handle_t* handle, uint64_t* number)
{
    uint8_t i;
    uint8_t res;
    uint8_t cmd[2];
    uint8_t data[14];

    cmd[0] = 0xFA;                       /* command 0 */
    cmd[1] = 0x0F;                       /* command 1 */
    res    = a_htu21d_write_cmd(cmd, 2); /* write command */

    res = a_htu21d_read_cmd(data, 8); /* read command */

    cmd[0] = 0xFC;                       /* command 0 */
    cmd[1] = 0xC9;                       /* command 1 */
    res    = a_htu21d_write_cmd(cmd, 2); /* write command */

    res = a_htu21d_read_cmd(data + 8, 6); /* read command */

    for (i = 0; i < 8; i += 2) /* check first data */
    {
        if (a_htu21d_crc(data[i], data[i + 1]) != 0) /* check the crc */
    }
    for (i = 8; i < 14; i += 3) /* check last data */
    {
        if (a_htu21d_crc(((uint16_t)data[i] << 8) | data[i + 1], data[i + 2]) != 0) /* check the crc */
    }
    *number = ((uint64_t)data[0] << 56) | ((uint64_t)data[2] << 48) | ((uint64_t)data[4] << 40) | ((uint64_t)data[6] << 32) | ((uint64_t)data[8] << 24) | ((uint64_t)data[9] << 16) | ((uint64_t)data[11] << 8) | ((uint64_t)data[12] << 0); /* set the number */
    return 0;                                                                                                                                                                                                                                /* success return 0 */
}
uint8_t htu21d_init(htu21d_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;

    res = a_htu21d_write(HTU21D_COMMAND_SOFT_RESET, NULL, 0); /* soft reset */

    delay_ms(15); /* delay 15 ms */
    res = a_htu21d_read(HUT21D_MODE_NO_HOLD_MASTER,
                        HTU21D_COMMAND_READ_USER_REGISTER, &prev, 1); /* read config */

    resolution = (htu21d_resolution_t)((((prev >> 7) & 0x01) << 1) | (((prev >> 0) & 0x01) << 0)); /* save the resolution */
    mode       = HUT21D_MODE_NO_HOLD_MASTER;                                                       /* set no hold master */
    inited     = 1;                                                                                /* flag finish initialization */
    return 0;                                                                                      /* success return 0 */
}
uint8_t htu21d_deinit(htu21d_handle_t* handle)
{
    uint8_t res;

    res = a_htu21d_write(HTU21D_COMMAND_SOFT_RESET, NULL, 0); /* soft reset */

    delay_ms(15); /* delay 15 ms */

    inited = 0; /* flag close */
    return 0;   /* success return 0 */
}
uint8_t htu21d_set_reg(htu21d_handle_t* handle, uint8_t* buf, uint16_t len)
{
    return a_htu21d_write_cmd(buf, len); /* write command */
}
uint8_t htu21d_get_reg(htu21d_handle_t* handle, uint8_t* buf, uint16_t len)
{
    return a_htu21d_read_cmd(buf, len); /* read command */
}
uint8_t htu21d_info(htu21d_info_t* info)
{
    memset(info, 0, sizeof(htu21d_info_t));                  /* initialize htu21d info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0;                                                /* success return 0 */
}
