
#ifndef DRIVER_HTU21D_H
#define DRIVER_HTU21D_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    HTU21D_BOOL_FALSE = 0x00,  // false
    HUT21D_BOOL_TRUE  = 0x01,  // true
} htu21d_bool_t;
typedef enum {
    HTU21D_MODE_HOLD_MASTER    = 0x00,  // hold master mode
    HUT21D_MODE_NO_HOLD_MASTER = 0x01,  // no hold master mode
} htu21d_mode_t;
typedef enum {
    HTU21D_STATUS_OVER_2P25 = 0x00,  // >2.25V
    HUT21D_STATUS_LESS_2P25 = 0x01,  // <2.25V
} htu21d_status_t;
typedef enum {
    HTU21D_RESOLUTION_TEMP_11_BITS_RH_11_BITS = 0x03,  // temp 11 bits and rh 11 bits
    HTU21D_RESOLUTION_TEMP_12_BITS_RH_8_BITS  = 0x01,  // temp 12 bits and rh 8 bits
    HTU21D_RESOLUTION_TEMP_13_BITS_RH_10_BITS = 0x02,  // temp 13 bits and rh 10 bits
    HTU21D_RESOLUTION_TEMP_14_BITS_RH_12_BITS = 0x00,  // temp 14 bits and rh 12 bits
} htu21d_resolution_t;
typedef struct htu21d_handle_s {
    uint8_t mode;        // chip mode
    uint8_t resolution;  // chip resolution
    uint8_t inited;      // inited flag
} htu21d_handle_t;

uint8_t htu21d_info(htu21d_info_t* info);
uint8_t htu21d_init(htu21d_handle_t* handle);
uint8_t htu21d_deinit(htu21d_handle_t* handle);
uint8_t htu21d_set_mode(htu21d_handle_t* handle, htu21d_mode_t mode);
uint8_t htu21d_get_mode(htu21d_handle_t* handle, htu21d_mode_t* mode);
uint8_t htu21d_soft_reset(htu21d_handle_t* handle);
uint8_t htu21d_read_temperature_humidity(htu21d_handle_t* handle,
                                         uint16_t*        temperature_raw,
                                         float*           temperature_s,
                                         uint16_t*        humidity_raw,
                                         float*           humidity_s);
uint8_t htu21d_read_temperature(htu21d_handle_t* handle, uint16_t* temperature_raw, float* temperature_s);
uint8_t htu21d_read_humidity(htu21d_handle_t* handle, uint16_t* humidity_raw, float* humidity_s);
uint8_t htu21d_set_resolution(htu21d_handle_t* handle, htu21d_resolution_t resolution);
uint8_t htu21d_get_resolution(htu21d_handle_t* handle, htu21d_resolution_t* resolution);
uint8_t htu21d_get_battery_status(htu21d_handle_t* handle, htu21d_status_t* status);
uint8_t htu21d_set_heater(htu21d_handle_t* handle, htu21d_bool_t enable);
uint8_t htu21d_get_heater(htu21d_handle_t* handle, htu21d_bool_t* enable);
uint8_t htu21d_set_disable_otp_reload(htu21d_handle_t* handle, htu21d_bool_t enable);
uint8_t htu21d_get_disable_otp_reload(htu21d_handle_t* handle, htu21d_bool_t* enable);
uint8_t htu21d_get_serial_number(htu21d_handle_t* handle, uint64_t* number);
uint8_t htu21d_set_reg(htu21d_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t htu21d_get_reg(htu21d_handle_t* handle, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
