
#ifndef DRIVER_MCP9600_H
#define DRIVER_MCP9600_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MCP9600_ADDRESS_0 = 0xC0,  // addr pin connected to the GND
    MCP9600_ADDRESS_1 = 0xC2,  // addr pin connected to the VCC
} mcp9600_address_t;
typedef enum {
    MCP9600_COLD_JUNCTION_RESOLUTION_0P0625 = 0x00,  // 0.0625C
    MCP9600_COLD_JUNCTION_RESOLUTION_0P25   = 0x01,  // 0.25C
} mcp9600_cold_junction_resolution_t;
typedef enum {
    MCP9600_ADC_RESOLUTION_18_BIT = 0x00,  // 18 bit resolution
    MCP9600_ADC_RESOLUTION_16_BIT = 0x01,  // 16 bit resolution
    MCP9600_ADC_RESOLUTION_14_BIT = 0x02,  // 14 bit resolution
    MCP9600_ADC_RESOLUTION_12_BIT = 0x03,  // 12 bit resolution
} mcp9600_adc_resolution_t;
typedef enum {
    MCP9600_BURST_MODE_SAMPLE_1   = 0x00,  // 1 sample
    MCP9600_BURST_MODE_SAMPLE_2   = 0x01,  // 2 sample
    MCP9600_BURST_MODE_SAMPLE_4   = 0x02,  // 4 sample
    MCP9600_BURST_MODE_SAMPLE_8   = 0x03,  // 8 sample
    MCP9600_BURST_MODE_SAMPLE_16  = 0x04,  // 16 sample
    MCP9600_BURST_MODE_SAMPLE_32  = 0x05,  // 32 sample
    MCP9600_BURST_MODE_SAMPLE_64  = 0x06,  // 64 sample
    MCP9600_BURST_MODE_SAMPLE_128 = 0x07,  // 128 sample
} mcp9600_burst_mode_sample_t;
typedef enum {
    MCP9600_MODE_NORMAL   = 0x00,  // normal mode
    MCP9600_MODE_SHUTDOWN = 0x01,  // shutdown mode
    MCP9600_MODE_BURST    = 0x02,  // burst mode
} mcp9600_mode_t;
typedef enum {
    MCP9600_THERMOCOUPLE_TYPE_K = 0x00,  // type k
    MCP9600_THERMOCOUPLE_TYPE_J = 0x01,  // type j
    MCP9600_THERMOCOUPLE_TYPE_T = 0x02,  // type t
    MCP9600_THERMOCOUPLE_TYPE_N = 0x03,  // type n
    MCP9600_THERMOCOUPLE_TYPE_S = 0x04,  // type s
    MCP9600_THERMOCOUPLE_TYPE_E = 0x05,  // type e
    MCP9600_THERMOCOUPLE_TYPE_B = 0x06,  // type b
    MCP9600_THERMOCOUPLE_TYPE_R = 0x07,  // type r
} mcp9600_thermocouple_type_t;
typedef enum {
    MCP9600_FILTER_COEFFICIENT_0 = 0x00,  // filter off
    MCP9600_FILTER_COEFFICIENT_1 = 0x01,  // filter 1
    MCP9600_FILTER_COEFFICIENT_2 = 0x02,  // filter 2
    MCP9600_FILTER_COEFFICIENT_3 = 0x03,  // filter 3
    MCP9600_FILTER_COEFFICIENT_4 = 0x04,  // filter 4
    MCP9600_FILTER_COEFFICIENT_5 = 0x05,  // filter 5
    MCP9600_FILTER_COEFFICIENT_6 = 0x06,  // filter 6
    MCP9600_FILTER_COEFFICIENT_7 = 0x07,  // filter 7
} mcp9600_filter_coefficient_t;
typedef enum {
    MCP9600_ALERT_1 = 0x00,  // alert 1
    MCP9600_ALERT_2 = 0x01,  // alert 2
    MCP9600_ALERT_3 = 0x02,  // alert 3
    MCP9600_ALERT_4 = 0x03,  // alert 4
} mcp9600_alert_t;
typedef enum {
    MCP9600_ALERT_STATUS_LESS = 0x00,  // less than threshold
    MCP9600_ALERT_STATUS_OVER = 0x01,  // over threshold
} mcp9600_alert_status_t;
typedef enum {
    MCP9600_INPUT_RANGE_EXCEEDS = 0x01,  // exceeds
    MCP9600_INPUT_RANGE_WITHIN  = 0x00,  // within
} mcp9600_input_range_t;
typedef enum {
    MCP9600_BOOL_FALSE = 0x00,  // false
    MCP9600_BOOL_TRUE  = 0x01,  // true
} mcp9600_bool_t;
typedef enum {
    MCP9600_TEMPERATURE_MAINTAIN_DETECT_COLD_JUNCTION = 0x01,  // cold junction
    MCP9600_TEMPERATURE_MAINTAIN_DETECT_HOT_JUNCTION  = 0x00,  // hot junction
} mcp9600_temperature_maintain_detect_t;
typedef enum {
    MCP9600_DETECT_EDGE_RISING  = 0x00,  // rising detect
    MCP9600_DETECT_EDGE_FALLING = 0x01,  // falling detect
} mcp9600_detect_edge_t;
typedef enum {
    MCP9600_ACTIVE_LEVEL_LOW  = 0x00,  // active low
    MCP9600_ACTIVE_LEVEL_HIGH = 0x01,  // active high
} mcp9600_active_level_t;
typedef enum {
    MCP9600_INTERRUPT_MODE_COMPARATOR = 0x00,  // comparator mode
    MCP9600_INTERRUPT_MODE_INTERRUPT  = 0x01,  // interrupt mode
} mcp9600_interrupt_mode_t;
typedef struct mcp9600_handle_s {
    uint8_t inited;    // inited flag
    uint8_t iic_addr;  // iic address
} mcp9600_handle_t;

uint8_t mcp9600_info(mcp9600_info_t* info);
uint8_t mcp9600_set_addr_pin(mcp9600_handle_t* handle, mcp9600_address_t addr_pin);
uint8_t mcp9600_get_addr_pin(mcp9600_handle_t* handle, mcp9600_address_t* addr_pin);
uint8_t mcp9600_init(mcp9600_handle_t* handle);
uint8_t mcp9600_deinit(mcp9600_handle_t* handle);
uint8_t mcp9600_start_continuous_read(mcp9600_handle_t* handle);
uint8_t mcp9600_stop_continuous_read(mcp9600_handle_t* handle);
uint8_t mcp9600_continuous_read(mcp9600_handle_t* handle, int16_t* hot_raw, float* hot_s, int16_t* delta_raw, float* delta_s, int16_t* cold_raw, float* cold_s);
uint8_t mcp9600_single_read(mcp9600_handle_t* handle, int16_t* hot_raw, float* hot_s, int16_t* delta_raw, float* delta_s, int16_t* cold_raw, float* cold_s);
uint8_t mcp9600_get_hot_junction_temperature(mcp9600_handle_t* handle, int16_t* raw, float* s);
uint8_t mcp9600_get_junction_thermocouple_delta(mcp9600_handle_t* handle, int16_t* raw, float* s);
uint8_t mcp9600_get_cold_junction_temperature(mcp9600_handle_t* handle, int16_t* raw, float* s);
uint8_t mcp9600_get_raw_adc(mcp9600_handle_t* handle, int32_t* raw, double* uv);
uint8_t mcp9600_set_filter_coefficient(mcp9600_handle_t* handle, mcp9600_filter_coefficient_t coefficient);
uint8_t mcp9600_get_filter_coefficient(mcp9600_handle_t* handle, mcp9600_filter_coefficient_t* coefficient);
uint8_t mcp9600_set_thermocouple_type(mcp9600_handle_t* handle, mcp9600_thermocouple_type_t type);
uint8_t mcp9600_get_thermocouple_type(mcp9600_handle_t* handle, mcp9600_thermocouple_type_t* type);
uint8_t mcp9600_get_status_burst_complete_flag(mcp9600_handle_t* handle, mcp9600_bool_t* status);
uint8_t mcp9600_clear_status_burst_complete_flag(mcp9600_handle_t* handle);
uint8_t mcp9600_get_status_temperature_update_flag(mcp9600_handle_t* handle, mcp9600_bool_t* status);
uint8_t mcp9600_clear_status_temperature_update_flag(mcp9600_handle_t* handle);
uint8_t mcp9600_get_status_input_range(mcp9600_handle_t* handle, mcp9600_input_range_t* range);
uint8_t mcp9600_get_alert_status(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_alert_status_t* status);
uint8_t mcp9600_set_cold_junction_resolution(mcp9600_handle_t* handle, mcp9600_cold_junction_resolution_t resolution);
uint8_t mcp9600_get_cold_junction_resolution(mcp9600_handle_t* handle, mcp9600_cold_junction_resolution_t* resolution);
uint8_t mcp9600_set_adc_resolution(mcp9600_handle_t* handle, mcp9600_adc_resolution_t resolution);
uint8_t mcp9600_get_adc_resolution(mcp9600_handle_t* handle, mcp9600_adc_resolution_t* resolution);
uint8_t mcp9600_set_burst_mode_sample(mcp9600_handle_t* handle, mcp9600_burst_mode_sample_t sample);
uint8_t mcp9600_get_burst_mode_sample(mcp9600_handle_t* handle, mcp9600_burst_mode_sample_t* sample);
uint8_t mcp9600_set_mode(mcp9600_handle_t* handle, mcp9600_mode_t mode);
uint8_t mcp9600_get_mode(mcp9600_handle_t* handle, mcp9600_mode_t* mode);
uint8_t mcp9600_alert_limit_convert_to_register(mcp9600_handle_t* handle, float c, int16_t* reg);
uint8_t mcp9600_alert_limit_convert_to_data(mcp9600_handle_t* handle, int16_t reg, float* c);
uint8_t mcp9600_set_alert_limit(mcp9600_handle_t* handle, mcp9600_alert_t alert, int16_t reg);
uint8_t mcp9600_get_alert_limit(mcp9600_handle_t* handle, mcp9600_alert_t alert, int16_t* reg);
uint8_t mcp9600_alert_hysteresis_convert_to_register(mcp9600_handle_t* handle, float c, uint8_t* reg);
uint8_t mcp9600_alert_hysteresis_convert_to_data(mcp9600_handle_t* handle, uint8_t reg, float* c);
uint8_t mcp9600_set_alert_hysteresis(mcp9600_handle_t* handle, mcp9600_alert_t alert, uint8_t reg);
uint8_t mcp9600_get_alert_hysteresis(mcp9600_handle_t* handle, mcp9600_alert_t alert, uint8_t* reg);
uint8_t mcp9600_clear_interrupt(mcp9600_handle_t* handle, mcp9600_alert_t alert);
uint8_t mcp9600_get_interrupt(mcp9600_handle_t* handle, mcp9600_alert_t alert, uint8_t* status);
uint8_t mcp9600_set_temperature_maintain_detect(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_temperature_maintain_detect_t maintain_detect);
uint8_t mcp9600_get_temperature_maintain_detect(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_temperature_maintain_detect_t* maintain_detect);
uint8_t mcp9600_set_detect_edge(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_detect_edge_t edge);
uint8_t mcp9600_get_detect_edge(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_detect_edge_t* edge);
uint8_t mcp9600_set_active_level(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_active_level_t level);
uint8_t mcp9600_get_active_level(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_active_level_t* level);
uint8_t mcp9600_set_interrupt_mode(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_interrupt_mode_t mode);
uint8_t mcp9600_get_interrupt_mode(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_interrupt_mode_t* mode);
uint8_t mcp9600_set_alert_output(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_bool_t enable);
uint8_t mcp9600_get_alert_output(mcp9600_handle_t* handle, mcp9600_alert_t alert, mcp9600_bool_t* enable);
uint8_t mcp9600_get_device_id_revision(mcp9600_handle_t* handle, uint8_t* id, uint8_t* revision);
uint8_t mcp9600_set_reg(mcp9600_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t mcp9600_get_reg(mcp9600_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
