
#ifndef DRIVER_MCP9600_REGISTER_TEST_H
#define DRIVER_MCP9600_REGISTER_TEST_H
#include "driver_mcp9600_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mcp9600_register_test(mcp9600_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
