
#ifndef DRIVER_MS5837_BASIC_H
#define DRIVER_MS5837_BASIC_H
#include "driver_ms5837_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MS5837_BASIC_DEFAULT_TEMPERATURE_OSR        MS5837_OSR_4096        // 4096 
#define MS5837_BASIC_DEFAULT_PRESSURE_OSR           MS5837_OSR_4096        // 4096 
uint8_t ms5837_basic_init(ms5837_type_t type);
uint8_t ms5837_basic_deinit(void);
uint8_t ms5837_basic_read(float *temperature_c, float *pressure_mbar);
#ifdef __cplusplus
}
#endif
#endif
