
#ifndef DRIVER_MS5837_READ_TEST_H
#define DRIVER_MS5837_READ_TEST_H
#include "driver_ms5837_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ms5837_read_test(ms5837_type_t type, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
