
#include "driver_ms5837.h" 

#define MANUFACTURER_NAME         "TE"               // manufacturer name
#define SUPPLY_VOLTAGE_MIN        1.5f               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        3.6f               // chip max supply voltage




#define MS5837_ADDRESS            0xEC        // iic device address
#define MS5837_CMD_RESET        0x1E        // command reset
#define MS5837_CMD_D1           0x40        // command convert d1
#define MS5837_CMD_D2           0x50        // command convert d2
#define MS5837_CMD_ADC_READ     0x00        // command adc read
#define MS5837_CMD_PROM_READ    0xA0        // command prom read
static uint8_t a_ms5837_iic_read(ms5837_handle_t *handle, uint8_t reg, uint8_t *data, uint16_t len)
{
    if (iic_read(MS5837_ADDRESS, reg, data, len) != 0)        /* read the register */
    {
        
    }
    else
    {
        return 0;                                                     /* success return 0 */
    }
}
static uint8_t a_ms5837_iic_write(ms5837_handle_t *handle, uint8_t reg, uint8_t *data, uint16_t len)
{
    if (iic_write(MS5837_ADDRESS, reg, data, len) != 0)       /* write the register */
    {
        
    }
    else
    {
        return 0;                                                     /* success return 0 */
    }
}
static uint8_t a_ms5837_crc4(uint16_t n_prom[8])
{
    uint16_t cnt;
    uint16_t n_rem = 0;
    uint16_t n_bit;
    n_prom[0] = ((n_prom[0]) & 0x0FFF);                              /* crc byte is replaced by 0 */
    n_prom[7] = 0;                                                   /* subsidiary value and set to 0 */
    for (cnt = 0; cnt < 16; cnt++)                                   /* operation is performed on bytes */
    {
        if ((cnt% 2) == 1)                                           /* 16 bits progress */
        {
            n_rem ^= (uint16_t)((n_prom[cnt >> 1]) & 0x00FF);        /* low part */
        }
        else
        {
            n_rem ^= (uint16_t)(n_prom[cnt >> 1] >> 8);              /* high part */
        }
        for (n_bit = 8; n_bit > 0; n_bit--)                          /* 8 times */
        {
            if ((n_rem & (0x8000U)) != 0)                            /* check msb */
            {
                n_rem = (n_rem << 1) ^ 0x3000;                       /* xor */
            }
            else
            {
                n_rem = (n_rem << 1);                                /* do nothing */
            }
        }
    }
    n_rem= ((n_rem >> 12) & 0x000F);                                 /* final 4-bit remainder is crc code */
    return (n_rem ^ 0x00);                                           /* return the crc */
}
static void a_ms5837_calculate_temperature_pressure(ms5837_handle_t *handle, uint32_t d2_temp, float *temperature_c, 
                                                    uint32_t d1_press, float *pressure_mbar)
{
    int32_t dt = 0;
    int64_t sens = 0;
    int64_t off = 0;
    int32_t sensi = 0;
    int32_t offi = 0;
    int32_t ti = 0;
    int64_t off2 = 0;
    int64_t sens2 = 0;
    int32_t p;
    int32_t temp;
    dt = d2_temp - (uint32_t)(c[4]) * 256;                                            /* get the dt */
    if ((type == MS5837_TYPE_02BA01) || (type == MS5837_TYPE_02BA21))         /* 02ba01 and 02ba21 */
    {
        sens = (int64_t)(c[0]) * 65536 + ((int64_t)(c[2]) * dt) / 128;        /* get the sens */
        off = (int64_t)(c[1]) * 131072 + ((int64_t)(c[3]) * dt) / 64;         /* get the off */
        p = (int32_t)((d1_press * sens / 2097152 - off) / 32768);                             /* get the p  */
    }
    else                                                                                      /* 30ba26 */
    {
        sens = (int64_t)(c[0]) * 32768 + ((int64_t)(c[2]) * dt) / 256;        /* get the sens */
        off = (int64_t)(c[1]) * 65536 + ((int64_t)(c[3]) *  dt) / 128;        /* get the off */
        p = (int32_t)((d1_press * sens / 2097152 - off) / 8192);                              /* get the p */
    }
    temp = 2000 + (int64_t)(dt) * c[5] / 8388608;                                     /* get the temp */
    if ((type == MS5837_TYPE_02BA01) || (type == MS5837_TYPE_02BA21))         /* 02ba01 and 02ba21 */
    {
        if ((temp / 100) < 20)                                                                /* if < 20 */
        {
            ti = (int32_t)((11 * (int64_t)(dt) * (int64_t)(dt)) / 34359738368U);              /* get the ti */
            offi = (31 * (temp - 2000) * (temp - 2000)) / 8;                                  /* get the offi */
            sensi = (63 * (temp - 2000) * (temp - 2000)) / 32;                                /* get the sensi */
        }
    }
    else
    {
        if ((temp / 100) < 20)                                                                /* if < 20 */
        {
            ti = (int32_t)((3 * (int64_t)(dt) * (int64_t)(dt)) / 8589934592U);                /* get the ti */
            offi = (3 * (temp - 2000) * (temp - 2000)) / 2;                                   /* get the offi */
            sensi = (5 * (temp - 2000) * (temp - 2000)) / 8;                                  /* get the sensi */
            if ((temp / 100) < -15)                                                           /* if < -15 */
            {
                offi = offi + 7 * (temp + 1500) * (temp + 1500);                              /* get the offi */
                sensi = sensi + 4 * (temp + 1500) * (temp + 1500);                            /* get the sensi */
            }
        }
        else
        {
            ti = (int32_t)(2 * (dt * dt) / 137438953472U);                                    /* get the ti */
            offi = (1 * (temp - 2000) * (temp - 2000)) / 16;                                  /* get the offi */
            sensi = 0;                                                                        /* get the sensi */
        }
    }
    off2 = off - offi;                                                                        /* get the off2 */
    sens2 = sens - sensi;                                                                     /* get the sens2 */
    temp = (temp - ti);                                                                       /* get the temp */
    *temperature_c = (float)(temp) / 100.0f;                                                  /* set the temperature */
    if ((type == MS5837_TYPE_02BA01) || (type == MS5837_TYPE_02BA21))         /* 02ba01 and 02ba21 */
    {
        p = (int32_t)((((d1_press * sens2) / 2097152 - off2) / 32768));                       /* get the p */
        *pressure_mbar = (float)(p) / 100.0f;                                                 /* set the pressure */
    }
    else
    {
        p = (int32_t)((((d1_press * sens2) / 2097152 - off2) / 8192));                        /* get the p */
        *pressure_mbar = (float)(p) / 10.0f;                                                  /* set the pressure */
    }
}
static void a_ms5837_calculate_temperature(ms5837_handle_t *handle, uint32_t d2_temp, float *temperature_c)
{
    int32_t dt = 0;
    int32_t ti = 0;
    int32_t temp;
    dt = d2_temp - (uint32_t)(c[4]) * 256;                                           /* get the dt */
    temp = 2000 + (int64_t)(dt) * c[5] / 8388608;                                    /* get the temp */
    if ((type == MS5837_TYPE_02BA01) || (type == MS5837_TYPE_02BA21))        /* 02ba01 and 02ba21 */
    {
        if ((temp / 100) < 20)                                                               /* if < 20 */
        {
            ti = (int32_t)((11 * (int64_t)(dt) * (int64_t)(dt)) / 34359738368U);             /* get the ti */
        }
    }
    else
    {
        if ((temp / 100) < 20)                                                               /* if < 20 */
        {
            ti = (int32_t)((3 * (int64_t)(dt) * (int64_t)(dt)) / 8589934592U);               /* get the ti */
        }
        else
        {
            ti = (int32_t)((2 * (dt * dt)) / 137438953472U);                                 /* get the ti */
        }
    }
    temp = (temp - ti);                                                                      /* get the temp */
    *temperature_c = (float)(temp) / 100.0f;                                                 /* set the temperature */
}
uint8_t ms5837_init(ms5837_handle_t *handle)
{
    uint8_t i;
    uint8_t crc;
    uint8_t crc_check;
    uint8_t type;
    uint16_t c[8];
    
    {
        
    }
    if (debug_print == NULL)                                 /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                    /* check iic_init */
    {
        
        
        
    }
    if (iic_deinit == NULL)                                  /* check iic_init */
    {
        
        
        
    }
    if (iic_read == NULL)                                    /* check iic_read */
    {
        
        
        
    }
    if (iic_write == NULL)                                   /* check iic_write */
    {
        
        
        
    }
    if (delay_ms == NULL)                                    /* check delay_ms */
    {
        
        
        
    }
    if (iic_init() != 0)                                     /* iic init */
    {
        
        
        
    }
    if (a_ms5837_iic_write( MS5837_CMD_RESET, 
        NULL, 0) != 0)                                               /* reset the device */
    {
        
        
        
    }
    delay_ms(10);                                            /* delay 10 ms */
    memset(c, 0, sizeof(uint16_t) * 8);                              /* clear the c */
    for (i = 0; i < 7; i++)                                          /* 7 times */
    {
        if (a_ms5837_iic_read( MS5837_CMD_PROM_READ + i * 2, 
            prom + i * 2, 2) != 0)                           /* read the prom */
        {
            
            
            
        }
        c[i] = ((uint16_t)(prom[i * 2]) << 8) | 
               (uint16_t)(prom[i * 2 + 1]);                  /* set c[i] */
    }
    crc_check = (c[0] >> 12) & 0xF;                                  /* get the crc check */
    type = (c[0] >> 5) & 0x7F;                                       /* set the type */
    crc = a_ms5837_crc4(c);                                          /* calculate the crc */
    if (crc != crc_check)                                            /* check the crc */
    {
        
        
        
    }
    c[0] = c[1];                                             /* set c0 */
    c[1] = c[2];                                             /* set c1 */
    c[2] = c[3];                                             /* set c2 */
    c[3] = c[4];                                             /* set c3 */
    c[4] = c[5];                                             /* set c4 */
    c[5] = c[6];                                             /* set c5 */
    if (type == 0x00)                                                /* check the type */
    {
        type = MS5837_TYPE_02BA01;                           /* ms5837 02ba01 */
    }
    else if (type == 0x15)                                           /* check the type */
    {
        type = MS5837_TYPE_02BA21;                           /* ms5837 02ba21 */
    }
    else if (type == 0x1A)                                           /* check the type */
    {
        type = MS5837_TYPE_30BA26;                           /* ms5837 30ba26 */
    }
    else
    {
        
        
        
    }
    temp_osr = MS5837_OSR_256;                               /* set 256 temperature osr */
    press_osr = MS5837_OSR_256;                              /* set 256 pressure osr */
    inited = 1;                                              /* flag finish initialization */
    return 0;                                                        /* success return 0 */
}
uint8_t ms5837_deinit(ms5837_handle_t *handle)
{
    
    {
        
    }
    
    {
        
    }
 
    if (a_ms5837_iic_write( MS5837_CMD_RESET, 
        NULL, 0) != 0)                                              /* reset the device */
    {
        
        
        
    }
    delay_ms(10);                                           /* delay 10 ms */
    if (iic_deinit() != 0)                                  /* iic deinit */
    {
        
        
        
    }   
    inited = 0;                                             /* flag close */
    return 0;                                                       /* success return 0 */
}
uint8_t ms5837_get_type(ms5837_handle_t *handle, ms5837_type_t *type)
{
    
    {
        
    }
    
    {
        
    }
    *type = (ms5837_type_t)(type);        /* get the type */
    return 0;                                     /* success return 0 */
}
uint8_t ms5837_set_type(ms5837_handle_t *handle, ms5837_type_t type)
{
    
    {
        
    }
    
    {
        
    }
    type = (uint8_t)(type);        /* set the type */
    return 0;                              /* success return 0 */
}
uint8_t ms5837_get_temperature_osr(ms5837_handle_t *handle, ms5837_osr_t *osr)
{
    
    {
        
    }
    
    {
        
    }
    *osr = (ms5837_osr_t)(temp_osr);        /* get the osr */
    return 0;                                       /* success return 0 */
}
uint8_t ms5837_set_temperature_osr(ms5837_handle_t *handle, ms5837_osr_t osr)
{
    
    {
        
    }
    
    {
        
    }
    if ((type == MS5837_TYPE_30BA26)
        && (osr == MS5837_OSR_8192)                                             /* check the osr */
       )
    {
        
        
        
    }
    temp_osr = (uint8_t)(osr);                                          /* set the osr */
    return 0;                                                                   /* success return 0 */
}
uint8_t ms5837_get_pressure_osr(ms5837_handle_t *handle, ms5837_osr_t *osr)
{
    
    {
        
    }
    
    {
        
    }
    *osr = (ms5837_osr_t)(press_osr);       /* get the osr */
    return 0;                                       /* success return 0 */
}
uint8_t ms5837_set_pressure_osr(ms5837_handle_t *handle, ms5837_osr_t osr)
{
    
    {
        
    }
    
    {
        
    }
    if ((type == MS5837_TYPE_30BA26)
        && (osr == MS5837_OSR_8192)                                             /* check the osr */
       )
    {
        
        
        
    }
    press_osr = (uint8_t)(osr);                                         /* set the osr */
    return 0;                                                                   /* success return 0 */
}
uint8_t ms5837_read_temperature_pressure(ms5837_handle_t *handle, uint32_t *temperature_raw, float *temperature_c, 
                                         uint32_t *pressure_raw, float *pressure_mbar)
{
    uint8_t buf[3];
    
    {
        
    }
    
    {
        
    }
    if (a_ms5837_iic_write( MS5837_CMD_D2 + temp_osr, NULL, 0) != 0)            /* sent d2 */
    {
        
        
        
    }
    if (temp_osr == MS5837_OSR_256)                                                    /* osr 256 */
    {
        delay_ms(1);                                                                   /* delay 1ms */
    }
    else if (temp_osr == MS5837_OSR_512)                                               /* osr 512 */
    {
        delay_ms(2);                                                                   /* delay 2ms */
    }
    else if (temp_osr == MS5837_OSR_1024)                                              /* osr 1024 */
    {
        delay_ms(3);                                                                   /* delay 3ms */
    }
    else if (temp_osr == MS5837_OSR_2048)                                              /* osr 2048 */
    {
        delay_ms(5);                                                                   /* delay 5ms */
    }
    else if (temp_osr == MS5837_OSR_4096)                                              /* osr 4096 */
    {
        delay_ms(9);                                                                   /* delay 9ms */
    }
    else                                                                                       /* osr 8192 */
    {
        delay_ms(18);                                                                  /* delay 18ms */
    }
    if (a_ms5837_iic_read( MS5837_CMD_ADC_READ, buf, 3) != 0)                           /* read adc */
    {
        
        
        
    }
    *temperature_raw = (((uint32_t)buf[0]) << 16) | (((uint32_t)buf[1]) << 8) | buf[2];        /* set the temperature raw */
    if (a_ms5837_iic_write( MS5837_CMD_D1 + press_osr, NULL, 0) != 0)           /* sent d1 */
    {
        
        
        
    }
    if (press_osr == MS5837_OSR_256)                                                   /* osr 256 */
    {
        delay_ms(1);                                                                   /* delay 1ms */
    }
    else if (press_osr == MS5837_OSR_512)                                              /* osr 512 */
    {
        delay_ms(2);                                                                   /* delay 2ms */
    }
    else if (press_osr == MS5837_OSR_1024)                                             /* osr 1024 */
    {
        delay_ms(3);                                                                   /* delay 3ms */
    }
    else if (press_osr == MS5837_OSR_2048)                                             /* osr 2048 */
    {
        delay_ms(5);                                                                   /* delay 5ms */
    }
    else if (press_osr == MS5837_OSR_4096)                                             /* osr 4096 */
    {
        delay_ms(9);                                                                   /* delay 9ms */
    }
    else                                                                                       /* osr 8192 */
    {
        delay_ms(18);                                                                  /* delay 18ms */
    }
    if (a_ms5837_iic_read( MS5837_CMD_ADC_READ, buf, 3) != 0)                           /* read adc */
    {
        
        
        
    }
    *pressure_raw = (((uint32_t)buf[0]) << 16) | (((uint32_t)buf[1]) << 8) | buf[2];           /* set the temperature raw */
    a_ms5837_calculate_temperature_pressure( *temperature_raw, temperature_c, 
                                            *pressure_raw, pressure_mbar);                     /* calculate temperature and pressure */
    return 0;                                                                                  /* success return 0 */
}
uint8_t ms5837_read_pressure(ms5837_handle_t *handle, uint32_t *pressure_raw, float *pressure_mbar)
{
    uint8_t buf[3];
    uint32_t temperature_raw;
    float temperature_c; 
    
    {
        
    }
    
    {
        
    }
    if (a_ms5837_iic_write( MS5837_CMD_D2 + temp_osr, NULL, 0) != 0)            /* sent d2 */
    {
        
        
        
    }
    if (temp_osr == MS5837_OSR_256)                                                    /* osr 256 */
    {
        delay_ms(1);                                                                   /* delay 1ms */
    }
    else if (temp_osr == MS5837_OSR_512)                                               /* osr 512 */
    {
        delay_ms(2);                                                                   /* delay 2ms */
    }
    else if (temp_osr == MS5837_OSR_1024)                                              /* osr 1024 */
    {
        delay_ms(3);                                                                   /* delay 3ms */
    }
    else if (temp_osr == MS5837_OSR_2048)                                              /* osr 2048 */
    {
        delay_ms(5);                                                                   /* delay 5ms */
    }
    else if (temp_osr == MS5837_OSR_4096)                                              /* osr 4096 */
    {
        delay_ms(9);                                                                   /* delay 9ms */
    }
    else                                                                                       /* osr 8192 */
    {
        delay_ms(18);                                                                  /* delay 18ms */
    }
    if (a_ms5837_iic_read( MS5837_CMD_ADC_READ, buf, 3) != 0)                           /* read adc */
    {
        
        
        
    }
    temperature_raw = (((uint32_t)buf[0]) << 16) | (((uint32_t)buf[1]) << 8) | buf[2];         /* set the temperature raw */
    if (a_ms5837_iic_write( MS5837_CMD_D1 + press_osr, NULL, 0) != 0)           /* sent d1 */
    {
        
        
        
    }
    if (press_osr == MS5837_OSR_256)                                                   /* osr 256 */
    {
        delay_ms(1);                                                                   /* delay 1ms */
    }
    else if (press_osr == MS5837_OSR_512)                                              /* osr 512 */
    {
        delay_ms(2);                                                                   /* delay 2ms */
    }
    else if (press_osr == MS5837_OSR_1024)                                             /* osr 1024 */
    {
        delay_ms(3);                                                                   /* delay 3ms */
    }
    else if (press_osr == MS5837_OSR_2048)                                             /* osr 2048 */
    {
        delay_ms(5);                                                                   /* delay 5ms */
    }
    else if (press_osr == MS5837_OSR_4096)                                             /* osr 4096 */
    {
        delay_ms(9);                                                                   /* delay 9ms */
    }
    else                                                                                       /* osr 8192 */
    {
        delay_ms(18);                                                                  /* delay 18ms */
    }
    if (a_ms5837_iic_read( MS5837_CMD_ADC_READ, buf, 3) != 0)                           /* read adc */
    {
        
        
        
    }
    *pressure_raw = (((uint32_t)buf[0]) << 16) | (((uint32_t)buf[1]) << 8) | buf[2];           /* set the temperature raw */
    a_ms5837_calculate_temperature_pressure( temperature_raw, &temperature_c, 
                                            *pressure_raw, pressure_mbar);                     /* calculate temperature and pressure */
    return 0;                                                                                  /* success return 0 */
}
uint8_t ms5837_read_temperature(ms5837_handle_t *handle, uint32_t *temperature_raw, float *temperature_c)
{
    uint8_t buf[3];
    
    {
        
    }
    
    {
        
    }
    if (a_ms5837_iic_write( MS5837_CMD_D2 + temp_osr, NULL, 0) != 0)            /* sent d2 */
    {
        
        
        
    }
    if (temp_osr == MS5837_OSR_256)                                                    /* osr 256 */
    {
        delay_ms(1);                                                                   /* delay 1ms */
    }
    else if (temp_osr == MS5837_OSR_512)                                               /* osr 512 */
    {
        delay_ms(2);                                                                   /* delay 2ms */
    }
    else if (temp_osr == MS5837_OSR_1024)                                              /* osr 1024 */
    {
        delay_ms(3);                                                                   /* delay 3ms */
    }
    else if (temp_osr == MS5837_OSR_2048)                                              /* osr 2048 */
    {
        delay_ms(5);                                                                   /* delay 5ms */
    }
    else if (temp_osr == MS5837_OSR_4096)                                              /* osr 4096 */
    {
        delay_ms(9);                                                                   /* delay 9ms */
    }
    else                                                                                       /* osr 8192 */
    {
        delay_ms(18);                                                                  /* delay 18ms */
    }
    if (a_ms5837_iic_read( MS5837_CMD_ADC_READ, buf, 3) != 0)                           /* read adc */
    {
        
        
        
    }
    *temperature_raw = (((uint32_t)buf[0]) << 16) | (((uint32_t)buf[1]) << 8) | buf[2];        /* set the temperature raw */
    a_ms5837_calculate_temperature( *temperature_raw, temperature_c);                   /* calculate temperature and pressure */
    return 0;                                                                                  /* success return 0 */
}
uint8_t ms5837_reset(ms5837_handle_t *handle)
{
    
    {
        
    }
    
    {
        
    } 
    if (a_ms5837_iic_write( MS5837_CMD_RESET, NULL, 0) != 0)        /* reset the device */
    {
        
        
        
    }
    delay_ms(10);                                                  /* delay 10 ms */
    return 0;                                                              /* success return 0 */
}
uint8_t ms5837_set_reg(ms5837_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = a_ms5837_iic_write( reg, buf, len);                    /* write data */
    if (res != 0)                                                       /* check result */
    {
        
        
        
    }
    return 0;                                                           /* success return 0 */
}
uint8_t ms5837_get_reg(ms5837_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = a_ms5837_iic_read( reg, buf, len);                    /* read data */
    if (res != 0)                                                      /* check result */
    {
        
        
        
    }
    return 0;                                                          /* success return 0 */
}
uint8_t ms5837_info(ms5837_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(ms5837_info_t));                         /* initialize ms5837 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
