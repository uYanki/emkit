
#ifndef DRIVER_MS5837_H
#define DRIVER_MS5837_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MS5837_TYPE_02BA01 = 0x00,  // ms5837 02ba01
    MS5837_TYPE_02BA21 = 0x01,  // ms5837 02ba21
    MS5837_TYPE_30BA26 = 0x02,  // ms5837 30ba26
} ms5837_type_t;
typedef enum {
    MS5837_OSR_256  = 0x00,  // max 0.6ms
    MS5837_OSR_512  = 0x01,  // max 1.17ms
    MS5837_OSR_1024 = 0x02,  // max 2.28ms
    MS5837_OSR_2048 = 0x03,  // max 4.54ms
    MS5837_OSR_4096 = 0x04,  // max 9.04ms
    MS5837_OSR_8192 = 0x05,  // max 18.08ms
} ms5837_osr_t;
typedef struct ms5837_handle_s {
    uint8_t  prom[16];   // prom
    uint16_t c[6];       // c1 - c6
    uint8_t  temp_osr;   // temperature osr
    uint8_t  press_osr;  // pressure osr
    uint8_t  type;       // type
    uint8_t  inited;     // inited flag
} ms5837_handle_t;

uint8_t ms5837_info(ms5837_info_t* info);
uint8_t ms5837_init(ms5837_handle_t* handle);
uint8_t ms5837_deinit(ms5837_handle_t* handle);
uint8_t ms5837_read_temperature_pressure(ms5837_handle_t* handle, uint32_t* temperature_raw, float* temperature_c, uint32_t* pressure_raw, float* pressure_mbar);
uint8_t ms5837_read_pressure(ms5837_handle_t* handle, uint32_t* pressure_raw, float* pressure_mbar);
uint8_t ms5837_read_temperature(ms5837_handle_t* handle, uint32_t* temperature_raw, float* temperature_c);
uint8_t ms5837_set_type(ms5837_handle_t* handle, ms5837_type_t type);
uint8_t ms5837_get_type(ms5837_handle_t* handle, ms5837_type_t* type);
uint8_t ms5837_set_temperature_osr(ms5837_handle_t* handle, ms5837_osr_t osr);
uint8_t ms5837_get_temperature_osr(ms5837_handle_t* handle, ms5837_osr_t* osr);
uint8_t ms5837_set_pressure_osr(ms5837_handle_t* handle, ms5837_osr_t osr);
uint8_t ms5837_get_pressure_osr(ms5837_handle_t* handle, ms5837_osr_t* osr);
uint8_t ms5837_reset(ms5837_handle_t* handle);
uint8_t ms5837_set_reg(ms5837_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t ms5837_get_reg(ms5837_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
