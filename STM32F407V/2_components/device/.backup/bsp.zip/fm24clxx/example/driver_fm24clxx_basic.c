
#include "driver_fm24clxx_basic.h"
static fm24clxx_handle_t gs_handle; // fm24clxx handle
uint8_t fm24clxx_basic_init(fm24clxx_t type, fm24clxx_address_t address)
{
    uint8_t res;
    /* link interface function */
    DRIVER_FM24CLXX_LINK_INIT(&gs_handle, fm24clxx_handle_t);
    DRIVER_FM24CLXX_LINK_IIC_INIT(&gs_handle, fm24clxx_interface_iic_init);
    DRIVER_FM24CLXX_LINK_IIC_DEINIT(&gs_handle, fm24clxx_interface_iic_deinit);
    DRIVER_FM24CLXX_LINK_IIC_READ(&gs_handle, fm24clxx_interface_iic_read);
    DRIVER_FM24CLXX_LINK_IIC_WRITE(&gs_handle, fm24clxx_interface_iic_write);
    DRIVER_FM24CLXX_LINK_IIC_READ_ADDRESS16(&gs_handle, fm24clxx_interface_iic_read_address16);
    DRIVER_FM24CLXX_LINK_IIC_WRITE_ADDRESS16(&gs_handle, fm24clxx_interface_iic_write_address16);
    DRIVER_FM24CLXX_LINK_DELAY_MS(&gs_handle, fm24clxx_interface_delay_ms);
    DRIVER_FM24CLXX_LINK_DEBUG_PRINT(&gs_handle, fm24clxx_interface_debug_print);
    /* set chip type */
    res = fm24clxx_set_type(&gs_handle, type);
    if (res != 0) {
        fm24clxx_interface_debug_print("fm24clxx: set type failed.\n");
        return 1;
    }
    /* set addr pin */
    res = fm24clxx_set_addr_pin(&gs_handle, address);
    if (res != 0) {
        fm24clxx_interface_debug_print("fm24clxx: set address pin failed.\n");
        return 1;
    }
    /* fm24clxx init */
    res = fm24clxx_init(&gs_handle);
    if (res != 0) {
        fm24clxx_interface_debug_print("fm24clxx: init failed.\n");
        return 1;
    }
    return 0;
}
uint8_t fm24clxx_basic_read(uint16_t address, uint8_t* buf, uint16_t len)
{
    /* read data */
    if (fm24clxx_read(&gs_handle, address, buf, len) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t fm24clxx_basic_write(uint16_t address, uint8_t* buf, uint16_t len)
{
    /* read data */
    if (fm24clxx_write(&gs_handle, address, buf, len) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t fm24clxx_basic_deinit(void)
{
    /* fm24clxx deinit */
    if (fm24clxx_deinit(&gs_handle) != 0) {
        return 1;
    } else {
        return 0;
    }
}
