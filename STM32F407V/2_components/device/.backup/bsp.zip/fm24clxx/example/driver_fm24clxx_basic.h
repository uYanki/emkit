
#ifndef DRIVER_FM24CLXX_BASIC_H
#define DRIVER_FM24CLXX_BASIC_H
#include "driver_fm24clxx_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t fm24clxx_basic_init(fm24clxx_t type, fm24clxx_address_t address);
uint8_t fm24clxx_basic_deinit(void);
uint8_t fm24clxx_basic_read(uint16_t address, uint8_t *buf, uint16_t len);
uint8_t fm24clxx_basic_write(uint16_t address, uint8_t *buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
