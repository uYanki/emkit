
#include "driver_fm24clxx.h"

#define MANUFACTURER_NAME  "Cypress"          // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.7f               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.65f              // chip max supply voltage




uint8_t fm24clxx_init(fm24clxx_handle_t* handle)
{
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (iic_read_address16 == NULL) /* check iic_read_address16 */
    {
        
        
    }
    if (iic_write_address16 == NULL) /* check iic_write_address16 */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_deinit(fm24clxx_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (iic_deinit() != 0) /* iic deinit */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_set_type( fm24clxx_t type)
{
    {
        
    }
    id = (uint16_t)type; /* set id */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_get_type( fm24clxx_t* type)
{
    {
        
    }
    *type = (fm24clxx_t)(id); /* get id */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_set_addr_pin( fm24clxx_address_t addr_pin)
{
    {
        
    }
    iic_addr = 0xA0;           /* set iic addr */
    iic_addr |= addr_pin << 1; /* set iic address */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_get_addr_pin( fm24clxx_address_t* addr_pin)
{
    {
        
    }
    *addr_pin = (fm24clxx_address_t)((iic_addr & (~0xA0)) >> 1); /* get iic address */
    return 0; /* success return 0 */
}
uint8_t fm24clxx_read( uint16_t address, uint8_t* buf, uint16_t len)
{
    uint8_t page_remain;
    {
        
    }
    {
        
    }
    if ((uint16_t)(address + len) > id) /* check length */
    {
        
        
    }
    page_remain = (uint8_t)(8 - address % 8); /* get page remain */
    if (len <= page_remain)                   /* page remain */
    {
        page_remain = (uint8_t)len; /* set page remain */
    }
    if (id > (uint16_t)FM24CL16B) /* choose id to set different address */
    {
        while (1) {
            if (iic_read_address16(iic_addr, address, buf, page_remain) != 0) /* read data */
            {
                
                
            }
            if (page_remain == len) /* check break */
            {
                break; /* break loop */
            } else {
                address += page_remain; /* address increase */
                buf += page_remain;     /* buffer point increase */
                len -= page_remain;     /* length decrease */
                if (len < 8)            /* check length */
                {
                    page_remain = (uint8_t)len; /* set the reset length */
                } else {
                    page_remain = 8; /* set page */
                }
            }
        }
    } else {
        while (1) {
            if (iic_read((uint8_t)(iic_addr + ((address / 256) << 1)), address % 256, buf,
                                 page_remain) != 0) /* read page */
            {
                
                
            }
            if (page_remain == len) /* check break */
            {
                break; /* break loop */
            } else {
                address += page_remain; /* address increase */
                buf += page_remain;     /* buffer point increase */
                len -= page_remain;     /* length decrease */
                if (len < 8)            /* check length */
                {
                    page_remain = (uint8_t)len; /* set the reset length */
                } else {
                    page_remain = 8; /* set page */
                }
            }
        }
    }
    return 0; /* success return 0 */
}
uint8_t fm24clxx_write( uint16_t address, uint8_t* buf, uint16_t len)
{
    uint8_t page_remain;
    {
        
    }
    {
        
    }
    if ((uint16_t)(address + len) > id) /* check length */
    {
        
        
    }
    page_remain = (uint8_t)(8 - address % 8); /* set page remain */
    if (len <= page_remain)                   /* check length */
    {
        page_remain = (uint8_t)len; /* set page remain */
    }
    if (id > (uint16_t)FM24CL16B) /* check id */
    {
        while (1) {
            if (iic_write_address16(iic_addr, address, buf, page_remain) != 0) /* write data */
            {
                
                
            }
            if (page_remain == len) /* check break */
            {
                break; /* break */
            } else {
                address += page_remain; /* address increase */
                buf += page_remain;     /* buffer point increase */
                len -= page_remain;     /* length decrease */
                if (len < 8)            /* check length */
                {
                    page_remain = (uint8_t)len; /* set the reset length */
                } else {
                    page_remain = 8; /* set page */
                }
            }
        }
    } else {
        while (1) {
            if (iic_write((uint8_t)(iic_addr + ((address / 256) << 1)), address % 256, buf,
                                  page_remain) != 0) /* write page */
            {
                
                
            }
            if (page_remain == len) /* check break */
            {
                break; /* break */
            } else {
                address += page_remain; /* address increase */
                buf += page_remain;     /* buffer point increase */
                len -= page_remain;     /* length decrease */
                if (len < 8)            /* check length */
                {
                    page_remain = (uint8_t)len; /* set the rest length */
                } else {
                    page_remain = 8; /* set page */
                }
            }
        }
    }
    return 0; /* success return 0 */
}
uint8_t fm24clxx_info(fm24clxx_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(fm24clxx_info_t));                /* initialize fm24clxx info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
