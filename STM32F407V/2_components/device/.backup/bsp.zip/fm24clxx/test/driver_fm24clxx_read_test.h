
#ifndef DRIVER_FM24CLXX_READ_TEST_H
#define DRIVER_FM24CLXX_READ_TEST_H
#include "driver_fm24clxx_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t fm24clxx_read_test(fm24clxx_t type, fm24clxx_address_t address);
#ifdef __cplusplus
}
#endif
#endif
