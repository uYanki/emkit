
#include "driver_bh1750fvi.h"

#define MANUFACTURER_NAME  "ROHM"           // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.4f             // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f             // chip max supply voltage




#define BH1750FVI_COMMAND_POWER_DOWN                      0x00 // power down command
#define BH1750FVI_COMMAND_POWER_ON                        0x01 // power on command
#define BH1750FVI_COMMAND_RESET                           0x07 // reset command
#define BH1750FVI_COMMAND_CONTINUOUSLY_H_RESOLUTION_MODE  0x10 // continuously h-resolution mode command
#define BH1750FVI_COMMAND_CONTINUOUSLY_H_RESOLUTION_MODE2 0x11 // continuously h-resolution mode2 command
#define BH1750FVI_COMMAND_CONTINUOUSLY_L_RESOLUTION_MODE  0x13 // continuously l-resolution mode command
#define BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE      0x20 // one time h-resolution mode command
#define BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE2     0x21 // one time h-resolution mode2 command
#define BH1750FVI_COMMAND_ONE_TIME_L_RESOLUTION_MODE      0x23 // one time l-resolution mode command
#define BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_HIGH    0x40 // change measurement time high command
#define BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_LOW     0x60 // change measurement time low command
static uint8_t a_bh1750fvi_iic_read( uint8_t* data, uint16_t len)
{
    if (iic_read_cmd(iic_addr, data, len) != 0) /* read the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_bh1750fvi_iic_write( uint8_t* data, uint16_t len)
{
    if (iic_write_cmd(iic_addr, data, len) != 0) /* write the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t bh1750fvi_set_addr_pin( bh1750fvi_address_t addr_pin)
{
    {
        
    }
    iic_addr = addr_pin; /* set iic addr */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_get_addr_pin( bh1750fvi_address_t* addr_pin)
{
    {
        
    }
    *addr_pin = (bh1750fvi_address_t)(iic_addr); /*get iic address */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_set_mode( bh1750fvi_mode_t mode)
{
    {
        
    }
    {
        
    }
    mode = (uint8_t)(mode); /* set the mode */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_get_mode( bh1750fvi_mode_t* mode)
{
    {
        
    }
    {
        
    }
    *mode = (bh1750fvi_mode_t)(mode); /* get the mode */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_init(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read_cmd == NULL) /* check iic_read_cmd */
    {
        
        
    }
    if (iic_write_cmd == NULL) /* check iic_write_cmd */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    prev = BH1750FVI_COMMAND_POWER_ON;              /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
        
    }
    delay_ms(5);                            /* delay 5ms */
    prev = BH1750FVI_COMMAND_RESET;                 /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
        
    }
    delay_ms(5);                                                        /* delay 5ms */
    prev = BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_HIGH | ((69 >> 5) & 0x07); /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1);                             /* write the command */
    
    {
        
        
    }
    prev = BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_LOW | ((69 >> 0) & 0x1F); /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1);                            /* write the command */
    
    {
        
        
    }
    delay_ms(5);                                  /* delay 5ms */
    mode   = BH1750FVI_MODE_HIGH_RESOLUTION_MODE; /* high resolutin mode */
    t      = 69;                                  /* set default 69 */
    inited = 1;                                   /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_deinit(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = BH1750FVI_COMMAND_POWER_DOWN;            /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    res = iic_deinit(); /* iic deinit */
    
    {
        
        
    }
    inited = 0; /* flag closed */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_power_down(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = BH1750FVI_COMMAND_POWER_DOWN;            /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_power_on(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = BH1750FVI_COMMAND_POWER_ON;              /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_reset(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = BH1750FVI_COMMAND_RESET;                 /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_set_measurement_time( uint8_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if ((t < 31) || (t > 254)) /* check t */
    {
        
        
    }
    prev = BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_HIGH | ((t >> 5) & 0x07); /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1);                            /* write the command */
    
    {
        
        
    }
    prev = BH1750FVI_COMMAND_CHANGE_MEASUREMENT_TIME_LOW | ((t >> 0) & 0x1F); /* set the command */
    res  = a_bh1750fvi_iic_write( &prev, 1);                           /* write the command */
    
    {
        
        
    }
    t = t; /* save the time */
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_single_read( uint16_t* raw, float* lux)
{
    uint8_t res;
    uint8_t prev;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE;         /* high resolution mode command */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2) /* high resolution mode2 */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE2;      /* high resolution mode2 command */
    } else if (mode == BH1750FVI_MODE_LOW_RESOLUTION_MODE) /* low resolution mode */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_L_RESOLUTION_MODE; /* low resolution mode command */
    } else {
        
        
    }
    res = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        delay_ms((uint32_t)(180.0f * (float)(t) / 69.0f)); /* delay the max time */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2)       /* high resolution mode2 */
    {
        delay_ms((uint32_t)(180.0f * (float)(t) / 69.0f)); /* delay the max time */
    } else                                                                 /* low resolution mode */
    {
        delay_ms((uint32_t)(24.0f * (float)(t) / 69.0f)); /* delay the max time */
    }
    res = a_bh1750fvi_iic_read( buf, 2); /* read data */
    
    {
        
        
    }
    *raw = (((uint16_t)buf[0]) << 8) | buf[1];               /* get the raw data */
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))); /* convert */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2)  /* high resolution mode2 */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))) / 2.0f; /* convert */
    } else                                                                   /* low resolution mode */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))); /* convert */
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_continuous_read( uint16_t* raw, float* lux)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_bh1750fvi_iic_read( buf, 2); /* read data */
    
    {
        
        
    }
    *raw = (((uint16_t)buf[0]) << 8) | buf[1];               /* get the raw data */
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))); /* convert */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2)  /* high resolution mode2 */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))) / 2.0f; /* convert */
    } else                                                                   /* low resolution mode */
    {
        *lux = (float)(*raw) / 1.2f * (69.0f / ((float)(t))); /* convert */
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_start_continuous_read(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        prev = BH1750FVI_COMMAND_CONTINUOUSLY_H_RESOLUTION_MODE;     /* high resolution mode command */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2) /* high resolution mode2 */
    {
        prev = BH1750FVI_COMMAND_CONTINUOUSLY_H_RESOLUTION_MODE2;  /* high resolution mode2 command */
    } else if (mode == BH1750FVI_MODE_LOW_RESOLUTION_MODE) /* low resolution mode */
    {
        prev = BH1750FVI_COMMAND_CONTINUOUSLY_L_RESOLUTION_MODE; /* low resolution mode command */
    } else {
        
        
    }
    res = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_stop_continuous_read(bh1750fvi_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE) /* high resolution mode */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE;         /* high resolution mode command */
    } else if (mode == BH1750FVI_MODE_HIGH_RESOLUTION_MODE2) /* high resolution mode2 */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_H_RESOLUTION_MODE2;      /* high resolution mode2 command */
    } else if (mode == BH1750FVI_MODE_LOW_RESOLUTION_MODE) /* low resolution mode */
    {
        prev = BH1750FVI_COMMAND_ONE_TIME_L_RESOLUTION_MODE; /* low resolution mode command */
    } else {
        
        
    }
    res = a_bh1750fvi_iic_write( &prev, 1); /* write the command */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t bh1750fvi_set_reg( uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_bh1750fvi_iic_write( buf, len); /* write command */
}
uint8_t bh1750fvi_get_reg( uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_bh1750fvi_iic_read( buf, len); /* read command */
}
uint8_t bh1750fvi_info(bh1750fvi_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(bh1750fvi_info_t));               /* initialize bh1750fvi info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
