
#ifndef DRIVER_BH1750FVI_H
#define DRIVER_BH1750FVI_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    BH1750FVI_ADDRESS_LOW  = 0x46,  // addr low
    BH1750FVI_ADDRESS_HIGH = 0xB8,  // addr high
} bh1750fvi_address_t;
typedef enum {
    BH1750FVI_MODE_HIGH_RESOLUTION_MODE  = 0x0,  // 1lx resolution
    BH1750FVI_MODE_HIGH_RESOLUTION_MODE2 = 0x1,  // 0.5lx resolution
    BH1750FVI_MODE_LOW_RESOLUTION_MODE   = 0x2,  // 4lx resolution
} bh1750fvi_mode_t;
typedef struct bh1750fvi_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t mode;    // chip mode
    uint8_t t;       // measurement time
    uint8_t inited;  // inited flag
} bh1750fvi_handle_t;

uint8_t bh1750fvi_info(bh1750fvi_info_t* info);
uint8_t bh1750fvi_set_addr_pin(bh1750fvi_handle_t* handle, bh1750fvi_address_t addr_pin);
uint8_t bh1750fvi_get_addr_pin(bh1750fvi_handle_t* handle, bh1750fvi_address_t* addr_pin);
uint8_t bh1750fvi_set_mode(bh1750fvi_handle_t* handle, bh1750fvi_mode_t mode);
uint8_t bh1750fvi_get_mode(bh1750fvi_handle_t* handle, bh1750fvi_mode_t* mode);
uint8_t bh1750fvi_init(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_deinit(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_single_read(bh1750fvi_handle_t* handle, uint16_t* raw, float* lux);
uint8_t bh1750fvi_continuous_read(bh1750fvi_handle_t* handle, uint16_t* raw, float* lux);
uint8_t bh1750fvi_start_continuous_read(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_stop_continuous_read(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_power_down(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_power_on(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_reset(bh1750fvi_handle_t* handle);
uint8_t bh1750fvi_set_measurement_time(bh1750fvi_handle_t* handle, uint8_t t);
uint8_t bh1750fvi_set_reg(bh1750fvi_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t bh1750fvi_get_reg(bh1750fvi_handle_t* handle, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
