
#ifndef DRIVER_BH1750FVI_READ_TEST_H
#define DRIVER_BH1750FVI_READ_TEST_H
#include "driver_bh1750fvi_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t bh1750fvi_read_test(bh1750fvi_address_t addr, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
