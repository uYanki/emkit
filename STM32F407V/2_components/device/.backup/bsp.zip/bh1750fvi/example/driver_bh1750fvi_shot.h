
#ifndef DRIVER_BH1750FVI_SHOT_H
#define DRIVER_BH1750FVI_SHOT_H
#include "driver_bh1750fvi_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define BH1750FVI_SHOT_DEFAULT_MODE                    BH1750FVI_MODE_HIGH_RESOLUTION_MODE        // high resolution mode 
#define BH1750FVI_SHOT_DEFAULT_MEASUREMENT_TIME        69                                         // measurement time 69 
uint8_t bh1750fvi_shot_init(bh1750fvi_address_t addr_pin);
uint8_t bh1750fvi_shot_read(float *lux);
uint8_t bh1750fvi_shot_deinit(void);
#ifdef __cplusplus
}
#endif
#endif
