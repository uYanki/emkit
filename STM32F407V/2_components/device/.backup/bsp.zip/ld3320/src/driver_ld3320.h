
#ifndef DRIVER_LD3320_H
#define DRIVER_LD3320_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C"{
#endif
#ifndef LD3320_CYSTAL_MHZ 
    #define LD3320_CYSTAL_MHZ        22.1184f        /* 22.1184 MHz */
#endif
typedef enum
{
    LD3320_MODE_ASR = 0x01,        // asr mode 
    LD3320_MODE_MP3 = 0x02,        // mp3 mode 
} ld3320_mode_t;
typedef enum
{
    LD3320_MIC_GAIN_COMMON = 0x43,        // common 
    LD3320_MIC_GAIN_NOISE  = 0x2F,        // noise 
} ld3320_mic_gain_t;
typedef enum
{
    LD3320_VAD_COMMON = 0x12,        // common 
    LD3320_VAD_FAR    = 0x0A,        // far 
} ld3320_vad_t;
typedef enum
{
    LD3320_STATUS_NONE           = 0x00,        // none 
    LD3320_STATUS_ASR_RUNNING    = 0x01,        // asr running 
    LD3320_STATUS_ASR_FOUND_OK   = 0x02,        // asr found ok 
    LD3320_STATUS_ASR_FOUND_ZERO = 0x03,        // asr found zero 
    LD3320_STATUS_ASR_ERROR      = 0x04,        // asr error 
    LD3320_STATUS_MP3_RUNNING    = 0x05,        // mp3 running 
    LD3320_STATUS_MP3_LOAD       = 0x06,        // mp3 load 
    LD3320_STATUS_MP3_END        = 0x07,        // mp3 end 
    LD3320_STATUS_MP3_ERROR      = 0x08,        // mp3 error 
} ld3320_status_t;
typedef struct ld3320_handle_s
{














    uint8_t inited;                                                                  // inited flag 
    uint8_t mode;                                                                    // running mode 
    uint8_t running_status;                                                          // running status 
    uint8_t mic_gain;                                                                // mic gain 
    uint8_t vad;                                                                     // vad 
    char text[50][50];                                                               // inner text 
    uint8_t len;                                                                     // inner text length 
    uint32_t point;                                                                  // mp3 play point 
    uint32_t size;                                                                   // mp3 size 
    uint8_t buf[512];                                                                // buffer 
} ld3320_handle_t;
















uint8_t ld3320_info(ld3320_info_t *info);
uint8_t ld3320_irq_handler(ld3320_handle_t *handle);
uint8_t ld3320_init(ld3320_handle_t *handle);
uint8_t ld3320_deinit(ld3320_handle_t *handle);
uint8_t ld3320_start(ld3320_handle_t *handle);
uint8_t ld3320_stop(ld3320_handle_t *handle);
uint8_t ld3320_configure_mp3(ld3320_handle_t *handle, char *name);
uint8_t ld3320_set_mode(ld3320_handle_t *handle, ld3320_mode_t mode);
uint8_t ld3320_get_mode(ld3320_handle_t *handle, ld3320_mode_t *mode);
uint8_t ld3320_set_key_words(ld3320_handle_t *handle, char text[50][50], uint8_t len);
uint8_t ld3320_get_key_words(ld3320_handle_t *handle, char text[50][50], uint8_t *len);
uint8_t ld3320_set_mic_gain(ld3320_handle_t *handle, ld3320_mic_gain_t gain);
uint8_t ld3320_get_mic_gain(ld3320_handle_t *handle, ld3320_mic_gain_t *gain);
uint8_t ld3320_set_vad(ld3320_handle_t *handle, ld3320_vad_t vad);
uint8_t ld3320_get_vad(ld3320_handle_t *handle, ld3320_vad_t *vad);
uint8_t ld3320_get_status(ld3320_handle_t *handle, ld3320_status_t *status);
uint8_t ld3320_set_speaker_volume(ld3320_handle_t *handle, uint8_t volume);
uint8_t ld3320_get_speaker_volume(ld3320_handle_t *handle, uint8_t *volume);
uint8_t ld3320_set_headset_volume(ld3320_handle_t *handle, uint8_t volume_left, uint8_t volume_right);
uint8_t ld3320_get_headset_volume(ld3320_handle_t *handle, uint8_t *volume_left, uint8_t *volume_right);
uint8_t ld3320_set_reg(ld3320_handle_t *handle, uint8_t reg, uint8_t data);
uint8_t ld3320_get_reg(ld3320_handle_t *handle, uint8_t reg, uint8_t *data);
#ifdef __cplusplus
}
#endif
#endif
