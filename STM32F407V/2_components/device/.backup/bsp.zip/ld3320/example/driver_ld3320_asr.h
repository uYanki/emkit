
#ifndef DRIVER_LD3320_ASR_H
#define DRIVER_LD3320_ASR_H
#include "driver_ld3320_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define LD3320_ASR_DEFAULT_MIC_GAIN        LD3320_MIC_GAIN_COMMON        // common gain 
#define LD3320_ASR_DEFAULT_VAD             LD3320_VAD_COMMON             // common vad 
uint8_t ld3320_asr_irq_handler(void);
uint8_t ld3320_asr_init(void (*receive_callback)(uint8_t type, uint8_t index, char *text));
uint8_t ld3320_asr_deinit(void);
uint8_t ld3320_asr_set_keys(char (*text)[50], uint8_t len);
uint8_t ld3320_asr_start(void);
uint8_t ld3320_asr_stop(void);
#ifdef __cplusplus
}
#endif
#endif
