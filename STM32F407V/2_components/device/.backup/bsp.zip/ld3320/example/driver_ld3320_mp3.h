
#ifndef DRIVER_LD3320_MP3_H
#define DRIVER_LD3320_MP3_H
#include "driver_ld3320_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define LD3320_MP3_DEFAULT_SPEAKER_VOLUME          1        // level 1 
#define LD3320_MP3_DEFAULT_HEADERSET_VOLUME        1        // level 1 
uint8_t ld3320_mp3_irq_handler(void);
uint8_t ld3320_mp3_init(char *name, void (*receive_callback)(uint8_t type, uint8_t index, char *text));
uint8_t ld3320_mp3_deinit(void);
uint8_t ld3320_mp3_start(void);
uint8_t ld3320_mp3_stop(void);
#ifdef __cplusplus
}
#endif
#endif
