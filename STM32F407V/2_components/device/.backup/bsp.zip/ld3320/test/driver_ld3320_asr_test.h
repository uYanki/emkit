
#ifndef DRIVER_LD3320_ASR_TEST_H
#define DRIVER_LD3320_ASR_TEST_H
#include "driver_ld3320_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ld3320_asr_test_irq_handler(void);
uint8_t ld3320_asr_test(void);
#ifdef __cplusplus
}
#endif
#endif
