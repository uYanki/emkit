
#ifndef DRIVER_LD3320_MP3_TEST_H
#define DRIVER_LD3320_MP3_TEST_H
#include "driver_ld3320_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ld3320_mp3_test_irq_handler(void);
uint8_t ld3320_mp3_test(char *name);
#ifdef __cplusplus
}
#endif
#endif
