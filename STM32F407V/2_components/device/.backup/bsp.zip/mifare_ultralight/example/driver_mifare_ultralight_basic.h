
#ifndef DRIVER_MIFARE_ULTRALIGHT_BASIC_H
#define DRIVER_MIFARE_ULTRALIGHT_BASIC_H
#include "driver_mifare_ultralight_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MIFARE_MIFARE_ULTRALIGHT_DEFAULT_SEARCH_DELAY_MS        200        // 5Hz 
uint8_t mifare_ultralight_basic_init(void);
uint8_t mifare_ultralight_basic_deinit(void);
uint8_t mifare_ultralight_basic_halt(void);
uint8_t mifare_ultralight_basic_wake_up(void);
uint8_t mifare_ultralight_basic_search(mifare_ultralight_storage_t *type, uint8_t id[8], int32_t timeout);
uint8_t mifare_ultralight_basic_read(uint8_t page, uint8_t data[4]);
uint8_t mifare_ultralight_basic_read_four_pages(uint8_t start_page, uint8_t data[16]);
uint8_t mifare_ultralight_basic_read_pages(uint8_t start_page, uint8_t stop_page, uint8_t *data, uint16_t *len);
uint8_t mifare_ultralight_basic_write(uint8_t page, uint8_t data[4]);
uint8_t mifare_ultralight_basic_write_otp(uint8_t data[4]);
uint8_t mifare_ultralight_basic_read_otp(uint8_t data[4]);
uint8_t mifare_ultralight_basic_get_version(mifare_ultralight_version_t *version);
uint8_t mifare_ultralight_basic_read_counter(uint8_t addr, uint32_t *cnt);
uint8_t mifare_ultralight_basic_increment_counter(uint8_t addr, uint32_t cnt);
uint8_t mifare_ultralight_basic_check_tearing_event(uint8_t addr, uint8_t *flag);
uint8_t mifare_ultralight_basic_read_signature(uint8_t signature[32]);
uint8_t mifare_ultralight_basic_get_serial_number(uint8_t number[7]);
uint8_t mifare_ultralight_basic_set_password_pack(uint8_t pwd[4], uint8_t pack[2]);
uint8_t mifare_ultralight_basic_authenticate(uint8_t pwd[4], uint8_t pack[2]);
uint8_t mifare_ultralight_basic_set_lock(uint8_t lock[5]);
uint8_t mifare_ultralight_basic_set_modulation_mode(mifare_ultralight_modulation_mode_t mode);
uint8_t mifare_ultralight_basic_set_protect_start_page(uint8_t page);
uint8_t mifare_ultralight_basic_set_authenticate_limitation(uint8_t limit);
uint8_t mifare_ultralight_basic_set_access(mifare_ultralight_access_t access, mifare_ultralight_bool_t enable);
#ifdef __cplusplus
}
#endif
#endif
