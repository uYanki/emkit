
#include "driver_mifare_ultralight_basic.h"
static mifare_ultralight_handle_t gs_handle;        // mifare_ultralight handle
static void s_debug_print(const char *const fmt, ...)
{
    (void)fmt;
    return;
}
uint8_t mifare_ultralight_basic_init(void)
{
    uint8_t res;
    /* link function */
    DRIVER_MIFARE_ULTRALIGHT_LINK_INIT(&gs_handle, mifare_ultralight_handle_t);
    DRIVER_MIFARE_ULTRALIGHT_LINK_CONTACTLESS_INIT(&gs_handle, mifare_ultralight_interface_contactless_init);
    DRIVER_MIFARE_ULTRALIGHT_LINK_CONTACTLESS_DEINIT(&gs_handle, mifare_ultralight_interface_contactless_deinit);
    DRIVER_MIFARE_ULTRALIGHT_LINK_CONTACTLESS_TRANSCEIVER(&gs_handle, mifare_ultralight_interface_contactless_transceiver);
    DRIVER_MIFARE_ULTRALIGHT_LINK_DELAY_MS(&gs_handle, mifare_ultralight_interface_delay_ms);
#ifndef NO_DEBUG
    DRIVER_MIFARE_ULTRALIGHT_LINK_DEBUG_PRINT(&gs_handle, mifare_ultralight_interface_debug_print);
#else
    DRIVER_MIFARE_ULTRALIGHT_LINK_DEBUG_PRINT(&gs_handle, s_debug_print);
#endif
    /* init */
    res = mifare_ultralight_init(&gs_handle);
    if (res != 0)
    {
        mifare_ultralight_interface_debug_print("mifare_ultralight: init failed.\n");
        
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_deinit(void)
{
    uint8_t res;
    /* deinit */
    res = mifare_ultralight_deinit(&gs_handle);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_halt(void)
{
    uint8_t res;
    /* halt */
    res = mifare_ultralight_halt(&gs_handle);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_wake_up(void)
{
    uint8_t res;
    mifare_ultralight_type_t type;
    /* wake up */
    res = mifare_ultralight_wake_up(&gs_handle, &type);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_search(mifare_ultralight_storage_t *type, uint8_t id[8], int32_t timeout)
{
    uint8_t res;
    mifare_ultralight_type_t t;
    /* loop */
    while (1)
    {
        /* request */
        res = mifare_ultralight_request(&gs_handle, &t);
        if (res == 0)
        {
            /* anticollision_cl1 */
            res = mifare_ultralight_anticollision_cl1(&gs_handle, id);
            if (res == 0)
            {
                /* cl1 */
                res = mifare_ultralight_select_cl1(&gs_handle, id);
                if (res == 0)
                {
                    /* anticollision_cl2 */
                    res = mifare_ultralight_anticollision_cl2(&gs_handle, id + 4);
                    if (res == 0)
                    {
                        /* cl2 */
                        res = mifare_ultralight_select_cl2(&gs_handle, id + 4);
                        if (res == 0)
                        {
                            uint8_t data[4];
                            
                            /* read page 0 */
                            res = mifare_ultralight_read_page(&gs_handle, 0x00, data);
                            if (res == 0)
                            {
                                mifare_ultralight_version_t version;
                                
                                /* get the chip version */
                                res = mifare_ultralight_get_version(&gs_handle, &version);
                                if (res == 0)
                                {
                                    /* get the type */
                                    res = mifare_ultralight_get_storage(&gs_handle, type);
                                    if (res == 0)
                                    {
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        /* delay */
        mifare_ultralight_interface_delay_ms(MIFARE_MIFARE_ULTRALIGHT_DEFAULT_SEARCH_DELAY_MS);
        
        /* check the timeout */
        if (timeout < 0)
        {
            /* never timeout */
            continue;
        }
        else
        {
            /* timeout */
            if (timeout == 0)
            {
                return 1;
            }
            else
            {
                /* timout-- */
                timeout--;
            }
        }
    }
}
uint8_t mifare_ultralight_basic_read(uint8_t page, uint8_t data[4])
{
    uint8_t res;
    /* read */
    res = mifare_ultralight_read_page(&gs_handle, page, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_read_four_pages(uint8_t start_page, uint8_t data[16])
{
    uint8_t res;
    /* read */
    res = mifare_ultralight_read_four_pages(&gs_handle, start_page, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_read_pages(uint8_t start_page, uint8_t stop_page, uint8_t *data, uint16_t *len)
{
    uint8_t res;
    /* fast read */
    res = mifare_ultralight_fast_read_page(&gs_handle, start_page, stop_page, data, len);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_write(uint8_t page, uint8_t data[4])
{
    uint8_t res;
    /* write */
    res = mifare_ultralight_write_page(&gs_handle, page, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_write_otp(uint8_t data[4])
{
    uint8_t res;
    /* write otp */
    res = mifare_ultralight_write_otp(&gs_handle, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_read_otp(uint8_t data[4])
{
    uint8_t res;
    /* read otp */
    res = mifare_ultralight_read_otp(&gs_handle, data);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_get_version(mifare_ultralight_version_t *version)
{
    uint8_t res;
    /* get the version */
    res = mifare_ultralight_get_version(&gs_handle, version);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_read_counter(uint8_t addr, uint32_t *cnt)
{
    uint8_t res;
    /* read the counter */
    res = mifare_ultralight_read_counter(&gs_handle, addr, cnt);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_increment_counter(uint8_t addr, uint32_t cnt)
{
    uint8_t res;
    /* increment the counter */
    res = mifare_ultralight_increment_counter(&gs_handle, addr, cnt);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_check_tearing_event(uint8_t addr, uint8_t *flag)
{
    uint8_t res;
    /* check the tearing event */
    res = mifare_ultralight_check_tearing_event(&gs_handle, addr, flag);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_read_signature(uint8_t signature[32])
{
    uint8_t res;
    /* read the signature */
    res = mifare_ultralight_read_signature(&gs_handle, signature);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_get_serial_number(uint8_t number[7])
{
    uint8_t res;
    /* get serial number */
    res = mifare_ultralight_get_serial_number(&gs_handle, number);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_password_pack(uint8_t pwd[4], uint8_t pack[2])
{
    uint8_t res;
    /* set password */
    res = mifare_ultralight_set_password(&gs_handle, pwd);
    if (res != 0)
    {
        return 1;
    }
    /* set pack */
    res = mifare_ultralight_set_pack(&gs_handle, pack);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_authenticate(uint8_t pwd[4], uint8_t pack[2])
{
    uint8_t res;
    /* authenticate */
    res = mifare_ultralight_authenticate(&gs_handle, pwd, pack);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_lock(uint8_t lock[5])
{
    uint8_t res;
    /* set lock */
    res = mifare_ultralight_set_lock(&gs_handle, lock);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_modulation_mode(mifare_ultralight_modulation_mode_t mode)
{
    uint8_t res;
    /* set modulation mode */
    res = mifare_ultralight_set_modulation_mode(&gs_handle, mode);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_protect_start_page(uint8_t page)
{
    uint8_t res;
    /* set protect start page */
    res = mifare_ultralight_set_protect_start_page(&gs_handle, page);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_authenticate_limitation(uint8_t limit)
{
    uint8_t res;
    /* set authenticate limitation */
    res = mifare_ultralight_set_authenticate_limitation(&gs_handle, limit);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
uint8_t mifare_ultralight_basic_set_access(mifare_ultralight_access_t access, mifare_ultralight_bool_t enable)
{
    uint8_t res;
    /* set access */
    res = mifare_ultralight_set_access(&gs_handle, access, enable);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
