
#ifndef DRIVER_MIFARE_ULTRALIGHT_H
#define DRIVER_MIFARE_ULTRALIGHT_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MIFARE_ULTRALIGHT_BOOL_FALSE = 0x00,  // false
    MIFARE_ULTRALIGHT_BOOL_TRUE  = 0x01,  // true
} mifare_ultralight_bool_t;
typedef enum {
    MIFARE_ULTRALIGHT_TYPE_INVALID    = 0x00,  // invalid
    MIFARE_ULTRALIGHT_TYPE_ULTRALIGHT = 0x01,  // ultralight
} mifare_ultralight_type_t;
typedef enum {
    MIFARE_ULTRALIGHT_STORAGE_MF0UL11 = 0x13,  // 20 pages
    MIFARE_ULTRALIGHT_STORAGE_MF0UL21 = 0x28,  // 41 pages
} mifare_ultralight_storage_t;
typedef enum {
    MIFARE_ULTRALIGHT_ACCESS_READ_PROTECTION      = 7,  // enable or disable read access protection
    MIFARE_ULTRALIGHT_ACCESS_USER_CONF_PROTECTION = 6,  // enable or disable user configuration protection
} mifare_ultralight_access_t;
typedef enum {
    MIFARE_ULTRALIGHT_MODULATION_MODE_NORMAL = 0x00,  // normal
    MIFARE_ULTRALIGHT_MODULATION_MODE_STRONG = 0x01,  // strong
} mifare_ultralight_modulation_mode_t;
typedef struct mifare_ultralight_version_s {
    uint8_t fixed_header;           // fixed header
    uint8_t vendor_id;              // vendor id
    uint8_t product_type;           // product type
    uint8_t product_subtype;        // product subtype
    uint8_t major_product_version;  // major product version
    uint8_t minor_product_version;  // minor product version
    uint8_t storage_size;           // storage size
    uint8_t protocol_type;          // protocol type
} mifare_ultralight_version_t;
typedef struct mifare_ultralight_handle_s {
    uint8_t (*contactless_transceiver)(uint8_t *in_buf, uint8_t in_len, 



    uint8_t end_page;                                                              // end page 
    uint8_t type;                                                                  // type 
    uint8_t inited;                                                                // inited flag
} mifare_ultralight_handle_t;

uint8_t mifare_ultralight_info(mifare_ultralight_info_t* info);
uint8_t mifare_ultralight_init(mifare_ultralight_handle_t* handle);
uint8_t mifare_ultralight_deinit(mifare_ultralight_handle_t* handle);
uint8_t mifare_ultralight_set_storage(mifare_ultralight_handle_t* handle, mifare_ultralight_storage_t storage);
uint8_t mifare_ultralight_get_storage(mifare_ultralight_handle_t* handle, mifare_ultralight_storage_t* storage);
uint8_t mifare_ultralight_request(mifare_ultralight_handle_t* handle, mifare_ultralight_type_t* type);
uint8_t mifare_ultralight_wake_up(mifare_ultralight_handle_t* handle, mifare_ultralight_type_t* type);
uint8_t mifare_ultralight_halt(mifare_ultralight_handle_t* handle);
uint8_t mifare_ultralight_anticollision_cl1(mifare_ultralight_handle_t* handle, uint8_t id[4]);
uint8_t mifare_ultralight_anticollision_cl2(mifare_ultralight_handle_t* handle, uint8_t id[4]);
uint8_t mifare_ultralight_select_cl1(mifare_ultralight_handle_t* handle, uint8_t id[4]);
uint8_t mifare_ultralight_select_cl2(mifare_ultralight_handle_t* handle, uint8_t id[4]);
uint8_t mifare_ultralight_get_version(mifare_ultralight_handle_t* handle, mifare_ultralight_version_t* version);
uint8_t mifare_ultralight_read_counter(mifare_ultralight_handle_t* handle, uint8_t addr, uint32_t* cnt);
uint8_t mifare_ultralight_increment_counter(mifare_ultralight_handle_t* handle, uint8_t addr, uint32_t cnt);
uint8_t mifare_ultralight_check_tearing_event(mifare_ultralight_handle_t* handle, uint8_t addr, uint8_t* flag);
uint8_t mifare_ultralight_vcsl(mifare_ultralight_handle_t* handle, uint8_t installation_identifier[16], uint8_t pcd_capabilities[4], uint8_t* identifier);
uint8_t mifare_ultralight_read_signature(mifare_ultralight_handle_t* handle, uint8_t signature[32]);
uint8_t mifare_ultralight_get_serial_number(mifare_ultralight_handle_t* handle, uint8_t number[7]);
uint8_t mifare_ultralight_read_four_pages(mifare_ultralight_handle_t* handle, uint8_t start_page, uint8_t data[16]);
uint8_t mifare_ultralight_read_page(mifare_ultralight_handle_t* handle, uint8_t page, uint8_t data[4]);
uint8_t mifare_ultralight_fast_read_page(mifare_ultralight_handle_t* handle, uint8_t start_page, uint8_t stop_page, uint8_t* data, uint16_t* len);
uint8_t mifare_ultralight_compatibility_write_page(mifare_ultralight_handle_t* handle, uint8_t page, uint8_t data[4]);
uint8_t mifare_ultralight_write_page(mifare_ultralight_handle_t* handle, uint8_t page, uint8_t data[4]);
uint8_t mifare_ultralight_authenticate(mifare_ultralight_handle_t* handle, uint8_t pwd[4], uint8_t pack[2]);
uint8_t mifare_ultralight_set_password(mifare_ultralight_handle_t* handle, uint8_t pwd[4]);
uint8_t mifare_ultralight_set_pack(mifare_ultralight_handle_t* handle, uint8_t pack[2]);
uint8_t mifare_ultralight_set_modulation_mode(mifare_ultralight_handle_t* handle, mifare_ultralight_modulation_mode_t mode);
uint8_t mifare_ultralight_get_modulation_mode(mifare_ultralight_handle_t* handle, mifare_ultralight_modulation_mode_t* mode);
uint8_t mifare_ultralight_set_protect_start_page(mifare_ultralight_handle_t* handle, uint8_t page);
uint8_t mifare_ultralight_get_protect_start_page(mifare_ultralight_handle_t* handle, uint8_t* page);
uint8_t mifare_ultralight_set_access(mifare_ultralight_handle_t* handle, mifare_ultralight_access_t access, mifare_ultralight_bool_t enable);
uint8_t mifare_ultralight_get_access(mifare_ultralight_handle_t* handle, mifare_ultralight_access_t access, mifare_ultralight_bool_t* enable);
uint8_t mifare_ultralight_set_authenticate_limitation(mifare_ultralight_handle_t* handle, uint8_t limit);
uint8_t mifare_ultralight_get_authenticate_limitation(mifare_ultralight_handle_t* handle, uint8_t* limit);
uint8_t mifare_ultralight_set_virtual_card_type_identifier(mifare_ultralight_handle_t* handle, uint8_t identifier);
uint8_t mifare_ultralight_get_virtual_card_type_identifier(mifare_ultralight_handle_t* handle, uint8_t* identifier);
uint8_t mifare_ultralight_set_lock(mifare_ultralight_handle_t* handle, uint8_t lock[5]);
uint8_t mifare_ultralight_get_lock(mifare_ultralight_handle_t* handle, uint8_t lock[5]);
uint8_t mifare_ultralight_read_otp(mifare_ultralight_handle_t* handle, uint8_t data[4]);
uint8_t mifare_ultralight_write_otp(mifare_ultralight_handle_t* handle, uint8_t data[4]);
uint8_t mifare_ultralight_transceiver(mifare_ultralight_handle_t* handle, uint8_t* in_buf, uint8_t in_len, uint8_t* out_buf, uint8_t* out_len);
#ifdef __cplusplus
}
#endif
#endif
