
#include "driver_mifare_ultralight.h"

#define MANUFACTURER_NAME         "NXP"                   // manufacturer name
#define SUPPLY_VOLTAGE_MIN        3.3f                    // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        4.0f                    // chip max supply voltage




#define MIFARE_ULTRALIGHT_COMMAND_REQUEST                  0x26           // request command
#define MIFARE_ULTRALIGHT_COMMAND_WAKE_UP                  0x52           // wake up command
#define MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL1        0x9320U        // anticollision cl1 command
#define MIFARE_ULTRALIGHT_COMMAND_SELECT_CL1               0x9370U        // select cl1 command
#define MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL2        0x9520U        // anticollision cl2 command
#define MIFARE_ULTRALIGHT_COMMAND_SELECT_CL2               0x9570U        // select cl2 command
#define MIFARE_ULTRALIGHT_COMMAND_HALT                     0x5000U        // halt command
#define MIFARE_ULTRALIGHT_COMMAND_GET_VERSION              0x60           // get version command
#define MIFARE_ULTRALIGHT_COMMAND_READ                     0x30           // read command
#define MIFARE_ULTRALIGHT_COMMAND_FAST_READ                0x3A           // fast read command
#define MIFARE_ULTRALIGHT_COMMAND_WRITE                    0xA2           // write command
#define MIFARE_ULTRALIGHT_COMMAND_COMP_WRITE               0xA0           // comp write command
#define MIFARE_ULTRALIGHT_COMMAND_READ_CNT                 0x39           // read cnt command
#define MIFARE_ULTRALIGHT_COMMAND_INCR_CNT                 0xA5           // increment cnt command
#define MIFARE_ULTRALIGHT_COMMAND_PWD_AUTH                 0x1B           // pwd auth command
#define MIFARE_ULTRALIGHT_COMMAND_READ_SIG                 0x3C           // read sig command
#define MIFARE_ULTRALIGHT_COMMAND_CHECK_TEARING_EVENT      0x3E           // check tearing event command
#define MIFARE_ULTRALIGHT_COMMAND_VCSL                     0x4B           // vcsl command
static void a_mifare_ultralight_iso14443a_crc(uint8_t *p, uint8_t len, uint8_t output[2])
{
    uint32_t w_crc = 0x6363;
    do 
    {
        uint8_t  bt;
        
        bt = *p++;                                                                                        /* get one byte */
        bt = (bt ^ (uint8_t)(w_crc & 0x00FF));                                                            /* xor */
        bt = (bt ^ (bt << 4));                                                                            /* xor */
        w_crc = (w_crc >> 8) ^ ((uint32_t) bt << 8) ^ ((uint32_t) bt << 3) ^ ((uint32_t) bt >> 4);        /* get the crc */
    } while (--len);                                                                                      /* len-- */
    output[0] = (uint8_t)(w_crc & 0xFF);                                                                  /* lsb */
    output[1] = (uint8_t)((w_crc >> 8) & 0xFF);                                                           /* msb */
}
static uint8_t a_mifare_ultralight_conf_read(mifare_ultralight_handle_t *handle, uint8_t page, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[5];
    uint8_t output_len;
    uint8_t output_buf[6];
    uint8_t crc_buf[2];
    input_len = 5;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_FAST_READ;                                          /* set the command */
    input_buf[1] = page;                                                                         /* set the start page */
    input_buf[2] = page;                                                                         /* set the stop page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 3, input_buf + 3);                             /* get the crc */
    output_len = 6;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 6)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 4, crc_buf);                                   /* get the crc */
    if ((output_buf[4] == crc_buf[0]) && (output_buf[5] == crc_buf[1]))                          /* check the crc */
    {
        memcpy(data, output_buf, 4);                                                             /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
static uint8_t a_mifare_ultralight_conf_write(mifare_ultralight_handle_t *handle, uint8_t page, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = page;                                                                         /* set the setting page */
    input_buf[2] = data[0];                                                                      /* set data0 */
    input_buf[3] = data[1];                                                                      /* set data1 */
    input_buf[4] = data[2];                                                                      /* set data2 */
    input_buf[5] = data[3];                                                                      /* set data3 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_set_storage(mifare_ultralight_handle_t *handle, mifare_ultralight_storage_t storage)
{
    
    {
        
    }
    
    {
        
    }
    end_page = (uint8_t)storage;        /* set the storage */
    return 0;                                   /* success return 0 */
}
uint8_t mifare_ultralight_get_storage(mifare_ultralight_handle_t *handle, mifare_ultralight_storage_t *storage)
{
    
    {
        
    }
    
    {
        
    }
    *storage = (mifare_ultralight_storage_t)(end_page);        /* get the storage */
    return 0;                                                          /* success return 0 */
}
uint8_t mifare_ultralight_init(mifare_ultralight_handle_t *handle)
{
    uint8_t res;
    
    {
        
    }
    if (debug_print == NULL)                                                         /* check debug_print */
    {
        
    }
    if (contactless_init == NULL)                                                    /* check contactless_init */
    {
        
        
        
    }
    if (contactless_deinit == NULL)                                                  /* check contactless_deinit */
    {
        
        
        
    }
    if (contactless_transceiver == NULL)                                             /* check contactless_transceiver */
    {
        
        
        
    }
    if (delay_ms == NULL)                                                            /* check delay_ms */
    {
        
        
        
    }
    res = contactless_init();                                                        /* contactless init */
    
    {
        
        
        
    }
    type = (uint8_t)MIFARE_ULTRALIGHT_TYPE_INVALID;                                  /* set the invalid type */
    end_page = 0xFF;                                                                 /* set the end page */
    inited = 1;                                                                      /* flag inited */
    return 0;                                                                                /* success return 0 */
}
uint8_t mifare_ultralight_deinit(mifare_ultralight_handle_t *handle)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = contactless_deinit();                                                /* contactless deinit */
    
    {
        
        
        
    }
    inited = 0;                                                                /* flag closed */
    return 0;                                                                          /* success return 0 */
}
uint8_t mifare_ultralight_request(mifare_ultralight_handle_t *handle, mifare_ultralight_type_t *type)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[1];
    uint8_t output_len;
    uint8_t output_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 1;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_REQUEST;                                            /* set the command */
    output_len = 2;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 2)                                                                         /* check the output_len */
    {
        
        
        
    }
    if ((output_buf[0] == 0x44) && (output_buf[1] == 0x00))                                      /* check classic type */
    {
        *type = MIFARE_ULTRALIGHT_TYPE_ULTRALIGHT;                                               /* ultralight */
        type = *type;                                                                    /* save the type */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        *type = MIFARE_ULTRALIGHT_TYPE_INVALID;                                                  /* invalid */
        type = *type;                                                                    /* save the type */
        
        
        
    }
}
uint8_t mifare_ultralight_wake_up(mifare_ultralight_handle_t *handle, mifare_ultralight_type_t *type)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[1];
    uint8_t output_len;
    uint8_t output_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 1;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WAKE_UP;                                            /* set the command */
    output_len = 2;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 2)                                                                         /* check the output_len */
    {
        
        
        
    }
    if ((output_buf[0] == 0x44) && (output_buf[1] == 0x00))                                      /* check classic type */
    {
        *type = MIFARE_ULTRALIGHT_TYPE_ULTRALIGHT;                                               /* ultralight */
        type = *type;                                                                    /* save the type */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        *type = MIFARE_ULTRALIGHT_TYPE_INVALID;                                                  /* invalid */
        type = *type;                                                                    /* save the type */
        
        
        
    }
}
uint8_t mifare_ultralight_halt(mifare_ultralight_handle_t *handle)
{
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = (MIFARE_ULTRALIGHT_COMMAND_HALT >> 8) & 0xFF;                                 /* set the command */
    input_buf[1] = (MIFARE_ULTRALIGHT_COMMAND_HALT >> 0) & 0xFF;                                 /* set the command */
    a_mifare_ultralight_iso14443a_crc(input_buf, 2, input_buf + 2);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    (void)contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_anticollision_cl1(mifare_ultralight_handle_t *handle, uint8_t id[4])
{
    uint8_t res;
    uint8_t i;
    uint8_t check;
    uint8_t input_len;
    uint8_t input_buf[2];
    uint8_t output_len;
    uint8_t output_buf[5];
    
    {
        
    }
    
    {
        
    }
    input_len = 2;                                                                               /* set the input length */
    input_buf[0] = (MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL1 >> 8) & 0xFF;                    /* set the command */
    input_buf[1] = (MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL1 >> 0) & 0xFF;                    /* set the command */
    output_len = 5;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 5)                                                                         /* check the output_len */
    {
        
        
        
    }
    check = 0;                                                                                   /* init 0 */
    for (i = 0; i < 4; i++)                                                                      /* run 4 times */
    {
        id[i] = output_buf[i];                                                                   /* get one id */
        check ^= output_buf[i];                                                                  /* xor */
    }
    if (check != output_buf[4])                                                                  /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_anticollision_cl2(mifare_ultralight_handle_t *handle, uint8_t id[4])
{
    uint8_t res;
    uint8_t i;
    uint8_t check;
    uint8_t input_len;
    uint8_t input_buf[2];
    uint8_t output_len;
    uint8_t output_buf[5];
    
    {
        
    }
    
    {
        
    }
    input_len = 2;                                                                               /* set the input length */
    input_buf[0] = (MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL2 >> 8) & 0xFF;                    /* set the command */
    input_buf[1] = (MIFARE_ULTRALIGHT_COMMAND_ANTICOLLISION_CL2 >> 0) & 0xFF;                    /* set the command */
    output_len = 5;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 5)                                                                         /* check the output_len */
    {
        
        
        
    }
    check = 0;                                                                                   /* init 0 */
    for (i = 0; i < 4; i++)                                                                      /* run 4 times */
    {
        id[i] = output_buf[i];                                                                   /* get one id */
        check ^= output_buf[i];                                                                  /* xor */
    }
    if (check != output_buf[4])                                                                  /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_select_cl1(mifare_ultralight_handle_t *handle, uint8_t id[4])
{
    uint8_t res;
    uint8_t i;
    uint8_t input_len;
    uint8_t input_buf[9];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 9;                                                                               /* set the input length */
    input_buf[0] = (MIFARE_ULTRALIGHT_COMMAND_SELECT_CL1 >> 8) & 0xFF;                           /* set the command */
    input_buf[1] = (MIFARE_ULTRALIGHT_COMMAND_SELECT_CL1 >> 0) & 0xFF;                           /* set the command */
    input_buf[6] = 0;                                                                            /* init 0 */
    for (i = 0; i < 4; i++)                                                                      /* run 4 times */
    {
        input_buf[2 + i] = id[i];                                                                /* get one id */
        input_buf[6] ^= id[i];                                                                   /* xor */
    }
    a_mifare_ultralight_iso14443a_crc(input_buf, 7, input_buf + 7);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] == 0x04)                                                                   /* check the sak */
    {
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_select_cl2(mifare_ultralight_handle_t *handle, uint8_t id[4])
{
    uint8_t res;
    uint8_t i;
    uint8_t input_len;
    uint8_t input_buf[9];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 9;                                                                               /* set the input length */
    input_buf[0] = (MIFARE_ULTRALIGHT_COMMAND_SELECT_CL2 >> 8) & 0xFF;                           /* set the command */
    input_buf[1] = (MIFARE_ULTRALIGHT_COMMAND_SELECT_CL2 >> 0) & 0xFF;                           /* set the command */
    input_buf[6] = 0;                                                                            /* init 0 */
    for (i = 0; i < 4; i++)                                                                      /* run 4 times */
    {
        input_buf[2 + i] = id[i];                                                                /* get one id */
        input_buf[6] ^= id[i];                                                                   /* xor */
    }
    a_mifare_ultralight_iso14443a_crc(input_buf, 7, input_buf + 7);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] == 0x00)                                                                   /* check the sak */
    {
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_get_version(mifare_ultralight_handle_t *handle, mifare_ultralight_version_t *version)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[3];
    uint8_t output_len;
    uint8_t output_buf[10];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 3;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_GET_VERSION;                                        /* set the command */
    a_mifare_ultralight_iso14443a_crc(input_buf, 1, input_buf + 1);                              /* get the crc */
    output_len = 10;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 10)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 8, crc_buf);                                   /* get the crc */
    if ((output_buf[8] == crc_buf[0]) && (output_buf[9] == crc_buf[1]))                          /* check the crc */
    {
        version->fixed_header = output_buf[0];                                                   /* fixed header */
        version->vendor_id = output_buf[1];                                                      /* vendor id */
        version->product_type = output_buf[2];                                                   /* product type */
        version->product_subtype = output_buf[3];                                                /* product subtype */
        version->major_product_version = output_buf[4];                                          /* major product version */
        version->minor_product_version = output_buf[5];                                          /* minor product version */
        version->storage_size = output_buf[6];                                                   /* storage size */
        if (version->storage_size == 0x0B)                                                       /* if 20 pages */
        {
            end_page = MIFARE_ULTRALIGHT_STORAGE_MF0UL11;                                /* set the end page */
        }
        else if (version->storage_size == 0x0E)                                                  /* if 41 pages */
        {
            end_page = MIFARE_ULTRALIGHT_STORAGE_MF0UL21;                                /* set the end page */
        }
        else
        {
                                                                                                 /* do nothing */
        }
        version->protocol_type = output_buf[7];                                                  /* protocol type */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_read_counter(mifare_ultralight_handle_t *handle, uint8_t addr, uint32_t *cnt)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[5];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    if (addr > 0x2)                                                                              /* check the addr */
    {
        
        
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ_CNT;                                           /* set the command */
    input_buf[1] = addr;                                                                         /* set the address */
    a_mifare_ultralight_iso14443a_crc(input_buf, 2, input_buf + 2);                              /* get the crc */
    output_len = 5;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 5)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 3, crc_buf);                                   /* get the crc */
    if ((output_buf[3] == crc_buf[0]) && (output_buf[4] == crc_buf[1]))                          /* check the result */
    {
        *cnt = ((uint32_t)output_buf[2] << 16) | ((uint32_t)output_buf[1] << 8) |
               ((uint32_t)output_buf[0] << 0);                                                   /* set the counter */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_increment_counter(mifare_ultralight_handle_t *handle, uint8_t addr, uint32_t cnt)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    if (addr > 0x2)                                                                              /* check the addr */
    {
        
        
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_INCR_CNT;                                           /* set the command */
    input_buf[1] = addr;                                                                         /* set the address */
    input_buf[2] = (cnt >> 0) & 0xFF;                                                            /* set cnt */
    input_buf[3] = (cnt >> 8) & 0xFF;                                                            /* set cnt */
    input_buf[4] = (cnt >> 16) & 0xFF;                                                           /* set cnt */
    input_buf[5] = 0x00;
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_check_tearing_event(mifare_ultralight_handle_t *handle, uint8_t addr, uint8_t *flag)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[3];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    if (addr > 0x2)                                                                              /* check the addr */
    {
        
        
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_CHECK_TEARING_EVENT;                                /* set the command */
    input_buf[1] = addr;                                                                         /* set the address */
    a_mifare_ultralight_iso14443a_crc(input_buf, 2, input_buf + 2);                              /* get the crc */
    output_len = 3;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 3)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 1, crc_buf);                                   /* get the crc */
    if ((output_buf[1] == crc_buf[0]) && (output_buf[2] == crc_buf[1]))                          /* check the result */
    {
        *flag = output_buf[0];                                                                   /* set the output buffer */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_vcsl(mifare_ultralight_handle_t *handle, uint8_t installation_identifier[16],
                               uint8_t pcd_capabilities[4], uint8_t *identifier)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[23];
    uint8_t output_len;
    uint8_t output_buf[3];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 23;                                                                              /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_CHECK_TEARING_EVENT;                                /* set the command */
    memcpy(input_buf + 1, installation_identifier, 16);
    memcpy(input_buf + 17, pcd_capabilities, 4);
    a_mifare_ultralight_iso14443a_crc(input_buf, 21, input_buf + 21);                            /* get the crc */
    output_len = 3;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 3)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 1, crc_buf);                                   /* get the crc */
    if ((output_buf[1] == crc_buf[0]) && (output_buf[2] == crc_buf[1]))                          /* check the result */
    {
        *identifier = output_buf[0];                                                             /* set the output buffer */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_read_signature(mifare_ultralight_handle_t *handle, uint8_t signature[32])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[34];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ_SIG;                                           /* set the command */
    input_buf[1] = 0x00;                                                                         /* set the address */
    a_mifare_ultralight_iso14443a_crc(input_buf, 2, input_buf + 2);                              /* get the crc */
    output_len = 34;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 34)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 32, crc_buf);                                  /* get the crc */
    if ((output_buf[32] == crc_buf[0]) && (output_buf[33] == crc_buf[1]))                        /* check the result */
    {
        memcpy(signature, output_buf, 32);                                                       /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_get_serial_number(mifare_ultralight_handle_t *handle, uint8_t number[7])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[18];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ;                                               /* set the command */
    input_buf[1] = 0x00;                                                                         /* set the read page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 2, input_buf + 2);                             /* get the crc */
    output_len = 18;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 18)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 16, crc_buf);                                  /* get the crc */
    if ((output_buf[16] == crc_buf[0]) && (output_buf[17] == crc_buf[1]))                        /* check the crc */
    {
        number[0] = output_buf[0];                                                               /* set the number 0 */
        number[1] = output_buf[1];                                                               /* set the number 1 */
        number[2] = output_buf[2];                                                               /* set the number 2 */
        number[3] = output_buf[4];                                                               /* set the number 3 */
        number[4] = output_buf[5];                                                               /* set the number 4 */
        number[5] = output_buf[6];                                                               /* set the number 5 */
        number[6] = output_buf[7];                                                               /* set the number 6 */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_read_four_pages(mifare_ultralight_handle_t *handle, uint8_t start_page, uint8_t data[16])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[18];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ;                                               /* set the command */
    input_buf[1] = start_page;                                                                   /* set the page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 2, input_buf + 2);                             /* get the crc */
    output_len = 18;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 18)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 16, crc_buf);                                  /* get the crc */
    if ((output_buf[16] == crc_buf[0]) && (output_buf[17] == crc_buf[1]))                        /* check the crc */
    {
        memcpy(data, output_buf, 16);                                                            /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_read_page(mifare_ultralight_handle_t *handle, uint8_t page, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[18];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ;                                               /* set the command */
    input_buf[1] = page;                                                                         /* set the page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 2, input_buf + 2);                             /* get the crc */
    output_len = 18;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 18)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 16, crc_buf);                                  /* get the crc */
    if ((output_buf[16] == crc_buf[0]) && (output_buf[17] == crc_buf[1]))                        /* check the crc */
    {
        memcpy(data, output_buf, 4);                                                             /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_fast_read_page(mifare_ultralight_handle_t *handle, uint8_t start_page, uint8_t stop_page, uint8_t *data, uint16_t *len)
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[5];
    uint8_t output_len;
    uint8_t cal_len;
    uint8_t output_buf[64];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    if (stop_page < start_page)                                                                         /* check start and stop page */
    {
        
        
        
    }
    if (stop_page - start_page + 1 > 15)                                                                /* check start and stop page */
    {
        
        
        
    }
    if ((*len) < (4 * (stop_page - start_page + 1)))                                                    /* check the length */
    {
        
        
        
    }
    input_len = 5;                                                                                      /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_FAST_READ;                                                 /* set the command */
    input_buf[1] = start_page;                                                                          /* set the start page */
    input_buf[2] = stop_page;                                                                           /* set the stop page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 3, input_buf + 3);                                    /* get the crc */
    cal_len = 4 * (stop_page - start_page + 1);                                                         /* set the cal length */
    output_len = (uint8_t)(cal_len + 2);                                                                /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);               /* transceiver */
    
    {
        
        
        
    }
    if (output_len != (cal_len + 2))                                                                    /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, (uint8_t)cal_len, crc_buf);                           /* get the crc */
    if ((output_buf[cal_len] == crc_buf[0]) && (output_buf[cal_len + 1] == crc_buf[1]))                 /* check the crc */
    {
        memcpy(data, output_buf, cal_len);                                                              /* copy the data */
        *len = cal_len;                                                                                 /* set the length */
        
        return 0;                                                                                       /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_compatibility_write_page(mifare_ultralight_handle_t *handle, uint8_t page, uint8_t data[4])
{
    uint8_t res;
    uint8_t i;
    uint8_t input_len;
    uint8_t input_buf[18];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_COMP_WRITE;                                         /* set the command */
    input_buf[1] = page;                                                                         /* set the page */
    a_mifare_ultralight_iso14443a_crc(input_buf, 2, input_buf + 2);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    for (i = 0; i < 4; i ++)                                                                     /* 4 times */
    {
        input_buf[i] = data[i];                                                                  /* copy data */
    }
    for (i = 0; i < 12; i ++)                                                                    /* 12 times */
    {
        input_buf[4 + i] = 0x00;                                                                 /* copy data */
    }
    a_mifare_ultralight_iso14443a_crc(input_buf, 16, input_buf + 16);                            /* get the crc */
    input_len = 18;                                                                              /* set the input length */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_write_page(mifare_ultralight_handle_t *handle, uint8_t page, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = page;                                                                         /* set the page */
    input_buf[2] = data[0];                                                                      /* set data0 */
    input_buf[3] = data[1];                                                                      /* set data1 */
    input_buf[4] = data[2];                                                                      /* set data2 */
    input_buf[5] = data[3];                                                                      /* set data3 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_authenticate(mifare_ultralight_handle_t *handle, uint8_t pwd[4], uint8_t pack[2])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[7];
    uint8_t output_len;
    uint8_t output_buf[4];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 7;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_PWD_AUTH;                                           /* set the command */
    input_buf[1] = pwd[0];                                                                       /* set pwd0 */
    input_buf[2] = pwd[1];                                                                       /* set pwd1 */
    input_buf[3] = pwd[2];                                                                       /* set pwd2 */
    input_buf[4] = pwd[3];                                                                       /* set pwd3 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 5, input_buf + 5);                              /* get the crc */
    output_len = 4;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 4)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 2, crc_buf);                                   /* get the crc */
    if ((output_buf[2] == crc_buf[0]) && (output_buf[3] == crc_buf[1]))                          /* check the crc */
    {
        if ((output_buf[0] != pack[0]) || (output_buf[1] != pack[1]))                            /* check the pack */
        {
            
            
            
        }
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_set_password(mifare_ultralight_handle_t *handle, uint8_t pwd[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = end_page - 1;                                                         /* set the last page */
    input_buf[2] = pwd[0];                                                                       /* set pwd0 */
    input_buf[3] = pwd[1];                                                                       /* set pwd1 */
    input_buf[4] = pwd[2];                                                                       /* set pwd2 */
    input_buf[5] = pwd[3];                                                                       /* set pwd3 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_set_pack(mifare_ultralight_handle_t *handle, uint8_t pack[2])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = end_page;                                                             /* set the last page */
    input_buf[2] = pack[0];                                                                      /* set pack0 */
    input_buf[3] = pack[1];                                                                      /* set pack1 */
    input_buf[4] = 0x00;                                                                         /* set 0x00 */
    input_buf[5] = 0x00;                                                                         /* set 0x00 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_set_modulation_mode(mifare_ultralight_handle_t *handle, mifare_ultralight_modulation_mode_t mode)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 3, conf);         /* read conf */
    
    {
        
        
        
    }
    conf[0] &= ~(1 << 2);                                                            /* clear the settings */
    conf[0] |= mode << 2;                                                            /* set the mode */
    res = a_mifare_ultralight_conf_write( end_page - 3, conf);        /* write conf */
    
    {
        
        
        
    }
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_get_modulation_mode(mifare_ultralight_handle_t *handle, mifare_ultralight_modulation_mode_t *mode)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 3, conf);         /* read conf */
    
    {
        
        
        
    }
    *mode = (mifare_ultralight_modulation_mode_t)((conf[0] >> 2) & 0x1);             /* get the conf */
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_set_protect_start_page(mifare_ultralight_handle_t *handle, uint8_t page)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 3, conf);         /* read conf */
    
    {
        
        
        
    }
    conf[3] = page;                                                                  /* set the page */
    res = a_mifare_ultralight_conf_write( end_page - 3, conf);        /* write conf */
    
    {
        
        
        
    }
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_get_protect_start_page(mifare_ultralight_handle_t *handle, uint8_t *page)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 3, conf);         /* read conf */
    
    {
        
        
        
    }
    *page = conf[3];                                                                 /* get the page */
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_set_access(mifare_ultralight_handle_t *handle, mifare_ultralight_access_t access, mifare_ultralight_bool_t enable)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    conf[0] &= ~(1 << access);                                                       /* clear the settings */
    conf[0] |= enable << access;                                                     /* set the access */
    res = a_mifare_ultralight_conf_write( end_page - 2, conf);        /* write conf */
    
    {
        
        
        
    }
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_get_access(mifare_ultralight_handle_t *handle, mifare_ultralight_access_t access, mifare_ultralight_bool_t *enable)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    *enable = (mifare_ultralight_bool_t)((conf[0] >> access) & 0x1);                 /* get the bool */
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_set_authenticate_limitation(mifare_ultralight_handle_t *handle, uint8_t limit)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    if (limit > 7)                                                                   /* check the limit */
    {
        
        
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    conf[0] &= ~(7 << 0);                                                            /* clear the settings */
    conf[0] |= limit << 0;                                                           /* set the limit */
    res = a_mifare_ultralight_conf_write( end_page - 2, conf);        /* write conf */
    
    {
        
        
        
    }
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_get_authenticate_limitation(mifare_ultralight_handle_t *handle, uint8_t *limit)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    *limit = conf[0] & 0x7;                                                          /* set the limit */
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_set_virtual_card_type_identifier(mifare_ultralight_handle_t *handle, uint8_t identifier)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    conf[1] = identifier;                                                            /* set the identifier */
    res = a_mifare_ultralight_conf_write( end_page - 2, conf);        /* write conf */
    
    {
        
        
        
    }
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_get_virtual_card_type_identifier(mifare_ultralight_handle_t *handle, uint8_t *identifier)
{
    uint8_t res;
    uint8_t conf[4];
    
    {
        
    }
    
    {
        
    }
    memset(conf, 0, sizeof(uint8_t) * 4);                                            /* clear the conf */
    res = a_mifare_ultralight_conf_read( end_page - 2, conf);         /* read conf */
    
    {
        
        
        
    }
    *identifier = conf[1];                                                           /* get the identifier */
    return 0;                                                                        /* success return 0 */
}
uint8_t mifare_ultralight_set_lock(mifare_ultralight_handle_t *handle, uint8_t lock[5])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = 0x02;                                                                         /* set the setting page */
    input_buf[2] = 0x00;                                                                         /* set 0x00 */
    input_buf[3] = 0x00;                                                                         /* set 0x00 */
    input_buf[4] = lock[0];                                                                      /* set lock0 */
    input_buf[5] = lock[1];                                                                      /* set lock1 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = end_page - 4;                                                         /* set the setting page */
    input_buf[2] = lock[2];                                                                      /* set lock2 */
    input_buf[3] = lock[3];                                                                      /* set lock3 */
    input_buf[4] = lock[4];                                                                      /* set lock4 */
    input_buf[5] = 0x00;                                                                         /* set 0x00 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_get_lock(mifare_ultralight_handle_t *handle, uint8_t lock[5])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[5];
    uint8_t output_len;
    uint8_t output_buf[6];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 5;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_FAST_READ;                                          /* set the command */
    input_buf[1] = 2;                                                                            /* set the start page */
    input_buf[2] = 2;                                                                            /* set the stop page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 3, input_buf + 3);                             /* get the crc */
    output_len = 6;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 6)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 4, crc_buf);                                   /* get the crc */
    if ((output_buf[4] == crc_buf[0]) && (output_buf[5] == crc_buf[1]))                          /* check the crc */
    {
        memcpy(lock, output_buf + 2, 2);                                                         /* copy the data */
    }
    else
    {
        
        
        
    }
    input_len = 5;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_FAST_READ;                                          /* set the command */
    input_buf[1] = end_page - 4;                                                         /* set the start page */
    input_buf[2] = end_page - 4;                                                         /* set the stop page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 3, input_buf + 3);                             /* get the crc */
    output_len = 6;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 6)                                                                         /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 4, crc_buf);                                   /* get the crc */
    if ((output_buf[4] == crc_buf[0]) && (output_buf[5] == crc_buf[1]))                          /* check the crc */
    {
        memcpy(lock + 2, output_buf, 3);                                                         /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_read_otp(mifare_ultralight_handle_t *handle, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[4];
    uint8_t output_len;
    uint8_t output_buf[18];
    uint8_t crc_buf[2];
    
    {
        
    }
    
    {
        
    }
    input_len = 4;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_READ;                                               /* set the command */
    input_buf[1] = 0x03;                                                                         /* set the page */
    a_mifare_ultralight_iso14443a_crc(input_buf , 2, input_buf + 2);                             /* get the crc */
    output_len = 18;                                                                             /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 18)                                                                        /* check the output_len */
    {
        
        
        
    }
    a_mifare_ultralight_iso14443a_crc(output_buf, 16, crc_buf);                                  /* get the crc */
    if ((output_buf[16] == crc_buf[0]) && (output_buf[17] == crc_buf[1]))                        /* check the crc */
    {
        memcpy(data, output_buf, 4);                                                             /* copy the data */
        
        return 0;                                                                                /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t mifare_ultralight_write_otp(mifare_ultralight_handle_t *handle, uint8_t data[4])
{
    uint8_t res;
    uint8_t input_len;
    uint8_t input_buf[8];
    uint8_t output_len;
    uint8_t output_buf[1];
    
    {
        
    }
    
    {
        
    }
    input_len = 8;                                                                               /* set the input length */
    input_buf[0] = MIFARE_ULTRALIGHT_COMMAND_WRITE;                                              /* set the command */
    input_buf[1] = 0x03;                                                                         /* set the page */
    input_buf[2] = data[0];                                                                      /* set data0 */
    input_buf[3] = data[1];                                                                      /* set data1 */
    input_buf[4] = data[2];                                                                      /* set data2 */
    input_buf[5] = data[3];                                                                      /* set data3 */
    a_mifare_ultralight_iso14443a_crc(input_buf, 6, input_buf + 6);                              /* get the crc */
    output_len = 1;                                                                              /* set the ouput length */
    res = contactless_transceiver(input_buf, input_len, output_buf, &output_len);        /* transceiver */
    
    {
        
        
        
    }
    if (output_len != 1)                                                                         /* check the output_len */
    {
        
        
        
    }
    if (output_buf[0] != 0xA)                                                                    /* check the result */
    {
        
        
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t mifare_ultralight_transceiver(mifare_ultralight_handle_t *handle, uint8_t *in_buf, uint8_t in_len, uint8_t *out_buf, uint8_t *out_len)
{
    
    {
        
    }
    
    {
        
    }
    if (contactless_transceiver(in_buf, in_len, 
                                        out_buf, out_len) != 0)        /* transceiver data */
    {
        
    }
    else
    {
        return 0;                                                      /* success return 0 */
    }
}
uint8_t mifare_ultralight_info(mifare_ultralight_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(mifare_ultralight_info_t));              /* initialize mifare_ultralight info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "RF", 8);                              /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
