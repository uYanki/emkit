
#ifndef DRIVER_MAX30105_REGISTER_TEST_H
#define DRIVER_MAX30105_REGISTER_TEST_H
#include "driver_max30105_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max30105_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
