
#ifndef DRIVER_MAX30105_FIFO_H
#define DRIVER_MAX30105_FIFO_H
#include "driver_max30105_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MAX30105_FIFO_DEFAULT_SAMPLE_AVERAGING               MAX30105_SAMPLE_AVERAGING_8                         // sample 8 
#define MAX30105_FIFO_DEFAULT_FIFO_ROLL                      MAX30105_BOOL_TRUE                                  // enable 
#define MAX30105_FIFO_DEFAULT_FIFO_ALMOST_FULL               0xF                                                 // 0xF 
#define MAX30105_FIFO_DEFAULT_MODE                           MAX30105_MODE_GREEN_RED_IR                          // gren red ir mode 
#define MAX30105_FIFO_DEFAULT_PARTICLE_SENSING_ADC_RANGE     MAX30105_PARTICLE_SENSING_ADC_RANGE_4096            // adc range 4096 
#define MAX30105_FIFO_DEFAULT_PARTICLE_SENSING_SAMPLE_RATE   MAX30105_PARTICLE_SENSING_SAMPLE_RATE_100_HZ        // 100 Hz 
#define MAX30105_FIFO_DEFAULT_ADC_RESOLUTION                 MAX30105_ADC_RESOLUTION_18_BIT                      // 18 bits 
#define MAX30105_FIFO_DEFAULT_LED_RED_PULSE_AMPLITUDE        0x7F                                                // 0x7F 
#define MAX30105_FIFO_DEFAULT_LED_IR_PULSE_AMPLITUDE         0x7F                                                // 0x7F 
#define MAX30105_FIFO_DEFAULT_LED_GREEN_PULSE_AMPLITUDE      0x7F                                                // 0x7F 
#define MAX30105_FIFO_DEFAULT_LED_PROXIMITY_PULSE_AMPLITUDE  0x7F                                                // 0x7F 
#define MAX30105_FIFO_DEFAULT_PROXIMITY_THRESHOLD            1023                                                // 1023 
#define MAX30105_FIFO_DEFAULT_SLOT1                          MAX30105_LED_RED_LED1_PA                            // led red 
#define MAX30105_FIFO_DEFAULT_SLOT2                          MAX30105_LED_IR_LED2_PA                             // led ir 
#define MAX30105_FIFO_DEFAULT_SLOT3                          MAX30105_LED_GREEN_LED3_PA                          // led none 
#define MAX30105_FIFO_DEFAULT_SLOT4                          MAX30105_LED_NONE                                   // led none 
#define MAX30105_FIFO_DEFAULT_DIE_TEMPERATURE                MAX30105_BOOL_FALSE                                 // disable 
#define MAX30105_FIFO_DEFAULT_INTERRUPT_DATA_RDY_EN          MAX30105_BOOL_FALSE                                 // disable 
#define MAX30105_FIFO_DEFAULT_INTERRUPT_ALC_OVF_EN           MAX30105_BOOL_TRUE                                  // enable 
#define MAX30105_FIFO_DEFAULT_INTERRUPT_DIE_TEMP_RDY_EN      MAX30105_BOOL_TRUE                                  // enable 
uint8_t max30105_fifo_irq_handler(void);
uint8_t max30105_fifo_init(void (*fifo_receive_callback)(uint8_t type));
uint8_t max30105_fifo_deinit(void);
uint8_t max30105_fifo_read(uint32_t *raw_red, uint32_t *raw_ir, uint32_t *raw_green, uint8_t *len);
#ifdef __cplusplus
}
#endif
#endif
