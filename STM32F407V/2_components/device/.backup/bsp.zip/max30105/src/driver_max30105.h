
#ifndef DRIVER_MAX30105_H
#define DRIVER_MAX30105_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MAX30105_BOOL_FALSE = 0x00,  // false
    MAX30105_BOOL_TRUE  = 0x01,  // true
} max30105_bool_t;
typedef enum {
    MAX30105_SAMPLE_AVERAGING_1  = 0x00,  // no averaging
    MAX30105_SAMPLE_AVERAGING_2  = 0x01,  // averaging 2
    MAX30105_SAMPLE_AVERAGING_4  = 0x02,  // averaging 4
    MAX30105_SAMPLE_AVERAGING_8  = 0x03,  // averaging 8
    MAX30105_SAMPLE_AVERAGING_16 = 0x04,  // averaging 16
    MAX30105_SAMPLE_AVERAGING_32 = 0x05,  // averaging 32
} max30105_sample_averaging_t;
typedef enum {
    MAX30105_MODE_RED          = 0x02,  // red only mode
    MAX30105_MODE_RED_IR       = 0x03,  // red and ir mode
    MAX30105_MODE_GREEN_RED_IR = 0x07,  // green, red and ir mode
} max30105_mode_t;
typedef enum {
    MAX30105_INTERRUPT_STATUS_FIFO_FULL    = 7,  // fifo almost full flag
    MAX30105_INTERRUPT_STATUS_DATA_RDY     = 6,  // new fifo data ready
    MAX30105_INTERRUPT_STATUS_ALC_OVF      = 5,  // ambient light cancellation overflow
    MAX30105_INTERRUPT_STATUS_PROX_INT     = 4,  // proximity threshold triggered
    MAX30105_INTERRUPT_STATUS_PWR_RDY      = 0,  // power ready flag
    MAX30105_INTERRUPT_STATUS_DIE_TEMP_RDY = 1,  // internal temperature ready flag
} max30105_interrupt_status_t;
typedef enum {
    MAX30105_INTERRUPT_FIFO_FULL_EN    = 7,  // fifo almost full enable
    MAX30105_INTERRUPT_DATA_RDY_EN     = 6,  // new fifo data ready enable
    MAX30105_INTERRUPT_ALC_OVF_EN      = 5,  // ambient light cancellation overflow enable
    MAX30105_INTERRUPT_PROX_INT_EN     = 4,  // proximity threshold interrupt enable
    MAX30105_INTERRUPT_DIE_TEMP_RDY_EN = 1,  // internal temperature enable
} max30105_interrupt_t;
typedef enum {
    MAX30105_PARTICLE_SENSING_ADC_RANGE_2048  = 0,  // range 2048
    MAX30105_PARTICLE_SENSING_ADC_RANGE_4096  = 1,  // range 4096
    MAX30105_PARTICLE_SENSING_ADC_RANGE_8192  = 2,  // range 8192
    MAX30105_PARTICLE_SENSING_ADC_RANGE_16384 = 3,  // range 16384
} max30105_particle_sensing_adc_range_t;
typedef enum {
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_50_HZ   = 0,  // 50Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_100_HZ  = 1,  // 100Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_200_HZ  = 2,  // 200Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_400_HZ  = 3,  // 400Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_800_HZ  = 4,  // 800Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_1000_HZ = 5,  // 1000Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_1600_HZ = 6,  // 1600Hz
    MAX30105_PARTICLE_SENSING_SAMPLE_RATE_3200_HZ = 7,  // 3200Hz
} max30105_particle_sensing_sample_rate_t;
typedef enum {
    MAX30105_ADC_RESOLUTION_15_BIT = 0,  // 15 bits
    MAX30105_ADC_RESOLUTION_16_BIT = 1,  // 16 bits
    MAX30105_ADC_RESOLUTION_17_BIT = 2,  // 17 bits
    MAX30105_ADC_RESOLUTION_18_BIT = 3,  // 18 bits
} max30105_adc_resolution_t;
typedef enum {
    MAX30105_LED_NONE           = 0,  // time slot is disabled
    MAX30105_LED_RED_LED1_PA    = 1,  // red led1 pa
    MAX30105_LED_IR_LED2_PA     = 2,  // ir led2 pa
    MAX30105_LED_GREEN_LED3_PA  = 3,  // green led3 pa
    MAX30105_LED_RED_PILOT_PA   = 5,  // red pilot pa
    MAX30105_LED_IR_PILOT_PA    = 6,  // ir pilot pa
    MAX30105_LED_GREEN_PILOT_PA = 7,  // green pilot pa
} max30105_led_t;
typedef enum {
    MAX30105_SLOT_1 = 0,  // slot 1
    MAX30105_SLOT_2 = 1,  // slot 2
    MAX30105_SLOT_3 = 2,  // slot 3
    MAX30105_SLOT_4 = 3,  // slot 4
} max30105_slot_t;
typedef struct max30105_handle_s {
    uint8_t  inited;         // inited flag
    uint8_t  finished_flag;  // finished flag
    uint16_t raw;            // raw
    float    temperature;    // temperature
    uint8_t  buf[288];       // inner buffer
} max30105_handle_t;

uint8_t max30105_info(max30105_info_t* info);
uint8_t max30105_irq_handler(max30105_handle_t* handle);
uint8_t max30105_init(max30105_handle_t* handle);
uint8_t max30105_deinit(max30105_handle_t* handle);
uint8_t max30105_read(max30105_handle_t* handle, uint32_t* raw_red, uint32_t* raw_ir, uint32_t* raw_green, uint8_t* len);
uint8_t max30105_read_temperature(max30105_handle_t* handle, uint16_t* raw, float* temp);
uint8_t max30105_get_interrupt_status(max30105_handle_t* handle, max30105_interrupt_status_t status, max30105_bool_t* enable);
uint8_t max30105_set_interrupt(max30105_handle_t* handle, max30105_interrupt_t type, max30105_bool_t enable);
uint8_t max30105_get_interrupt(max30105_handle_t* handle, max30105_interrupt_t type, max30105_bool_t* enable);
uint8_t max30105_set_fifo_write_pointer(max30105_handle_t* handle, uint8_t pointer);
uint8_t max30105_get_fifo_write_pointer(max30105_handle_t* handle, uint8_t* pointer);
uint8_t max30105_set_fifo_overflow_counter(max30105_handle_t* handle, uint8_t counter);
uint8_t max30105_get_fifo_overflow_counter(max30105_handle_t* handle, uint8_t* counter);
uint8_t max30105_set_fifo_read_pointer(max30105_handle_t* handle, uint8_t pointer);
uint8_t max30105_get_fifo_read_pointer(max30105_handle_t* handle, uint8_t* pointer);
uint8_t max30105_set_fifo_data(max30105_handle_t* handle, uint8_t data);
uint8_t max30105_get_fifo_data(max30105_handle_t* handle, uint8_t* data);
uint8_t max30105_set_fifo_sample_averaging(max30105_handle_t* handle, max30105_sample_averaging_t sample);
uint8_t max30105_get_fifo_sample_averaging(max30105_handle_t* handle, max30105_sample_averaging_t* sample);
uint8_t max30105_set_fifo_roll(max30105_handle_t* handle, max30105_bool_t enable);
uint8_t max30105_get_fifo_roll(max30105_handle_t* handle, max30105_bool_t* enable);
uint8_t max30105_set_fifo_almost_full(max30105_handle_t* handle, uint8_t value);
uint8_t max30105_get_fifo_almost_full(max30105_handle_t* handle, uint8_t* value);
uint8_t max30105_set_shutdown(max30105_handle_t* handle, max30105_bool_t enable);
uint8_t max30105_get_shutdown(max30105_handle_t* handle, max30105_bool_t* enable);
uint8_t max30105_reset(max30105_handle_t* handle);
uint8_t max30105_set_mode(max30105_handle_t* handle, max30105_mode_t mode);
uint8_t max30105_get_mode(max30105_handle_t* handle, max30105_mode_t* mode);
uint8_t max30105_set_particle_sensing_adc_range(max30105_handle_t* handle, max30105_particle_sensing_adc_range_t range);
uint8_t max30105_get_particle_sensing_adc_range(max30105_handle_t* handle, max30105_particle_sensing_adc_range_t* range);
uint8_t max30105_set_particle_sensing_sample_rate(max30105_handle_t* handle, max30105_particle_sensing_sample_rate_t rate);
uint8_t max30105_get_particle_sensing_sample_rate(max30105_handle_t* handle, max30105_particle_sensing_sample_rate_t* rate);
uint8_t max30105_set_adc_resolution(max30105_handle_t* handle, max30105_adc_resolution_t resolution);
uint8_t max30105_get_adc_resolution(max30105_handle_t* handle, max30105_adc_resolution_t* resolution);
uint8_t max30105_set_led_red_pulse_amplitude(max30105_handle_t* handle, uint8_t amp);
uint8_t max30105_get_led_red_pulse_amplitude(max30105_handle_t* handle, uint8_t* amp);
uint8_t max30105_set_led_ir_pulse_amplitude(max30105_handle_t* handle, uint8_t amp);
uint8_t max30105_get_led_ir_pulse_amplitude(max30105_handle_t* handle, uint8_t* amp);
uint8_t max30105_set_led_green_pulse_amplitude(max30105_handle_t* handle, uint8_t amp);
uint8_t max30105_get_led_green_pulse_amplitude(max30105_handle_t* handle, uint8_t* amp);
uint8_t max30105_set_led_proximity_pulse_amplitude(max30105_handle_t* handle, uint8_t amp);
uint8_t max30105_get_led_proximity_pulse_amplitude(max30105_handle_t* handle, uint8_t* amp);
uint8_t max30105_set_slot(max30105_handle_t* handle, max30105_slot_t slot, max30105_led_t led);
uint8_t max30105_get_slot(max30105_handle_t* handle, max30105_slot_t slot, max30105_led_t* led);
uint8_t max30105_set_die_temperature(max30105_handle_t* handle, max30105_bool_t enable);
uint8_t max30105_get_die_temperature(max30105_handle_t* handle, max30105_bool_t* enable);
uint8_t max30105_set_proximity_interrupt_threshold(max30105_handle_t* handle, uint8_t threshold);
uint8_t max30105_get_proximity_interrupt_threshold(max30105_handle_t* handle, uint8_t* threshold);
uint8_t max30105_proximity_threshold_convert_to_register(max30105_handle_t* handle, uint32_t adc, uint8_t* reg);
uint8_t max30105_proximity_threshold_convert_to_data(max30105_handle_t* handle, uint8_t reg, uint32_t* adc);
uint8_t max30105_get_id(max30105_handle_t* handle, uint8_t* revision_id, uint8_t* part_id);
uint8_t max30105_set_reg(max30105_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t max30105_get_reg(max30105_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
