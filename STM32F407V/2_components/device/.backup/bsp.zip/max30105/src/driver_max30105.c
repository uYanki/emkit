
#include "driver_max30105.h"

#define MANUFACTURER_NAME         "Maxim Integrated"                 // manufacturer name
#define SUPPLY_VOLTAGE_MIN        1.7f                               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        2.0f                               // chip max supply voltage




#define MAX30105_ADDRESS        0xAE        // iic address
#define MAX30105_REG_INTERRUPT_STATUS_1          0x00        // interrupt status 1 register
#define MAX30105_REG_INTERRUPT_STATUS_2          0x01        // interrupt status 2 register
#define MAX30105_REG_INTERRUPT_ENABLE_1          0x02        // interrupt enable 1 register
#define MAX30105_REG_INTERRUPT_ENABLE_2          0x03        // interrupt enable 2 register
#define MAX30105_REG_FIFO_WRITE_POINTER          0x04        // fifo write pointer register
#define MAX30105_REG_OVERFLOW_COUNTER            0x05        // overflow counter register
#define MAX30105_REG_FIFO_READ_POINTER           0x06        // fifo read pointer register
#define MAX30105_REG_FIFO_DATA_REGISTER          0x07        // fifo data register
#define MAX30105_REG_FIFO_CONFIG                 0x08        // fifo config register
#define MAX30105_REG_MODE_CONFIG                 0x09        // mode config register
#define MAX30105_REG_SPO2_CONFIG                 0x0A        // spo2 config register
#define MAX30105_REG_LED_1_PA                    0x0C        // led 1 pa register
#define MAX30105_REG_LED_2_PA                    0x0D        // led 2 pa register
#define MAX30105_REG_LED_3_PA                    0x0E        // led 3 pa register
#define MAX30105_REG_PILOT_PA                    0x10        // proximity mode led pulse amplitude register
#define MAX30105_REG_MULTI_LED_MODE_CONTROL_1    0x11        // multi led mode control 1 register
#define MAX30105_REG_MULTI_LED_MODE_CONTROL_2    0x12        // multi led mode control 2 register
#define MAX30105_REG_DIE_TEMP_INTEGER            0x1F        // die temperature integer register
#define MAX30105_REG_DIE_TEMP_FRACTION           0x20        // die temperature fraction register
#define MAX30105_REG_DIE_TEMP_CONFIG             0x21        // die temperature config register
#define MAX30105_REG_PROX_INT_THRESH             0x30        // proximity interrupt threshold
#define MAX30105_REG_REVISION_ID                 0xFE        // revision id register
#define MAX30105_REG_PART_ID                     0xFF        // part id register
uint8_t max30105_init(max30105_handle_t *handle)
{
    uint8_t res;
    uint8_t prev;
    uint8_t part_id;
    
    {
        
    }
    if (debug_print == NULL)                                                                        /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                                                           /* check iic_init */
    {
        
        
        
    }
    if (iic_deinit == NULL)                                                                         /* check iic_deinit */
    {
        
        
        
    }
    if (iic_read == NULL)                                                                           /* check iic_read */
    {
        
        
        
    }
    if (iic_write == NULL)                                                                          /* check iic_write */
    {
        
        
        
    }
    if (receive_callback == NULL)                                                                   /* check receive_callback */
    {
        
        
        
    }
    if (delay_ms == NULL)                                                                           /* check delay_ms */
    {
        
        
        
    }
    if (iic_init() != 0)                                                                            /* init iic */
    {
        
        
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_PART_ID, (uint8_t *)&part_id, 1);                 /* read part id */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    if (part_id != 0x15)                                                                                    /* check part id */
    {
        
        
        
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);                /* read mode config */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    prev &= ~(1 << 6);                                                                                      /* clear config */
    prev |= 1 << 6;                                                                                         /* set 1 */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);               /* write mode config */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    delay_ms(10);                                                                                   /* delay 10 ms */
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);                /* read mode config */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    if ((prev & (1 << 6)) != 0)                                                                             /* check result */
    {
        
        
        
        
    }
    prev = 0;                                                                                               /* set zero */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_READ_POINTER, (uint8_t *)&prev, 1);         /* write fifo read pointer */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_WRITE_POINTER, (uint8_t *)&prev, 1);        /* write fifo write pointer */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_OVERFLOW_COUNTER, (uint8_t *)&prev, 1);          /* write overflow counter */
    if (res != 0)                                                                                           /* check result */
    {
        
        
        
        
    }
    inited = 1;                                                                                     /* flag finish initialization */
    return 0;                                                                                               /* success return 0 */
}
uint8_t max30105_deinit(max30105_handle_t *handle)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 7);                                                                               /* clear config */
    prev |= 1 << 7;                                                                                  /* set bool */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);        /* write mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    if (iic_deinit() != 0)                                                                   /* iic deinit */
    {
        
        
        
    }
    inited = 0;                                                                              /* flag close */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_irq_handler(max30105_handle_t *handle)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_STATUS_1, (uint8_t *)&prev, 1);                /* read interrupt status1 */
    if (res != 0)                                                                                                  /* check result */
    {
        
       
        
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_FIFO_FULL)) != 0)                                                  /* check fifo full */
    {
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_FIFO_FULL);                                         /* run callback */
        }
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_DATA_RDY)) != 0)                                                   /* check data ready */
    {
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_DATA_RDY);                                          /* run callback */
        }
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_ALC_OVF)) != 0)                                                    /* check alc ovf */
    {
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_ALC_OVF);                                           /* run callback */
        }
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_PROX_INT)) != 0)                                                   /* check prox int */
    {
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_PROX_INT);                                          /* run callback */
        }
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_PWR_RDY)) != 0)                                                    /* check pwr ready */
    {
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_PWR_RDY);                                           /* run callback */
        }
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_STATUS_2, (uint8_t *)&prev, 1);                /* read interrupt status2 */
    if (res != 0)                                                                                                  /* check result */
    {
        
       
        
    }
    if ((prev & (1 << MAX30105_INTERRUPT_STATUS_DIE_TEMP_RDY)) != 0)                                               /* check die temp ready */
    {
        uint8_t prev1;
        
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_INTEGER, (uint8_t *)&prev, 1);              /* read die temp integer */
        if (res != 0)                                                                                              /* check result */
        {
            
           
            
        }
        raw = (uint16_t)prev << 4;                                                                         /* set integer part */
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_FRACTION, (uint8_t *)&prev1, 1);            /* read die temp fraction */
        if (res != 0)                                                                                              /* check result */
        {
            
           
            
        }
        raw = raw | prev1;                                                                         /* set fraction part */
        temperature = (float)(prev) + (float)(prev1) * 0.0625f;                                            /* set the temperature */
        finished_flag = 1;                                                                                 /* set flag */
        
        if (receive_callback != NULL)                                                                      /* if receive callback */
        {
            receive_callback(MAX30105_INTERRUPT_STATUS_DIE_TEMP_RDY);                                      /* run callback */
        }
    }
    return 0;                                                                                                      /* success return 0 */
}
uint8_t max30105_read(max30105_handle_t *handle, uint32_t *raw_red, uint32_t *raw_ir, uint32_t *raw_green, uint8_t *len)
{
    uint8_t res;
    uint8_t prev;
    uint8_t mode;
    uint8_t k;
    uint8_t read_point;
    uint8_t write_point;
    uint8_t l;
    uint8_t bit;
    uint8_t i;
    uint8_t r;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_OVERFLOW_COUNTER, (uint8_t *)&prev, 1);                 /* read overflow counter */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    r = 0;                                                                                                        /* set 0 */
    if (prev != 0)                                                                                                /* check overflow */
    {
        r = 4;                                                                                                    /* set 4 */
        
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_READ_POINTER, (uint8_t *)&read_point, 1);          /* read fifo read point */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_WRITE_POINTER, (uint8_t *)&write_point, 1);        /* read fifo write point */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    if (write_point > read_point)                                                                                 /* check point */
    {
        l = write_point - read_point;                                                                             /* get length */
    }
    else
    {
        l = 32 + write_point - read_point;                                                                        /* get length */
    }
    *len = ((*len) > l) ? l : (*len);                                                                             /* set read length */
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);                      /* read mode config */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    mode = (max30105_mode_t)(prev & 0x7);                                                                         /* get mode */
    if (mode == MAX30105_MODE_RED)                                                                                /* check red mode */
    {
        k = 3;                                                                                                    /* 3 */
    }
    else if (mode == MAX30105_MODE_RED_IR)                                                                        /* check red && ir mode*/
    {
        k = 6;                                                                                                    /* 6 */
    }
    else if (mode == MAX30105_MODE_GREEN_RED_IR)                                                                  /* check red && ir && green mode */
    {
        k = 9;                                                                                                    /* 9 */
    }
    else
    {
        
       
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_DATA_REGISTER, buf, (*len) * k);           /* read fifo read point */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);                      /* read spo2 config */
    if (res != 0)                                                                                                 /* check result */
    {
        
       
        
    }
    prev = prev & 0x3;                                                                                            /* get config */
    if (prev == 0)                                                                                                /* if 0 */
    {
        bit = 3;                                                                                                  /* 15 bits */
    }
    else if (prev == 1)                                                                                           /* if 1 */
    {
        bit = 2;                                                                                                  /* 16 bits */
    }
    else if (prev == 2)                                                                                           /* if 2 */
    {
        bit = 1;                                                                                                  /* 17 bits */
    }
    else                                                                                                          /* if 3 */
    {
        bit = 0;                                                                                                  /* 18 bits */
    }
    for (i = 0; i < (*len); i++)                                                                                  /* copy data */
    {
        if (mode == MAX30105_MODE_RED)                                                                            /* check red mode */
        {
            raw_red[i] = ((uint32_t)buf[i * 3 + 0] << 16) |                                               /* get raw red data */
                         ((uint32_t)buf[i * 3 + 1] << 8) |                                                /* get raw red data */
                         ((uint32_t)buf[i * 3 + 2] << 0);                                                 /* get raw red data */
            raw_red[i] = raw_red[i] >> bit;                                                                       /* right shift bit */
        }
        else if (mode == MAX30105_MODE_RED_IR)                                                                    /* check red && ir mode*/
        {
            raw_red[i] = ((uint32_t)buf[i * 6 + 0] << 16) |                                               /* get raw red data */
                         ((uint32_t)buf[i * 6 + 1] << 8) |                                                /* get raw red data */
                         ((uint32_t)buf[i * 6 + 2] << 0);                                                 /* get raw red data */
            raw_red[i] = raw_red[i] >> bit;                                                                       /* right shift bit */
            raw_ir[i] = ((uint32_t)buf[i * 6 + 3] << 16) |                                                /* get raw ir data */
                        ((uint32_t)buf[i * 6 + 4] << 8) |                                                 /* get raw ir data */
                        ((uint32_t)buf[i * 6 + 5] << 0);                                                  /* get raw ir data */
            raw_ir[i] = raw_ir[i] >> bit;                                                                         /* right shift bit */
        }
        else
        {
            raw_red[i] = ((uint32_t)buf[i * 9 + 0] << 16) |                                               /* get raw red data */
                         ((uint32_t)buf[i * 9 + 1] << 8) |                                                /* get raw red data */
                         ((uint32_t)buf[i * 9 + 2] << 0);                                                 /* get raw red data */
            raw_red[i] = raw_red[i] >> bit;                                                                       /* right shift bit */
            raw_ir[i] = ((uint32_t)buf[i * 9 + 3] << 16) |                                                /* get raw ir data */
                        ((uint32_t)buf[i * 9 + 4] << 8) |                                                 /* get raw ir data */
                        ((uint32_t)buf[i * 9 + 5] << 0);                                                  /* get raw ir data */
            raw_ir[i] = raw_ir[i] >> bit;                                                                         /* right shift bit */
            raw_green[i] = ((uint32_t)buf[i * 9 + 6] << 16) |                                             /* get raw green data */
                           ((uint32_t)buf[i * 9 + 7] << 8) |                                              /* get raw green data */
                           ((uint32_t)buf[i * 9 + 8] << 0);                                               /* get raw green data */
            raw_green[i] = raw_green[i] >> bit;                                                                   /* right shift bit */
        }
    }
    return r;                                                                                                     /* success return 0 */
}
uint8_t max30105_read_temperature(max30105_handle_t *handle, uint16_t *raw, float *temp)
{
    uint8_t res;
    uint8_t prev;
    uint16_t timeout;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_2, (uint8_t *)&prev, 1);            /* read interrupt enable2 */
    if (res != 0)                                                                                              /* check result */
    {
        
       
        
    }
    if ((prev & (1 << 1)) == 0)                                                                                /* check config */
    {
        prev &= ~(1 << 1);                                                                                     /* clear interrupt */
        prev |= 1 << 1;                                                                                        /* set interrupt */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_2, (uint8_t *)&prev, 1);       /* write interrupt enable2 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_CONFIG, (uint8_t *)&prev, 1);               /* read die temp config */
    if (res != 0)                                                                                              /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 0);                                                                                         /* clear config */
    prev |= (1 << 0);                                                                                          /* set bool */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_CONFIG, (uint8_t *)&prev, 1);              /* write die temp config */
    if (res != 0)                                                                                              /* check result */
    {
        
       
        
    }
    timeout = 5000;                                                                                            /* set 5000 ms */
    finished_flag = 0;                                                                                 /* clear finished flag */
    while (timeout != 0)                                                                                       /* timeout */
    {
        delay_ms(1);                                                                                   /* delay 1 ms */
        timeout--;                                                                                             /* timeout */
        if (finished_flag != 0)                                                                        /* check finished flag */
        {
            break;                                                                                             /* break */
        }
    }
    if (timeout == 0)                                                                                          /* check timeout */
    {
        
       
        
    }
    *raw = raw;                                                                                        /* get raw */
    *temp = temperature;                                                                               /* get temperature */
    return 0;                                                                                                  /* success return 0 */
}
uint8_t max30105_get_interrupt_status(max30105_handle_t *handle, max30105_interrupt_status_t status, max30105_bool_t *enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (status == MAX30105_INTERRUPT_STATUS_DIE_TEMP_RDY)                                                      /* if die temp ready status */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_STATUS_2, (uint8_t *)&prev, 1);        /* read interrupt status2 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        *enable = (max30105_bool_t)((prev >> status) & 0x01);                                                  /* get bool */
        return 0;                                                                                              /* success return 0 */
    }
    else
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_STATUS_1, (uint8_t *)&prev, 1);        /* read interrupt status1 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        *enable = (max30105_bool_t)((prev >> status) & 0x01);                                                  /* get bool */
        return 0;                                                                                              /* success return 0 */
    }
}
uint8_t max30105_set_interrupt(max30105_handle_t *handle, max30105_interrupt_t type, max30105_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (type == MAX30105_INTERRUPT_DIE_TEMP_RDY_EN)                                                            /* if internal temperature enable */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_2, (uint8_t *)&prev, 1);        /* read interrupt enable2 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        prev &= ~(1 << type);                                                                                  /* clear interrupt */
        prev |= enable << type;                                                                                /* set interrupt */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_2, (uint8_t *)&prev, 1);       /* write interrupt enable2 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        
        return 0;                                                                                              /* success return 0 */
    }
    else
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_1, (uint8_t *)&prev, 1);        /* read interrupt enable1 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        prev &= ~(1 << type);                                                                                  /* clear interrupt */
        prev |= enable << type;                                                                                /* set interrupt */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_1, (uint8_t *)&prev, 1);       /* write interrupt enable1 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        return 0;                                                                                              /* success return 0 */
    }
}
uint8_t max30105_get_interrupt(max30105_handle_t *handle, max30105_interrupt_t type, max30105_bool_t *enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (type == MAX30105_INTERRUPT_DIE_TEMP_RDY_EN)                                                            /* if internal temperature enable */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_2, (uint8_t *)&prev, 1);        /* read interrupt enable2 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        *enable = (max30105_bool_t)((prev >> type) & 0x01);                                                    /* get bool */
        return 0;                                                                                              /* success return 0 */
    }
    else
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_INTERRUPT_ENABLE_1, (uint8_t *)&prev, 1);        /* read interrupt enable1 */
        if (res != 0)                                                                                          /* check result */
        {
            
           
            
        }
        *enable = (max30105_bool_t)((prev >> type) & 0x01);                                                    /* get bool */
        return 0;                                                                                              /* success return 0 */
    }
}
uint8_t max30105_set_fifo_write_pointer(max30105_handle_t *handle, uint8_t pointer)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (pointer > 0x1F)                                                                                     /* check pointer */
    {
        
       
        
    }
    prev = pointer & 0x1F;                                                                                  /* set pointer */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_WRITE_POINTER, (uint8_t *)&prev, 1);        /* write fifo write pointer */
    if (res != 0)                                                                                           /* check result */
    {
        
       
        
    }
    return 0;                                                                                               /* success return 0 */
}
uint8_t max30105_get_fifo_write_pointer(max30105_handle_t *handle, uint8_t *pointer)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_WRITE_POINTER, (uint8_t *)&prev, 1);        /* read fifo write pointer */
    if (res != 0)                                                                                          /* check result */
    {
        
       
        
    }
    *pointer = prev & 0x1F;                                                                                /* get pointer */
    return 0;                                                                                              /* success return 0 */
}
uint8_t max30105_set_fifo_overflow_counter(max30105_handle_t *handle, uint8_t counter)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (counter > 0x1F)                                                                                   /* check counter */
    {
        
       
        
    }
    prev = counter & 0x1F;                                                                                /* set counter */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_OVERFLOW_COUNTER, (uint8_t *)&prev, 1);        /* set fifo overflow counter */
    if (res != 0)                                                                                         /* check result */
    {
        
       
        
    }
    return 0;                                                                                             /* success return 0 */
}
uint8_t max30105_get_fifo_overflow_counter(max30105_handle_t *handle, uint8_t *counter)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_OVERFLOW_COUNTER, (uint8_t *)&prev, 1);        /* get fifo overflow counter */
    if (res != 0)                                                                                        /* check result */
    {
        
       
        
    }
    *counter = prev & 0x1F;                                                                              /* get pointer */
    return 0;                                                                                            /* success return 0 */
}
uint8_t max30105_set_fifo_read_pointer(max30105_handle_t *handle, uint8_t pointer)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (pointer > 0x1F)                                                                                    /* check pointer */
    {
        
       
        
    }
    prev = pointer & 0x1F;                                                                                 /* set pointer */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_READ_POINTER, (uint8_t *)&prev, 1);        /* write fifo read pointer */
    if (res != 0)                                                                                          /* check result */
    {
        
       
        
    }
    return 0;                                                                                              /* success return 0 */
}
uint8_t max30105_get_fifo_read_pointer(max30105_handle_t *handle, uint8_t *pointer)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_READ_POINTER, (uint8_t *)&prev, 1);        /* read fifo read pointer */
    if (res != 0)                                                                                         /* check result */
    {
        
       
        
    }
    *pointer = prev & 0x1F;                                                                               /* get pointer */
    return 0;                                                                                             /* success return 0 */
}
uint8_t max30105_set_fifo_data(max30105_handle_t *handle, uint8_t data)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_DATA_REGISTER, (uint8_t *)&data, 1);        /* write fifo data register */
    if (res != 0)                                                                                           /* check result */
    {
        
       
        
    }
    return 0;                                                                                               /* success return 0 */
}
uint8_t max30105_get_fifo_data(max30105_handle_t *handle, uint8_t *data)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_DATA_REGISTER, (uint8_t *)data, 1);        /* read fifo data register */
    if (res != 0)                                                                                         /* check result */
    {
        
       
        
    }
    return 0;                                                                                             /* success return 0 */
}
uint8_t max30105_set_fifo_sample_averaging(max30105_handle_t *handle, max30105_sample_averaging_t sample)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);         /* read fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(0x7 << 5);                                                                             /* clear config */
    prev |= sample << 5;                                                                             /* set sample */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);        /* write fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_fifo_sample_averaging(max30105_handle_t *handle, max30105_sample_averaging_t *sample)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);         /* read fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *sample = (max30105_sample_averaging_t)(0x7 & (prev >> 5));                                      /* get sample averaging */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_fifo_roll(max30105_handle_t *handle, max30105_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);         /* read fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(0x1 << 4);                                                                             /* clear config */
    prev |= enable << 4;                                                                             /* set enable */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);        /* write fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_fifo_roll(max30105_handle_t *handle, max30105_bool_t *enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);         /* read fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *enable = (max30105_bool_t)(0x1 & (prev >> 4));                                                  /* get bool */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_fifo_almost_full(max30105_handle_t *handle, uint8_t value)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (value > 0xF)                                                                                 /* check value */
    {
        
       
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);         /* read fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(0xF << 0);                                                                             /* clear config */
    prev |= value << 0;                                                                              /* set value */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);        /* write fifo config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_fifo_almost_full(max30105_handle_t *handle, uint8_t *value)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_FIFO_CONFIG, (uint8_t *)&prev, 1);        /* read fifo config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    *value = prev & 0xF;                                                                            /* get value */
    return 0;                                                                                       /* success return 0 */
}
uint8_t max30105_set_shutdown(max30105_handle_t *handle, max30105_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 7);                                                                               /* clear config */
    prev |= enable << 7;                                                                             /* set bool */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);        /* write mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_shutdown(max30105_handle_t *handle, max30105_bool_t *enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *enable = (max30105_bool_t)((prev >> 7) & 0x01);                                                 /* get bool */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_reset(max30105_handle_t *handle)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 6);                                                                               /* clear config */
    prev |= 1 << 6;                                                                                  /* set 1 */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);        /* write mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_mode(max30105_handle_t *handle, max30105_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(7 << 0);                                                                               /* clear config */
    prev |= mode << 0;                                                                               /* set mode */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);        /* write mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_mode(max30105_handle_t *handle, max30105_mode_t *mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MODE_CONFIG, (uint8_t *)&prev, 1);         /* read mode config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *mode = (max30105_mode_t)(prev & 0x7);                                                           /* get mode */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_particle_sensing_adc_range(max30105_handle_t *handle, max30105_particle_sensing_adc_range_t range)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);         /* read spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(3 << 5);                                                                               /* clear config */
    prev |= range << 5;                                                                              /* set range */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);        /* write spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_particle_sensing_adc_range(max30105_handle_t *handle, max30105_particle_sensing_adc_range_t *range)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);         /* read spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *range = (max30105_particle_sensing_adc_range_t)((prev >> 5) & 0x3);                             /* get range */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_particle_sensing_sample_rate(max30105_handle_t *handle, max30105_particle_sensing_sample_rate_t rate)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);         /* read spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(7 << 2);                                                                               /* clear config */
    prev |= rate << 2;                                                                               /* set sample rate */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);        /* write spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_particle_sensing_sample_rate(max30105_handle_t *handle, max30105_particle_sensing_sample_rate_t *rate)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);        /* read spo2 config */
    if (res != 0)                                                                                   /* check result */
    {
        
       
        
    }
    *rate = (max30105_particle_sensing_sample_rate_t)((prev >> 2) & 0x7);                           /* get sample rate */
    return 0;                                                                                       /* success return 0 */
}
uint8_t max30105_set_adc_resolution(max30105_handle_t *handle, max30105_adc_resolution_t resolution)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);         /* read spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    prev &= ~(3 << 0);                                                                               /* clear config */
    prev |= resolution << 0;                                                                         /* set adc resolution */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);        /* write spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_get_adc_resolution(max30105_handle_t *handle, max30105_adc_resolution_t *resolution)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_SPO2_CONFIG, (uint8_t *)&prev, 1);         /* read spo2 config */
    if (res != 0)                                                                                    /* check result */
    {
        
       
        
    }
    *resolution = (max30105_adc_resolution_t)((prev >> 0) & 0x3);                                    /* set adc resolution */
    return 0;                                                                                        /* success return 0 */
}
uint8_t max30105_set_led_red_pulse_amplitude(max30105_handle_t *handle, uint8_t amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_LED_1_PA, (uint8_t *)&amp, 1);        /* write led 1 pa*/
    if (res != 0)                                                                                /* check result */
    {
        
       
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t max30105_get_led_red_pulse_amplitude(max30105_handle_t *handle, uint8_t *amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_LED_1_PA, (uint8_t *)amp, 1);        /* read led 1 pa */
    if (res != 0)                                                                              /* check result */
    {
        
       
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t max30105_set_led_ir_pulse_amplitude(max30105_handle_t *handle, uint8_t amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_LED_2_PA, (uint8_t *)&amp, 1);        /* write led 2 pa */
    if (res != 0)                                                                                /* check result */
    {
        
       
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t max30105_get_led_ir_pulse_amplitude(max30105_handle_t *handle, uint8_t *amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_LED_2_PA, (uint8_t *)amp, 1);        /* read led 2 pa */
    if (res != 0)                                                                              /* check result */
    {
        
       
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t max30105_set_led_green_pulse_amplitude(max30105_handle_t *handle, uint8_t amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_LED_3_PA, (uint8_t *)&amp, 1);        /* write led 3 pa */
    if (res != 0)                                                                                /* check result */
    {
        
       
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t max30105_get_led_green_pulse_amplitude(max30105_handle_t *handle, uint8_t *amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_LED_3_PA, (uint8_t *)amp, 1);        /* read led 3 pa */
    if (res != 0)                                                                              /* check result */
    {
        
       
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t max30105_set_led_proximity_pulse_amplitude(max30105_handle_t *handle, uint8_t amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_PILOT_PA, (uint8_t *)&amp, 1);        /* write led proximity pa */
    if (res != 0)                                                                                /* check result */
    {
        
       
        
    }
    return 0;                                                                                    /* success return 0 */
}
uint8_t max30105_get_led_proximity_pulse_amplitude(max30105_handle_t *handle, uint8_t *amp)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_PILOT_PA, (uint8_t *)amp, 1);        /* read led proximity pa */
    if (res != 0)                                                                              /* check result */
    {
        
       
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t max30105_set_slot(max30105_handle_t *handle, max30105_slot_t slot, max30105_led_t led)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (slot == MAX30105_SLOT_1)                                                                                     /* slot 1 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        prev &= ~(0x7 << 0);                                                                                         /* clear config */
        prev |= led << 0;                                                                                            /* set led */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);       /* write led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_2)                                                                                /* slot 2 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        prev &= ~(0x7 << 4);                                                                                         /* clear config */
        prev |= led << 4;                                                                                            /* set led */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);       /* write led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_3)                                                                                /* slot 3 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        prev &= ~(0x7 << 0);                                                                                         /* clear config */
        prev |= led << 0;                                                                                            /* set led */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);       /* write led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_4)                                                                                /* slot 4 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        prev &= ~(0x7 << 4);                                                                                         /* clear config */
        prev |= led << 4;                                                                                            /* set led */
        res = iic_write(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);       /* write led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        
        return 0;                                                                                                    /* success return 0 */
    }
    else                                                                                                             /* unknown */
    {
        
       
        
    }
}
uint8_t max30105_get_slot(max30105_handle_t *handle, max30105_slot_t slot, max30105_led_t *led)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    if (slot == MAX30105_SLOT_1)                                                                                     /* slot 1 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        *led = (max30105_led_t)((prev >> 0) & 0x7);                                                                  /* get led */
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_2)                                                                                /* slot 2 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_1, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        *led = (max30105_led_t)((prev >> 4) & 0x7);                                                                  /* get led */
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_3)                                                                                /* slot 3 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        *led = (max30105_led_t)((prev >> 0) & 0x7);                                                                  /* get led */
        
        return 0;                                                                                                    /* success return 0 */
    }
    else if (slot == MAX30105_SLOT_4)                                                                                /* slot 4 */
    {
        res = iic_read(MAX30105_ADDRESS, MAX30105_REG_MULTI_LED_MODE_CONTROL_2, (uint8_t *)&prev, 1);        /* read led slot */
        if (res != 0)                                                                                                /* check result */
        {
            
           
            
        }
        *led = (max30105_led_t)((prev >> 4) & 0x7);                                                                  /* get led */
        
        return 0;                                                                                                    /* success return 0 */
    }
    else                                                                                                             /* unknown */
    {
        
       
        
    }
}
uint8_t max30105_set_die_temperature(max30105_handle_t *handle, max30105_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_CONFIG, (uint8_t *)&prev, 1);         /* read die temp config */
    if (res != 0)                                                                                        /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 0);                                                                                   /* clear config */
    prev |= (enable << 0);                                                                               /* set bool */
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_CONFIG, (uint8_t *)&prev, 1);        /* write die temp config */
    if (res != 0)                                                                                        /* check result */
    {
        
       
        
    }
    return 0;                                                                                            /* success return 0 */
}
uint8_t max30105_get_die_temperature(max30105_handle_t *handle, max30105_bool_t *enable)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_DIE_TEMP_CONFIG, (uint8_t *)&prev, 1);         /* read die temp config */
    if (res != 0)                                                                                        /* check result */
    {
        
       
        
    }
    *enable = (max30105_bool_t)((prev >> 0) & 0x1);                                                      /* get bool */
    return 0;                                                                                            /* success return 0 */
}
uint8_t max30105_set_proximity_interrupt_threshold(max30105_handle_t *handle, uint8_t threshold)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_write(MAX30105_ADDRESS, MAX30105_REG_PROX_INT_THRESH, (uint8_t *)&threshold, 1);        /* write proximity interrupt threshold */
    if (res != 0)                                                                                             /* check result */
    {
        
       
        
    }
    return 0;                                                                                                 /* success return 0 */
}
uint8_t max30105_get_proximity_interrupt_threshold(max30105_handle_t *handle, uint8_t *threshold)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_PROX_INT_THRESH, (uint8_t *)threshold, 1);        /* read proximity interrupt threshold */
    if (res != 0)                                                                                           /* check result */
    {
        
       
        
    }
    return 0;                                                                                               /* success return 0 */
}
uint8_t max30105_proximity_threshold_convert_to_register(max30105_handle_t *handle, uint32_t adc, uint8_t *reg)
{
    
    {
        
    }
    
    {
        
    }
    *reg = (uint8_t)(adc / 1023);   /* convert real data to register data */
    return 0;                       /* success return 0 */
}
uint8_t max30105_proximity_threshold_convert_to_data(max30105_handle_t *handle, uint8_t reg, uint32_t *adc)
{
    
    {
        
    }
    
    {
        
    }
    *adc = (uint32_t)(reg * 1023);  /* convert raw data to real data */
    return 0;                       /* success return 0 */
}
uint8_t max30105_get_id(max30105_handle_t *handle, uint8_t *revision_id, uint8_t *part_id)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_REVISION_ID, (uint8_t *)revision_id, 1);        /* read revision id */
    if (res != 0)                                                                                         /* check result */
    {
        
       
        
    }
    res = iic_read(MAX30105_ADDRESS, MAX30105_REG_PART_ID, (uint8_t *)part_id, 1);                /* read part id */
    if (res != 0)                                                                                         /* check result */
    {
        
       
        
    }
    return 0;                                                                                             /* success return 0 */
}
uint8_t max30105_set_reg(max30105_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    if (iic_write(MAX30105_ADDRESS, reg, buf, len) != 0)   /* write data */
    {
        
    }
    else
    {
        return 0;                                                  /* success return 0 */
    }
}
uint8_t max30105_get_reg(max30105_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    if (iic_read(MAX30105_ADDRESS, reg, buf, len) != 0)   /* read data */
    {
        
    }
    else
    {
        return 0;                                                 /* success return 0 */
    }
}
uint8_t max30105_info(max30105_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(max30105_info_t));                       /* initialize max30105 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
