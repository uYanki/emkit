
#ifndef DRIVER_MLX90614_REGISTER_TEST_H
#define DRIVER_MLX90614_REGISTER_TEST_H
#include "driver_mlx90614_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mlx90614_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
