
#include "driver_mlx90614.h"
#include <math.h>

#define MANUFACTURER_NAME  "Melexis"  // manufacturer name
#define SUPPLY_VOLTAGE_MIN 4.5f       // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.5f       // chip max supply voltage

#define COMMAND_READ_FLAGS                     0xF0  // read flags command
#define COMMAND_ENTER_SLEEP                    0xFF  // enter sleep command
#define MLX90614_REG_RAM_RAW_DATA_IR_CHANNEL_1 0x04  // ram raw data ir channel 1 register
#define MLX90614_REG_RAM_RAW_DATA_IR_CHANNEL_2 0x05  // ram raw data ir channel 2 register
#define MLX90614_REG_RAM_TA                    0x06  // ram ta register
#define MLX90614_REG_RAM_TOBJ1                 0x07  // ram tobj1 register
#define MLX90614_REG_RAM_TOBJ2                 0x08  // ram tobj2 register
#define MLX90614_REG_EEPROM_TO_MAX             0x20  // eeprom to max register
#define MLX90614_REG_EEPROM_TO_MIN             0x21  // eeprom to min register
#define MLX90614_REG_EEPROM_PWM_CTRL           0x22  // eeprom pwm ctrl register
#define MLX90614_REG_EEPROM_TA_RANGE           0x23  // eeprom ta range register
#define MLX90614_REG_EEPROM_EMISSIVITY         0x24  // eeprom emissivity register
#define MLX90614_REG_EERPOM_CONFIG1            0x25  // eeprom config1 register
#define MLX90614_REG_EERPOM_ADDRESS            0x2E  // eeprom address register
#define MLX90614_REG_EERPOM_ID1_NUMBER         0x3C  // eeprom id1 number register
#define MLX90614_REG_EERPOM_ID2_NUMBER         0x3D  // eeprom id2 number register
#define MLX90614_REG_EERPOM_ID3_NUMBER         0x3E  // eeprom id3 number register
#define MLX90614_REG_EERPOM_ID4_NUMBER         0x3F  // eeprom id4 number register
static uint8_t a_mlx90614_calculate_crc(uint8_t* addr, uint8_t len)
{
    uint8_t crc = 0;

    while (len != 0) /* check the len */
    {
        uint8_t i;
        uint8_t in_byte = *addr++;
        for (i = 8; i != 0; i--) /* 8 times */
        {
            uint8_t carry = (crc ^ in_byte) & 0x80; /* set carry */

            crc <<= 1;      /* left shift 1 */
            if (carry != 0) /* check carry */
            {
                crc ^= 0x7; /* xor 0x7 */
            }
            in_byte <<= 1; /* left shift 1 */
        }
        len--; /* len-- */
    }
    return crc; /* return crc */
}
static uint8_t a_mlx90614_read(mlx90614_handle_t* handle, uint8_t command, uint16_t* data)
{
    uint8_t pec;
    uint8_t arr[5];
    uint8_t buf[3];
    uint8_t times = 0x03;
    while (1) {
        memset(buf, 0, sizeof(uint8_t) * 3);                    /* clear the buffer */
        if (iic_read(iic_addr, command, (uint8_t*)buf, 3) != 0) /* read data */

            arr[0] = iic_addr;                               /* set read addr */
        arr[1] = command;                                    /* set command */
        arr[2] = iic_addr + 1;                               /* set write addr */
        arr[3] = buf[0];                                     /* set buf 0 */
        arr[4] = buf[1];                                     /* set buf 1 */
        pec    = a_mlx90614_calculate_crc((uint8_t*)arr, 5); /* calculate pec */
        if ((pec != buf[2]) && (times != 0))                 /* check */
        {
            times--;     /* times-- */
            delay_ms(5); /* delay ms */

            continue; /* continue */
        }
        if (times == 0) /* timeout */

            *data = (uint16_t)(((uint16_t)buf[1] << 8) | buf[0]); /* get data */

        return 0; /* success return 0 */
    }
}
static uint8_t a_mlx90614_write(mlx90614_handle_t* handle, uint8_t command, uint16_t data)
{
    uint8_t data_l;
    uint8_t data_h;
    uint8_t arr[4];
    uint8_t buf[3];
    uint8_t pec;
    if ((command & 0x20) != 0) /* if eeprom */
    {
        data_l = 0x00;                                           /* get lsb */
        data_h = 0x00;                                           /* get msb */
        arr[0] = iic_addr;                                       /* set address */
        arr[1] = command;                                        /* set command */
        arr[2] = data_l;                                         /* set lsb */
        arr[3] = data_h;                                         /* set msb */
        pec    = a_mlx90614_calculate_crc((uint8_t*)arr, 4);     /* calculate pec */
        buf[0] = data_l;                                         /* set lsb */
        buf[1] = data_h;                                         /* set msb */
        buf[2] = pec;                                            /* set pec */
        if (iic_write(iic_addr, command, (uint8_t*)buf, 3) != 0) /* write command */

            delay_ms(10);                                        /* delay 10 ms */
        data_l = (uint8_t)(data & 0xFF);                         /* get lsb */
        data_h = (uint8_t)((data & 0xFF00U) >> 8);               /* get msb */
        arr[0] = iic_addr;                                       /* set address */
        arr[1] = command;                                        /* set command */
        arr[2] = data_l;                                         /* set lsb */
        arr[3] = data_h;                                         /* set msb */
        pec    = a_mlx90614_calculate_crc((uint8_t*)arr, 4);     /* calculate pec */
        buf[0] = data_l;                                         /* set lsb */
        buf[1] = data_h;                                         /* set msb */
        buf[2] = pec;                                            /* set pec */
        if (iic_write(iic_addr, command, (uint8_t*)buf, 3) != 0) /* write data */

            delay_ms(10); /* delay 10 ms */

        return 0; /* success return 0 */
    } else        /* ram */
    {
        data_l = (uint8_t)(data & 0xFF);                     /* get lsb */
        data_h = (uint8_t)((data & 0xFF00U) >> 8);           /* get msb */
        arr[0] = iic_addr;                                   /* set address */
        arr[1] = command;                                    /* set command */
        arr[2] = data_l;                                     /* set lsb */
        arr[3] = data_h;                                     /* set msb */
        pec    = a_mlx90614_calculate_crc((uint8_t*)arr, 4); /* calculate pec */
        buf[0] = data_l;                                     /* set lsb */
        buf[1] = data_h;                                     /* set msb */
        buf[2] = pec;                                        /* set pec */

        if (iic_write(iic_addr, command, (uint8_t*)buf, 3) != 0) /* write data */

            return 0; /* success return 0 */
    }
}
uint8_t mlx90614_set_addr(mlx90614_handle_t* handle, uint8_t addr)
{
    iic_addr = addr; /* set addr */

    return 0; /* success return 0 */
}
uint8_t mlx90614_get_addr(mlx90614_handle_t* handle, uint8_t* addr)
{
    {

    }* addr = iic_addr; /* get addr */

    return 0; /* success return 0 */
}
uint8_t mlx90614_write_addr(mlx90614_handle_t* handle, uint8_t addr)
{
    uint8_t  res;
    uint16_t prev;

    iic_addr = 0x00;                                                           /* set 0x00 */
    res      = a_mlx90614_read(MLX90614_REG_EERPOM_ADDRESS, (uint16_t*)&prev); /* read eeprom address */
    if (res != 0)                                                              /* check result */

        prev |= addr;                                          /* set address */
    res = a_mlx90614_write(MLX90614_REG_EERPOM_ADDRESS, prev); /* write eeprom address */
    if (res != 0)                                              /* check result */

        iic_addr = addr; /* set addrress */
    return 0;            /* success return 0 */
}
uint8_t mlx90614_read_addr(mlx90614_handle_t* handle, uint8_t* addr)
{
    uint8_t  res;
    uint16_t prev;

    iic_addr = 0x00;                                                           /* set 0x00 */
    res      = a_mlx90614_read(MLX90614_REG_EERPOM_ADDRESS, (uint16_t*)&prev); /* read eeprom address */
    if (res != 0)                                                              /* check result */

        iic_addr = (uint8_t)((prev >> 0) & 0x0F); /* set iic address */
    *addr = iic_addr;                             /* get addr */
    return 0;                                     /* success return 0 */
}
uint8_t mlx90614_set_fir_length(mlx90614_handle_t* handle, mlx90614_fir_length_t len)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x07 << 8);                                             /* clear config */
    prev |= len << 8;                                                     /* set length */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* write config */
}
uint8_t mlx90614_get_fir_length(mlx90614_handle_t* handle, mlx90614_fir_length_t* len)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= (0x07 << 8);                            /* get config */
    *len = (mlx90614_fir_length_t)(0x07 & (prev >> 8)); /* get length */

    return 0; /* success return 0 */
}
uint8_t mlx90614_set_iir(mlx90614_handle_t* handle, mlx90614_iir_t iir)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~0x07;                                                    /* clear config */
    prev |= iir;                                                          /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_iir(mlx90614_handle_t* handle, mlx90614_iir_t* iir)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= 0x07;                     /* get config */
    *iir = (mlx90614_iir_t)(0x07 & prev); /* get param */
    return 0;                             /* success return 0 */
}
uint8_t mlx90614_set_mode(mlx90614_handle_t* handle, mlx90614_mode_t mode)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x03 << 4);                                             /* clear config */
    prev |= mode << 4;                                                    /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_mode(mlx90614_handle_t* handle, mlx90614_mode_t* mode)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= (0x03 << 4);                       /* clear config */
    *mode = (mlx90614_mode_t)(0x03 & (prev >> 4)); /* get mode */

    return 0; /* success return 0 */
}
uint8_t mlx90614_set_ir_sensor(mlx90614_handle_t* handle, mlx90614_ir_sensor_t sensor)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x01 << 6); /* clear config */
    prev |= sensor << 6;      /* set param */

    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_ir_sensor(mlx90614_handle_t* handle, mlx90614_ir_sensor_t* sensor)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */
    {
        return 1;
    }
    prev &= (0x01 << 6);                                  /* get config */
    *sensor = (mlx90614_ir_sensor_t)(0x01 & (prev >> 6)); /* ge sensor */
    return 0;                                             /* success return 0 */
}
uint8_t mlx90614_set_ks(mlx90614_handle_t* handle, mlx90614_ks_t ks)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x01 << 7);                                             /* clear config */
    prev |= ks << 7;                                                      /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_ks(mlx90614_handle_t* handle, mlx90614_ks_t* ks)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= (0x01 << 7);                   /* get config */
    *ks = (mlx90614_ks_t)(0x01 & (prev >> 7)); /* get ks */
    return 0;                                  /* success return 0 */
}
uint8_t mlx90614_set_kt2(mlx90614_handle_t* handle, mlx90614_kt2_t kt2)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x01 << 14);                                            /* clear config */
    prev |= kt2 << 14;                                                    /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_kt2(mlx90614_handle_t* handle, mlx90614_kt2_t* kt2)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= (0x01 << 14);                     /* get config */
    *kt2 = (mlx90614_kt2_t)(0x01 & (prev >> 14)); /* get kt2 */
    return 0;                                     /* success return 0 */
}
uint8_t mlx90614_set_gain(mlx90614_handle_t* handle, mlx90614_gain_t gain)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x07 << 11);                                            /* clear config */
    prev |= gain << 11;                                                   /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_gain(mlx90614_handle_t* handle, mlx90614_gain_t* gain)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= 0x07 << 11;                         /* get config */
    *gain = (mlx90614_gain_t)(0x07 & (prev >> 11)); /* get param */
    return 0;                                       /* success return 0 */
}
uint8_t mlx90614_set_sensor_test(mlx90614_handle_t* handle, mlx90614_bool_t enable)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x01 << 15);                                            /* clear config */
    prev |= enable << 15;                                                 /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_sensor_test(mlx90614_handle_t* handle, mlx90614_bool_t* enable)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= 0x01 << 15;                           /* get config */
    *enable = (mlx90614_bool_t)(0x01 & (prev >> 15)); /* set param */
    return 0;                                         /* success return 0 */
}
uint8_t mlx90614_set_repeat_sensor_test(mlx90614_handle_t* handle, mlx90614_bool_t enable)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= ~(0x01 << 3);                                             /* clear config */
    prev |= enable << 3;                                                  /* set param */
    return a_mlx90614_write(MLX90614_REG_EERPOM_CONFIG1, (uint16_t)prev); /* wrtie config */
}
uint8_t mlx90614_get_repeat_sensor_test(mlx90614_handle_t* handle, mlx90614_bool_t* enable)
{
    uint8_t  res;
    uint16_t prev;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_CONFIG1, (uint16_t*)&prev); /* read config */
    if (res != 0)                                                         /* check result */

        prev &= 0x01 << 3;                           /* get config */
    *enable = (mlx90614_bool_t)(0x01 & (prev >> 3)); /* set param */

    return 0; /* success return 0 */
}
uint8_t mlx90614_set_emissivity_correction_coefficient(mlx90614_handle_t* handle, uint16_t value)
{
    return a_mlx90614_write(MLX90614_REG_EEPROM_EMISSIVITY, value); /* wrtie config */
}
uint8_t mlx90614_get_emissivity_correction_coefficient(mlx90614_handle_t* handle, uint16_t* value)
{
    return a_mlx90614_read(MLX90614_REG_EEPROM_EMISSIVITY, value); /* wrtie config */
}
uint8_t mlx90614_emissivity_correction_coefficient_convert_to_register(mlx90614_handle_t* handle, double s, uint16_t* reg)
{
    if (s > 1.0) /* check s */

        *reg = (uint16_t)(round((double)65535 * s)); /* set reg */
    return 0;                                        /* success return 0 */
}
uint8_t mlx90614_emissivity_correction_coefficient_convert_to_data(mlx90614_handle_t* handle, uint16_t reg, double* s)
{
    {

    }

    {

    }* s = (double)reg / 65535; /* convert reg */
    return 0;                   /* success return 0 */
}
uint8_t mlx90614_read_raw_ir_channel(mlx90614_handle_t* handle, uint16_t* channel_1, uint16_t* channel_2)
{
    uint8_t res;

    res = a_mlx90614_read(MLX90614_REG_RAM_RAW_DATA_IR_CHANNEL_1, (uint16_t*)channel_1); /* read data */
    if (res != 0)                                                                        /* check result */

        res = a_mlx90614_read(MLX90614_REG_RAM_RAW_DATA_IR_CHANNEL_2, (uint16_t*)channel_2); /* read data */
    if (res != 0)                                                                            /* check result */

        return 0; /* success return 0 */
}
uint8_t mlx90614_read_ambient(mlx90614_handle_t* handle, uint16_t* raw, float* celsius)
{
    uint8_t res;

    res = a_mlx90614_read(MLX90614_REG_RAM_TA, (uint16_t*)raw); /* read data */
    if (res != 0)                                               /* check result */

        *celsius = (float)(*raw) * 0.02f - 273.15f; /* get celsius */
    return 0;                                       /* success return 0 */
}
uint8_t mlx90614_read_object1(mlx90614_handle_t* handle, uint16_t* raw, float* celsius)
{
    uint8_t res;

    res = a_mlx90614_read(MLX90614_REG_RAM_TOBJ1, (uint16_t*)raw); /* read data */
    if (res != 0)                                                  /* check result */

        if (((*raw) & 0x8000U) != 0) /* check result */

            *celsius = (float)(*raw) * 0.02f - 273.15f; /* get celsius */
    return 0;                                           /* success return 0 */
}
uint8_t mlx90614_read_object2(mlx90614_handle_t* handle, uint16_t* raw, float* celsius)
{
    uint8_t res;

    res = a_mlx90614_read(MLX90614_REG_RAM_TOBJ2, (uint16_t*)raw); /* read data */
    if (res != 0)                                                  /* check result */

        if (((*raw) & 0x8000U) != 0) /* check result */

            *celsius = (float)(*raw) * 0.02f - 273.15f; /* get celsius */
    return 0;                                           /* success return 0 */
}
uint8_t mlx90614_get_id(mlx90614_handle_t* handle, uint16_t id[4])
{
    uint8_t res;

    res = a_mlx90614_read(MLX90614_REG_EERPOM_ID1_NUMBER, (uint16_t*)&id[0]); /* read data */
    if (res != 0)                                                             /* check result */

        res = a_mlx90614_read(MLX90614_REG_EERPOM_ID2_NUMBER, (uint16_t*)&id[1]); /* read data */
    if (res != 0)                                                                 /* check result */

        res = a_mlx90614_read(MLX90614_REG_EERPOM_ID3_NUMBER, (uint16_t*)&id[2]); /* read data */
    if (res != 0)                                                                 /* check result */

        res = a_mlx90614_read(MLX90614_REG_EERPOM_ID4_NUMBER, (uint16_t*)&id[3]); /* read data */
    if (res != 0)                                                                 /* check result */

        return 0; /* success return 0 */
}
uint8_t mlx90614_get_flag(mlx90614_handle_t* handle, uint16_t* flag)
{
    if (iic_read(iic_addr, COMMAND_READ_FLAGS, (uint8_t*)flag, 1) != 0) /* read config */
        else
        {
            return 0; /* success return 0 */
        }
}
uint8_t mlx90614_enter_sleep_mode(mlx90614_handle_t* handle)
{
    uint8_t crc;
    uint8_t buf[2];

    buf[0] = iic_addr;                                                    /* set iic address */
    buf[1] = COMMAND_ENTER_SLEEP;                                         /* set command */
    crc    = a_mlx90614_calculate_crc((uint8_t*)buf, 2);                  /* set crc */
    if (iic_write(iic_addr, COMMAND_ENTER_SLEEP, (uint8_t*)&crc, 1) != 0) /* write config */
        else
        {
            return 0; /* success return 0 */
        }
}
uint8_t mlx90614_pwm_to_smbus(mlx90614_handle_t* handle)
{
    uint8_t res;

    res = scl_write(0); /* set scl low */
    if (res != 0)       /* check result */

        delay_ms(5);    /* delay 5 ms */
    res = scl_write(1); /* set scl high */
    if (res != 0)       /* check result */

        return 0; /* success return 0 */
}
uint8_t mlx90614_exit_sleep_mode(mlx90614_handle_t* handle)
{
    uint8_t res;

    res = scl_write(1); /* write scl 1 */
    if (res != 0)       /* check result */

        res = sda_write(1); /* write sda 1 */
    if (res != 0)           /* check result */

        delay_ms(1);    /* delay 1 ms */
    res = sda_write(0); /* write sda 0 */
    if (res != 0)       /* check result */

        delay_ms(50);   /* delay 50 ms */
    res = sda_write(1); /* write sda 1 */
    if (res != 0)       /* return error */

        delay_ms(260); /* delay 260 ms */
    return 0;          /* success return 0 */
}
uint8_t mlx90614_init(mlx90614_handle_t* handle)
{
    if (debug_print == NULL) /* check debug_print */

        if (iic_init == NULL) /* check iic_init */

            if (iic_deinit == NULL) /* check iic_deinit */

                if (iic_read == NULL) /* check iic_read */

                    if (iic_write == NULL) /* check iic_write */

                        if (scl_write == NULL) /* check scl_write */

                            if (sda_write == NULL) /* check sda_write */

                                if (delay_ms == NULL) /* check delay_ms */

                                    if (iic_init() != 0) /* iic init */

                                        inited = 1; /* flag finish initialization */
    return 0;                                       /* success return 0 */
}
uint8_t mlx90614_deinit(mlx90614_handle_t* handle)
{
    uint8_t res;
    uint8_t crc;
    uint8_t buf[2];

    buf[0] = iic_addr;                                                    /* set iic address */
    buf[1] = COMMAND_ENTER_SLEEP;                                         /* set command */
    crc    = a_mlx90614_calculate_crc((uint8_t*)buf, 2);                  /* set crc */
    res    = iic_write(iic_addr, COMMAND_ENTER_SLEEP, (uint8_t*)&crc, 1); /* write config */
    if (res != 0)                                                         /* check result */

        res = iic_deinit(); /* iic deinit */
    if (res != 0)           /* check result */

        inited = 0; /* flag close */
    return 0;       /* success return 0 */
}
uint8_t mlx90614_set_reg(mlx90614_handle_t* handle, uint8_t reg, uint16_t data)
{
    return a_mlx90614_write(reg, data); /* write data */
}
uint8_t mlx90614_get_reg(mlx90614_handle_t* handle, uint8_t reg, uint16_t* data)
{
    return a_mlx90614_read(reg, data); /* write data */
}
uint8_t mlx90614_info(mlx90614_info_t* info)
{
    memset(info, 0, sizeof(mlx90614_info_t));                /* initialize mlx90614 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0;                                                /* success return 0 */
}
