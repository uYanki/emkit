
#include "driver_mlx90614_basic.h"
static mlx90614_handle_t gs_handle;        // mlx90614 handle
uint8_t mlx90614_basic_init(void)
{
    uint8_t res;
    /* link interface function */
    DRIVER_MLX90614_LINK_INIT(&gs_handle, mlx90614_handle_t);
    DRIVER_MLX90614_LINK_IIC_INIT(&gs_handle, mlx90614_interface_iic_init);
    DRIVER_MLX90614_LINK_IIC_DEINIT(&gs_handle, mlx90614_interface_iic_deinit);
    DRIVER_MLX90614_LINK_IIC_READ(&gs_handle, mlx90614_interface_iic_read);
    DRIVER_MLX90614_LINK_IIC_WRITE(&gs_handle, mlx90614_interface_iic_write);
    DRIVER_MLX90614_LINK_SCL_WRITE(&gs_handle, mlx90614_interface_scl_write);
    DRIVER_MLX90614_LINK_SDA_WRITE(&gs_handle, mlx90614_interface_sda_write);
    DRIVER_MLX90614_LINK_DELAY_MS(&gs_handle, mlx90614_interface_delay_ms);
    DRIVER_MLX90614_LINK_DEBUG_PRINT(&gs_handle, mlx90614_interface_debug_print);
    /* set address */
    res = mlx90614_set_addr(&gs_handle, MLX90614_ADDRESS_DEFAULT);
    if (res != 0)
    {
        mlx90614_interface_debug_print("mlx90614: set addr failed.\n");
        
        return 1;
    }
    /* mlx90614 init */
    res = mlx90614_init(&gs_handle);
    if (res != 0)
    {
        mlx90614_interface_debug_print("mlx90614: init failed.\n");
        
        return 1;
    }
    /* pwm to smbus */
    res = mlx90614_pwm_to_smbus(&gs_handle);
    if (res != 0)
    {
        mlx90614_interface_debug_print("mlx90614: pwm to smbus failed.\n");
        (void)mlx90614_deinit(&gs_handle);
        
        return 1;
    }
    /* exit sleep mode */
    res = mlx90614_exit_sleep_mode(&gs_handle);
    if (res != 0)
    {
        mlx90614_interface_debug_print("mlx90614: exit sleep mode failed.\n");
        (void)mlx90614_deinit(&gs_handle);
        
        return 1;
    }
    return 0;
}
uint8_t mlx90614_basic_deinit(void)
{
    uint8_t res;
    /* deinit */
    res = mlx90614_deinit(&gs_handle);
    if (res != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t mlx90614_basic_read(float *ambient, float *object)
{
    uint8_t res;
    uint16_t raw;
    /* read ambient */
    res = mlx90614_read_ambient(&gs_handle, (uint16_t *)&raw, ambient);
    if (res != 0)
    {
        return 1;
    }
    /* read object1 */
    res = mlx90614_read_object1(&gs_handle, (uint16_t *)&raw, object);
    if (res != 0)
    {
        return 1;
    }
    return 0;
}
