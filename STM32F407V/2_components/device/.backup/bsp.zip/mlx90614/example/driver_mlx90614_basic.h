
#ifndef DRIVER_MLX90614_BASIC_H
#define DRIVER_MLX90614_BASIC_H
#include "driver_mlx90614_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mlx90614_basic_init(void);
uint8_t mlx90614_basic_deinit(void);
uint8_t mlx90614_basic_read(float *ambient, float *object);
#ifdef __cplusplus
}
#endif
#endif
