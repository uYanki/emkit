
#ifndef DRIVER_MLX90614_ADVANCE_H
#define DRIVER_MLX90614_ADVANCE_H
#include "driver_mlx90614_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MLX90614_ADVANCE_DEFAULT_FIR_LENGTH                               MLX90614_FIR_LENGTH_1024        // fir length 1024 
#define MLX90614_ADVANCE_DEFAULT_IIR                                      MLX90614_IIR_A1_1_B1_0          // iir a1 1 b1 0 
#define MLX90614_ADVANCE_DEFAULT_MODE                                     MLX90614_MODE_TA_TOBJ1          // ta tobj1 mode 
#define MLX90614_ADVANCE_DEFAULT_IR_SENSOR                                MLX90614_IR_SENSOR_DUAL         // dual ir sensor mode 
#define MLX90614_ADVANCE_DEFAULT_KS                                       MLX90614_KS_POSITIVE            // positive ks 
#define MLX90614_ADVANCE_DEFAULT_KT2                                      MLX90614_KT2_POSITIVE           // positive kt2 
#define MLX90614_ADVANCE_DEFAULT_GAIN                                     MLX90614_GAIN_100               // gain 100 
#define MLX90614_ADVANCE_DEFAULT_SENSOR_TEST                              MLX90614_BOOL_FALSE             // false 
#define MLX90614_ADVANCE_DEFAULT_REPEAT_SENSOR_TEST                       MLX90614_BOOL_FALSE             // false 
#define MLX90614_ADVANCE_DEFAULT_EMISSIVITY_CORRECTION_COEFFICIENT        1.0                             // 1.0 
uint8_t mlx90614_advance_init(void);
uint8_t mlx90614_advance_deinit(void);
uint8_t mlx90614_advance_enter_sleep(void);
uint8_t mlx90614_advance_exit_sleep(void);
uint8_t mlx90614_advance_read(float *ambient, float *object);
uint8_t mlx90614_advance_get_id(uint16_t id[4]);
#ifdef __cplusplus
}
#endif
#endif
