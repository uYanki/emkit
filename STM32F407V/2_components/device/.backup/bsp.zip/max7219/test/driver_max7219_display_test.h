
#ifndef DRIVER_MAX7219_DISPLAY_TEST_H
#define DRIVER_MAX7219_DISPLAY_TEST_H
#include "driver_max7219_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max7219_display_test(void);
#ifdef __cplusplus
}
#endif
#endif
