
#ifndef DRIVER_MAX7219_MATRIX_CASCADE_TEST_H
#define DRIVER_MAX7219_MATRIX_CASCADE_TEST_H
#include "driver_max7219_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define  MATRIX_CASCADE_TEST_LENGTH 4        // test cascade length 4 
uint8_t max7219_matrix_cascade_test(void);
#ifdef __cplusplus
}
#endif
#endif
