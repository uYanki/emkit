
#ifndef DRIVER_MAX7219_H
#define DRIVER_MAX7219_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
#ifndef MAX7219_MAX_CASCADE_SIZE
#define MAX7219_MAX_CASCADE_SIZE 128  // 128 cascade
#endif
typedef enum {
    MAX7219_SEGMENT_A  = (1 << 6),  // segment A
    MAX7219_SEGMENT_B  = (1 << 5),  // segment B
    MAX7219_SEGMENT_C  = (1 << 4),  // segment C
    MAX7219_SEGMENT_D  = (1 << 3),  // segment D
    MAX7219_SEGMENT_E  = (1 << 2),  // segment E
    MAX7219_SEGMENT_F  = (1 << 1),  // segment F
    MAX7219_SEGMENT_G  = (1 << 0),  // segment G
    MAX7219_SEGMENT_DP = (1 << 7),  // segment DP
} max7219_segment_t;
typedef enum {
    MAX7219_CODEB_FONT_0     = 0x00,  // code b font 0
    MAX7219_CODEB_FONT_1     = 0x01,  // code b font 1
    MAX7219_CODEB_FONT_2     = 0x02,  // code b font 2
    MAX7219_CODEB_FONT_3     = 0x03,  // code b font 3
    MAX7219_CODEB_FONT_4     = 0x04,  // code b font 4
    MAX7219_CODEB_FONT_5     = 0x05,  // code b font 5
    MAX7219_CODEB_FONT_6     = 0x06,  // code b font 6
    MAX7219_CODEB_FONT_7     = 0x07,  // code b font 7
    MAX7219_CODEB_FONT_8     = 0x08,  // code b font 8
    MAX7219_CODEB_FONT_9     = 0x09,  // code b font 9
    MAX7219_CODEB_FONT_LINE  = 0x0A,  // code b font line
    MAX7219_CODEB_FONT_E     = 0x0B,  // code b font e
    MAX7219_CODEB_FONT_H     = 0x0C,  // code b font h
    MAX7219_CODEB_FONT_L     = 0x0D,  // code b font l
    MAX7219_CODEB_FONT_P     = 0x0E,  // code b font p
    MAX7219_CODEB_FONT_BLACK = 0x0F,  // code b font black
} max7219_codeb_font_t;
typedef enum {
    MAX7219_NO_DECODE_FONT_0     = 0x7E,  // no decode font 0
    MAX7219_NO_DECODE_FONT_1     = 0x30,  // no decode font 1
    MAX7219_NO_DECODE_FONT_2     = 0x6D,  // no decode font 2
    MAX7219_NO_DECODE_FONT_3     = 0x79,  // no decode font 3
    MAX7219_NO_DECODE_FONT_4     = 0x33,  // no decode font 4
    MAX7219_NO_DECODE_FONT_5     = 0x5B,  // no decode font 5
    MAX7219_NO_DECODE_FONT_6     = 0x5F,  // no decode font 6
    MAX7219_NO_DECODE_FONT_7     = 0x70,  // no decode font 7
    MAX7219_NO_DECODE_FONT_8     = 0x7F,  // no decode font 8
    MAX7219_NO_DECODE_FONT_9     = 0x7B,  // no decode font 9
    MAX7219_NO_DECODE_FONT_LINE  = 0x01,  // no decode font line
    MAX7219_NO_DECODE_FONT_E     = 0x4F,  // no decode font e
    MAX7219_NO_DECODE_FONT_H     = 0x37,  // no decode font h
    MAX7219_NO_DECODE_FONT_L     = 0x0E,  // no decode font l
    MAX7219_NO_DECODE_FONT_P     = 0x67,  // no decode font p
    MAX7219_NO_DECODE_FONT_BLACK = 0x00,  // no decode font black
} max7219_no_decode_font_t;
typedef enum {
    MAX7219_SCAN_LIMIT_DIGIT_0_0 = 0x00,  // scan limit digit 0 - 0
    MAX7219_SCAN_LIMIT_DIGIT_0_1 = 0x01,  // scan limit digit 0 - 1
    MAX7219_SCAN_LIMIT_DIGIT_0_2 = 0x02,  // scan limit digit 0 - 2
    MAX7219_SCAN_LIMIT_DIGIT_0_3 = 0x03,  // scan limit digit 0 - 3
    MAX7219_SCAN_LIMIT_DIGIT_0_4 = 0x04,  // scan limit digit 0 - 4
    MAX7219_SCAN_LIMIT_DIGIT_0_5 = 0x05,  // scan limit digit 0 - 5
    MAX7219_SCAN_LIMIT_DIGIT_0_6 = 0x06,  // scan limit digit 0 - 6
    MAX7219_SCAN_LIMIT_DIGIT_0_7 = 0x07,  // scan limit digit 0 - 7
} max7219_scan_limit_t;
typedef enum {
    MAX7219_INTENSITY_1_32  = 0x00,  // intensity 1 / 32
    MAX7219_INTENSITY_3_32  = 0x01,  // intensity 3 / 32
    MAX7219_INTENSITY_5_32  = 0x02,  // intensity 5 / 32
    MAX7219_INTENSITY_7_32  = 0x03,  // intensity 7 / 32
    MAX7219_INTENSITY_9_32  = 0x04,  // intensity 9 / 32
    MAX7219_INTENSITY_11_32 = 0x05,  // intensity 11 / 32
    MAX7219_INTENSITY_13_32 = 0x06,  // intensity 13 / 32
    MAX7219_INTENSITY_15_32 = 0x07,  // intensity 15 / 32
    MAX7219_INTENSITY_17_32 = 0x08,  // intensity 17 / 32
    MAX7219_INTENSITY_19_32 = 0x09,  // intensity 19 / 32
    MAX7219_INTENSITY_21_32 = 0x0A,  // intensity 21 / 32
    MAX7219_INTENSITY_23_32 = 0x0B,  // intensity 23 / 32
    MAX7219_INTENSITY_25_32 = 0x0C,  // intensity 25 / 32
    MAX7219_INTENSITY_27_32 = 0x0D,  // intensity 27 / 32
    MAX7219_INTENSITY_29_32 = 0x0E,  // intensity 29 / 32
    MAX7219_INTENSITY_31_32 = 0x0F,  // intensity 31 / 32
} max7219_intensity_t;
typedef enum {
    MAX7219_MODE_SHUT_DOWN = 0x00,  // shut down mode
    MAX7219_MODE_NORMAL    = 0x01,  // normal mode
} max7219_mode_t;
typedef enum {
    MAX7219_DISPLAY_TEST_MODE_OFF = 0x00,  // test mode off
    MAX7219_DISPLAY_TEST_MODE_ON  = 0x01,  // test mode on
} max7219_display_test_mode_t;
typedef enum {
    MAX7219_DECODE_CODEB_DIGITS_NONE = 0x00,  // decode code b digits none
    MAX7219_DECODE_CODEB_DIGITS_0    = 0x01,  // decode code b digits 0
    MAX7219_DECODE_CODEB_DIGITS_3_0  = 0x0F,  // decode code b digits 3 - 0
    MAX7219_DECODE_CODEB_DIGITS_7_0  = 0xFF,  // decode code b digits 7 - 0
} max7219_decode_t;
typedef enum {
    MAX7219_DIGITAL_0 = 0x01,  // digital 0
    MAX7219_DIGITAL_1 = 0x02,  // digital 1
    MAX7219_DIGITAL_2 = 0x03,  // digital 2
    MAX7219_DIGITAL_3 = 0x04,  // digital 3
    MAX7219_DIGITAL_4 = 0x05,  // digital 4
    MAX7219_DIGITAL_5 = 0x06,  // digital 5
    MAX7219_DIGITAL_6 = 0x07,  // digital 6
    MAX7219_DIGITAL_7 = 0x08,  // digital 7
} max7219_digital_t;
typedef enum {
    MAX7219_CASCADE_COMMAND_CASCADE      = 0x00,  // cascade command
    MAX7219_CASCADE_COMMAND_DIGIT_0      = 0x01,  // digit 0 command
    MAX7219_CASCADE_COMMAND_DIGIT_1      = 0x02,  // digit 1 command
    MAX7219_CASCADE_COMMAND_DIGIT_2      = 0x03,  // digit 2 command
    MAX7219_CASCADE_COMMAND_DIGIT_3      = 0x04,  // digit 3 command
    MAX7219_CASCADE_COMMAND_DIGIT_4      = 0x05,  // digit 4 command
    MAX7219_CASCADE_COMMAND_DIGIT_5      = 0x06,  // digit 5 command
    MAX7219_CASCADE_COMMAND_DIGIT_6      = 0x07,  // digit 6 command
    MAX7219_CASCADE_COMMAND_DIGIT_7      = 0x08,  // digit 7 command
    MAX7219_CASCADE_COMMAND_DECODE       = 0x09,  // decode command
    MAX7219_CASCADE_COMMAND_INTENSITY    = 0x0A,  // intensity command
    MAX7219_CASCADE_COMMAND_SCAN_LIMIT   = 0x0B,  // scan limit command
    MAX7219_CASCADE_COMMAND_SHUT_DOWN    = 0x0C,  // shut down command
    MAX7219_CASCADE_COMMAND_DISPLAY_TEST = 0x0F,  // display test command
} max7219_cascade_command_t;
typedef struct max7219_cascade_s {
    max7219_cascade_command_t command;  // cascade command
    uint8_t                   data;     // cascade data
} max7219_cascade_t;
typedef struct max7219_handle_s {
    uint8_t buf[MAX7219_MAX_CASCADE_SIZE * 2];  // cascade buffer
    uint8_t inited;                             // inited flag
} max7219_handle_t;

uint8_t max7219_info(max7219_info_t* info);
uint8_t max7219_init(max7219_handle_t* handle);
uint8_t max7219_deinit(max7219_handle_t* handle);
uint8_t max7219_set_display(max7219_handle_t* handle, max7219_digital_t digital, uint8_t data);
uint8_t max7219_set_matrix(max7219_handle_t* handle, uint8_t matrix[8]);
uint8_t max7219_set_decode(max7219_handle_t* handle, max7219_decode_t decode);
uint8_t max7219_set_mode(max7219_handle_t* handle, max7219_mode_t mode);
uint8_t max7219_set_mode(max7219_handle_t* handle, max7219_mode_t mode);
uint8_t max7219_set_display_test_mode(max7219_handle_t* handle, max7219_display_test_mode_t mode);
uint8_t max7219_set_intensity(max7219_handle_t* handle, max7219_intensity_t intensity);
uint8_t max7219_set_scan_limit(max7219_handle_t* handle, max7219_scan_limit_t limit);
uint8_t max7219_set_cascade(max7219_handle_t* handle, max7219_cascade_t* cascade, uint16_t len);
uint8_t max7219_set_reg(max7219_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
