
  
#include "driver_max7219.h"

#define MANUFACTURER_NAME         "Maxim Integrated"                // manufacturer name
#define SUPPLY_VOLTAGE_MIN        4.0f                              // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f                              // chip max supply voltage




#define MAX7219_REG_DECODE              0x09        // decode register
#define MAX7219_REG_INTENSITY           0x0A        // intensity register
#define MAX7219_REG_SCAN_LIMIT          0x0B        // scan limit register
#define MAX7219_REG_SHUT_DOWN           0x0C        // shut down register
#define MAX7219_REG_DISPLAY_TEST        0x0F        // display test register
uint8_t max7219_set_display(max7219_handle_t *handle, max7219_digital_t digital, uint8_t data)
{
    uint8_t res;
    
    {
        
    }
    
    {
        
    }
    res = spi_write(digital, &data, 1);                 /* spi write data */
    if (res != 0)                                               /* check result */
    {
        
       
        
    }
    return 0;                                                   /* success return 0 */
}
uint8_t max7219_set_matrix(max7219_handle_t *handle, uint8_t matrix[8])
{
    uint8_t res;
    uint8_t i;
    
    {
        
    }
    
    {
        
    }
    for (i = 0; i < 8; i++)
    {
        res = spi_write(i + 1, &matrix[i], 1);              /* spi write data */
        if (res != 0)                                               /* check result */
        {
            
           
            
        }
    }
    return 0;                                                       /* success return 0 */
}
uint8_t max7219_set_cascade(max7219_handle_t *handle, max7219_cascade_t *cascade, uint16_t len)
{
    uint8_t res;
    uint16_t i;
    
    {
        
    }
    
    {
        
    }
    if (len > MAX7219_MAX_CASCADE_SIZE)                                                 /* check length */
    {
        
       
        
    }
    for (i = 0; i < len; i++)                                                           /* set buf */
    {
        buf[i * 2 + 0] = cascade[i].command;                                    /* set command */
        buf[i * 2 + 1] = cascade[i].data;                                       /* set data */
    }
    res = spi_write_cmd(buf, len * 2);                                  /* write command */
    if (res != 0)                                                                       /* check result */
    {
        
       
        
    }
    return 0;                                                                           /* success return 0 */
}
uint8_t max7219_set_decode(max7219_handle_t *handle, max7219_decode_t decode)
{
    uint8_t res;
    uint8_t d;
    
    {
        
    }
    
    {
        
    }
    d = (uint8_t)decode;                                                  /* set the decode */
    res = spi_write(MAX7219_REG_DECODE, (uint8_t *)&d, 1);        /* spi write data */
    if (res != 0)                                                         /* check result */
    {
        
       
        
    }
    return 0;                                                             /* success return 0 */
}
uint8_t max7219_set_mode(max7219_handle_t *handle, max7219_mode_t mode)
{
    uint8_t res;
    uint8_t m;
    
    {
        
    }
    
    {
        
    }
    m = (uint8_t)mode;                                                       /* set the mode */
    res = spi_write(MAX7219_REG_SHUT_DOWN, (uint8_t *)&m, 1);        /* spi write data */
    if (res != 0)                                                            /* check result */
    {
        
       
        
    }
    return 0;                                                                /* success return 0 */
}
uint8_t max7219_set_display_test_mode(max7219_handle_t *handle, max7219_display_test_mode_t mode)
{
    uint8_t res;
    uint8_t m;
    
    {
        
    }
    
    {
        
    }
    m = (uint8_t)mode;                                                          /* set the mode */
    res = spi_write(MAX7219_REG_DISPLAY_TEST, (uint8_t *)&m, 1);        /* spi write data */
    if (res != 0)                                                               /* check result */
    {
        
       
        
    }
    return 0;                                                                   /* success return 0 */
}
uint8_t max7219_set_intensity(max7219_handle_t *handle, max7219_intensity_t intensity)
{
    uint8_t res;
    uint8_t in;
    
    {
        
    }
    
    {
        
    }
    in = (uint8_t)intensity;                                                  /* set the intensity */
    res = spi_write(MAX7219_REG_INTENSITY, (uint8_t *)&in, 1);        /* spi write data */
    if (res != 0)                                                             /* check result */
    {
        
       
        
    }
    return 0;                                                                 /* success return 0 */
}
uint8_t max7219_set_scan_limit(max7219_handle_t *handle, max7219_scan_limit_t limit)
{
    uint8_t res;
    uint8_t l;
    
    {
        
    }
    
    {
        
    }
    l = (uint8_t)limit;                                                       /* set the limit */
    res = spi_write(MAX7219_REG_SCAN_LIMIT, (uint8_t *)&l, 1);        /* spi write data */
    if (res != 0)                                                             /* check result */
    {
        
       
        
    }
    return 0;                                                                 /* success return 0 */
}
uint8_t max7219_init(max7219_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                     /* check debug_print */
    {
        
    }
    if (spi_init == NULL)                                        /* check spi_init */
    {
        
       
        
    }
    if (spi_deinit == NULL)                                      /* check spi_deinit */
    {
        
       
        
    }
    if (spi_write_cmd == NULL)                                   /* check spi_write_cmd */
    {
        
       
        
    }
    if (spi_write == NULL)                                       /* check spi_write */
    {
        
       
        
    }
    if (delay_ms == NULL)                                        /* check delay_ms */
    {
        
       
        
    }
    if (spi_init() != 0)                                         /* spi init */
    {
        
       
        
    }
    inited = 1;                                                  /* flag finish initialization */
    return 0;                                                            /* success return 0 */
}
uint8_t max7219_deinit(max7219_handle_t *handle)
{
    uint8_t res;
    uint8_t mode = (uint8_t)MAX7219_MODE_SHUT_DOWN;
    
    {
        
    }
    
    {
        
    }
    res = spi_write(MAX7219_REG_SHUT_DOWN, (uint8_t *)&mode, 1);        /* spi write data */
    if (res != 0)                                                               /* check result */
    {
        
       
        
    }
    res = spi_deinit();                                                 /* spi deinit */
    if (res != 0)                                                               /* check result */
    {
        
       
        
    }
    inited = 0;                                                         /* flag close */
    return 0;                                                                   /* success return 0 */
}
uint8_t max7219_set_reg(max7219_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
    if (spi_write(reg, buf, len) != 0)        /* write data */
    {
        
    }
    else
    {
        return 0;                                     /* success return 0 */
    }
}
uint8_t max7219_info(max7219_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(max7219_info_t));                        /* initialize max7219 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "SPI", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
