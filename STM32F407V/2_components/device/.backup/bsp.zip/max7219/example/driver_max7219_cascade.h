
#ifndef DRIVER_MAX7219_CASCADE_H
#define DRIVER_MAX7219_CASCADE_H
#include "driver_max7219_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define  MATRIX_CASCADE_LENGTH 4        // cascade 4 
#define MAX7219_CASCADE_DEFAULT_DECODE           MAX7219_DECODE_CODEB_DIGITS_NONE        // set no decode 
#define MAX7219_CASCADE_DEFAULT_MODE             MAX7219_MODE_NORMAL                     // set normal mode 
#define MAX7219_CASCADE_DEFAULT_TEST_MODE        MAX7219_DISPLAY_TEST_MODE_OFF           // set test mode off 
#define MAX7219_CASCADE_DEFAULT_INTENSITY        MAX7219_INTENSITY_31_32                 // set intensity 31/32 
#define MAX7219_CASCADE_DEFAULT_SCAN_LIMIT       MAX7219_SCAN_LIMIT_DIGIT_0_7            // set scan limit digit 0-7 
extern uint8_t g_matrix[MATRIX_CASCADE_LENGTH][8];        // global matrix 
uint8_t max7219_cascade_init(void);
uint8_t max7219_cascade_deinit(void);
uint8_t max7219_cascade_update(void);
#ifdef __cplusplus
}
#endif
#endif
