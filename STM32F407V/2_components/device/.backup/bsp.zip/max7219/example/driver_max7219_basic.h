
#ifndef DRIVER_MAX7219_BASIC_H
#define DRIVER_MAX7219_BASIC_H
#include "driver_max7219_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define MAX7219_BASIC_DEFAULT_DECODE           MAX7219_DECODE_CODEB_DIGITS_NONE        // set no decode 
#define MAX7219_BASIC_DEFAULT_MODE             MAX7219_MODE_NORMAL                     // set normal mode 
#define MAX7219_BASIC_DEFAULT_TEST_MODE        MAX7219_DISPLAY_TEST_MODE_OFF           // set test mode off 
#define MAX7219_BASIC_DEFAULT_INTENSITY        MAX7219_INTENSITY_31_32                 // set intensity 31/32 
#define MAX7219_BASIC_DEFAULT_SCAN_LIMIT       MAX7219_SCAN_LIMIT_DIGIT_0_7            // set scan limit digit 0-7 
uint8_t max7219_basic_init(void);
uint8_t max7219_basic_deinit(void);
uint8_t max7219_basic_set_matrix(uint8_t matrix[8]);
uint8_t max7219_basic_set_display(max7219_digital_t digital, uint8_t data);
#ifdef __cplusplus
}
#endif
#endif
