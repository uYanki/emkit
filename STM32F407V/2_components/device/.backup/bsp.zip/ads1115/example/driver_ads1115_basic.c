
#include "driver_ads1115_basic.h"
static ads1115_handle_t gs_handle;  // ads1115 handle
uint8_t                 ads1115_basic_init(ads1115_address_t addr, ads1115_channel_t channel)
{
    uint8_t res;
    /* link interface function */
    DRIVER_ADS1115_LINK_INIT(&gs_handle, ads1115_handle_t);
    DRIVER_ADS1115_LINK_IIC_INIT(&gs_handle, ads1115_interface_iic_init);
    DRIVER_ADS1115_LINK_IIC_DEINIT(&gs_handle, ads1115_interface_iic_deinit);
    DRIVER_ADS1115_LINK_IIC_READ(&gs_handle, ads1115_interface_iic_read);
    DRIVER_ADS1115_LINK_IIC_WRITE(&gs_handle, ads1115_interface_iic_write);
    DRIVER_ADS1115_LINK_DELAY_MS(&gs_handle, ads1115_interface_delay_ms);
    DRIVER_ADS1115_LINK_DEBUG_PRINT(&gs_handle, ads1115_interface_debug_print);
    /* set addr pin */
    res = ads1115_set_addr_pin(&gs_handle, addr);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: set addr failed.\n");
        return 1;
    }
    /* ads1115 init */
    res = ads1115_init(&gs_handle);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: init failed.\n");
        return 1;
    }
    /* set channel */
    res = ads1115_set_channel(&gs_handle, channel);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: set channel failed.\n");
        (void)ads1115_deinit(&gs_handle);
        return 1;
    }
    /* set default range */
    res = ads1115_set_range(&gs_handle, ADS1115_BASIC_DEFAULT_RANGE);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: set range failed.\n");
        (void)ads1115_deinit(&gs_handle);
        return 1;
    }
    /* set default rate */
    res = ads1115_set_rate(&gs_handle, ADS1115_BASIC_DEFAULT_RATE);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: set rate failed.\n");
        (void)ads1115_deinit(&gs_handle);
        return 1;
    }
    /* disable compare */
    res = ads1115_set_compare(&gs_handle, ADS1115_BOOL_FALSE);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: set compare failed.\n");
        (void)ads1115_deinit(&gs_handle);
        return 1;
    }
    /* start continuous read */
    res = ads1115_start_continuous_read(&gs_handle);
    if (res != 0) {
        ads1115_interface_debug_print("ads1115: start continus read mode failed.\n");
        (void)ads1115_deinit(&gs_handle);
        return 1;
    }
    return 0;
}
uint8_t ads1115_basic_read(float* s)
{
    int16_t raw;
    /* read data */
    if (ads1115_continuous_read(&gs_handle, (int16_t*)&raw, s) != 0) {
        return 1;
    } else {
        return 0;
    }
}
uint8_t ads1115_basic_deinit(void)
{
    uint8_t res;
    /* stop continuous read */
    res = ads1115_stop_continuous_read(&gs_handle);
    if (res != 0) {
        return 1;
    }
    /* deinit ads1115 */
    res = ads1115_deinit(&gs_handle);
    if (res != 0) {
        return 1;
    }
    return 0;
}
