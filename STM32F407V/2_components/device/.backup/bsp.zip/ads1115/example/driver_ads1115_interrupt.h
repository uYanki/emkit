
#ifndef DRIVER_ADS1115_INTERRUPT_H
#define DRIVER_ADS1115_INTERRUPT_H
#include "driver_ads1115_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define ADS1115_INTERRUPT_DEFAULT_RANGE                   ADS1115_RANGE_6P144V                // range 6.144V 
#define ADS1115_INTERRUPT_DEFAULT_ALERT_PIN               ADS1115_PIN_LOW                     // pin low 
#define ADS1115_INTERRUPT_DEFAULT_RATE                    ADS1115_RATE_128SPS                 // 128 SPS 
#define ADS1115_INTERRUPT_DEFAULT_COMPARATOR_QUEUE        ADS1115_COMPARATOR_QUEUE_2_CONV     // 2 conv 
uint8_t ads1115_interrupt_init(ads1115_address_t addr, ads1115_channel_t channel, ads1115_compare_t compare, 
                               float f_high_threshold, float f_low_threshold);
uint8_t ads1115_interrupt_read(float *s);
uint8_t ads1115_interrupt_deinit(void);
#ifdef __cplusplus
}
#endif
#endif
