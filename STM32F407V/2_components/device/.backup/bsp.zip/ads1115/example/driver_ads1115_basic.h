
#ifndef DRIVER_ADS1115_BASIC_H
#define DRIVER_ADS1115_BASIC_H
#include "driver_ads1115_interface.h"
#ifdef __cplusplus
extern "C" {
#endif
#define ADS1115_BASIC_DEFAULT_RANGE ADS1115_RANGE_6P144V  // set range 6.144V
#define ADS1115_BASIC_DEFAULT_RATE  ADS1115_RATE_128SPS   // set 128 SPS
uint8_t ads1115_basic_init(ads1115_address_t addr, ads1115_channel_t channel);
uint8_t ads1115_basic_read(float* s);
uint8_t ads1115_basic_deinit(void);
#ifdef __cplusplus
}
#endif
#endif
