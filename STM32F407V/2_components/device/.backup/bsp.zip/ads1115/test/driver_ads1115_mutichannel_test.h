
#ifndef DRIVER_ADS1115_MUTICHANNEL_TEST_H
#define DRIVER_ADS1115_MUTICHANNEL_TEST_H
#include "driver_ads1115_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ads1115_multichannel_test(ads1115_address_t addr, ads1115_channel_t channel, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
