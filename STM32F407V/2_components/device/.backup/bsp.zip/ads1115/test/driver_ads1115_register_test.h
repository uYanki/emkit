
#ifndef DRIVER_ADS1115_REGISTER_TEST_H
#define DRIVER_ADS1115_REGISTER_TEST_H
#include "driver_ads1115_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ads1115_register_test(ads1115_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
