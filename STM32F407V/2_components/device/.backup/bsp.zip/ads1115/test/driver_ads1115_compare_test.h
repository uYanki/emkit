
#ifndef DRIVER_ADS1115_COMPARE_TEST_H
#define DRIVER_ADS1115_COMPARE_TEST_H
#include "driver_ads1115_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ads1115_compare_test(ads1115_address_t addr, ads1115_channel_t channel, ads1115_compare_t compare, 
                             float f_high_threshold, float f_low_threshold, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
