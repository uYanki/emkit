
#ifndef DRIVER_ADS1115_READ_TEST_H
#define DRIVER_ADS1115_READ_TEST_H
#ifdef __cplusplus
extern "C"{
#endif
#include "driver_ads1115_interface.h"
uint8_t ads1115_read_test(ads1115_address_t addr, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
