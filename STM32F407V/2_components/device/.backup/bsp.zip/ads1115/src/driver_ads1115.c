
#include "driver_ads1115.h"

#define MANUFACTURER_NAME  "Texas Instruments"  // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.0f                 // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.5f                 // chip max supply voltage

#define ADS1115_REG_CONVERT  0x00         // adc result register
#define ADS1115_REG_CONFIG   0x01         // chip config register
#define ADS1115_REG_LOWRESH  0x02         // interrupt low threshold register
#define ADS1115_REG_HIGHRESH 0x03         // interrupt high threshold register
#define ADS1115_ADDRESS1     (0x48 << 1)  // iic address 1
#define ADS1115_ADDRESS2     (0x49 << 1)  // iic address 2
#define ADS1115_ADDRESS3     (0x4A << 1)  // iic address 3
#define ADS1115_ADDRESS4     (0x4B << 1)  // iic address 4
static uint8_t a_ads1115_iic_multiple_read(uint8_t reg, int16_t* data)
{
    uint8_t buf[2];
    memset(buf, 0, sizeof(uint8_t) * 2);                /* clear the buffer */
    if (iic_read(iic_addr, reg, (uint8_t*)buf, 2) == 0) /* read data */
    {
        *data = (uint16_t)(((uint16_t)buf[0] << 8) | buf[1]); /* set data */

        return 0; /* success return 0 */
    } else {
    }
}
static uint8_t a_ads1115_iic_multiple_write(uint8_t reg, uint16_t data)
{
    uint8_t buf[2];

    buf[0] = (data >> 8) & 0xFF;                         /* set MSB */
    buf[1] = data & 0xFF;                                /* set LSB */
    if (iic_write(iic_addr, reg, (uint8_t*)buf, 2) != 0) /* write data */
        else
        {
            return 0; /* success return 0 */
        }
}
uint8_t ads1115_init(ads1115_handle_t* handle)
{
    if (debug_print == NULL) /* check debug_print */

        if (iic_init == NULL) /* check iic_init */

            if (iic_deinit == NULL) /* check iic_deinit */

                if (iic_read == NULL) /* check iic_read */

                    if (iic_write == NULL) /* check iic_write */

                        if (delay_ms == NULL) /* check delay_ms */

                            if (iic_init() != 0) /* iic init */

                                inited = 1; /* flag inited */
    return 0;                               /* success return 0 */
}
uint8_t ads1115_deinit(ads1115_handle_t* handle)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x01 << 8);                                         /* clear bit */
    conf |= 1 << 8;                                               /* set stop continus read */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    res = iic_deinit(); /* close iic */

    inited = 0; /* flag close */
    return 0;   /* success return 0 */
}
uint8_t ads1115_set_channel(ads1115_channel_t channel)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x07 << 12);                                        /* clear channel */
    conf |= (channel & 0x07) << 12;                               /* set channel */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_channel(ads1115_channel_t* channel)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* channel = (ads1115_channel_t)((conf >> 12) & 0x07); /* get channel */
    return 0;                                              /* success return 0 */
}
uint8_t ads1115_set_range(ads1115_range_t range)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x07 << 9);                                         /* clear range */
    conf |= (range & 0x07) << 9;                                  /* set range */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_range(ads1115_range_t* range)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* range = (ads1115_range_t)((conf >> 9) & 0x07); /* get range */
    return 0;                                         /* success return 0 */
}
uint8_t ads1115_set_alert_pin(ads1115_pin_t pin)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(1 << 3);                                            /* clear alert pin */
    conf |= (pin & 0x01) << 3;                                    /* set alert pin */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_alert_pin(ads1115_pin_t* pin)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* pin = (ads1115_pin_t)((conf >> 3) & 0x01); /* get alert pin */
    return 0;                                     /* success return 0 */
}
uint8_t ads1115_set_compare_mode(ads1115_compare_t compare)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(1 << 4);                                            /* clear compare mode */
    conf |= (compare & 0x01) << 4;                                /* set compare mode */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_compare_mode(ads1115_compare_t* compare)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* compare = (ads1115_compare_t)((conf >> 4) & 0x01); /* get compare mode */
    return 0;                                             /* success return 0 */
}
uint8_t ads1115_set_rate(ads1115_rate_t rate)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x07 << 5);                                         /* clear rate */
    conf |= (rate & 0x07) << 5;                                   /* set rate */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return */
}
uint8_t ads1115_get_rate(ads1115_rate_t* rate)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* rate = (ads1115_rate_t)((conf >> 5) & 0x07); /* get rate */
    return 0;                                       /* success return 0 */
}
uint8_t ads1115_set_comparator_queue(ads1115_comparator_queue_t comparator_queue)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x03 << 0);                                         /* clear comparator queue */
    conf |= (comparator_queue & 0x03) << 0;                       /* set comparator queue */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_comparator_queue(ads1115_comparator_queue_t* comparator_queue)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* comparator_queue = (ads1115_comparator_queue_t)((conf >> 0) & 0x03); /* get comparator queue */
    return 0;                                                               /* success return 0 */
}
uint8_t ads1115_set_addr_pin(ads1115_address_t addr_pin)
{
    if (addr_pin == ADS1115_ADDR_GND) /* gnd */
    {
        iic_addr = ADS1115_ADDRESS1;         /* set address 1 */
    } else if (addr_pin == ADS1115_ADDR_VCC) /* vcc */
    {
        iic_addr = ADS1115_ADDRESS2;         /* set address 2 */
    } else if (addr_pin == ADS1115_ADDR_SDA) /* sda */
    {
        iic_addr = ADS1115_ADDRESS3;         /* set address 3 */
    } else if (addr_pin == ADS1115_ADDR_SCL) /* scl */
    {
        iic_addr = ADS1115_ADDRESS4; /* set address 4 */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_get_addr_pin(ads1115_address_t* addr_pin)
{
    if (iic_addr == ADS1115_ADDRESS1) /* if address 1 */
    {
        *addr_pin = ADS1115_ADDR_GND;        /* set gnd */
    } else if (iic_addr == ADS1115_ADDRESS2) /* if address 2 */
    {
        *addr_pin = ADS1115_ADDR_VCC;        /* set vcc */
    } else if (iic_addr == ADS1115_ADDRESS3) /* if address 3 */
    {
        *addr_pin = ADS1115_ADDR_SDA;        /* set sda */
    } else if (iic_addr == ADS1115_ADDRESS4) /* set address 4 */
    {
        *addr_pin = ADS1115_ADDR_SCL; /* set scl */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_single_read(int16_t* raw, float* v)
{
    uint8_t  res;
    uint8_t  range;
    uint16_t conf;
    uint32_t timeout = 500;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    range = (ads1115_range_t)((conf >> 9) & 0x07);                /* get range conif */
    conf &= ~(1 << 8);                                            /* clear bit */
    conf |= 1 << 8;                                               /* set single read */
    conf |= 1 << 15;                                              /* start single read */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    while (timeout != 0) /* check timeout */
    {
        delay_ms(8);                                                            /* wait 8 ms */
        res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

        if ((conf & (1 << 15)) == (1 << 15)) /* check finished */
        {
            break; /* break */
        }
        timeout--; /* timeout-- */
    }
    if (timeout == 0) /* check timeout */

        res = a_ads1115_iic_multiple_read(ADS1115_REG_CONVERT, raw); /* read data */

    if (range == ADS1115_RANGE_6P144V) /* if 6.144V */
    {
        *v = (float)(*raw) * 6.144f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_4P096V)   /* if 4.096V */
    {
        *v = (float)(*raw) * 4.096f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_2P048V)   /* if 2.048V */
    {
        *v = (float)(*raw) * 2.048f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_1P024V)   /* if 1.024V */
    {
        *v = (float)(*raw) * 1.024f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_0P512V)   /* if 0.512V */
    {
        *v = (float)(*raw) * 0.512f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_0P256V)   /* if 0.256V */
    {
        *v = (float)(*raw) * 0.256f / 32768.0f; /* get convert adc */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_continuous_read(int16_t* raw, float* v)
{
    uint8_t  res;
    uint8_t  range;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    range = (ads1115_range_t)((conf >> 9) & 0x07);                 /* get range conif */
    res   = a_ads1115_iic_multiple_read(ADS1115_REG_CONVERT, raw); /* read data */

    if (range == ADS1115_RANGE_6P144V) /* if 6.144V */
    {
        *v = (float)(*raw) * 6.144f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_4P096V)   /* if 4.096V */
    {
        *v = (float)(*raw) * 4.096f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_2P048V)   /* if 2.048V */
    {
        *v = (float)(*raw) * 2.048f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_1P024V)   /* if 1.024V */
    {
        *v = (float)(*raw) * 1.024f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_0P512V)   /* if 0.512V */
    {
        *v = (float)(*raw) * 0.512f / 32768.0f; /* get convert adc */
    } else if (range == ADS1115_RANGE_0P256V)   /* if 0.256V */
    {
        *v = (float)(*raw) * 0.256f / 32768.0f; /* get convert adc */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_start_continuous_read(ads1115_handle_t* handle)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x01 << 8);                                         /* set start continuous read */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_stop_continuous_read(ads1115_handle_t* handle)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x01 << 8);                                         /* clear bit */
    conf |= 1 << 8;                                               /* set stop continus read */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_set_compare(ads1115_bool_t enable)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    conf &= ~(0x01 << 2);                                         /* clear compare */
    conf |= enable << 2;                                          /* set compare */
    res = a_ads1115_iic_multiple_write(ADS1115_REG_CONFIG, conf); /* write config */

    return 0; /* success return 0 */
}
uint8_t ads1115_get_compare(ads1115_bool_t* enable)
{
    uint8_t  res;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    {

    }* enable = (ads1115_bool_t)((conf >> 2) & 0x01); /* get compare */
    return 0;                                         /* success return 0 */
}
uint8_t ads1115_set_compare_threshold(int16_t high_threshold, int16_t low_threshold)
{
    if (a_ads1115_iic_multiple_write(ADS1115_REG_HIGHRESH, high_threshold) != 0) /* write high threshold */

        if (a_ads1115_iic_multiple_write(ADS1115_REG_LOWRESH, low_threshold) != 0) /* write low threshold */

            return 0; /* success return 0 */
}
uint8_t ads1115_get_compare_threshold(int16_t* high_threshold, int16_t* low_threshold)
{
    if (a_ads1115_iic_multiple_read(ADS1115_REG_HIGHRESH, high_threshold) != 0) /* read high threshold */

        if (a_ads1115_iic_multiple_read(ADS1115_REG_LOWRESH, low_threshold) != 0) /* read low threshold */

            return 0; /* success return 0 */
}
uint8_t ads1115_convert_to_register(float s, int16_t* reg)
{
    uint8_t  res;
    uint8_t  range;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    range = (ads1115_range_t)((conf >> 9) & 0x07); /* get range conif */
    if (range == ADS1115_RANGE_6P144V)             /* if 6.144V */
    {
        *reg = (int16_t)(s * 32768.0f / 6.144f); /* convert to reg */
    } else if (range == ADS1115_RANGE_4P096V)    /* if 4.096V */
    {
        *reg = (int16_t)(s * 32768.0f / 4.096f); /* convert to reg */
    } else if (range == ADS1115_RANGE_2P048V)    /* if 2.048V */
    {
        *reg = (int16_t)(s * 32768.0f / 2.048f); /* convert to reg */
    } else if (range == ADS1115_RANGE_1P024V)    /* if 1.024V */
    {
        *reg = (int16_t)(s * 32768.0f / 1.024f); /* convert to reg */
    } else if (range == ADS1115_RANGE_0P512V)    /* if 0.512V */
    {
        *reg = (int16_t)(s * 32768.0f / 0.512f); /* convert to reg */
    } else if (range == ADS1115_RANGE_0P256V)    /* if 0.256V */
    {
        *reg = (int16_t)(s * 32768.0f / 0.256f); /* convert to reg */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_convert_to_data(int16_t reg, float* s)
{
    uint8_t  res;
    uint8_t  range;
    uint16_t conf;

    res = a_ads1115_iic_multiple_read(ADS1115_REG_CONFIG, (int16_t*)&conf); /* read config */

    range = (ads1115_range_t)((conf >> 9) & 0x07); /* get range conif */
    if (range == ADS1115_RANGE_6P144V)             /* if 6.144V */
    {
        *s = (float)(reg)*6.144f / 32768.0f;  /* convert to data */
    } else if (range == ADS1115_RANGE_4P096V) /* if 4.096V */
    {
        *s = (float)(reg)*4.096f / 32768.0f;  /* convert to data */
    } else if (range == ADS1115_RANGE_2P048V) /* if 2.048V */
    {
        *s = (float)(reg)*2.048f / 32768.0f;  /* convert to data */
    } else if (range == ADS1115_RANGE_1P024V) /* if 1.024V */
    {
        *s = (float)(reg)*1.024f / 32768.0f;  /* convert to data */
    } else if (range == ADS1115_RANGE_0P512V) /* if 0.512V */
    {
        *s = (float)(reg)*0.512f / 32768.0f;  /* convert to data */
    } else if (range == ADS1115_RANGE_0P256V) /* if 0.256V */
    {
        *s = (float)(reg)*0.256f / 32768.0f; /* convert to data */
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t ads1115_set_reg(uint8_t reg, int16_t value)
{
    return a_ads1115_iic_multiple_write(reg, value); /* write reg */
}
uint8_t ads1115_get_reg(uint8_t reg, int16_t* value)
{
    return a_ads1115_iic_multiple_read(reg, value); /* read reg */
}
uint8_t ads1115_info(ads1115_info_t* info)
{
    memset(info, 0, sizeof(ads1115_info_t));                 /* initialize ads1115 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0;                                                /* success return 0 */
}
