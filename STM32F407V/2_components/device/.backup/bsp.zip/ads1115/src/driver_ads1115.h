
#ifndef DRIVER_ADS1115_H
#define DRIVER_ADS1115_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    ADS1115_ADDR_GND = 0x00,  // ADDR pin connected to GND
    ADS1115_ADDR_VCC = 0x01,  // ADDR pin connected to VCC
    ADS1115_ADDR_SDA = 0x02,  // ADDR pin connected to SDA
    ADS1115_ADDR_SCL = 0x03,  // ADDR pin connected to SCL
} ads1115_address_t;
typedef enum {
    ADS1115_BOOL_FALSE = 0x00,  // disable function
    ADS1115_BOOL_TRUE  = 0x01,  // enable function
} ads1115_bool_t;
typedef enum {
    ADS1115_RANGE_6P144V = 0x00,  // 6.144V range
    ADS1115_RANGE_4P096V = 0x01,  // 4.096V range
    ADS1115_RANGE_2P048V = 0x02,  // 2.048V range
    ADS1115_RANGE_1P024V = 0x03,  // 1.024V range
    ADS1115_RANGE_0P512V = 0x04,  // 0.512V range
    ADS1115_RANGE_0P256V = 0x05,  // 0.256V range
} ads1115_range_t;
typedef enum {
    ADS1115_RATE_8SPS   = 0x00,  // 8 sample per second
    ADS1115_RATE_16SPS  = 0x01,  // 16 sample per second
    ADS1115_RATE_32SPS  = 0x02,  // 32 sample per second
    ADS1115_RATE_64SPS  = 0x03,  // 64 sample per second
    ADS1115_RATE_128SPS = 0x04,  // 128 sample per second
    ADS1115_RATE_250SPS = 0x05,  // 250 sample per second
    ADS1115_RATE_475SPS = 0x06,  // 475 sample per second
    ADS1115_RATE_860SPS = 0x07,  // 860 sample per second
} ads1115_rate_t;
typedef enum {
    ADS1115_CHANNEL_AIN0_AIN1 = 0x00,  // AIN0 and AIN1 pins
    ADS1115_CHANNEL_AIN0_AIN3 = 0x01,  // AIN0 and AIN3 pins
    ADS1115_CHANNEL_AIN1_AIN3 = 0x02,  // AIN1 and AIN3 pins
    ADS1115_CHANNEL_AIN2_AIN3 = 0x03,  // AIN2 and AIN3 pins
    ADS1115_CHANNEL_AIN0_GND  = 0x04,  // AIN0 and GND pins
    ADS1115_CHANNEL_AIN1_GND  = 0x05,  // AIN1 and GND pins
    ADS1115_CHANNEL_AIN2_GND  = 0x06,  // AIN2 and GND pins
    ADS1115_CHANNEL_AIN3_GND  = 0x07,  // AIN3 and GND pins
} ads1115_channel_t;
typedef enum {
    ADS1115_PIN_LOW  = 0x00,  // set pin low
    ADS1115_PIN_HIGH = 0x01,  // set pin high
} ads1115_pin_t;
typedef enum {
    ADS1115_COMPARE_THRESHOLD = 0x00,  // threshold compare interrupt mode
    ADS1115_COMPARE_WINDOW    = 0x01,  // window compare interrupt mode
} ads1115_compare_t;
typedef enum {
    ADS1115_COMPARATOR_QUEUE_1_CONV    = 0x00,  // comparator queue has 1 conv
    ADS1115_COMPARATOR_QUEUE_2_CONV    = 0x01,  // comparator queue has 2 conv
    ADS1115_COMPARATOR_QUEUE_4_CONV    = 0x02,  // comparator queue has 3 conv
    ADS1115_COMPARATOR_QUEUE_NONE_CONV = 0x03,  // comparator queue has no conv
} ads1115_comparator_queue_t;

uint8_t ads1115_info();
uint8_t ads1115_set_addr_pin(ads1115_address_t addr_pin);
uint8_t ads1115_get_addr_pin(ads1115_address_t* addr_pin);
uint8_t ads1115_init();
uint8_t ads1115_deinit();
uint8_t ads1115_single_read(int16_t* raw, float* v);
uint8_t ads1115_start_continuous_read();
uint8_t ads1115_stop_continuous_read();
uint8_t ads1115_continuous_read(int16_t* raw, float* v);
uint8_t ads1115_set_channel(ads1115_channel_t channel);
uint8_t ads1115_get_channel(ads1115_channel_t* channel);
uint8_t ads1115_set_range(ads1115_range_t range);
uint8_t ads1115_get_range(ads1115_range_t* range);
uint8_t ads1115_set_rate(ads1115_rate_t rate);
uint8_t ads1115_get_rate(ads1115_rate_t* rate);
uint8_t ads1115_set_alert_pin(ads1115_pin_t pin);
uint8_t ads1115_get_alert_pin(ads1115_pin_t* pin);
uint8_t ads1115_set_compare_mode(ads1115_compare_t compare);
uint8_t ads1115_get_compare_mode(ads1115_compare_t* compare);
uint8_t ads1115_set_comparator_queue(ads1115_comparator_queue_t comparator_queue);
uint8_t ads1115_get_comparator_queue(ads1115_comparator_queue_t* comparator_queue);
uint8_t ads1115_set_compare(ads1115_bool_t enable);
uint8_t ads1115_get_compare(ads1115_bool_t* enable);
uint8_t ads1115_set_compare_threshold(int16_t high_threshold, int16_t low_threshold);
uint8_t ads1115_get_compare_threshold(int16_t* high_threshold, int16_t* low_threshold);
uint8_t ads1115_convert_to_register(float s, int16_t* reg);
uint8_t ads1115_convert_to_data(int16_t reg, float* s);
uint8_t ads1115_set_reg(uint8_t reg, int16_t value);
uint8_t ads1115_get_reg(uint8_t reg, int16_t* value);
#ifdef __cplusplus
}
#endif
#endif
