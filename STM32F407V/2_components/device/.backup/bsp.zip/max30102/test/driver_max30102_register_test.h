
#ifndef DRIVER_MAX30102_REGISTER_TEST_H
#define DRIVER_MAX30102_REGISTER_TEST_H
#include "driver_max30102_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max30102_register_test(void);
#ifdef __cplusplus
}
#endif
#endif
