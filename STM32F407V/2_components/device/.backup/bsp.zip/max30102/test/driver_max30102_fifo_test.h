
#ifndef DRIVER_MAX30102_FIFO_TEST_H
#define DRIVER_MAX30102_FIFO_TEST_H
#include "driver_max30102_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t max30102_fifo_test_irq_handler(void);
uint8_t max30102_fifo_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
