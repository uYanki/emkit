
#ifndef DRIVER_MAX30102_H
#define DRIVER_MAX30102_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MAX30102_BOOL_FALSE = 0x00,  // false
    MAX30102_BOOL_TRUE  = 0x01,  // true
} max30102_bool_t;
typedef enum {
    MAX30102_SAMPLE_AVERAGING_1  = 0x00,  // no averaging
    MAX30102_SAMPLE_AVERAGING_2  = 0x01,  // averaging 2
    MAX30102_SAMPLE_AVERAGING_4  = 0x02,  // averaging 4
    MAX30102_SAMPLE_AVERAGING_8  = 0x03,  // averaging 8
    MAX30102_SAMPLE_AVERAGING_16 = 0x04,  // averaging 16
    MAX30102_SAMPLE_AVERAGING_32 = 0x05,  // averaging 32
} max30102_sample_averaging_t;
typedef enum {
    MAX30102_MODE_HEART_RATE = 0x02,  // heart rate mode
    MAX30102_MODE_SPO2       = 0x03,  // spo2 mode
    MAX30102_MODE_MULTI_LED  = 0x07,  // multi-led mode
} max30102_mode_t;
typedef enum {
    MAX30102_INTERRUPT_STATUS_FIFO_FULL    = 7,  // fifo almost full flag
    MAX30102_INTERRUPT_STATUS_PPG_RDY      = 6,  // new fifo data ready
    MAX30102_INTERRUPT_STATUS_ALC_OVF      = 5,  // ambient light cancellation overflow
    MAX30102_INTERRUPT_STATUS_PWR_RDY      = 0,  // power ready flag
    MAX30102_INTERRUPT_STATUS_DIE_TEMP_RDY = 1,  // internal temperature ready flag
} max30102_interrupt_status_t;
typedef enum {
    MAX30102_INTERRUPT_FIFO_FULL_EN    = 7,  // fifo almost full enable
    MAX30102_INTERRUPT_PPG_RDY_EN      = 6,  // new fifo data ready enable
    MAX30102_INTERRUPT_ALC_OVF_EN      = 5,  // ambient light cancellation overflow enable
    MAX30102_INTERRUPT_DIE_TEMP_RDY_EN = 1,  // internal temperature enable
} max30102_interrupt_t;
typedef enum {
    MAX30102_SPO2_ADC_RANGE_2048  = 0,  // range 2048
    MAX30102_SPO2_ADC_RANGE_4096  = 1,  // range 4096
    MAX30102_SPO2_ADC_RANGE_8192  = 2,  // range 8192
    MAX30102_SPO2_ADC_RANGE_16384 = 3,  // range 16384
} max30102_spo2_adc_range_t;
typedef enum {
    MAX30102_SPO2_SAMPLE_RATE_50_HZ   = 0,  // 50Hz
    MAX30102_SPO2_SAMPLE_RATE_100_HZ  = 1,  // 100Hz
    MAX30102_SPO2_SAMPLE_RATE_200_HZ  = 2,  // 200Hz
    MAX30102_SPO2_SAMPLE_RATE_400_HZ  = 3,  // 400Hz
    MAX30102_SPO2_SAMPLE_RATE_800_HZ  = 4,  // 800Hz
    MAX30102_SPO2_SAMPLE_RATE_1000_HZ = 5,  // 1000Hz
    MAX30102_SPO2_SAMPLE_RATE_1600_HZ = 6,  // 1600Hz
    MAX30102_SPO2_SAMPLE_RATE_3200_HZ = 7,  // 3200Hz
} max30102_spo2_sample_rate_t;
typedef enum {
    MAX30102_ADC_RESOLUTION_15_BIT = 0,  // 15 bits
    MAX30102_ADC_RESOLUTION_16_BIT = 1,  // 16 bits
    MAX30102_ADC_RESOLUTION_17_BIT = 2,  // 17 bits
    MAX30102_ADC_RESOLUTION_18_BIT = 3,  // 18 bits
} max30102_adc_resolution_t;
typedef enum {
    MAX30102_LED_NONE = 0,  // time slot is disabled
    MAX30102_LED_RED  = 1,  // enable red
    MAX30102_LED_IR   = 2,  // enable ir
} max30102_led_t;
typedef enum {
    MAX30102_SLOT_1 = 0,  // slot 1
    MAX30102_SLOT_2 = 1,  // slot 2
    MAX30102_SLOT_3 = 2,  // slot 3
    MAX30102_SLOT_4 = 3,  // slot 4
} max30102_slot_t;

uint8_t max30102_info();
uint8_t max30102_init();
uint8_t max30102_deinit();
uint8_t max30102_read(uint32_t* raw_red, uint32_t* raw_ir, uint8_t* len);
uint8_t max30102_read_temperature(uint16_t* raw, float* temp);
uint8_t max30102_irq_handler();
uint8_t max30102_get_interrupt_status(max30102_interrupt_status_t status, max30102_bool_t* enable);
uint8_t max30102_set_interrupt(max30102_interrupt_t type, max30102_bool_t enable);
uint8_t max30102_get_interrupt(max30102_interrupt_t type, max30102_bool_t* enable);
uint8_t max30102_set_fifo_write_pointer(uint8_t pointer);
uint8_t max30102_get_fifo_write_pointer(uint8_t* pointer);
uint8_t max30102_set_fifo_overflow_counter(uint8_t counter);
uint8_t max30102_get_fifo_overflow_counter(uint8_t* counter);
uint8_t max30102_set_fifo_read_pointer(uint8_t pointer);
uint8_t max30102_get_fifo_read_pointer(uint8_t* pointer);
uint8_t max30102_set_fifo_data(uint8_t data);
uint8_t max30102_get_fifo_data(uint8_t* data);
uint8_t max30102_set_fifo_sample_averaging(max30102_sample_averaging_t sample);
uint8_t max30102_get_fifo_sample_averaging(max30102_sample_averaging_t* sample);
uint8_t max30102_set_fifo_roll(max30102_bool_t enable);
uint8_t max30102_get_fifo_roll(max30102_bool_t* enable);
uint8_t max30102_set_fifo_almost_full(uint8_t value);
uint8_t max30102_get_fifo_almost_full(uint8_t* value);
uint8_t max30102_set_shutdown(max30102_bool_t enable);
uint8_t max30102_get_shutdown(max30102_bool_t* enable);
uint8_t max30102_reset();
uint8_t max30102_set_mode(max30102_mode_t mode);
uint8_t max30102_get_mode(max30102_mode_t* mode);
uint8_t max30102_set_spo2_adc_range(max30102_spo2_adc_range_t range);
uint8_t max30102_get_spo2_adc_range(max30102_spo2_adc_range_t* range);
uint8_t max30102_set_spo2_sample_rate(max30102_spo2_sample_rate_t rate);
uint8_t max30102_get_spo2_sample_rate(max30102_spo2_sample_rate_t* rate);
uint8_t max30102_set_adc_resolution(max30102_adc_resolution_t resolution);
uint8_t max30102_get_adc_resolution(max30102_adc_resolution_t* resolution);
uint8_t max30102_set_led_red_pulse_amplitude(uint8_t amp);
uint8_t max30102_get_led_red_pulse_amplitude(uint8_t* amp);
uint8_t max30102_set_led_ir_pulse_amplitude(uint8_t amp);
uint8_t max30102_get_led_ir_pulse_amplitude(uint8_t* amp);
uint8_t max30102_set_slot(max30102_slot_t slot, max30102_led_t led);
uint8_t max30102_get_slot(max30102_slot_t slot, max30102_led_t* led);
uint8_t max30102_set_die_temperature(max30102_bool_t enable);
uint8_t max30102_get_die_temperature(max30102_bool_t* enable);
uint8_t max30102_get_id(uint8_t* revision_id, uint8_t* part_id);
uint8_t max30102_set_reg(uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t max30102_get_reg(uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
