
#ifndef DRIVER_L3GD20H_REGISTER_TEST_H
#define DRIVER_L3GD20H_REGISTER_TEST_H
#include "driver_l3gd20h_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t l3gd20h_register_test(l3gd20h_interface_t interface, l3gd20h_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
