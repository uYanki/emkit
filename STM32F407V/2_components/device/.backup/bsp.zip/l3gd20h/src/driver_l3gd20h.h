
#ifndef DRIVER_L3GD20H_H
#define DRIVER_L3GD20H_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    L3GD20H_INTERFACE_IIC = 0x00,  // iic interface function
    L3GD20H_INTERFACE_SPI = 0x01,  // spi interface function
} l3gd20h_interface_t;
typedef enum {
    L3GD20H_ADDRESS_SDO_0 = 0xD4,  // addr pin connected to the GND
    L3GD20H_ADDRESS_SDO_1 = 0xD6,  // addr pin connected to the VCC
} l3gd20h_address_t;
typedef enum {
    L3GD20H_BOOL_FALSE = 0x00,  // false
    L3GD20H_BOOL_TRUE  = 0x01,  // true
} l3gd20h_bool_t;
typedef enum {
    L3GD20H_AXIS_X = 0x01,  // axis x
    L3GD20H_AXIS_Y = 0x00,  // axis y
    L3GD20H_AXIS_Z = 0x02,  // axis z
} l3gd20h_axis_t;
typedef enum {
    L3GD20H_MODE_POWER_DOWN = 0x00,  // power down mode
    L3GD20H_MODE_NORMAL     = 0x01,  // normal mode
    L3GD20H_MODE_SLEEP      = 0x02,  // sleep mode
} l3gd20h_mode_t;
typedef enum {
    L3GD20H_HIGH_PASS_FILTER_MODE_NORMAL_RESET     = 0x00,  // normal reset mode
    L3GD20H_HIGH_PASS_FILTER_MODE_REFERENCE_SIGNAL = 0x01,  // reference signal mode
    L3GD20H_HIGH_PASS_FILTER_MODE_NORMAL           = 0x02,  // normal mode
    L3GD20H_HIGH_PASS_FILTER_MODE_AUTORESET_ON_INT = 0x03,  // autoreset on int mode
} l3gd20h_high_pass_filter_mode_t;
typedef enum {
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_0 = 0x00,  // frequency 0
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_1 = 0x01,  // frequency 1
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_2 = 0x02,  // frequency 2
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_3 = 0x03,  // frequency 3
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_4 = 0x04,  // frequency 4
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_5 = 0x05,  // frequency 5
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_6 = 0x06,  // frequency 6
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_7 = 0x07,  // frequency 7
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_8 = 0x08,  // frequency 8
    L3GD20H_HIGH_PASS_FILTER_CUT_OFF_FREQUENCY_9 = 0x09,  // frequency 9
} l3gd20h_high_pass_filter_cut_off_frequency_t;
typedef enum {
    L3GD20H_LOW_ODR_0_ODR_100HZ_BW_0_12P5HZ = 0x00,  // 100Hz bandwidth 12.5 Hz
    L3GD20H_LOW_ODR_0_ODR_100HZ_BW_1_25HZ   = 0x01,  // 100Hz bandwidth 25 Hz
    L3GD20H_LOW_ODR_0_ODR_100HZ_BW_2_25HZ   = 0x02,  // 100Hz bandwidth 25 Hz
    L3GD20H_LOW_ODR_0_ODR_100HZ_BW_3_25HZ   = 0x03,  // 100Hz bandwidth 25 Hz
    L3GD20H_LOW_ODR_0_ODR_200HZ_BW_0_12P5HZ = 0x04,  // 200Hz bandwidth 12.5 Hz
    L3GD20H_LOW_ODR_0_ODR_200HZ_BW_1_NA     = 0x05,  // 200Hz bandwidth NA
    L3GD20H_LOW_ODR_0_ODR_200HZ_BW_2_NA     = 0x06,  // 200Hz bandwidth NA
    L3GD20H_LOW_ODR_0_ODR_200HZ_BW_3_70HZ   = 0x07,  // 200Hz bandwidth 70 Hz
    L3GD20H_LOW_ODR_0_ODR_400HZ_BW_0_20HZ   = 0x08,  // 400Hz bandwidth 20 Hz
    L3GD20H_LOW_ODR_0_ODR_400HZ_BW_1_25HZ   = 0x09,  // 400Hz bandwidth 25 Hz
    L3GD20H_LOW_ODR_0_ODR_400HZ_BW_2_50HZ   = 0x0A,  // 400Hz bandwidth 50 Hz
    L3GD20H_LOW_ODR_0_ODR_400HZ_BW_3_110HZ  = 0x0B,  // 400Hz bandwidth 110 Hz
    L3GD20H_LOW_ODR_0_ODR_800HZ_BW_0_30HZ   = 0x0C,  // 800Hz bandwidth 30 Hz
    L3GD20H_LOW_ODR_0_ODR_800HZ_BW_1_35HZ   = 0x0D,  // 800Hz bandwidth 35 Hz
    L3GD20H_LOW_ODR_0_ODR_800HZ_BW_2_NA     = 0x0E,  // 800Hz bandwidth NA
    L3GD20H_LOW_ODR_0_ODR_800HZ_BW_3_100HZ  = 0x0F,  // 800Hz bandwidth 100 Hz
    L3GD20H_LOW_ODR_1_ODR_12P5HZ_BW_0_NA    = 0x10,  // low power 12.5 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_12P5HZ_BW_1_NA    = 0x11,  // low power 12.5 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_12P5HZ_BW_2_NA    = 0x12,  // low power 12.5 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_12P5HZ_BW_3_NA    = 0x13,  // low power 12.5 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_25HZ_BW_0_NA      = 0x14,  // low power 25 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_25HZ_BW_1_NA      = 0x15,  // low power 25 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_25HZ_BW_2_NA      = 0x16,  // low power 25 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_25HZ_BW_3_NA      = 0x17,  // low power 25 Hz bandwidth NA
    L3GD20H_LOW_ODR_1_ODR_50HZ_BW_0_16P6HZ  = 0x18,  // low power 50 Hz bandwidth 16.6 Hz
    L3GD20H_LOW_ODR_1_ODR_50HZ_BW_1_16P6HZ  = 0x19,  // low power 50 Hz bandwidth 16.6 Hz
    L3GD20H_LOW_ODR_1_ODR_50HZ_BW_2_16P6HZ  = 0x1A,  // low power 50 Hz bandwidth 16.6 Hz
    L3GD20H_LOW_ODR_1_ODR_50HZ_BW_3_16P6HZ  = 0x1B,  // low power 50 Hz bandwidth 16.6 Hz
} l3gd20h_lodr_odr_bw_t;
typedef enum {
    L3GD20H_DATA_FORMAT_BIG_ENDIAN    = 0x00,  // big endian
    L3GD20H_DATA_FORMAT_LITTLE_ENDIAN = 0x01,  // little endian
} l3gd20h_data_format_t;
typedef enum {
    L3GD20H_FULL_SCALE_245_DPS  = 0x00,  // ±245 dps
    L3GD20H_FULL_SCALE_500_DPS  = 0x01,  // ±500 dps
    L3GD20H_FULL_SCALE_2000_DPS = 0x02,  // ±2000 dps
} l3gd20h_full_scale_t;
typedef enum {
    L3GD20H_SELF_TEST_NORMAL = 0x00,  // normal mode
    L3GD20H_SELF_TEST_0      = 0x01,  // test 0 mode
    L3GD20H_SELF_TEST_1      = 0x03,  // test 1 mode
} l3gd20h_self_test_t;
typedef enum {
    L3GD20H_SPI_WIRE_4 = 0x00,  // spi 4 wire
    L3GD20H_SPI_WIRE_3 = 0x01,  // spi 3 wire
} l3gd20h_spi_wire_t;
typedef enum {
    L3GD20H_BOOT_NORMAL = 0x00,  // boot normal
    L3GD20H_BOOT_REBOOT = 0x01,  // boot reboot
} l3gd20h_boot_t;
typedef enum {
    L3GD20H_SELECTION_LPF1          = 0x00,  // LPF1
    L3GD20H_SELECTION_LPF1_HPF      = 0x01,  // LPF1->HPF
    L3GD20H_SELECTION_LPF1_HPF_LPF2 = 0x02,  // LPF1->HPF->LPF2
} l3gd20h_selection_t;
typedef enum {
    L3GD20H_STATUS_XYZ_OVERRUN    = 0x07,  // xyz overrun
    L3GD20H_STATUS_Z_OVERRUN      = 0x06,  // z overrun
    L3GD20H_STATUS_Y_OVERRUN      = 0x05,  // y overrun
    L3GD20H_STATUS_X_OVERRUN      = 0x04,  // x overrun
    L3GD20H_STATUS_XYZ_DATA_READY = 0x03,  // xyz data ready
    L3GD20H_STATUS_Z_DATA_READY   = 0x02,  // reset mode
    L3GD20H_STATUS_Y_DATA_READY   = 0x01,  // reset mode
    L3GD20H_STATUS_X_DATA_READY   = 0x00,  // reset mode
} l3gd20h_status_t;
typedef enum {
    L3GD20H_INTERRUPT_ACTIVE_LEVEL_HIGH = 0x00,  // active level high
    L3GD20H_INTERRUPT_ACTIVE_LEVEL_LOW  = 0x01,  // active level low
} l3gd20h_interrupt_active_level_t;
typedef enum {
    L3GD20H_PIN_PUSH_PULL  = 0x00,  // push pull
    L3GD20H_PIN_OPEN_DRAIN = 0x01,  // open drain
} l3gd20h_pin_type_t;
typedef enum {
    L3GD20H_COUNTER_MODE_RESET     = 0x00,  // reset mode
    L3GD20H_COUNTER_MODE_DECREMENT = 0x01,  // decrement mode
} l3gd20h_counter_mode_t;
typedef enum {
    L3GD20H_INTERRUPT_EVENT_AND_OR_COMBINATION = 0x07,  // and or combination
    L3GD20H_INTERRUPT_EVENT_LATCH              = 0x06,  // latch
    L3GD20H_INTERRUPT_EVENT_Z_HIGH_EVENT       = 0x05,  // z high event
    L3GD20H_INTERRUPT_EVENT_Z_LOW_EVENT        = 0x04,  // z low event
    L3GD20H_INTERRUPT_EVENT_Y_HIGH_EVENT       = 0x03,  // y high event
    L3GD20H_INTERRUPT_EVENT_Y_LOW_EVENT        = 0x02,  // y low event
    L3GD20H_INTERRUPT_EVENT_X_HIGH_EVENT       = 0x01,  // x high event
    L3GD20H_INTERRUPT_EVENT_X_LOW_EVENT        = 0x00,  // x low event
} l3gd20h_interrupt_event_t;
typedef enum {
    L3GD20H_INTERRUPT1_INTERRUPT_ACTIVE = 0x10 | (1 << 6),                       // active
    L3GD20H_INTERRUPT1_Z_HIGH           = 0x10 | (1 << 5),                       // z high
    L3GD20H_INTERRUPT1_Z_LOW            = 0x10 | (1 << 4),                       // z low
    L3GD20H_INTERRUPT1_Y_HIGH           = 0x10 | (1 << 3),                       // y high
    L3GD20H_INTERRUPT1_Y_LOW            = 0x10 | (1 << 2),                       // y low
    L3GD20H_INTERRUPT1_X_HIGH           = 0x10 | (1 << 1),                       // x high
    L3GD20H_INTERRUPT1_X_LOW            = 0x10 | (1 << 0),                       // x low
    L3GD20H_INTERRUPT2_XYZ_OVERRUN      = 0x20 | L3GD20H_STATUS_XYZ_OVERRUN,     // xyz overrun
    L3GD20H_INTERRUPT2_Z_OVERRUN        = 0x20 | L3GD20H_STATUS_Z_OVERRUN,       // z overrun
    L3GD20H_INTERRUPT2_Y_OVERRUN        = 0x20 | L3GD20H_STATUS_Y_OVERRUN,       // y overrun
    L3GD20H_INTERRUPT2_X_OVERRUN        = 0x20 | L3GD20H_STATUS_X_OVERRUN,       // x overrun
    L3GD20H_INTERRUPT2_XYZ_DATA_READY   = 0x20 | L3GD20H_STATUS_XYZ_DATA_READY,  // xyz data ready
    L3GD20H_INTERRUPT2_Z_DATA_READY     = 0x20 | L3GD20H_STATUS_Z_DATA_READY,    // z data ready
    L3GD20H_INTERRUPT2_Y_DATA_READY     = 0x20 | L3GD20H_STATUS_Y_DATA_READY,    // y data ready
    L3GD20H_INTERRUPT2_X_DATA_READY     = 0x20 | L3GD20H_STATUS_X_DATA_READY,    // x data ready
    L3GD20H_INTERRUPT2_FIFO_THRESHOLD   = 0x41,                                  // fifo threshold
    L3GD20H_INTERRUPT2_FIFO_OVERRRUN    = 0x42,                                  // fifo overrun
    L3GD20H_INTERRUPT2_FIFO_EMPTY       = 0x43,                                  // fifo empty
} l3gd20h_interrupt_t;
typedef enum {
    L3GD20H_FIFO_MODE_BYPASS           = 0x00,  // bypass mode
    L3GD20H_FIFO_MODE_FIFO             = 0x01,  // fifo mode
    L3GD20H_FIFO_MODE_STREAM           = 0x02,  // stream mode
    L3GD20H_FIFO_MODE_STREAM_TO_FIFO   = 0x03,  // stream to fifo mode
    L3GD20H_FIFO_MODE_BYPASS_TO_STREAM = 0x04,  // bypass to stream mode
    L3GD20H_FIFO_MODE_DYNAMIC_STREAM   = 0x06,  // dynamic stream mode
    L3GD20H_FIFO_MODE_BYPASS_TO_FIFO   = 0x07,  // bypass to fifo mode
} l3gd20h_fifo_mode_t;
typedef struct l3gd20h_handle_s {
    uint8_t iic_addr;  // iic address

    uint8_t inited;   // inited flag
    uint8_t iic_spi;  // iic spi interface type
} l3gd20h_handle_t;

uint8_t l3gd20h_info(l3gd20h_info_t* info);
uint8_t l3gd20h_set_interface(l3gd20h_handle_t* handle, l3gd20h_interface_t interface);
uint8_t l3gd20h_get_interface(l3gd20h_handle_t* handle, l3gd20h_interface_t* interface);
uint8_t l3gd20h_set_addr_pin(l3gd20h_handle_t* handle, l3gd20h_address_t addr_pin);
uint8_t l3gd20h_get_addr_pin(l3gd20h_handle_t* handle, l3gd20h_address_t* addr_pin);
uint8_t l3gd20h_init(l3gd20h_handle_t* handle);
uint8_t l3gd20h_deinit(l3gd20h_handle_t* handle);
uint8_t l3gd20h_read(l3gd20h_handle_t* handle, int16_t (*raw)[3], float (*dps)[3], uint16_t* len);
uint8_t l3gd20h_irq_handler(l3gd20h_handle_t* handle, uint8_t num);
uint8_t l3gd20h_read_temperature(l3gd20h_handle_t* handle, int8_t* raw, float* temp);
uint8_t l3gd20h_set_mode(l3gd20h_handle_t* handle, l3gd20h_mode_t mode);
uint8_t l3gd20h_get_mode(l3gd20h_handle_t* handle, l3gd20h_mode_t* mode);
uint8_t l3gd20h_set_axis(l3gd20h_handle_t* handle, l3gd20h_axis_t axis, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_axis(l3gd20h_handle_t* handle, l3gd20h_axis_t axis, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_rate_bandwidth(l3gd20h_handle_t* handle, l3gd20h_lodr_odr_bw_t rate_bandwidth);
uint8_t l3gd20h_get_rate_bandwidth(l3gd20h_handle_t* handle, l3gd20h_lodr_odr_bw_t* rate_bandwidth);
uint8_t l3gd20h_set_edge_trigger(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_edge_trigger(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_level_trigger(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_level_trigger(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_high_pass_filter_mode(l3gd20h_handle_t* handle, l3gd20h_high_pass_filter_mode_t mode);
uint8_t l3gd20h_get_high_pass_filter_mode(l3gd20h_handle_t* handle, l3gd20h_high_pass_filter_mode_t* mode);
uint8_t l3gd20h_set_high_pass_filter_cut_off_frequency(l3gd20h_handle_t* handle, l3gd20h_high_pass_filter_cut_off_frequency_t frequency);
uint8_t l3gd20h_get_high_pass_filter_cut_off_frequency(l3gd20h_handle_t* handle, l3gd20h_high_pass_filter_cut_off_frequency_t* frequency);
uint8_t l3gd20h_set_block_data_update(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_block_data_update(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_data_format(l3gd20h_handle_t* handle, l3gd20h_data_format_t data_format);
uint8_t l3gd20h_get_data_format(l3gd20h_handle_t* handle, l3gd20h_data_format_t* data_format);
uint8_t l3gd20h_set_full_scale(l3gd20h_handle_t* handle, l3gd20h_full_scale_t full_scale);
uint8_t l3gd20h_get_full_scale(l3gd20h_handle_t* handle, l3gd20h_full_scale_t* full_scale);
uint8_t l3gd20h_set_level_sensitive_latched(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_level_sensitive_latched(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_self_test(l3gd20h_handle_t* handle, l3gd20h_self_test_t self_test);
uint8_t l3gd20h_get_self_test(l3gd20h_handle_t* handle, l3gd20h_self_test_t* self_test);
uint8_t l3gd20h_set_spi_wire(l3gd20h_handle_t* handle, l3gd20h_spi_wire_t spi_wire);
uint8_t l3gd20h_get_spi_wire(l3gd20h_handle_t* handle, l3gd20h_spi_wire_t* spi_wire);
uint8_t l3gd20h_set_boot(l3gd20h_handle_t* handle, l3gd20h_boot_t boot);
uint8_t l3gd20h_get_boot(l3gd20h_handle_t* handle, l3gd20h_boot_t* boot);
uint8_t l3gd20h_set_high_pass_filter(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_high_pass_filter(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_out_selection(l3gd20h_handle_t* handle, l3gd20h_selection_t selection);
uint8_t l3gd20h_get_out_selection(l3gd20h_handle_t* handle, l3gd20h_selection_t* selection);
uint8_t l3gd20h_set_high_pass_filter_reference(l3gd20h_handle_t* handle, uint8_t value);
uint8_t l3gd20h_get_high_pass_filter_reference(l3gd20h_handle_t* handle, uint8_t* value);
uint8_t l3gd20h_get_status(l3gd20h_handle_t* handle, uint8_t* status);
uint8_t l3gd20h_set_iic(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_iic(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_soft_reset(l3gd20h_handle_t* handle);
uint8_t l3gd20h_set_interrupt1(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_interrupt1(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_boot_on_interrupt1(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_boot_on_interrupt1(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_interrupt_active_level(l3gd20h_handle_t* handle, l3gd20h_interrupt_active_level_t level);
uint8_t l3gd20h_get_interrupt_active_level(l3gd20h_handle_t* handle, l3gd20h_interrupt_active_level_t* level);
uint8_t l3gd20h_set_interrupt_pin_type(l3gd20h_handle_t* handle, l3gd20h_pin_type_t pin_type);
uint8_t l3gd20h_get_interrupt_pin_type(l3gd20h_handle_t* handle, l3gd20h_pin_type_t* pin_type);
uint8_t l3gd20h_set_data_ready_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_data_ready_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_fifo_threshold_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_fifo_threshold_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_fifo_overrun_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_fifo_overrun_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_fifo_empty_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_fifo_empty_on_interrupt2(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_interrupt_selection(l3gd20h_handle_t* handle, l3gd20h_selection_t selection);
uint8_t l3gd20h_get_interrupt_selection(l3gd20h_handle_t* handle, l3gd20h_selection_t* selection);
uint8_t l3gd20h_set_interrupt_event(l3gd20h_handle_t* handle, l3gd20h_interrupt_event_t interrupt_event, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_interrupt_event(l3gd20h_handle_t* handle, l3gd20h_interrupt_event_t interrupt_event, l3gd20h_bool_t* enable);
uint8_t l3gd20h_get_interrupt_source(l3gd20h_handle_t* handle, uint8_t* src);
uint8_t l3gd20h_set_x_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t threshold);
uint8_t l3gd20h_get_x_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t* threshold);
uint8_t l3gd20h_set_y_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t threshold);
uint8_t l3gd20h_get_y_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t* threshold);
uint8_t l3gd20h_set_z_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t threshold);
uint8_t l3gd20h_get_z_interrupt_threshold(l3gd20h_handle_t* handle, uint16_t* threshold);
uint8_t l3gd20h_interrupt_threshold_convert_to_register(l3gd20h_handle_t* handle, float dps, uint16_t* reg);
uint8_t l3gd20h_interrupt_threshold_convert_to_data(l3gd20h_handle_t* handle, uint16_t reg, float* dps);
uint8_t l3gd20h_set_counter_mode(l3gd20h_handle_t* handle, l3gd20h_counter_mode_t counter_mode);
uint8_t l3gd20h_get_counter_mode(l3gd20h_handle_t* handle, l3gd20h_counter_mode_t* counter_mode);
uint8_t l3gd20h_set_wait(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_wait(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_duration(l3gd20h_handle_t* handle, uint8_t duration);
uint8_t l3gd20h_get_duration(l3gd20h_handle_t* handle, uint8_t* duration);
uint8_t l3gd20h_set_data_ready_active_level(l3gd20h_handle_t* handle, l3gd20h_interrupt_active_level_t level);
uint8_t l3gd20h_get_data_ready_active_level(l3gd20h_handle_t* handle, l3gd20h_interrupt_active_level_t* level);
uint8_t l3gd20h_set_fifo(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_fifo(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_stop_on_fifo_threshold(l3gd20h_handle_t* handle, l3gd20h_bool_t enable);
uint8_t l3gd20h_get_stop_on_fifo_threshold(l3gd20h_handle_t* handle, l3gd20h_bool_t* enable);
uint8_t l3gd20h_set_fifo_mode(l3gd20h_handle_t* handle, l3gd20h_fifo_mode_t fifo_mode);
uint8_t l3gd20h_get_fifo_mode(l3gd20h_handle_t* handle, l3gd20h_fifo_mode_t* fifo_mode);
uint8_t l3gd20h_set_fifo_threshold(l3gd20h_handle_t* handle, uint8_t threshold);
uint8_t l3gd20h_get_fifo_threshold(l3gd20h_handle_t* handle, uint8_t* threshold);
uint8_t l3gd20h_get_fifo_level(l3gd20h_handle_t* handle, uint8_t* level);
uint8_t l3gd20h_set_reg(l3gd20h_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t l3gd20h_get_reg(l3gd20h_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
