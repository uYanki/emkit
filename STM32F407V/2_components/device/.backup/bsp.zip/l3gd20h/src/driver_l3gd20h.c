
#include "driver_l3gd20h.h"

#define MANUFACTURER_NAME     "STMicroelectronic"                // manufacturer name
#define SUPPLY_VOLTAGE_MIN    2.2f                               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX    3.6f                               // chip max supply voltage




#define L3GD20H_REG_WHO_AM_I           0x0F        // who am i register
#define L3GD20H_REG_CTRL1              0x20        // control 1 register
#define L3GD20H_REG_CTRL2              0x21        // control 2 register
#define L3GD20H_REG_CTRL3              0x22        // control 3 register
#define L3GD20H_REG_CTRL4              0x23        // control 4 register
#define L3GD20H_REG_CTRL5              0x24        // control 5 register
#define L3GD20H_REG_REFERENCE          0x25        // reference register
#define L3GD20H_REG_OUT_TEMP           0x26        // output temperature register
#define L3GD20H_REG_STATUS             0x27        // status register
#define L3GD20H_REG_OUT_X_L            0x28        // out x low register
#define L3GD20H_REG_OUT_X_H            0x29        // out x high register
#define L3GD20H_REG_OUT_Y_L            0x2A        // out y low register
#define L3GD20H_REG_OUT_Y_H            0x2B        // out y high register
#define L3GD20H_REG_OUT_Z_L            0x2C        // out z low register
#define L3GD20H_REG_OUT_Z_H            0x2D        // out z high register
#define L3GD20H_REG_FIFO_CTRL          0x2E        // fifo control register
#define L3GD20H_REG_FIFO_SRC           0x2F        // fifo source register
#define L3GD20H_REG_IG_CFG             0x30        // interrupt configure register
#define L3GD20H_REG_IG_SRC             0x31        // interrupt source register
#define L3GD20H_REG_IG_THS_XH          0x32        // threshold x high register
#define L3GD20H_REG_IG_THS_XL          0x33        // threshold x low register
#define L3GD20H_REG_IG_THS_YH          0x34        // threshold y high register
#define L3GD20H_REG_IG_THS_YL          0x35        // threshold y low register
#define L3GD20H_REG_IG_THS_ZH          0x36        // threshold z high register
#define L3GD20H_REG_IG_THS_ZL          0x37        // threshold z low register
#define L3GD20H_REG_IG_DURATION        0x38        // interrupt duration register
#define L3GD20H_REG_LOW_ODR            0x39        // low power output data rate register
static uint8_t a_l3gd20h_iic_spi_read(l3gd20h_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    if (iic_spi == L3GD20H_INTERFACE_IIC)                        /* iic interface */
    {
        if (len > 1)                                                     /* len > 1 */
        {
            reg |= 1 << 7;                                               /* flag bit 7 */
        }
        
        if (iic_read(iic_addr, reg, buf, len) != 0)      /* read data */
        {
            
        }
        else
        {
            return 0;                                                    /* success return 0 */
        }
    }
    else                                                                 /* spi interface */
    {
        if (len > 1)                                                     /* len > 1*/
        {
            reg |= 1 << 6;                                               /* flag address increment */
        }
        reg |= 1 << 7;                                                   /* set read bit */
        
        if (spi_read(reg, buf, len) != 0)                        /* read data */
        {
            
        }
        else
        {
            return 0;                                                    /* success return 0 */
        }
    }
}
static uint8_t a_l3gd20h_iic_spi_write(l3gd20h_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    if (iic_spi == L3GD20H_INTERFACE_IIC)                         /* iic interface */
    {
        if (iic_write(iic_addr, reg, buf, len) != 0)      /* write data */
        {
            
        }
        else
        {
            return 0;                                                     /* success return 0 */
        }
    }
    else                                                                  /* spi interface */
    {
        if (len > 1)                                                      /* len > 1 */
        {
            reg |= 1 << 6;                                                /* flag address increment */
        }
        reg &= ~(1 << 7);                                                 /* set write bit */
        
        if (spi_write(reg, buf, len) != 0)                        /* write data */
        {
            
        }
        else
        {
            return 0;                                                     /* success return 0 */
        }
    }
}
uint8_t l3gd20h_set_interface(l3gd20h_handle_t *handle, l3gd20h_interface_t interface)
{
    
    {
        
    }
    iic_spi = (uint8_t)interface;        /* set the interface */
    return 0;                                    /* success return 0 */
}
uint8_t l3gd20h_get_interface(l3gd20h_handle_t *handle, l3gd20h_interface_t *interface)
{
    
    {
        
    }
    *interface = (l3gd20h_interface_t)(iic_spi);        /* get the interface */
    return 0;                                                   /* success return 0 */
}
uint8_t l3gd20h_set_addr_pin(l3gd20h_handle_t *handle, l3gd20h_address_t addr_pin)
{
    
    {
        
    }
    iic_addr = (uint8_t)addr_pin;        /* set the iic address */
    return 0;                                    /* success return 0 */
}
uint8_t l3gd20h_get_addr_pin(l3gd20h_handle_t *handle, l3gd20h_address_t *addr_pin)
{
    
    {
        
    }
    *addr_pin = (l3gd20h_address_t)(iic_addr);        /* get the iic adress */
    return 0;                                                 /* success return 0 */
}
uint8_t l3gd20h_set_mode(l3gd20h_handle_t *handle, l3gd20h_mode_t mode)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);             /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
        
        
    }
    if (mode == L3GD20H_MODE_SLEEP)                                                           /* if sleep mode */
    {
        prev |= (1 << 3);                                                                     /* set pd */
        prev &= ~(0x07);                                                                      /* clear config */
        
        return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* write config */
    }
    else
    {
        prev &= ~(1 << 3);                                                                    /* clear pd */
        prev |= (mode << 3);                                                                  /* set mode */
        prev |= 0x07;                                                                         /* set x,y,z enale */
        
        return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* write config */
    }
}
uint8_t l3gd20h_get_mode(l3gd20h_handle_t *handle, l3gd20h_mode_t *mode)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    if ((prev & 0x07) != 0)                                                             /* if x,y,z valid */
    {
        prev &= 1 << 3;                                                                 /* set pd */
        *mode  = (l3gd20h_mode_t)((prev >> 3) & 0x01);                                  /* normal or power down mode */
    }
    else
    {
        if ((prev & (1 << 3)) != 0)                                                     /* if pd == 1 */
        {
            *mode = L3GD20H_MODE_SLEEP;                                                 /* sleep mode*/
        }
        else
        {
            prev &= 1 << 3;                                                             /* set pd */
            *mode  = (l3gd20h_mode_t)((prev >> 3) & 0x01);                              /* set power down mode */
        }
    }
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_axis(l3gd20h_handle_t *handle, l3gd20h_axis_t axis, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << axis);                                                                 /* clear enable bit */
    prev |= enable << axis;                                                               /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_axis(l3gd20h_handle_t *handle, l3gd20h_axis_t axis, l3gd20h_bool_t *enable) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << axis);                                                                /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> axis);                                           /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_rate_bandwidth(l3gd20h_handle_t *handle, l3gd20h_lodr_odr_bw_t rate_bandwidth) 
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(0xF << 4);                                                                  /* clear rate and bandwidth bits */
    prev |= (rate_bandwidth & 0xF) << 4;                                                  /* set rate and bandwidth */
    if (a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1) != 0)     /* write config */
    {
        
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* read low odr */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 0);                                                                    /* clear odr bit */
    prev |= ((rate_bandwidth & 0x10) >> 4) & 0x01;                                        /* set odr */
    if (a_l3gd20h_iic_spi_write( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1) != 0)   /* write config */
    {
        
        
        
    }
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_get_rate_bandwidth(l3gd20h_handle_t *handle, l3gd20h_lodr_odr_bw_t *rate_bandwidth)
{
    uint8_t res, prev1, prev2;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev1, 1);          /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev2, 1);        /* read low odr */
    if (res != 0)                                                                           /* check result */
    {
        
        
        
    }
    *rate_bandwidth = (l3gd20h_lodr_odr_bw_t)(((prev2 & 0x01) << 4) | (prev1 >> 4));        /* get rate and bandwidth */
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_edge_trigger(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                    /* clear enable bit */
    prev |= enable << 7;                                                                  /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_edge_trigger(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 7);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 7);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_level_trigger(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 6);                                                                    /* get bool */
    prev |= enable << 6;                                                                  /* set the enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_level_trigger(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= (1 << 6);                                                                     /* get the enable */
    *enable = (l3gd20h_bool_t)(prev >> 6);                                                /* get bool */
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_set_high_pass_filter_mode(l3gd20h_handle_t *handle, l3gd20h_high_pass_filter_mode_t mode)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(3 << 4);                                                                    /* clear the mode */
    prev |= mode << 4;                                                                    /* set the mode */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_high_pass_filter_mode(l3gd20h_handle_t *handle, l3gd20h_high_pass_filter_mode_t *mode)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= (3 << 4);                                                                     /* get the mode bits */
    *mode = (l3gd20h_high_pass_filter_mode_t)(prev >> 4);                                 /* get the mode */
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_set_high_pass_filter_cut_off_frequency(l3gd20h_handle_t *handle, l3gd20h_high_pass_filter_cut_off_frequency_t frequency)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(0x0F);                                                                      /* clear the cut off frequency */
    prev |= frequency;                                                                    /* set the frequency */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_high_pass_filter_cut_off_frequency(l3gd20h_handle_t *handle, l3gd20h_high_pass_filter_cut_off_frequency_t *frequency)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL2, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= 0x0F;                                                                         /* get the cut off frequency */
    *frequency = (l3gd20h_high_pass_filter_cut_off_frequency_t)(prev >> 0);               /* get the frequency */
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_set_interrupt1(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                    /* clear the enable */
    prev |= enable << 7;                                                                  /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_interrupt1(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 7);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 7);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_boot_on_interrupt1(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 6);                                                                    /* clear enable bit */
    prev |= enable << 6;                                                                  /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_boot_on_interrupt1(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 6);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 6);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_interrupt_active_level(l3gd20h_handle_t *handle, l3gd20h_interrupt_active_level_t level)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 5);                                                                    /* clear level bit */
    prev |= level << 5;                                                                   /* set level bit */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_interrupt_active_level(l3gd20h_handle_t *handle, l3gd20h_interrupt_active_level_t *level)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 5);                                                                   /* get the level bit */
    *level = (l3gd20h_interrupt_active_level_t)(prev >> 5);                             /* get the level */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_interrupt_pin_type(l3gd20h_handle_t *handle, l3gd20h_pin_type_t pin_type)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 4);                                                                    /* clear pin type bit */
    prev |= pin_type << 4;                                                                /* set pin type */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_interrupt_pin_type(l3gd20h_handle_t *handle, l3gd20h_pin_type_t *pin_type)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 4);                                                                   /* get pin type bit */
    *pin_type = (l3gd20h_pin_type_t)(prev >> 4);                                        /* get pin type */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_data_ready_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 3);                                                                    /* set data ready bit */
    prev |= enable << 3;                                                                  /* set data ready */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_data_ready_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 3);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 3);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_fifo_threshold_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 2);                                                                    /* clear enable bit */
    prev |= enable << 2;                                                                  /* set enable */
   
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_fifo_threshold_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 2);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 2);                                              /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_fifo_overrun_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 1);                                                                    /* clear enable bit */
    prev |= enable << 1;                                                                  /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_fifo_overrun_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 1);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 1);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_fifo_empty_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 0);                                                                    /* clear enable bit */
    prev |= enable << 0;                                                                  /* set enable */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_fifo_empty_on_interrupt2(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL3, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 0);                                                                   /* get the enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 0);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_block_data_update(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                    /* clear the enable bit */
    prev |= enable << 7;                                                                  /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_block_data_update(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 7);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 7);                                              /* get bool */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_data_format(l3gd20h_handle_t *handle, l3gd20h_data_format_t data_format)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 6);                                                                    /* clear enable bit */
    prev |= data_format << 6;                                                             /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_data_format(l3gd20h_handle_t *handle, l3gd20h_data_format_t *data_format)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 6);                                                                   /* get enable bit */
    *data_format = (l3gd20h_data_format_t)(prev >> 6);                                  /* set enable */
   
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_full_scale(l3gd20h_handle_t *handle, l3gd20h_full_scale_t full_scale)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(3 << 4);                                                                    /* clear the scale bits */
    prev |= full_scale << 4;                                                              /* set scale */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_full_scale(l3gd20h_handle_t *handle, l3gd20h_full_scale_t *full_scale)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (3 << 4);                                                                   /* get scale bits */
    *full_scale = (l3gd20h_full_scale_t)(prev >> 4);                                    /* get scale */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_level_sensitive_latched(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 3);                                                                    /* clear enable bit */
    prev |= enable << 3;                                                                  /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_level_sensitive_latched(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 3);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 3);                                              /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_self_test(l3gd20h_handle_t *handle, l3gd20h_self_test_t self_test)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(3 << 1);                                                                    /* clear self test bits */
    prev |= self_test << 1;                                                               /* set self test */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_self_test(l3gd20h_handle_t *handle, l3gd20h_self_test_t *self_test)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (3 << 1);                                                                   /* get self test bits */
    *self_test = (l3gd20h_self_test_t)(prev >> 1);                                      /* get self test */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_spi_wire(l3gd20h_handle_t *handle, l3gd20h_spi_wire_t spi_wire)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 0);                                                                    /* clear spi wire bit */
    prev |= spi_wire << 0;                                                                /* set spi wire */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_spi_wire(l3gd20h_handle_t *handle, l3gd20h_spi_wire_t *spi_wire)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 0);                                                                   /* get spi wire bit */
    *spi_wire = (l3gd20h_spi_wire_t)(prev >> 0);                                        /* get spi wire */
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_boot(l3gd20h_handle_t *handle, l3gd20h_boot_t boot)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 7);                                                                    /* clear boot */
    prev |= boot << 7;                                                                    /* set boot */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_boot(l3gd20h_handle_t *handle, l3gd20h_boot_t *boot)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 7);                                                                   /* get enable bit */
    *boot = (l3gd20h_boot_t)(prev >> 7);                                                /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_fifo(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 6);                                                                    /* clear enable bit */
    prev |= enable << 6;                                                                  /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_fifo(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 6);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 6);                                              /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_stop_on_fifo_threshold(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 5);                                                                    /* clear fifo enable bit */
    prev |= enable << 5;                                                                  /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_stop_on_fifo_threshold(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 5);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 5);                                              /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_high_pass_filter(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 4);                                                                    /* clear enable bit */
    prev |= enable << 4;                                                                  /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_high_pass_filter(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (1 << 4);                                                                   /* get enable bit */
    *enable = (l3gd20h_bool_t)(prev >> 4);                                              /* get bool */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_interrupt_selection(l3gd20h_handle_t *handle, l3gd20h_selection_t selection)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(3 << 2);                                                                    /* clear selection */
    prev |= selection << 2;                                                               /* set selection */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_interrupt_selection(l3gd20h_handle_t *handle, l3gd20h_selection_t *selection)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (3 << 2);                                                                   /* get the selection bits */
    *selection = (l3gd20h_selection_t)(prev >> 2);                                      /* get the selection */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_out_selection(l3gd20h_handle_t *handle, l3gd20h_selection_t selection)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
        
    }
    prev &= ~(3 << 0);                                                                    /* clear the selection bits */
    prev |= selection << 0;                                                               /* get the selection */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_out_selection(l3gd20h_handle_t *handle, l3gd20h_selection_t *selection)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
        
        
    }
    prev &= (3 << 0);                                                                   /* get the selection bits */
    *selection = (l3gd20h_selection_t)(prev >> 0);                                      /* get the selection */
  
    return 0;                                                                           /* success return 0 */
}
uint8_t l3gd20h_set_high_pass_filter_reference(l3gd20h_handle_t *handle, uint8_t value)
{
    
    {
        
    }
    
    {
        
    }
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_REFERENCE, (uint8_t *)&value, 1);       /* write config */
}
uint8_t l3gd20h_get_high_pass_filter_reference(l3gd20h_handle_t *handle, uint8_t *value)
{
    
    {
        
    }
    
    {
        
    }
    return a_l3gd20h_iic_spi_read( L3GD20H_REG_REFERENCE, (uint8_t *)value, 1);         /* read config */
}
uint8_t l3gd20h_read_temperature(l3gd20h_handle_t *handle, int8_t *raw, float *temp)
{
    uint8_t res;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_OUT_TEMP, (uint8_t *)raw, 1);       /* read data */
    if (res != 0)                                                                        /* check result */
    {
        
        
    }
    *temp = (float)(*raw) * (-1.0f) + 25.0f;                                             /* convert the raw data */
  
    return 0;                                                                            /* success return 0 */
}
uint8_t l3gd20h_get_status(l3gd20h_handle_t *handle, uint8_t *status)
{
    
    {
        
    }
    
    {
        
    }
    return a_l3gd20h_iic_spi_read( L3GD20H_REG_STATUS, (uint8_t *)status, 1);     /* read config */
}
uint8_t l3gd20h_set_fifo_mode(l3gd20h_handle_t *handle, l3gd20h_fifo_mode_t fifo_mode)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
   
        
    }
    prev &= ~(7 << 5);
    prev |= fifo_mode << 5;                                                                   /* clear fifo mode bits */
                                                                                              /* set fifo mode */
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);       /* wrtie config */
}
uint8_t l3gd20h_get_fifo_mode(l3gd20h_handle_t *handle, l3gd20h_fifo_mode_t *fifo_mode)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
   
        
    }
    prev &= (7 << 5);                                                                       /* get fifo mode bits */
    *fifo_mode = (l3gd20h_fifo_mode_t)(prev >> 5);                                          /* get fifo mode */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_fifo_threshold(l3gd20h_handle_t *handle, uint8_t threshold)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    if (threshold > 31)                                                                       /* check the threshold */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
        
    }
    prev &= ~(0x1F);                                                                          /* clear the threshold bits */
    prev |= threshold;                                                                        /* set the threshold */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);       /* wrtie config */
}
uint8_t l3gd20h_get_fifo_threshold(l3gd20h_handle_t *handle, uint8_t *threshold)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
    }
    prev &= (0x1F);                                                                         /* get threshold bits */
    *threshold = prev;                                                                      /* set threshold */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_get_fifo_level(l3gd20h_handle_t *handle, uint8_t *level)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_SRC, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                          /* check result */
    {
        
        
    }
    prev &= (0x1F);                                                                        /* get level bits */
    *level = prev;                                                                         /* get level */
  
    return 0;                                                                              /* success return 0 */
}
uint8_t l3gd20h_set_interrupt_event(l3gd20h_handle_t *handle, l3gd20h_interrupt_event_t interrupt_event, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_CFG, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                          /* check result */
    {
        
        
    }
    prev &= ~(1 << interrupt_event);                                                       /* clear event bit */
    prev |= enable << interrupt_event;                                                     /* set event bit */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_CFG, (uint8_t *)&prev, 1);       /* wrtie config */
}
uint8_t l3gd20h_get_interrupt_event(l3gd20h_handle_t *handle, l3gd20h_interrupt_event_t interrupt_event, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_CFG, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
        
    }
    prev &= (1 << interrupt_event);                                                      /* get interrupt bit */
    *enable = (l3gd20h_bool_t)(prev >> interrupt_event);                                 /* get interrupt */
  
    return 0;                                                                            /* success return 0 */
}
uint8_t l3gd20h_get_interrupt_source(l3gd20h_handle_t *handle, uint8_t *src)
{
    uint8_t res;
  
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_SRC, (uint8_t *)src, 1);       /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
        
    }
    return 0;                                                                          /* success return 0 */
}
uint8_t l3gd20h_set_x_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (threshold > 0x8000U)                                                                   /* check the threshold */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_XH, (uint8_t *)buf, 1);            /* read x interrupt threshold */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    buf[0] = buf[0] | ((threshold >> 8) & 0x7F);                                               /* set threshold high */
    buf[1] = (threshold) & 0xFF;                                                               /* set threshold low*/
  
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_XH, (uint8_t *)&buf[0], 1);       /* write config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_XL, (uint8_t *)&buf[1], 1);       /* write config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t l3gd20h_get_x_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t *threshold)
{
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_XH, (uint8_t *)&buf[0], 1) != 0)  /* read x interrupt high threshold */
    {
        
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_XL, (uint8_t *)&buf[1], 1) != 0)  /* read x interrupt low threshold */
    {
        
        
    }
    *threshold = (uint16_t)((uint16_t)buf[0] << 8) | buf[1];                                /* get the threshold */
    *threshold &= ~(1 << 15);                                                               /* clear the 15th bit */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_y_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (threshold > 0x8000U)                                                                   /* check the threshold */
    {
        
        
    }
    buf[0] = (threshold >> 8) & 0xFF;                                                          /* set the high threshold */
    buf[1] = (threshold) & 0xFF;                                                               /* set the low threshold */
  
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_YH, (uint8_t *)&buf[0], 1);       /* write the config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_YL, (uint8_t *)&buf[1], 1);       /* write the config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t l3gd20h_get_y_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t *threshold)
{
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_YH, (uint8_t *)&buf[0], 1) != 0)  /* read y interrupt high threshold */
    {
        
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_YL, (uint8_t *)&buf[1], 1) != 0)  /* read y interrupt low threshold */
    {
        
        
    }
    *threshold = (uint16_t)(buf[0] << 8) | buf[1];                                          /* get the threshold */
    *threshold &= ~(1 << 15);                                                               /* clear the 15th bit */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_z_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (threshold > 0x8000U)                                                                   /* check the threshold */
    {
        
        
    }
    buf[0] = (threshold >> 8) & 0xFF;                                                          /* set the high threshold */
    buf[1] = (threshold) & 0xFF;                                                               /* set the low threshold */
  
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_ZH, (uint8_t *)&buf[0], 1);       /* write config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_ZL, (uint8_t *)&buf[1], 1);       /* write config */
    if (res != 0)                                                                              /* check result */
    {
        
        
    }
    return 0;                                                                                  /* success return 0 */
}
uint8_t l3gd20h_get_z_interrupt_threshold(l3gd20h_handle_t *handle, uint16_t *threshold)
{
    uint8_t buf[2];
  
    
    {
        
    }
    
    {
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_ZH, (uint8_t *)&buf[0], 1) != 0)  /* read the config */
    {
        
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_ZL, (uint8_t *)&buf[1], 1) != 0)  /* read the config */
    {
        
        
    }
    *threshold = (uint16_t)((uint16_t)buf[0] << 8) | buf[1];                                /* get the threshold */
    *threshold &= ~(1 << 15);                                                               /* clear the 15th bit */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_counter_mode(l3gd20h_handle_t *handle, l3gd20h_counter_mode_t counter_mode)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_XH, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
        
    }
    prev &= ~(1 << 7);                                                                        /* clear the counter mode bit */
    prev |= counter_mode << 7;                                                                /* set the counter mode */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_THS_XH, (uint8_t *)&prev, 1);       /* wrtie config */
}
uint8_t l3gd20h_get_counter_mode(l3gd20h_handle_t *handle, l3gd20h_counter_mode_t *counter_mode)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_THS_XH, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
    }
    prev &= (1 << 7);                                                                       /* get the counter mode bit */
    *counter_mode = (l3gd20h_counter_mode_t)(prev >> 7);                                    /* get the counter mode */
  
    return 0;                                                                               /* success return 0 */
}
uint8_t l3gd20h_set_wait(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                               /* check result */
    {
        
        
    }
    prev &= ~(1 << 7);                                                                          /* clear enable bit */
    prev |= enable << 7;                                                                        /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);       /* wrtie config */
}
uint8_t l3gd20h_get_wait(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
        
    }
    prev &= (1 << 7);                                                                         /* get the wait bit */
    *enable = (l3gd20h_bool_t)(prev >> 7);                                                    /* get bool */
  
    return 0;                                                                                 /* success return 0 */
}
uint8_t l3gd20h_set_duration(l3gd20h_handle_t *handle, uint8_t duration)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    if (duration > 0x7F)                                                                        /* check the duration */
    {
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                               /* check result */
    {
        
        
    }
    prev |= duration & 0x7F;                                                                    /* set the duration */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_duration(l3gd20h_handle_t *handle, uint8_t *duration)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_DURATION, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                             /* check result */
    {
        
        
    }
    prev &= 0x7F;                                                                             /* get duration bits */
    *duration = prev;                                                                         /* get duration */
  
    return 0;                                                                                 /* success return 0 */
}
uint8_t l3gd20h_set_data_ready_active_level(l3gd20h_handle_t *handle, l3gd20h_interrupt_active_level_t level)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 5);                                                                      /* clear level bit */
    prev |= level << 5;                                                                     /* set level */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_data_ready_active_level(l3gd20h_handle_t *handle, l3gd20h_interrupt_active_level_t *level)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        
    }
    prev &= (1 << 5);                                                                     /* get pin level bit */
    *level = (l3gd20h_interrupt_active_level_t)(prev >> 5);                               /* get pin level */
  
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_set_iic(l3gd20h_handle_t *handle, l3gd20h_bool_t enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 3);                                                                      /* clear enable bit */
    prev |= enable << 3;                                                                    /* set enable */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_get_iic(l3gd20h_handle_t *handle, l3gd20h_bool_t *enable)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        return 1;                                                                         /* return erro */
    }
    prev &= (1 << 3);                                                                     /* get enable bit */
   *enable = (l3gd20h_bool_t)(prev >> 3);                                                 /* get bool */
  
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_soft_reset(l3gd20h_handle_t *handle)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                           /* check result */
    {
        
        
    }
    prev &= ~(1 << 2);                                                                      /* clear reset bit */
    prev |= 1 << 2;                                                                         /* set reset bit */
  
    return a_l3gd20h_iic_spi_write( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* write config */
}
uint8_t l3gd20h_interrupt_threshold_convert_to_register(l3gd20h_handle_t *handle, float dps, uint16_t *reg)
{
    uint8_t range, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1) != 0)  /* read config */
    {
        
        
    }
    range = (prev & (3 << 4)) >> 4;                                                   /* get range */
    if (range == 0)
    {
        *reg = (uint16_t)(dps * 1000.0f / 7.5f);                                      /* convert */
    }
    else if (range == 1)
    {
        *reg = (uint16_t)(dps * 1000.0f / 15.3f);                                     /* convert */
    }
    else
    {
        *reg = (uint16_t)(dps * 1000.0f / 61.0f);                                     /* convert */
    }
    return 0;                                                                         /* success return 0 */
}
uint8_t l3gd20h_interrupt_threshold_convert_to_data(l3gd20h_handle_t *handle, uint16_t reg, float *dps)
{
    uint8_t range, prev;
  
    
    {
        
    }
    
    {
        
    }
  
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1) != 0)  /* read config */
    {
        
        
    }
    range = (prev & (3 << 4)) >> 4;                                                   /* get range */
    if (range == 0)
    {
        *dps = (float)(reg * 8.75f / 1000.0f);                                        /* convert */
    }
    else if (range == 1)
    {
        *dps = (float)(reg * 17.50f / 1000.0f);                                       /* convert */
    }
    else
    {
        *dps = (float)(reg * 70.0f / 1000.0f);                                        /* convert */
    }
    return 0;                                                                         /* success return 0 */
}
uint8_t l3gd20h_irq_handler(l3gd20h_handle_t *handle, uint8_t num)
{
    uint8_t res, prev;
  
    
    {
        
    }
    
    {
        
    }
    if (num == 1)                                                                            /* interrupt 1 */
    {
        res = a_l3gd20h_iic_spi_read( L3GD20H_REG_IG_SRC, (uint8_t *)&prev, 1);       /* read config */
        if (res != 0)                                                                        /* check result */
        {
            
      
            
        }
        if ((prev & (1 << 6)) != 0)                                                          /* check active */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_INTERRUPT_ACTIVE);               /* run receive callback */
            }
        }
        if ((prev & (1 << 5)) != 0)                                                          /* check z high */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_Z_HIGH);                         /* run receive callback */
            }
        }
        if ((prev & (1 << 4)) != 0)                                                          /* check z low */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_Z_LOW);                          /* run receive callback */
            }
        }
        if ((prev & (1 << 3)) != 0)                                                          /* check y high */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_Y_HIGH);                         /* run receive callback */
            }
        }
        if ((prev & (1 << 2)) != 0)                                                          /* check y low */
        {                                                                                    /* check y low */
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_Y_LOW);                          /* run receive callback */
            }
        }
        if ((prev & (1 << 1)) != 0)                                                          /* check x high */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
            {
                receive_callback(L3GD20H_INTERRUPT1_X_HIGH);                         /* run receive callback */
            }
        }
        if ((prev & (1 << 0)) != 0)                                                          /* check x low */
        {
            if (receive_callback != NULL)                                            /* receive callback is valid */
           {
               receive_callback(L3GD20H_INTERRUPT1_X_LOW);                           /* run receive callback */
           }
        }
        
        return 0;                                                                            /* success return 0 */
  }
  else if (num == 2)                                                                         /* interrupt 2 */
  {
      res = a_l3gd20h_iic_spi_read( L3GD20H_REG_STATUS, (uint8_t *)&prev, 1);         /* read config */
      if (res != 0)                                                                          /* check result */
      {
          
      
          
      }
      if ((prev & (1 << L3GD20H_STATUS_XYZ_OVERRUN)) != 0)                                   /* check status xyz overrun */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_XYZ_OVERRUN);                      /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_Z_OVERRUN)) != 0)                                     /* check status z overrun */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_Z_OVERRUN);                        /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_Y_OVERRUN)) != 0)                                     /* check status y overrun */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_Y_OVERRUN);                        /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_X_OVERRUN)) != 0)                                     /* check status x overrun */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_X_OVERRUN);                        /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_XYZ_DATA_READY)) != 0)                                /* check status xyz data ready */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_XYZ_DATA_READY);                   /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_Z_DATA_READY)) != 0)                                  /* check status z data ready */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_Z_DATA_READY);                     /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_Y_DATA_READY)) != 0)                                  /* check status y data ready */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_Y_DATA_READY);                     /* run receive callback */
          }
      }
      if ((prev & (1 << L3GD20H_STATUS_X_DATA_READY)) != 0)                                  /* check status x data ready */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_X_DATA_READY);                     /* run receive callback */
          }
      }
      res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_SRC, (uint8_t *)&prev, 1);       /* read config */
      if (res != 0)                                                                          /* check result */
      {
          
      
          
      }
      if ((prev & (1 << 7)) != 0)                                                            /* check fifo threshold */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_FIFO_THRESHOLD);                   /* run receive callback */
          }
      }
      if ((prev & (1 << 6)) != 0)                                                            /* check fifo overrun */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_FIFO_OVERRRUN);                    /* run receive callback */
          }
      }
      if ((prev & (1 << 5)) != 0)                                                            /* check fifo empty */
      {
          if (receive_callback != NULL)                                              /* receive callback is valid */
          {
              receive_callback(L3GD20H_INTERRUPT2_FIFO_EMPTY);                       /* run receive callback */
          }
      }
      
      return 0;                                                                              /* success return 0 */
  }
  else
  {
      
      
  }
}
uint8_t l3gd20h_init(l3gd20h_handle_t *handle)
{
    uint8_t res, prev;
    uint8_t id;
  
    
    {
        
    }
    if (debug_print == NULL)                                                      /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                                         /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL)                                                       /* check iic_deinit */
    {
        
        
        
    }
    if (iic_read == NULL)                                                         /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL)                                                        /* check iic_write */
    {
        
        
    }
    if (spi_init == NULL)                                                         /* check spi_init */
    {
        
        
    }
    if (spi_deinit == NULL)                                                       /* check spi_deinit */
    {
        
        
    }
    if (spi_read == NULL)                                                         /* check spi_read */
    {
        
        
    }
    if (spi_write == NULL)                                                        /* check spi_write */
    {
        
        
    }
    if (delay_ms == NULL)                                                         /* check delay_ms */
    {
        
        
    }
    if (iic_spi == L3GD20H_INTERFACE_IIC)                                         /* iic interface */
    {
        if (iic_init() != 0)                                                      /* initialize iic bus */
        {
            
      
            
        }
    }
    else
    {
        if (spi_init() != 0)                                                      /* initialize spi bus */
        {
            
      
            
        }
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_WHO_AM_I, (uint8_t *)&id, 1) != 0)     /* read id */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {
            
        }
        else                                                                              /* spi interface */
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
        
    }
    if (id != 0xD7)                                                                       /* check id */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {
            
        }
        else
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {                                                                               
            
        }
        else
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
    }
    prev &= ~(1 << 2);                                                                    /* clear reset bit */
    prev |= 1 << 2;                                                                       /* set reset bit */
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);      /* write config */
    if (res != 0)                                                                         /* check result */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {
            
        }
        else
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
        
    }
    delay_ms(12);                                                                 /* delay 12 ms */
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_LOW_ODR, (uint8_t *)&prev, 1);       /* read config */
    if (res != 0)                                                                         /* check result */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {
            
        }
        else
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
    }
    if (((prev >> 2) & 0x01) != 0x0)                                                      /* check result */
    {
        
        if (iic_spi == L3GD20H_INTERFACE_IIC)                                     /* if iic interface */
        {
            
        }
        else
        {
            (void)spi_deinit();                                                   /* spi deinit */
        }
        
    }
    inited = 1;                                                                   /* flag finish initialization */
  
    return 0;                                                                             /* success return 0 */
}
uint8_t l3gd20h_deinit(l3gd20h_handle_t *handle)
{
    uint8_t res, prev;
    
    {
        
    }
    
    {
        
    }
    res = a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);        /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
        
        
    }
    prev &= ~(1 << 3);                                                                   /* set power down bit */
    res = a_l3gd20h_iic_spi_write( L3GD20H_REG_CTRL1, (uint8_t *)&prev, 1);       /* write config */
    if (res != 0)                                                                        /* check result */
    {
        
        
        
    }
    inited = 0;                                                                  /* flag close */
    return 0;                                                                            /* success return 0 */
}
uint8_t l3gd20h_read(l3gd20h_handle_t *handle, int16_t (*raw)[3], float (*dps)[3], uint16_t *len) 
{
    uint8_t res, prev;
    uint8_t mode, cnt, i;
    uint8_t ble, range, enable;
    uint8_t buf[32 * 6];
  
    
    {
        
    }
    
    {
        
    }
    if ((*len) == 0)                                                                                 /* check length */
    {
        
        
    }
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_CTRL, (uint8_t *)&prev, 1) != 0)             /* read fifo ctrl */
    {
        
        
    }
    mode = prev >> 5;                                                                                /* get the mode */
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL5, (uint8_t *)&prev, 1) != 0)                 /* read ctrl5 */
    {
        
        
    }
    enable = (prev & (1 << 6)) >> 6;                                                                 /* get enable */
    if (a_l3gd20h_iic_spi_read( L3GD20H_REG_CTRL4, (uint8_t *)&prev, 1) != 0)                 /* get ctrl4 */
    {
        
        
    }
    range = (prev & (3 << 4)) >> 4;                                                                  /* get range */
    ble = (prev & (1 << 6)) >> 6;                                                                    /* get big little endian */
    if ((mode && enable) != 0)                                                                       /* fifo modes */
    {
        res = a_l3gd20h_iic_spi_read( L3GD20H_REG_FIFO_SRC, (uint8_t *)&prev, 1);             /* read fifo source */
        if (res != 0)                                                                                /* check result */
        {
            
      
            
        }
        cnt = prev & 0x1F;                                                                           /* get counter */
        *len = ((*len) < cnt) ? (*len) : cnt;                                                        /* get the lenght */
        res = a_l3gd20h_iic_spi_read( L3GD20H_REG_OUT_X_L, (uint8_t *)buf, 6 * (*len));       /* read all data */
        if (res != 0)                                                                                /* check result */
        {
            
      
            
        }
        for (i = 0; i < (*len); i++)                                                                 /* get data */
        {
            if (ble == 0)                                                                            /* little endian */
            {
                raw[i][0] = (int16_t)(((uint16_t)buf[1 + i * 6] << 8) | buf[0 + i * 6]);             /* set x */
                raw[i][1] = (int16_t)(((uint16_t)buf[3 + i * 6] << 8) | buf[2 + i * 6]);             /* set y */
                raw[i][2] = (int16_t)(((uint16_t)buf[5 + i * 6] << 8) | buf[4 + i * 6]);             /* set z */
            }
            else                                                                                     /* big endian */
            {
                raw[i][0] = (int16_t)(((uint16_t)buf[0 + i * 6] << 8) | buf[1 + i * 6]);             /* set x */
                raw[i][1] = (int16_t)(((uint16_t)buf[2 + i * 6] << 8) | buf[3 + i * 6]);             /* set y */
                raw[i][2] = (int16_t)(((uint16_t)buf[4 + i * 6] << 8) | buf[5 + i * 6]);             /* set z */
            }
           if (range == 0)                                                                           /* ±245 dps */
           {
               dps[i][0] = (float)(raw[i][0]) * 8.75f / 1000.0f;                                     /* set x */
               dps[i][1] = (float)(raw[i][1]) * 8.75f / 1000.0f;                                     /* set y */
               dps[i][2] = (float)(raw[i][2]) * 8.75f / 1000.0f;                                     /* set z */
           }
           else if (range == 1)                                                                      /* ±500 dps */
           {
               dps[i][0] = (float)(raw[i][0]) * 17.5f / 1000.0f;                                     /* set x */
               dps[i][1] = (float)(raw[i][1]) * 17.5f / 1000.0f;                                     /* set y */
               dps[i][2] = (float)(raw[i][2]) * 17.5f / 1000.0f;                                     /* set z */
           }
           else                                                                                      /* ±2000 dps */
           {
               dps[i][0] = (float)(raw[i][0]) * 70.0f / 1000.0f;                                     /* set x */
               dps[i][1] = (float)(raw[i][1]) * 70.0f / 1000.0f;                                     /* set y */
               dps[i][2] = (float)(raw[i][2]) * 70.0f / 1000.0f;                                     /* set z */
           }
       }
    }                                                                                                /* bypass mode */
    else
    {
        *len = 1;                                                                                    /* set length */
        res = a_l3gd20h_iic_spi_read( L3GD20H_REG_OUT_X_L, (uint8_t *)buf, 6);                /* read data */
        if (res != 0)                                                                                /* check result */
        {
            
      
            
        }
        if (ble == 0)                                                                                /* little endian */
        {
            raw[0][0] = (int16_t)(((uint16_t)buf[1] << 8) | buf[0]);                                 /* set x */
            raw[0][1] = (int16_t)(((uint16_t)buf[3] << 8) | buf[2]);                                 /* set y */
            raw[0][2] = (int16_t)(((uint16_t)buf[5] << 8) | buf[4]);                                 /* set z */
        }
        else                                                                                         /* big endian */
        {
            raw[0][0] = (int16_t)(((uint16_t)buf[0] << 8) | buf[1]);                                 /* set x */
            raw[0][1] = (int16_t)(((uint16_t)buf[2] << 8) | buf[3]);                                 /* set y */
            raw[0][2] = (int16_t)(((uint16_t)buf[4] << 8) | buf[5]);                                 /* set z */
        }
        if (range == 0)                                                                              /* ±245 dps */
        {
            dps[0][0] = (float)(raw[0][0]) * 8.75f / 1000.0f;                                        /* set x */
            dps[0][1] = (float)(raw[0][1]) * 8.75f / 1000.0f;                                        /* set y */
            dps[0][2] = (float)(raw[0][2]) * 8.75f / 1000.0f;                                        /* set z */
        }
        else if (range == 1)                                                                         /* ±500 dps */
        {
            dps[0][0] = (float)(raw[0][0]) * 17.5f / 1000.0f;                                        /* set x */
            dps[0][1] = (float)(raw[0][1]) * 17.5f / 1000.0f;                                        /* set y */
            dps[0][2] = (float)(raw[0][2]) * 17.5f / 1000.0f;                                        /* set z */
        }
        else                                                                                         /* ±2000 dps */
        {
            dps[0][0] = (float)(raw[0][0]) * 70.0f / 1000.0f;                                        /* set x */
            dps[0][1] = (float)(raw[0][1]) * 70.0f / 1000.0f;                                        /* set y */
            dps[0][2] = (float)(raw[0][2]) * 70.0f / 1000.0f;                                        /* set z */
        }
     }
  
     return 0;                                                                                       /* success return 0 */
}
uint8_t l3gd20h_set_reg(l3gd20h_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
  
    return a_l3gd20h_iic_spi_write( reg, buf, len);       /* write data */
}
uint8_t l3gd20h_get_reg(l3gd20h_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
  
    return a_l3gd20h_iic_spi_read( reg, buf, len);       /* read data */
}
uint8_t l3gd20h_info(l3gd20h_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(l3gd20h_info_t));                        /* initialize l3gd20h info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC SPI", 8);                         /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
