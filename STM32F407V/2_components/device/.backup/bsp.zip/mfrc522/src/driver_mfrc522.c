
#include "driver_mfrc522.h"

#define MANUFACTURER_NAME  "NXP"         // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.5f          // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f          // chip max supply voltage




#define MFRC522_REG_COMMAND        0x01 // starts and stops command execution register
#define MFRC522_REG_COMIEN         0x02 // enable and disable interrupt request control bits register
#define MFRC522_REG_DIVIEN         0x03 // enable and disable interrupt request control bits register
#define MFRC522_REG_COMIRQ         0x04 // interrupt request bits register
#define MFRC522_REG_DIVIRQ         0x05 // interrupt request bits register
#define MFRC522_REG_ERROR          0x06 // error bits showing the error status of the last command execued register
#define MFRC522_REG_STATUS1        0x07 // communication status bits register
#define MFRC522_REG_STATUS2        0x08 // receiver and transmitter status bits register
#define MFRC522_REG_FIFO_DATA      0x09 // input and output of 64 byte FIFO buffer register
#define MFRC522_REG_FIFO_LEVEL     0x0A // number of bytes stored in the FIFO buffer register
#define MFRC522_REG_WATER_LEVEL    0x0B // level for FIFO underflow and overflow warning register
#define MFRC522_REG_CONTROL        0x0C // miscellaneous control registers register
#define MFRC522_REG_BIT_FRAMING    0x0D // adjustments for bit-oriented frames register
#define MFRC522_REG_COLL           0x0E // bit position of the first bit-collision detected on the RF interface register
#define MFRC522_REG_MODE           0x11 // defines general modes for transmitting and receiving register
#define MFRC522_REG_TX_MODE        0x12 // defines transmission data rate and framing register
#define MFRC522_REG_RX_MODE        0x13 // defines reception data rate and framing register
#define MFRC522_REG_TX_CONTROL     0x14 // controls the logical behavior of the antenna driver pins TX1 and TX 2 register
#define MFRC522_REG_TX_ASK         0x15 // controls the setting of the transmission modulation register
#define MFRC522_REG_TX_SEL         0x16 // selects the internal sources for the antenna driver register
#define MFRC522_REG_RX_SEL         0x17 // selects internal receiver settings register
#define MFRC522_REG_RX_THRESHOLD   0x18 // selects thresholds for the bit decoder register
#define MFRC522_REG_DEMOD          0x19 // defines demodulator settings register
#define MFRC522_REG_MFTX           0x1C // controls some MIFARE communication transmit parameters register
#define MFRC522_REG_MFRX           0x1D // controls some MIFARE communication receive parameters register
#define MFRC522_REG_SERIAL_SPEED   0x1F // selects the speed of the serial UART interface register
#define MFRC522_REG_CRC_RESULT_H   0x21 // shows the MSB and LSB values of the CRC calculation high register
#define MFRC522_REG_CRC_RESULT_L   0x22 // shows the MSB and LSB values of the CRC calculation low register
#define MFRC522_REG_MOD_WIDTH      0x24 // controls the ModWidth setting register
#define MFRC522_REG_RFCFG          0x26 // configures the receiver gain register
#define MFRC522_REG_GSN            0x27 // selects the conductance of the antenna driver pins TX1 and TX2 for modulation register
#define MFRC522_REG_CWGSP          0x28 // defines the conductance of the p-driver output during periods of no modulation register
#define MFRC522_REG_MODGSP         0x29 // defines the conductance of the p-driver output during periods of modulation register
#define MFRC522_REG_TMODE          0x2A // defines settings for the internal timer register
#define MFRC522_REG_TPRESCALER     0x2B // defines settings for the internal timer register
#define MFRC522_REG_TRELOAD_H      0x2C // defines the 16-bit timer reload value high register
#define MFRC522_REG_TRELOAD_L      0x2D // defines the 16-bit timer reload value low register
#define MFRC522_REG_TCOUNTER_VAL_H 0x2E // shows the 16-bit timer value high register
#define MFRC522_REG_TCOUNTER_VAL_L 0x2F // shows the 16-bit timer value low register
#define MFRC522_REG_TEST_SEL1      0x31 // general test signal configuration register
#define MFRC522_REG_TEST_SEL2      0x32 // general test signal configuration and PRBS control register
#define MFRC522_REG_TEST_PIN_EN    0x33 // enables pin output driver on pins D1 to D7 register
#define MFRC522_REG_TEST_PIN_VALUE 0x34 // defines the values for D1 to D7 when it is used as an I/O bus register
#define MFRC522_REG_TEST_BUS       0x35 // shows the status of the internal test bus register
#define MFRC522_REG_AUTO_TEST      0x36 // controls the digital self test register
#define MFRC522_REG_VERSION        0x37 // shows the software version register
#define MFRC522_REG_ANALOG_TEST    0x38 // controls the pins AUX1 and AUX2 register
#define MFRC522_REG_TEST_DAC1      0x39 // defines the test value for TestDAC1 register
#define MFRC522_REG_TEST_DAC2      0x3A // defines the test value for TestDAC2 register
#define MFRC522_REG_TEST_ADC       0x3B // shows the value of ADC I and Q channels register
static uint8_t a_mfrc522_read( uint8_t reg, uint8_t* buf, uint16_t len)
{
    uint16_t i;
    if (iic_spi_uart == MFRC522_INTERFACE_IIC) /* if iic interface */
    {
        uint8_t addr;
        for (i = 0; i < len; i++) /* len times */
        {
            addr = reg + i;                                                /* set the address */
            if (iic_read(iic_addr, addr, buf + i, 1) != 0) /* check the result */
            {
                
            }
        }
        return 0;                                             /* success return 0 */
    } else if (iic_spi_uart == MFRC522_INTERFACE_SPI) /* if spi interface */
    {
        uint8_t addr;
        for (i = 0; i < len; i++) /* len times */
        {
            addr = (uint8_t)((1 << 7) | (((reg + i) & 0x3F) << 1)); /* set the address */
            if (spi_read(addr, buf + i, 1) != 0)            /* check the result */
            {
                
            }
        }
        return 0;                                              /* success return 0 */
    } else if (iic_spi_uart == MFRC522_INTERFACE_UART) /* if uart interface */
    {
        uint8_t addr;
        for (i = 0; i < len; i++) /* len times */
        {
            addr = (uint8_t)((1 << 7) | (((reg + i) & 0x3F) << 0)); /* set the address */
            if (uart_flush() != 0)                          /* uart flush */
            {
                
            }
            if (uart_write(&addr, 1) != 0) /* uart write */
            {
                
            }
            if (uart_read(buf + i, 1) != 1) /* uart read */
            {
                
            }
            delay_ms(2); /* uart delay 2 ms */
        }
        return 0; /* success return 0 */
    } else {      /* return error */
        return 1;
    }
}
static uint8_t a_mfrc522_write( uint8_t reg, uint8_t* buf, uint16_t len)
{
    uint16_t i;
    if (iic_spi_uart == MFRC522_INTERFACE_IIC) /* if iic interface */
    {
        uint8_t addr;
        for (i = 0; i < len; i++) /* len times */
        {
            addr = reg + i; /* set the address */
            if (iic_write(iic_addr, addr,
                                  buf + i, 1) != 0) /* check the result */
            {
                
            }
        }
        return 0;                                             /* success return 0 */
    } else if (iic_spi_uart == MFRC522_INTERFACE_SPI) /* if spi interface */
    {
        uint8_t addr;
        for (i = 0; i < len; i++) /* len times */
        {
            addr = (uint8_t)((0 << 7) | (((reg + i) & 0x3F) << 1)); /* set the address */
            if (spi_write(addr, buf + i, 1) != 0)           /* check the result */
            {
                
            }
        }
        return 0;                                              /* success return 0 */
    } else if (iic_spi_uart == MFRC522_INTERFACE_UART) /* if uart interface */
    {
        uint8_t addr;
        uint8_t b[2];
        for (i = 0; i < len; i++) /* len times */
        {
            addr = ((reg + i) & 0x3F) << 0;    /* set the addr */
            b[0] = addr;                       /* set to buffer */
            b[1] = buf[i];                     /* set buffer */
            if (uart_write(b, 2) != 0) /* uart write */
            {
                
            }
            delay_ms(5); /* uart delay 5 ms */
        }
        return 0; /* success return 0 */
    } else {
        
    }
}
uint8_t mfrc522_set_interface( mfrc522_interface_t interface)
{
    {
        
    }
    iic_spi_uart = (uint8_t)interface; /* set interface */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interface( mfrc522_interface_t* interface)
{
    {
        
    }
    *interface = (mfrc522_interface_t)(iic_spi_uart); /* get interface */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_addr_pin( uint8_t addr_pin)
{
    {
        
    }
    iic_addr = (uint8_t)addr_pin; /* set pin */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_addr_pin( uint8_t* addr_pin)
{
    {
        
    }
    *addr_pin = (uint8_t)(iic_addr); /* get pin */
    return 0; /* success return 0 */
}
uint8_t mfrc522_init(mfrc522_handle_t* handle)
{
    uint8_t  res;
    uint8_t  prev;
    uint8_t  id;
    uint32_t timeout;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (reset_gpio_init == NULL) /* check reset_gpio_init */
    {
        
        
    }
    if (reset_gpio_deinit == NULL) /* check reset_gpio_deinit */
    {
        
        
    }
    if (reset_gpio_write == NULL) /* check reset_gpio_write */
    {
        
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (uart_init == NULL) /* check uart_init */
    {
        
        
    }
    if (uart_deinit == NULL) /* check uart_deinit */
    {
        
        
    }
    if (uart_read == NULL) /* check uart_read */
    {
        
        
    }
    if (uart_write == NULL) /* check uart_write */
    {
        
        
    }
    if (uart_flush == NULL) /* check uart_flush */
    {
        
        
    }
    if (spi_init == NULL) /* check spi_init */
    {
        
        
    }
    if (spi_deinit == NULL) /* check spi_deinit */
    {
        
        
    }
    if (spi_read == NULL) /* check spi_read */
    {
        
        
    }
    if (spi_write == NULL) /* check spi_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (receive_callback == NULL) /* check receive_callback */
    {
        
        
    }
    if (reset_gpio_init() != 0) /* reset gpio init */
    {
        
        
    }
    if (iic_spi_uart == MFRC522_INTERFACE_IIC) /* if iic interface */
    {
        if (iic_init() != 0) /* iic init */
        {
            
            (void)reset_gpio_deinit();                  /* reset gpio deinit */
            
        }
    } else if (iic_spi_uart == MFRC522_INTERFACE_SPI) /* if spi interface */
    {
        if (spi_init() != 0) /* spi init */
        {
            
            (void)reset_gpio_deinit();                  /* reset gpio deinit */
            
        }
    } else if (iic_spi_uart == MFRC522_INTERFACE_UART) /* if uart interface */
    {
        if (uart_init() != 0) /* uart init */
        {
            
            (void)reset_gpio_deinit();                   /* reset gpio deinit */
            
        }
    } else {
        
        
    }
    if (reset_gpio_write(0) != 0) /* set 0 */
    {
        
        res = 1;                                                    /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    delay_ms(10);                 /* delay 10 ms */
    if (reset_gpio_write(1) != 0) /* set 1 */
    {
        
        res = 1;                                                    /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        res = 1;                                                /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= MFRC522_COMMAND_SOFT_RESET;                           /* set the idle */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        res = 1;                                                 /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    delay_ms(1); /* delay 1 ms */
    timeout = 1000;      /* set 1000 ms */
    while (timeout != 0) /* check the timeout */
    {
        res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
        
        {
            
            res = 1;                                                /* set the exit code */
            goto exit_code; /* goto the exit code */
        }
        timeout--;                  /* timeout-- */
        delay_ms(1);        /* delay 1 ms */
        if ((prev & (1 << 4)) == 0) /* check the power on bit */
        {
            break; /* break */
        }
        if (timeout == 0) /* check the timeout */
        {
            
            res = 1;                                         /* set the exit code */
            goto exit_code; /* goto the exit code */
        }
    }
    if (a_mfrc522_read( MFRC522_REG_VERSION, &id, 1) != 0) /* get the id */
    {
        
        res = 5;                                          /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    if (((id >> 4) & 0xF) != 9) /* check the id */
    {
        
        res = 6;                                            /* set the exit code */
        goto exit_code; /* goto the exit code */
    }
    inited   = 1;      /* flag inited */
    irq_flag = 0x0000; /* set 0x0000 */
    return 0; /* success return 0 */
exit_code:
    if (iic_spi_uart == MFRC522_INTERFACE_IIC) /* if iic interface */
    {
        
    } else if (iic_spi_uart == MFRC522_INTERFACE_SPI) /* if spi interface */
    {
        (void)spi_deinit(); /* spi deinit */
    } else                          /* if uart interface */
    {
        (void)uart_deinit(); /* uart deinit */
    }
    (void)reset_gpio_deinit(); /* reset gpio deinit */
    return res; /* return error */
}
uint8_t mfrc522_deinit(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= MFRC522_COMMAND_SOFT_RESET;                           /* set the idle */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    delay_ms(10);                 /* delay 10 ms */
    if (reset_gpio_write(0) != 0) /* power down */
    {
        
        
    }
    if (iic_spi_uart == MFRC522_INTERFACE_IIC) /* if iic interface */
    {
        if (iic_deinit() != 0) /* iic deinit */
        {
            
            
        }
    } else if (iic_spi_uart == MFRC522_INTERFACE_SPI) /* if spi interface */
    {
        if (spi_deinit() != 0) /* spi deinit */
        {
            
            
        }
    } else if (iic_spi_uart == MFRC522_INTERFACE_UART) /* if uart interface */
    {
        if (uart_deinit() != 0) /* uart deinit */
        {
            
            
        }
    } else {
        
        
    }
    if (reset_gpio_deinit() != 0) /* reset gpio deinit */
    {
        
        
    }
    inited = 0; /* flag closed */
    return 0; /* success return 0 */
}
uint8_t mfrc522_irq_handler(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    uint8_t prev1;
    uint8_t prev2;
    {
        
    }
    {
        
    }
    if (iic_spi_uart == MFRC522_INTERFACE_UART) /* if uart interface */
    {
        delay_ms(2); /* for uart interface delay 2 ms */
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS1, &prev, 1); /* read status1 */
    
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIRQ, &prev1, 1); /* read comirq */
    
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIRQ, &prev2, 1); /* read divirq */
    
    {
        
        
    }
    if ((prev & (1 << 4)) != 0) /* if set */
    {
        res = a_mfrc522_read( MFRC522_REG_COMIRQ, &prev, 1); /* read config */
        
        {
            
            
        }
        prev &= ~(1 << 7);                                           /* clear the settings */
        res = a_mfrc522_write( MFRC522_REG_COMIRQ, &prev, 1); /* write config */
        
        {
            
            
        }
        res = a_mfrc522_read( MFRC522_REG_DIVIRQ, &prev, 1); /* read config */
        
        {
            
            
        }
        prev &= ~(1 << 7);                                           /* clear the settings */
        res = a_mfrc522_write( MFRC522_REG_DIVIRQ, &prev, 1); /* write config */
        
        {
            
            
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_TIMER)) != 0) /* timer */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_TIMER; /* set the irq flag */
            if (receive_callback != NULL)             /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_TIMER); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_ERR)) != 0) /* err */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_ERR; /* set the irq flag */
            if (receive_callback != NULL)           /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_ERR); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_LO_ALERT)) != 0) /* lo alert */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_LO_ALERT; /* set the irq flag */
            if (receive_callback != NULL)                /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_LO_ALERT); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_HI_ALERT)) != 0) /* hi alert */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_HI_ALERT; /* set the irq flag */
            if (receive_callback != NULL)                /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_HI_ALERT); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_IDLE)) != 0) /* idle */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_IDLE; /* set the irq flag */
            if (receive_callback != NULL)            /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_IDLE); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_RX)) != 0) /* rx */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_RX; /* set the irq flag */
            if (receive_callback != NULL)          /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_RX); /* run callback */
            }
        }
        if ((prev1 & (1 << MFRC522_INTERRUPT_TX)) != 0) /* tx */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_TX; /* set the irq flag */
            if (receive_callback != NULL)          /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_TX); /* run callback */
            }
        }
        if ((prev2 & (1 << MFRC522_INTERRUPT2_CRC)) != 0) /* crc */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_CRC; /* set the irq flag */
            if (receive_callback != NULL)           /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_CRC); /* run callback */
            }
        }
        if ((prev2 & (1 << MFRC522_INTERRUPT2_MFIN_ACT)) != 0) /* mfin act */
        {
            irq_flag |= 1 << MFRC522_INTERRUPT_MFIN_ACT; /* set the irq flag */
            if (receive_callback != NULL)                /* if receive callback */
            {
                receive_callback(MFRC522_INTERRUPT_MFIN_ACT); /* run callback */
            }
        }
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_transceiver(
                            mfrc522_command_t command,
                            uint8_t*          in_buf,
                            uint8_t           in_len,
                            uint8_t*          out_buf,
                            uint8_t*          out_len,
                            uint8_t*          err,
                            uint32_t          ms)
{
    uint8_t  res;
    uint8_t  prev;
    uint8_t  i;
    uint16_t wait_for;
    uint32_t timeout;
    {
        
    }
    {
        
    }
    if ((in_buf == NULL) || (out_buf == NULL)) /* check the buffer */
    {
        
        
    }
    if (in_len > 64) /* check the length */
    {
        
        
    }
    /* set idle */
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= MFRC522_COMMAND_IDLE;                                 /* set the idle */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    /* flush the fifo */
    res = a_mfrc522_read( MFRC522_REG_FIFO_LEVEL, &prev, 1); /* read level */
    
    {
        
        
    }
    prev |= 1 << 7;                                                  /* set the flush bit */
    res = a_mfrc522_write( MFRC522_REG_FIFO_LEVEL, &prev, 1); /* write level */
    
    {
        
        
    }
    /* write fifo */
    for (i = 0; i < in_len; i++) /* loop */
    {
        res = a_mfrc522_write( MFRC522_REG_FIFO_DATA, in_buf + i, 1); /* write data */
        
        {
            
            
        }
    }
    /* clear the flag */
    irq_flag = 0;                                                    /* clear the irq flag */
    res              = a_mfrc522_read( MFRC522_REG_COMIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    res = a_mfrc522_write( MFRC522_REG_COMIRQ, &prev, 1); /* write config */
    
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    res = a_mfrc522_write( MFRC522_REG_DIVIRQ, &prev, 1); /* write config */
    
    {
        
        
    }
    /* set the command */
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= command;                                              /* set the command */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    /* set bit framing */
    if (command == MFRC522_COMMAND_TRANSCEIVE) /* if transceive*/
    {
        res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
        
        {
            
            
        }
        prev |= 1 << 7;                                                   /* set the start bit */
        res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
        
        {
            
            
        }
    }
    /* set the wait bit */
    if (command == MFRC522_COMMAND_MF_AUTHENT) /* if authent */
    {
        wait_for = (1 << MFRC522_INTERRUPT_IDLE) |
                   (1 << MFRC522_INTERRUPT_TIMER);    /* if idle && timer */
    } else if (command == MFRC522_COMMAND_TRANSCEIVE) /* if transceive */
    {
        wait_for = (1 << MFRC522_INTERRUPT_RX) |
                   (1 << MFRC522_INTERRUPT_TIMER);  /* if rx && timer */
    } else if (command == MFRC522_COMMAND_CALC_CRC) /* if crc */
    {
        wait_for = (1 << MFRC522_INTERRUPT_CRC) |
                   (1 << MFRC522_INTERRUPT_TIMER); /* if crc && timer */
    } else {
        wait_for = (1 << MFRC522_INTERRUPT_IDLE) |
                   (1 << MFRC522_INTERRUPT_TIMER); /* if idle && timer */
    }
    timeout = ms;        /* set timeout */
    while (timeout != 0) /* check the timeout */
    {
        delay_ms(1);                    /* delay 1ms */
        timeout--;                              /* timeout-- */
        if ((irq_flag & wait_for) != 0) /* check the wait for */
        {
            break; /* break */
        }
        if (timeout == 0) /* if timeout == 0 */
        {
            
            
        }
    }
    /* end */
    if (command == MFRC522_COMMAND_TRANSCEIVE) /* if transceive*/
    {
        res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
        
        {
            
            
        }
        prev &= ~(1 << 7);                                                /* clear the settings */
        res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
        
        {
            
            
        }
    }
    /* check timer timeout */
    if ((irq_flag & ((1 << MFRC522_INTERRUPT_TIMER))) != 0) /* check the timer */
    {
        
        
    }
    /* check error */
    if ((irq_flag & ((1 << MFRC522_INTERRUPT_ERR))) != 0) /* check the error */
    {
        res = a_mfrc522_read( MFRC522_REG_ERROR, err, 1); /* read config */
        
        {
            
            
        }
        
        
    }
    /* get the fifo */
    if ((command == MFRC522_COMMAND_TRANSCEIVE) && ((*out_len) != 0)) /* if transceive and need get from fifo */
    {
        uint8_t level;
        res = a_mfrc522_read( MFRC522_REG_FIFO_LEVEL, &level, 1); /* read level */
        
        {
            
            
        }
        *out_len = level > (*out_len) ? (*out_len) : level; /* set the output length */
        for (i = 0; i < (*out_len); i++)                    /* loop */
        {
            res = a_mfrc522_read( MFRC522_REG_FIFO_DATA, out_buf + i, 1); /* read data */
            
            {
                
                
            }
        }
    }
    if ((command == MFRC522_COMMAND_MEM) && ((*out_len) != 0)) /* if mem and need get from fifo */
    {
        uint8_t level;
        res = a_mfrc522_read( MFRC522_REG_FIFO_LEVEL, &level, 1); /* read level */
        
        {
            
            
        }
        *out_len = level > (*out_len) ? (*out_len) : level; /* set the output length */
        for (i = 0; i < (*out_len); i++)                    /* loop */
        {
            res = a_mfrc522_read( MFRC522_REG_FIFO_DATA, out_buf + i, 1); /* read data */
            
            {
                
                
            }
        }
    }
    /* stop the timer */
    res = a_mfrc522_read( MFRC522_REG_CONTROL, &prev, 1); /* read control */
    
    {
        
        
    }
    prev |= 1 << 7;                                               /* set the stop bit */
    res = a_mfrc522_write( MFRC522_REG_CONTROL, &prev, 1); /* write control */
    
    {
        
        
    }
    /* set the idle */
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= MFRC522_COMMAND_IDLE;                                 /* set the idle */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    *err = prev; /* set the 0 */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_receiver_analog( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 5);                                            /* clear the settings */
    prev |= ((!enable) << 5) | MFRC522_COMMAND_NO_CHANGE;         /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_receiver_analog( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)(!((prev >> 5) & 0x01)); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_power_down( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 4);                                            /* clear the settings */
    prev |= (enable << 4) | MFRC522_COMMAND_NO_CHANGE;            /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_power_down( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 4) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_command( mfrc522_command_t command)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                          /* clear the settings */
    prev |= command;                                              /* set the command */
    res = a_mfrc522_write( MFRC522_REG_COMMAND, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_command( mfrc522_command_t* command)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMMAND, &prev, 1); /* read config */
    
    {
        
        
    }
    *command = (mfrc522_command_t)((prev >> 0) & 0x0F); /* get the command */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt1( mfrc522_interrupt1_t type, mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << type);                                        /* clear the settings */
    prev |= (enable << type);                                    /* set the type */
    res = a_mfrc522_write( MFRC522_REG_COMIEN, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt1( mfrc522_interrupt1_t type, mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> type) & 0x01); /* set the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt1_pin_invert( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    prev |= (enable << 7);                                       /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_COMIEN, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt1_pin_invert( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt1_mark( mfrc522_interrupt_mark_t mark)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    prev |= (mark << 7);                                         /* set the mark */
    res = a_mfrc522_write( MFRC522_REG_COMIRQ, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt2( mfrc522_interrupt2_t type, mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << type);                                        /* clear the settings */
    prev |= (enable << type);                                    /* set the type */
    res = a_mfrc522_write( MFRC522_REG_DIVIEN, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt2( mfrc522_interrupt2_t type, mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> type) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt_pin_type( mfrc522_interrupt_pin_type_t type)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    prev |= (type << 7);                                         /* set the type */
    res = a_mfrc522_write( MFRC522_REG_DIVIEN, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt_pin_type( mfrc522_interrupt_pin_type_t* type)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIEN, &prev, 1); /* read config */
    
    {
        
        
    }
    *type = (mfrc522_interrupt_pin_type_t)((prev >> 7) & 0x01); /* get the type */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_interrupt2_mark( mfrc522_interrupt_mark_t mark)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                           /* clear the settings */
    prev |= (mark << 7);                                         /* set the mark */
    res = a_mfrc522_write( MFRC522_REG_DIVIRQ, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt1_status( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COMIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    *status = prev & (~(1 << 7)); /* get the status */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_interrupt2_status( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DIVIRQ, &prev, 1); /* read config */
    
    {
        
        
    }
    *status = prev & (~(1 << 7)); /* get the status */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_error( uint8_t* err)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_ERROR, &prev, 1); /* read config */
    
    {
        
        
    }
    *err = prev; /* set the error */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_status1( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS1, &prev, 1); /* read config */
    
    {
        
        
    }
    *status = prev; /* set the status */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_status2( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    *status = prev & (1 << 3); /* set the status */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_modem_state( mfrc522_modem_state_t* state)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    *state = (mfrc522_modem_state_t)(prev & 0x7); /* set the modem state */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_mifare_crypto1_on( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 3);                                            /* clear the settings */
    prev |= (enable << 3);                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_STATUS2, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_force_iic_high_speed( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 6);                                            /* clear the settings */
    prev |= (enable << 6);                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_STATUS2, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_force_iic_high_speed( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 6) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_clear_temperature_error( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                            /* clear the settings */
    prev |= (enable << 7);                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_STATUS2, &prev, 1); /* write config */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_clear_temperature_error( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_STATUS2, &prev, 1); /* read config */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_fifo_data( uint8_t* data, uint8_t len)
{
    uint8_t res;
    uint8_t i;
    {
        
    }
    {
        
    }
    if (len > 64) /* check the length */
    {
        
        
    }
    for (i = 0; i < len; i++) /* loop */
    {
        res = a_mfrc522_write( MFRC522_REG_FIFO_DATA, data + i, 1); /* write data */
        
        {
            
            
        }
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_fifo_data( uint8_t* data, uint8_t len)
{
    uint8_t res;
    uint8_t i;
    {
        
    }
    {
        
    }
    if (len > 64) /* check the length */
    {
        
        
    }
    for (i = 0; i < len; i++) /* loop */
    {
        res = a_mfrc522_read( MFRC522_REG_FIFO_DATA, data + i, 1); /* read data */
        
        {
            
            
        }
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_fifo_level( uint8_t* level)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_FIFO_LEVEL, level, 1); /* read level */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_flush_fifo(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_FIFO_LEVEL, &prev, 1); /* read level */
    
    {
        
        
    }
    prev |= 1 << 7;                                                  /* set the flush bit */
    res = a_mfrc522_write( MFRC522_REG_FIFO_LEVEL, &prev, 1); /* write level */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_water_level( uint8_t* level)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_WATER_LEVEL, level, 1); /* read level */
    
    {
        
        
    }
    *level &= ~(3 << 6); /* clear the bits */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_water_level( uint8_t level)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    if (level > 0x3F) /* check the level */
    {
        
        
    }
    res = a_mfrc522_write( MFRC522_REG_WATER_LEVEL, &level, 1); /* write level */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_stop_timer(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_CONTROL, &prev, 1); /* read control */
    
    {
        
        
    }
    prev |= 1 << 7;                                               /* set the stop bit */
    res = a_mfrc522_write( MFRC522_REG_CONTROL, &prev, 1); /* write control */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_start_timer(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_CONTROL, &prev, 1); /* read control */
    
    {
        
        
    }
    prev |= 1 << 6;                                               /* set the start bit */
    res = a_mfrc522_write( MFRC522_REG_CONTROL, &prev, 1); /* write control */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_last_bits( uint8_t* bits)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_CONTROL, &prev, 1); /* read control */
    
    {
        
        
    }
    *bits = prev & (0x7 << 0); /* set bits */
    return 0; /* success return 0 */
}
uint8_t mfrc522_start_send(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                                /* clear the settings */
    prev |= 1 << 7;                                                   /* set the start bit */
    res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_stop_send(mfrc522_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                                /* clear the settings */
    res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_last_bits( uint8_t* bits)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    *bits = prev & (0x7 << 0); /* set bits */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_last_bits( uint8_t bits)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (bits > 7) /* check the length */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    prev &= ~(7 << 0);                                                /* clear the settings */
    prev |= bits << 0;                                                /* set the bits */
    res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_align( mfrc522_rx_align_t align)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    prev &= ~(7 << 4);                                                /* clear the settings */
    prev |= align << 4;                                               /* set the align */
    res = a_mfrc522_write( MFRC522_REG_BIT_FRAMING, &prev, 1); /* write bit framing */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_align( mfrc522_rx_align_t* align)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_BIT_FRAMING, &prev, 1); /* read bit framing */
    
    {
        
        
    }
    *align = (mfrc522_rx_align_t)((prev >> 4) & 0x07); /* get the align */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_value_clear_after_coll( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COLL, &prev, 1); /* read coll */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                         /* clear the settings */
    prev |= (!enable) << 7;                                    /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_COLL, &prev, 1); /* write coll */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_value_clear_after_coll( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COLL, &prev, 1); /* read coll */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)(!((prev >> 7) & 0x01)); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_collision_position_not_valid( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COLL, &prev, 1); /* read coll */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 5) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_collision_position( uint8_t* pos)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_COLL, &prev, 1); /* read coll */
    
    {
        
        
    }
    *pos = prev & 0x1F; /* get the pos */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_crc_msb_first( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                         /* clear the settings */
    prev |= enable << 7;                                       /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_MODE, &prev, 1); /* write mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_crc_msb_first( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_wait_rf( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    prev &= ~(1 << 5);                                         /* clear the settings */
    prev |= enable << 5;                                       /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_MODE, &prev, 1); /* write mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_wait_rf( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 5) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_mfin_polarity( mfrc522_mfin_polarity_t polarity)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    prev &= ~(1 << 3);                                         /* clear the settings */
    prev |= polarity << 3;                                     /* set the polarity */
    res = a_mfrc522_write( MFRC522_REG_MODE, &prev, 1); /* write mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_mfin_polarity( mfrc522_mfin_polarity_t* polarity)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    *polarity = (mfrc522_mfin_polarity_t)((prev >> 3) & 0x01); /* get the polarity */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_crc_preset( mfrc522_crc_preset_t preset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    prev &= ~(3 << 0);                                         /* clear the settings */
    prev |= preset << 0;                                       /* set the preset */
    res = a_mfrc522_write( MFRC522_REG_MODE, &prev, 1); /* write mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_crc_preset( mfrc522_crc_preset_t* preset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODE, &prev, 1); /* read mode */
    
    {
        
        
    }
    *preset = (mfrc522_crc_preset_t)(prev & 0x3); /* get the preset */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_crc_generation( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                            /* clear the settings */
    prev |= enable << 7;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TX_MODE, &prev, 1); /* write tx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_crc_generation( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_speed( mfrc522_speed_t speed)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    prev &= ~(7 << 4);                                            /* clear the settings */
    prev |= speed << 4;                                           /* set the speed */
    res = a_mfrc522_write( MFRC522_REG_TX_MODE, &prev, 1); /* write tx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_speed( mfrc522_speed_t* speed)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    *speed = (mfrc522_speed_t)((prev >> 4) & 0x7); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_modulation_invert( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    prev &= ~(1 << 3);                                            /* clear the settings */
    prev |= enable << 3;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TX_MODE, &prev, 1); /* write tx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_modulation_invert( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_MODE, &prev, 1); /* read tx mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 3) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_crc_generation( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                            /* clear the settings */
    prev |= enable << 7;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_RX_MODE, &prev, 1); /* write rx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_crc_generation( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_speed( mfrc522_speed_t speed)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    prev &= ~(7 << 4);                                            /* clear the settings */
    prev |= speed << 4;                                           /* set the speed */
    res = a_mfrc522_write( MFRC522_REG_RX_MODE, &prev, 1); /* write rx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_speed( mfrc522_speed_t* speed)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    *speed = (mfrc522_speed_t)((prev >> 4) & 0x07); /* get the speed */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_no_error( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    prev &= ~(1 << 3);                                            /* clear the settings */
    prev |= enable << 3;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_RX_MODE, &prev, 1); /* write rx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_no_error( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 3) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_multiple( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    prev &= ~(1 << 2);                                            /* clear the settings */
    prev |= enable << 2;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_RX_MODE, &prev, 1); /* write rx mode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_multiple( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_MODE, &prev, 1); /* read rx mode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 2) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_antenna_driver( mfrc522_antenna_driver_t driver, mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_CONTROL, &prev, 1); /* read tx control */
    
    {
        
        
    }
    prev &= ~(1 << driver);                                          /* clear the settings */
    prev |= enable << driver;                                        /* set the driver */
    res = a_mfrc522_write( MFRC522_REG_TX_CONTROL, &prev, 1); /* write tx control */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_antenna_driver( mfrc522_antenna_driver_t driver, mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_CONTROL, &prev, 1); /* read tx control */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> driver) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_force_100_ask( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_ASK, &prev, 1); /* read tx ask */
    
    {
        
        
    }
    prev &= ~(1 << 6);                                           /* clear the settings */
    prev |= enable << 6;                                         /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TX_ASK, &prev, 1); /* write tx ask */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_force_100_ask( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_ASK, &prev, 1); /* read tx ask */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 6) & 0x1); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_input( mfrc522_tx_input_t input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_SEL, &prev, 1); /* read tx sel */
    
    {
        
        
    }
    prev &= ~(3 << 4);                                           /* clear the settings */
    prev |= input << 4;                                          /* set the input */
    res = a_mfrc522_write( MFRC522_REG_TX_SEL, &prev, 1); /* write tx sel */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_input( mfrc522_tx_input_t* input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_SEL, &prev, 1); /* read tx sel */
    
    {
        
        
    }
    *input = (mfrc522_tx_input_t)((prev >> 4) & 0x3); /* get the input */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_mfout_input( mfrc522_mfout_input_t input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_SEL, &prev, 1); /* read tx sel */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                         /* clear the settings */
    prev |= input << 0;                                          /* set the input */
    res = a_mfrc522_write( MFRC522_REG_TX_SEL, &prev, 1); /* write tx sel */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_mfout_input( mfrc522_mfout_input_t* input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TX_SEL, &prev, 1); /* read tx sel */
    
    {
        
        
    }
    *input = (mfrc522_mfout_input_t)(prev & 0x0F); /* get the input */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_contactless_uart_input( mfrc522_contactless_uart_input_t input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_SEL, &prev, 1); /* read rx sel */
    
    {
        
        
    }
    prev &= ~(3 << 6);                                           /* clear the settings */
    prev |= input << 6;                                          /* set the input */
    res = a_mfrc522_write( MFRC522_REG_RX_SEL, &prev, 1); /* write rx sel */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_contactless_uart_input( mfrc522_contactless_uart_input_t* input)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_SEL, &prev, 1); /* read rx sel */
    
    {
        
        
    }
    *input = (mfrc522_contactless_uart_input_t)((prev >> 6) & 0x3); /* get th input */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_wait( uint8_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t > 0x3F) /* check t */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_SEL, &prev, 1); /* read rx sel */
    
    {
        
        
    }
    prev &= ~(0x3F << 0);                                        /* clear the settings */
    prev |= t << 0;                                              /* set the input */
    res = a_mfrc522_write( MFRC522_REG_RX_SEL, &prev, 1); /* write rx sel */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_wait( uint8_t* t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_SEL, &prev, 1); /* read rx sel */
    
    {
        
        
    }
    *t = prev & 0x3F; /* get the rx wait */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_min_level( uint8_t level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (level > 0xF) /* check the level */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* read rx threshold */
    
    {
        
        
    }
    prev &= ~(0xF << 4);                                               /* clear the settings */
    prev |= level << 4;                                                /* set the level */
    res = a_mfrc522_write( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* write rx threshold */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_min_level( uint8_t* level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* read rx threshold */
    
    {
        
        
    }
    *level = (prev >> 4) & 0xF; /* get the level */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_collision_level( uint8_t level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (level > 7) /* check the level */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* read rx threshold */
    
    {
        
        
    }
    prev &= ~(0x7 << 0);                                               /* clear the settings */
    prev |= level << 0;                                                /* set the level */
    res = a_mfrc522_write( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* write rx threshold */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_collision_level( uint8_t* level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RX_THRESHOLD, &prev, 1); /* read rx threshold */
    
    {
        
        
    }
    *level = prev & 0x07; /* get the level */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_channel_reception( mfrc522_channel_reception_t reception)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    prev &= ~(0x3 << 6);                                        /* clear the settings */
    prev |= reception << 6;                                     /* set the reception */
    res = a_mfrc522_write( MFRC522_REG_DEMOD, &prev, 1); /* write demod */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_channel_reception( mfrc522_channel_reception_t* reception)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    *reception = (mfrc522_channel_reception_t)((prev >> 6) & 0x03); /* get the reception */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_fix_iq( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    prev &= ~(1 << 5);                                          /* clear the settings */
    prev |= enable << 5;                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_DEMOD, &prev, 1); /* write demod */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_fix_iq( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 5) & 0x01); /* set the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_prescal_even( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    prev &= ~(1 << 4);                                          /* clear the settings */
    prev |= enable << 4;                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_DEMOD, &prev, 1); /* write demod */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_prescal_even( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 4) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_constant_reception( uint8_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t > 3) /* check the t */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    prev &= ~(3 << 2);                                          /* clear the settings */
    prev |= t << 2;                                             /* set the pll */
    res = a_mfrc522_write( MFRC522_REG_DEMOD, &prev, 1); /* write demod */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_constant_reception( uint8_t* t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    *t = (prev >> 2) & 0x3; /* get the pll */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_constant_sync( uint8_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t > 3) /* check the t */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    prev &= ~(3 << 0);                                          /* clear the settings */
    prev |= t << 0;                                             /* set the pll */
    res = a_mfrc522_write( MFRC522_REG_DEMOD, &prev, 1); /* write demod */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_constant_sync( uint8_t* t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_DEMOD, &prev, 1); /* read demod */
    
    {
        
        
    }
    *t = (prev >> 0) & 0x3; /* get the pll */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_tx_wait( uint8_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t > 3) /* check the t */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_MFTX, &prev, 1); /* read mftx */
    
    {
        
        
    }
    prev &= ~(3 << 0);                                         /* clear the settings */
    prev |= t << 0;                                            /* set the wait */
    res = a_mfrc522_write( MFRC522_REG_MFTX, &prev, 1); /* write mftx */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_tx_wait( uint8_t* t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MFTX, &prev, 1); /* read mftx */
    
    {
        
        
    }
    *t = prev & 0x03; /* set the wait */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_parity_disable( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MFRX, &prev, 1); /* read mfrx */
    
    {
        
        
    }
    prev &= ~(1 << 4);                                         /* clear the settings */
    prev |= enable << 4;                                       /* set the enable */
    res = a_mfrc522_write( MFRC522_REG_MFRX, &prev, 1); /* write mfrx */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_parity_disable( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MFRX, &prev, 1); /* read mfrx */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 4) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_serial_speed( uint8_t t0, uint8_t t1)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t0 > 0x7) /* check the t0 */
    {
        
        
    }
    if (t1 > 0x1F) /* check the t1 */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_SERIAL_SPEED, &prev, 1); /* read serial speed  */
    
    {
        
        
    }
    prev = ((t0 & 0x7) << 5) | (t1 & 0x1F);                             /* set the speed */
    res  = a_mfrc522_write( MFRC522_REG_SERIAL_SPEED, &prev, 1); /* write serial speed */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_serial_speed( uint8_t* t0, uint8_t* t1)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_SERIAL_SPEED, &prev, 1); /* read serial speed */
    
    {
        
        
    }
    *t0 = (prev >> 5) & 0xF;  /* set the t0 */
    *t1 = (prev >> 0) & 0x1F; /* set the t1 */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_crc( uint16_t* crc)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_CRC_RESULT_H, buf, 2); /* read crc result */
    
    {
        
        
    }
    *crc = ((uint16_t)buf[0] << 8) | buf[1]; /* get the result */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_modulation_width( uint8_t width)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_mfrc522_write( MFRC522_REG_MOD_WIDTH, &width, 1); /* write mod width */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_modulation_width( uint8_t* width)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MOD_WIDTH, width, 1); /* read mod width */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_rx_gain( mfrc522_rx_gain_t gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RFCFG, &prev, 1); /* read rf cfg */
    
    {
        
        
    }
    prev &= ~(7 << 4);                                          /* clear the settings */
    prev |= gain << 4;                                          /* set the gain */
    res = a_mfrc522_write( MFRC522_REG_RFCFG, &prev, 1); /* write rf cfg */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_rx_gain( mfrc522_rx_gain_t* gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_RFCFG, &prev, 1); /* read rf cfg */
    
    {
        
        
    }
    *gain = (mfrc522_rx_gain_t)((prev >> 4) & 0x7); /* get the gain */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_cwgsn( uint8_t n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (n > 0xF) /* check n */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_GSN, &prev, 1); /* read gsn */
    
    {
        
        
    }
    prev &= ~(0xF << 4);                                      /* clear the settings */
    prev |= n << 4;                                           /* set the param */
    res = a_mfrc522_write( MFRC522_REG_GSN, &prev, 1); /* write gsn */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_cwgsn( uint8_t* n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_GSN, &prev, 1); /* read gsn */
    
    {
        
        
    }
    *n = (prev >> 4) & 0xF; /* get the param */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_modgsn( uint8_t n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (n > 0xF) /* check n */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_GSN, &prev, 1); /* read gsn */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                      /* clear the settings */
    prev |= n << 0;                                           /* set the param */
    res = a_mfrc522_write( MFRC522_REG_GSN, &prev, 1); /* write gsn */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_modgsn( uint8_t* n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_GSN, &prev, 1); /* read gsn */
    
    {
        
        
    }
    *n = (prev >> 0) & 0xF; /* get the param */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_cwgsp( uint8_t n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (n > 0x3F) /* check n */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_CWGSP, &prev, 1); /* read cwgsp */
    
    {
        
        
    }
    prev &= ~(0x3F << 0);                                       /* clear the settings */
    prev |= n << 0;                                             /* set the param */
    res = a_mfrc522_write( MFRC522_REG_CWGSP, &prev, 1); /* write cwgsp */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_cwgsp( uint8_t* n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_CWGSP, &prev, 1); /* read cwgsp */
    
    {
        
        
    }
    *n = prev & 0x3F; /* get the cwgsp */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_modgsp( uint8_t n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (n > 0x3F) /* check n */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODGSP, &prev, 1); /* read modgsp */
    
    {
        
        
    }
    prev &= ~(0x3F << 0);                                        /* clear the settings */
    prev |= n << 0;                                              /* set the param */
    res = a_mfrc522_write( MFRC522_REG_MODGSP, &prev, 1); /* write modgsp */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_modgsp( uint8_t* n)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_MODGSP, &prev, 1); /* read modgsp */
    
    {
        
        
    }
    *n = prev & 0x3F; /* get the modgsp */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_auto( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                          /* clear the settings */
    prev |= enable << 7;                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TMODE, &prev, 1); /* write tmode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_auto( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_gated_mode( mfrc522_timer_gated_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    prev &= ~(3 << 5);                                          /* clear the settings */
    prev |= mode << 5;                                          /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TMODE, &prev, 1); /* write tmode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_gated_mode( mfrc522_timer_gated_mode_t* mode)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    *mode = (mfrc522_timer_gated_mode_t)((prev >> 5) & 0x03); /* get the mode */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_auto_restart( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    prev &= ~(1 << 4);                                          /* clear the settings */
    prev |= enable << 4;                                        /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TMODE, &prev, 1); /* write tmode */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_auto_restart( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 4) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_prescaler( uint16_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (t > 0xFFF) /* check t */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev, 1); /* read tmode */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                        /* clear the settings */
    prev |= ((t >> 8) & 0xF) << 0;                              /* set the param */
    res = a_mfrc522_write( MFRC522_REG_TMODE, &prev, 1); /* write tmode */
    
    {
        
        
    }
    prev = t & 0xFF;                                                  /* set the t */
    res  = a_mfrc522_write( MFRC522_REG_TPRESCALER, &prev, 1); /* write tprescaler */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_prescaler( uint16_t* t)
{
    uint8_t res;
    uint8_t prev1, prev2;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TMODE, &prev1, 1); /* read tmode */
    
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TPRESCALER, &prev2, 1); /* read tprescaler */
    
    {
        
        
    }
    *t = (uint16_t)((prev1 >> 0) & 0xF) << 8 | prev2; /* set the param */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_timer_reload( uint16_t reload)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (reload >> 8) & 0xFF;                                   /* set high */
    buf[1] = (reload >> 0) & 0xFF;                                   /* set low */
    res    = a_mfrc522_write( MFRC522_REG_TRELOAD_H, buf, 2); /* write treload */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_reload( uint16_t* reload)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TRELOAD_H, buf, 2); /* read treload */
    
    {
        
        
    }
    *reload = (uint16_t)buf[0] << 8 | buf[1]; /* set the reload */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_timer_counter( uint16_t* cnt)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TCOUNTER_VAL_H, buf, 2); /* read tcounter */
    
    {
        
        
    }
    *cnt = (uint16_t)buf[0] << 8 | buf[1]; /* set the reload */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_bus_signal_1( uint8_t s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (s > 7) /* check s */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL1, &prev, 1); /* read test sel 1 */
    
    {
        
        
    }
    prev &= ~(0x7 << 0);                                            /* clear the settings */
    prev |= s << 0;                                                 /* set the signal */
    res = a_mfrc522_write( MFRC522_REG_TEST_SEL1, &prev, 1); /* write test sel 1 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_bus_signal_1( uint8_t* s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL1, &prev, 1); /* read test sel 1 */
    
    {
        
        
    }
    *s = (prev >> 0) & 0x7; /* get the signal */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_bus_signal_2( uint8_t s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (s > 0x1F) /* check s */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    prev &= ~(0x1F << 0);                                           /* clear the settings */
    prev |= s << 0;                                                 /* set the signal */
    res = a_mfrc522_write( MFRC522_REG_TEST_SEL2, &prev, 1); /* write test sel 2 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_bus_signal_2( uint8_t* s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    *s = (prev >> 0) & 0x1F; /* set the signal */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_bus_flip( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                              /* clear the settings */
    prev |= enable << 7;                                            /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TEST_SEL2, &prev, 1); /* write test sel 2 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_bus_flip( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_prbs9( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    prev &= ~(1 << 6);                                              /* clear the settings */
    prev |= enable << 6;                                            /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TEST_SEL2, &prev, 1); /* write test sel 2 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_prbs9( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 6) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_prbs15( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    prev &= ~(1 << 5);                                              /* clear the settings */
    prev |= enable << 5;                                            /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TEST_SEL2, &prev, 1); /* write test sel 2 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_prbs15( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_SEL2, &prev, 1); /* read test sel 2 */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 5) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_rs232_line( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* read test pin en */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                                /* clear the settings */
    prev |= enable << 7;                                              /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* write test pin en */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_rs232_line( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* read test pin en */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_pin_enable( uint8_t pin)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (pin > 0x3F) /* check pin */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* read test pin en */
    
    {
        
        
    }
    prev &= ~(0x3F << 1);                                             /* clear the settings */
    prev |= pin << 1;                                                 /* set the pin */
    res = a_mfrc522_write( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* write test pin en */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_pin_enable( uint8_t* pin)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_EN, &prev, 1); /* read test pin en */
    
    {
        
        
    }
    *pin = (prev >> 1) & 0x3F; /* get the pin */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_port_io( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* read test pin value */
    
    {
        
        
    }
    prev &= ~(1 << 7);                                                   /* clear the settings */
    prev |= enable << 7;                                                 /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* write test pin value */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_port_io( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* read test pin value */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 7) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_pin_value( uint8_t value)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (value > 0x3F) /* check the value */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* read test pin value */
    
    {
        
        
    }
    prev &= ~(0x3F << 1);                                                /* clear the settings */
    prev |= value << 1;                                                  /* set the value */
    res = a_mfrc522_write( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* write test pin value */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_pin_value( uint8_t* value)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_PIN_VALUE, &prev, 1); /* read test pin value */
    
    {
        
        
    }
    *value = (prev >> 1) & 0x3F; /* get the value */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_bus( uint8_t* bus)
{
    uint8_t res;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_BUS, bus, 1); /* read test bus */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_amp_rcv( mfrc522_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_AUTO_TEST, &prev, 1); /* read auto test */
    
    {
        
        
    }
    prev &= ~(1 << 6);                                              /* clear the settings */
    prev |= enable << 6;                                            /* set the bool */
    res = a_mfrc522_write( MFRC522_REG_AUTO_TEST, &prev, 1); /* write auto test */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_amp_rcv( mfrc522_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_AUTO_TEST, &prev, 1); /* read auto test */
    
    {
        
        
    }
    *enable = (mfrc522_bool_t)((prev >> 6) & 0x01); /* get the bool */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_self_test( uint8_t test)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (test > 0xF) /* check the test */
    {
        
        
    }
    res = a_mfrc522_read( MFRC522_REG_AUTO_TEST, &prev, 1); /* read auto test */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                            /* clear the settings */
    prev |= test << 0;                                              /* set the test */
    res = a_mfrc522_write( MFRC522_REG_AUTO_TEST, &prev, 1); /* write auto test */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_self_test( uint8_t* test)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_AUTO_TEST, &prev, 1); /* read auto test */
    
    {
        
        
    }
    *test = prev & 0xF; /* get the test */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_version( uint8_t* id, uint8_t* version)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_VERSION, &prev, 1); /* read version */
    
    {
        
        
    }
    *id      = (prev >> 4) & 0xF; /* get the id */
    *version = (prev >> 0) & 0xF; /* get the version */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_analog_control_aux_1( mfrc522_test_analog_control_t control)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_ANALOG_TEST, &prev, 1); /* read analog test */
    
    {
        
        
    }
    prev &= ~(0xF << 4);                                              /* clear the settings */
    prev |= control << 4;                                             /* set the control */
    res = a_mfrc522_write( MFRC522_REG_ANALOG_TEST, &prev, 1); /* write analog test */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_analog_control_aux_1( mfrc522_test_analog_control_t* control)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_ANALOG_TEST, &prev, 1); /* read analog test */
    
    {
        
        
    }
    *control = (mfrc522_test_analog_control_t)((prev >> 4) & 0xF); /* get the control */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_analog_control_aux_2( mfrc522_test_analog_control_t control)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_ANALOG_TEST, &prev, 1); /* read analog test */
    
    {
        
        
    }
    prev &= ~(0xF << 0);                                              /* clear the settings */
    prev |= control << 0;                                             /* set the control */
    res = a_mfrc522_write( MFRC522_REG_ANALOG_TEST, &prev, 1); /* write analog test */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_analog_control_aux_2( mfrc522_test_analog_control_t* control)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_ANALOG_TEST, &prev, 1); /* read analog test */
    
    {
        
        
    }
    *control = (mfrc522_test_analog_control_t)((prev >> 0) & 0xF); /* get the control */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_dac_1( uint8_t dac)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (dac > 0x3F) /* check the dac */
    {
        
        
    }
    prev = dac & 0x3F;                                               /* set the dac */
    res  = a_mfrc522_write( MFRC522_REG_TEST_DAC1, &prev, 1); /* write test dac1 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_dac_1( uint8_t* dac)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_DAC1, &prev, 1); /* read test dac1 */
    
    {
        
        
    }
    *dac = prev & 0x3F; /* get the dac */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_test_dac_2( uint8_t dac)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (dac > 0x3F) /* check the dac */
    {
        
        
    }
    prev = dac & 0x3F;                                               /* set the dac */
    res  = a_mfrc522_write( MFRC522_REG_TEST_DAC2, &prev, 1); /* write test dac2 */
    
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_dac_2( uint8_t* dac)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_DAC2, &prev, 1); /* read test dac2 */
    
    {
        
        
    }
    *dac = prev & 0x3F; /* get the dac */
    return 0; /* success return 0 */
}
uint8_t mfrc522_get_test_adc( uint8_t* adc_i, uint8_t* adc_q)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_mfrc522_read( MFRC522_REG_TEST_ADC, &prev, 1); /* read test dac2 */
    
    {
        
        
    }
    *adc_i = (prev >> 4) & 0xF; /* get adc i */
    *adc_q = (prev >> 0) & 0xF; /* get adc q */
    return 0; /* success return 0 */
}
uint8_t mfrc522_set_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_mfrc522_write( reg, buf, len); /* write data */
}
uint8_t mfrc522_get_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {
        
    }
    {
        
    }
    return a_mfrc522_read( reg, buf, len); /* read data */
}
uint8_t mfrc522_info(mfrc522_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(mfrc522_info_t));                 /* initialize mfrc522 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC SPI UART", 32);            /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
