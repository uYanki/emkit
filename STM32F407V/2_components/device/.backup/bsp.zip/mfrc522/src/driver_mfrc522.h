﻿
#ifndef DRIVER_MFRC522_H
#define DRIVER_MFRC522_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MFRC522_INTERFACE_IIC  = 0x00,  // iic interface
    MFRC522_INTERFACE_SPI  = 0x01,  // spi interface
    MFRC522_INTERFACE_UART = 0x02,  // uart interface
} mfrc522_interface_t;
typedef enum {
    MFRC522_BOOL_FALSE = 0x00,  // disable function
    MFRC522_BOOL_TRUE  = 0x01,  // enable function
} mfrc522_bool_t;
typedef enum {
    MFRC522_COMMAND_IDLE       = 0x00,  // no action, cancels current command execution
    MFRC522_COMMAND_MEM        = 0x01,  // stores 25 bytes into the internal buffer
    MFRC522_COMMAND_RANDOM_ID  = 0x02,  // generates a 10-byte random id number
    MFRC522_COMMAND_CALC_CRC   = 0x03,  // activates the crc coprocessor or performs a self test
    MFRC522_COMMAND_TRANSMIT   = 0x04,  // transmits data from the fifo buffer
    MFRC522_COMMAND_NO_CHANGE  = 0x07,  // no command change
    MFRC522_COMMAND_RECEIVE    = 0x08,  // activates the receiver circuits
    MFRC522_COMMAND_TRANSCEIVE = 0x0C,  /**< transmits data from fifo buffer to antenna and automatically
                                             activates the receiver after transmission */
    MFRC522_COMMAND_MF_AUTHENT = 0x0E,  // performs the MIFARE standard authentication as a reader
    MFRC522_COMMAND_SOFT_RESET = 0x0F,  // resets the chip
} mfrc522_command_t;
typedef enum {
    MFRC522_INTERRUPT1_TX       = 6,  // allows the transmitter interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_RX       = 5,  // allows the receiver interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_IDLE     = 4,  // allows the idle interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_HI_ALERT = 3,  // allows the high alert interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_LO_ALERT = 2,  // allows the low alert interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_ERR      = 1,  // allows the error interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT1_TIMER    = 0,  // allows the timer interrupt request to be propagated to pin irq
} mfrc522_interrupt1_t;
typedef enum {
    MFRC522_INTERRUPT2_MFIN_ACT = 4,  // allows the MFIN active interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT2_CRC      = 2,  // allows the CRC interrupt request to be propagated to pin irq
} mfrc522_interrupt2_t;
typedef enum {
    MFRC522_INTERRUPT_MFIN_ACT = MFRC522_INTERRUPT2_MFIN_ACT + 8,  // allows the MFIN active interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_CRC      = MFRC522_INTERRUPT2_CRC + 8,       // allows the CRC interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_TX       = MFRC522_INTERRUPT1_TX,            // allows the transmitter interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_RX       = MFRC522_INTERRUPT1_RX,            // allows the receiver interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_IDLE     = MFRC522_INTERRUPT1_IDLE,          // allows the idle interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_HI_ALERT = MFRC522_INTERRUPT1_HI_ALERT,      // allows the high alert interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_LO_ALERT = MFRC522_INTERRUPT1_LO_ALERT,      // allows the low alert interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_ERR      = MFRC522_INTERRUPT1_ERR,           // allows the error interrupt request to be propagated to pin irq
    MFRC522_INTERRUPT_TIMER    = MFRC522_INTERRUPT1_TIMER,         // allows the timer interrupt request to be propagated to pin irq
} mfrc522_interrupt_t;
typedef enum {
    MFRC522_INTERRUPT_PIN_TYPE_STANDARD_CMOS = 1,  // standard cmos output pin
    MFRC522_INTERRUPT_PIN_TYPE_OPEN_DRAIN    = 0,  // open drain output pin
} mfrc522_interrupt_pin_type_t;
typedef enum {
    MFRC522_INTERRUPT_MARK_SET     = 1,  // marked 1
    MFRC522_INTERRUPT_MARK_CLEARED = 0,  // marked 0
} mfrc522_interrupt_mark_t;
typedef enum {
    MFRC522_ERROR_WR               = (1 << 7),  // write error
    MFRC522_ERROR_TEMP             = (1 << 6),  // overheating
    MFRC522_ERROR_BUFFER_OVER_FLOW = (1 << 4),  // buffer is full
    MFRC522_ERROR_COLL             = (1 << 3),  // a bit collision is detected
    MFRC522_ERROR_CRC              = (1 << 2),  // crc calculation fails
    MFRC522_ERROR_PARITY           = (1 << 1),  // parity check failed
    MFRC522_ERROR_PROTOCOL         = (1 << 0),  // sof is incorrect
} mfrc522_error_t;
typedef enum {
    MFRC522_STATUS1_CRC_OK    = (1 << 6),  // crc is ok
    MFRC522_STATUS1_CRC_READY = (1 << 5),  // the crc calculation has finished
    MFRC522_STATUS1_IRQ       = (1 << 4),  // irq
    MFRC522_STATUS1_TRUNNING  = (1 << 3),  // timer unit is running
    MFRC522_STATUS1_HI_ALERT  = (1 << 1),  // hi alert = (64 – fifo length) <= water level
    MFRC522_STATUS1_LO_ALERT  = (1 << 0),  // lo alert = fifo length <= water level
} mfrc522_status1_t;
typedef enum {
    MFRC522_STATUS2_MFCRYPTO1_ON = (1 << 3),  // indicates that the mifare crypto1 unit is switched on
} mfrc522_status2_t;
typedef enum {
    MFRC522_MODEM_STATE_IDLE             = 0x00,  // idle
    MFRC522_MODEM_STATE_WAIT_BIT_FRAMING = 0x01,  // wait for the start send bit
    MFRC522_MODEM_STATE_TX_WAIT          = 0x02,  // wait until rf field is present
    MFRC522_MODEM_STATE_TRANSMITTING     = 0x03,  // transmitting
    MFRC522_MODEM_STATE_RX_WAIT          = 0x04,  // wait until rf field is present
    MFRC522_MODEM_STATE_WAIT_DATA        = 0x05,  // wait for data
    MFRC522_MODEM_STATE_RECEIVING        = 0x06,  // receiving
} mfrc522_modem_state_t;
typedef enum {
    MFRC522_RX_ALIGN_0 = 0, /**< lsb of the received bit is stored at bit position 0, the second
                                 received bit is stored at bit position 1 */
    MFRC522_RX_ALIGN_1 = 1, /**< lsb of the received bit is stored at bit position 1, the second
                                 received bit is stored at bit position 2 */
    MFRC522_RX_ALIGN_7 = 7, /**< lsb of the received bit is stored at bit position 7, the second
                                 received bit is stored in the next byte that follows at bit
                                 position 0 */
} mfrc522_rx_align_t;
typedef enum {
    MFRC522_MFIN_POLARITY_LOW  = 0,  // polarity of pin mfin is active low
    MFRC522_MFIN_POLARITY_HIGH = 1,  // polarity of pin mfin is active high
} mfrc522_mfin_polarity_t;
typedef enum {
    MFRC522_CRC_PRESET_0000 = 0,  // 0000h
    MFRC522_CRC_PRESET_6363 = 1,  // 6363h
    MFRC522_CRC_PRESET_A671 = 2,  // A671h
    MFRC522_CRC_PRESET_FFFF = 3,  // FFFFh
} mfrc522_crc_preset_t;
typedef enum {
    MFRC522_SPEED_106_KBD = 0,  // 106 kBd
    MFRC522_SPEED_212_KBD = 1,  // 212 kBd
    MFRC522_SPEED_424_KBD = 2,  // 424 kBd
    MFRC522_SPEED_848_KBD = 3,  // 848 kBd
} mfrc522_speed_t;
typedef enum {
    MFRC522_ANTENNA_DRIVER_INV_TX2_RF_ON  = 7,  // output signal on pin tx2 inverted when driver tx2 is enabled
    MFRC522_ANTENNA_DRIVER_INV_TX1_RF_ON  = 6,  // output signal on pin tx1 inverted when driver tx1 is enabled
    MFRC522_ANTENNA_DRIVER_INV_TX2_RF_OFF = 5,  // output signal on pin tx2 inverted when driver tx2 is disabled
    MFRC522_ANTENNA_DRIVER_INV_TX1_RF_OFF = 4,  // output signal on pin tx1 inverted when driver tx1 is disabled
    MFRC522_ANTENNA_DRIVER_TX2_CW         = 3,  /**< output signal on pin tx2 continuously delivers the unmodulated 13.56 MHz energy carrier
                                                     tx2cw bit is enabled to modulate the 13.56 MHz energy carrier */
    MFRC522_ANTENNA_DRIVER_TX2_RF = 1,          /**< output signal on pin tx2 delivers the 13.56 MHz energy carrier modulated by
                                                     the transmission data */
    MFRC522_ANTENNA_DRIVER_TX1_RF = 0,          /**< output signal on pin tx1 delivers the 13.56 MHz energy carrier modulated by
                                                     the transmission data */
} mfrc522_antenna_driver_t;
typedef enum {
    MFRC522_TX_INPUT_3_STATE = 0,          /**< 3 state, in soft power-down the drivers are only in 3-state
                                                mode if the DriverSel[1:0] value is set to 3-state mode */
    MFRC522_TX_INPUT_INTERNAL_ENCODER = 1, /**< modulation signal (envelope) from the internal encoder, miller
                                                pulse encoded */
    MFRC522_TX_INPUT_MFIN_PIN = 2,         // modulation signal (envelope) from pin mfin
    MFRC522_TX_INPUT_CONTROL  = 3,         /**< HIGH, the HIGH level depends on the setting of bits
                                                InvTx1RFOn/InvTx1RFOff and InvTx2RFOn/InvTx2RFOff */
} mfrc522_tx_input_t;
typedef enum {
    MFRC522_MFOUT_INPUT_3_STATE          = 0,  // 3 state
    MFRC522_MFOUT_INPUT_LOW              = 1,  // low
    MFRC522_MFOUT_INPUT_HIGH             = 2,  // high
    MFRC522_MFOUT_INPUT_TEST             = 3,  // test bus signal as defined by the testsel1reg register’s tstbusbitsel[2:0] value
    MFRC522_MFOUT_INPUT_INTERNAL_ENCODER = 4,  // modulation signal (envelope) from the internal encoder, miller pulse encoded
    MFRC522_MFOUT_INPUT_TRANSMITTED      = 5,  // serial data stream to be transmitted, data stream before miller encoder
    MFRC522_MFOUT_INPUT_RECEIVED         = 7,  // serial data stream received, data stream after manchester decoder
} mfrc522_mfout_input_t;
typedef enum {
    MFRC522_CONTACTLESS_UART_INPUT_CONSTANT_LOW     = 0,  // constant low
    MFRC522_CONTACTLESS_UART_MFIN_PIN               = 1,  // manchester with subcarrier from pin mfin
    MFRC522_CONTACTLESS_UART_INTERNAL_ANALOG_MODULE = 2,  // modulated signal from the internal analog module
    MFRC522_CONTACTLESS_UART_NRZ                    = 3,  /**< NRZ coding without subcarrier from pin MFIN which is only valid
                                                               for transfer speeds above 106 kBd */
} mfrc522_contactless_uart_input_t;
typedef enum {
    MFRC522_CHANNEL_RECEPTION_STRONGER                 = 0,  // selects the stronger channel
    MFRC522_CHANNEL_RECEPTION_STRONGER_FREEZE_SELECTED = 1,  /**< selects the stronger channel and
                                                                  freezes the selected channel during communication */
} mfrc522_channel_reception_t;
typedef enum {
    MFRC522_RX_GAIN_18_DB = 2,  // 18 dB
    MFRC522_RX_GAIN_23_DB = 3,  // 23 dB
    MFRC522_RX_GAIN_33_DB = 4,  // 33 dB
    MFRC522_RX_GAIN_38_DB = 5,  // 38 dB
    MFRC522_RX_GAIN_43_DB = 6,  // 43 dB
    MFRC522_RX_GAIN_48_DB = 7,  // 48 dB
} mfrc522_rx_gain_t;
typedef enum {
    MFRC522_TIMER_GATED_MODE_NONE = 0,  // non gated mode
    MFRC522_TIMER_GATED_MODE_MFIN = 1,  // gated by pin MFIN
    MFRC522_TIMER_GATED_MODE_AUX1 = 2,  // gated by pin AUX1
} mfrc522_timer_gated_mode_t;
typedef enum {
    MFRC522_TEST_ANALOG_CONTROL_3_STATE                   = 0x0,  // 3 state
    MFRC522_TEST_ANALOG_CONTROL_OUTPUT                    = 0x1,  // output of test dac1, output of test dac2
    MFRC522_TEST_ANALOG_CONTROL_TEST_SIGNAL_CORR1         = 0x2,  // test signal corr1
    MFRC522_TEST_ANALOG_CONTROL_DAC_TEST_SIGNAL_MIN_LEVEL = 0x4,  // dac test signal min level
    MFRC522_TEST_ANALOG_CONTROL_DAC_TEST_SIGNAL_ADC_I     = 0x5,  // dac test signal adc i
    MFRC522_TEST_ANALOG_CONTROL_DAC_TEST_SIGNAL_ADC_Q     = 0x6,  // dac test signal adc q
    MFRC522_TEST_ANALOG_CONTROL_SIGNAL_FOR_PRODUCTION     = 0x8,  // test signal for production
    MFRC522_TEST_ANALOG_CONTROL_HIGH                      = 0xA,  // high
    MFRC522_TEST_ANALOG_CONTROL_LOW                       = 0xB,  // low
    MFRC522_TEST_ANALOG_CONTROL_TX_ACTIVE                 = 0xC,  // tx active
    MFRC522_TEST_ANALOG_CONTROL_RX_ACTIVE                 = 0xD,  // rx active
    MFRC522_TEST_ANALOG_CONTROL_SUBCARRIER_DETECTED       = 0xE,  // subcarrier detected
    MFRC522_TEST_ANALOG_CONTROL_DEFINED_BIT               = 0xF,  /**< test bus bit as defined by the testsel1reg register’s
                                                                       tstbusbitsel[2:0] bits */
} mfrc522_test_analog_control_t;
typedef struct mfrc522_handle_s {
    uint8_t  inited;        // inited flag
    uint8_t  iic_addr;      // iic address
    uint8_t  iic_spi_uart;  // iic spi uart
    uint16_t irq_flag;      // set the irq flag
} mfrc522_handle_t;

uint8_t mfrc522_info(mfrc522_info_t* info);
uint8_t mfrc522_set_interface(mfrc522_handle_t* handle, mfrc522_interface_t interface);
uint8_t mfrc522_get_interface(mfrc522_handle_t* handle, mfrc522_interface_t* interface);
uint8_t mfrc522_set_addr_pin(mfrc522_handle_t* handle, uint8_t addr_pin);
uint8_t mfrc522_get_addr_pin(mfrc522_handle_t* handle, uint8_t* addr_pin);
uint8_t mfrc522_irq_handler(mfrc522_handle_t* handle);
uint8_t mfrc522_init(mfrc522_handle_t* handle);
uint8_t mfrc522_deinit(mfrc522_handle_t* handle);
uint8_t mfrc522_transceiver(mfrc522_handle_t* handle,
                            mfrc522_command_t command,
                            uint8_t*          in_buf,
                            uint8_t           in_len,
                            uint8_t*          out_buf,
                            uint8_t*          out_len,
                            uint8_t*          err,
                            uint32_t          ms);
uint8_t mfrc522_set_receiver_analog(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_receiver_analog(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_power_down(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_power_down(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_command(mfrc522_handle_t* handle, mfrc522_command_t command);
uint8_t mfrc522_get_command(mfrc522_handle_t* handle, mfrc522_command_t* command);
uint8_t mfrc522_set_interrupt1(mfrc522_handle_t* handle, mfrc522_interrupt1_t type, mfrc522_bool_t enable);
uint8_t mfrc522_get_interrupt1(mfrc522_handle_t* handle, mfrc522_interrupt1_t type, mfrc522_bool_t* enable);
uint8_t mfrc522_set_interrupt1_pin_invert(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_interrupt1_pin_invert(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_interrupt1_mark(mfrc522_handle_t* handle, mfrc522_interrupt_mark_t mark);
uint8_t mfrc522_set_interrupt2(mfrc522_handle_t* handle, mfrc522_interrupt2_t type, mfrc522_bool_t enable);
uint8_t mfrc522_get_interrupt2(mfrc522_handle_t* handle, mfrc522_interrupt2_t type, mfrc522_bool_t* enable);
uint8_t mfrc522_set_interrupt_pin_type(mfrc522_handle_t* handle, mfrc522_interrupt_pin_type_t type);
uint8_t mfrc522_get_interrupt_pin_type(mfrc522_handle_t* handle, mfrc522_interrupt_pin_type_t* type);
uint8_t mfrc522_set_interrupt2_mark(mfrc522_handle_t* handle, mfrc522_interrupt_mark_t mark);
uint8_t mfrc522_get_interrupt1_status(mfrc522_handle_t* handle, uint8_t* status);
uint8_t mfrc522_get_interrupt2_status(mfrc522_handle_t* handle, uint8_t* status);
uint8_t mfrc522_get_error(mfrc522_handle_t* handle, uint8_t* err);
uint8_t mfrc522_get_status1(mfrc522_handle_t* handle, uint8_t* status);
uint8_t mfrc522_get_status2(mfrc522_handle_t* handle, uint8_t* status);
uint8_t mfrc522_get_modem_state(mfrc522_handle_t* handle, mfrc522_modem_state_t* state);
uint8_t mfrc522_set_mifare_crypto1_on(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_set_force_iic_high_speed(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_force_iic_high_speed(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_clear_temperature_error(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_clear_temperature_error(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_fifo_data(mfrc522_handle_t* handle, uint8_t* data, uint8_t len);
uint8_t mfrc522_get_fifo_data(mfrc522_handle_t* handle, uint8_t* data, uint8_t len);
uint8_t mfrc522_get_fifo_level(mfrc522_handle_t* handle, uint8_t* level);
uint8_t mfrc522_flush_fifo(mfrc522_handle_t* handle);
uint8_t mfrc522_set_water_level(mfrc522_handle_t* handle, uint8_t level);
uint8_t mfrc522_get_water_level(mfrc522_handle_t* handle, uint8_t* level);
uint8_t mfrc522_stop_timer(mfrc522_handle_t* handle);
uint8_t mfrc522_start_timer(mfrc522_handle_t* handle);
uint8_t mfrc522_get_rx_last_bits(mfrc522_handle_t* handle, uint8_t* bits);
uint8_t mfrc522_start_send(mfrc522_handle_t* handle);
uint8_t mfrc522_stop_send(mfrc522_handle_t* handle);
uint8_t mfrc522_set_tx_last_bits(mfrc522_handle_t* handle, uint8_t bits);
uint8_t mfrc522_get_tx_last_bits(mfrc522_handle_t* handle, uint8_t* bits);
uint8_t mfrc522_set_rx_align(mfrc522_handle_t* handle, mfrc522_rx_align_t align);
uint8_t mfrc522_get_rx_align(mfrc522_handle_t* handle, mfrc522_rx_align_t* align);
uint8_t mfrc522_set_value_clear_after_coll(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_value_clear_after_coll(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_get_collision_position_not_valid(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_get_collision_position(mfrc522_handle_t* handle, uint8_t* pos);
uint8_t mfrc522_set_crc_msb_first(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_crc_msb_first(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_tx_wait_rf(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_tx_wait_rf(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_mfin_polarity(mfrc522_handle_t* handle, mfrc522_mfin_polarity_t polarity);
uint8_t mfrc522_get_mfin_polarity(mfrc522_handle_t* handle, mfrc522_mfin_polarity_t* polarity);
uint8_t mfrc522_set_crc_preset(mfrc522_handle_t* handle, mfrc522_crc_preset_t preset);
uint8_t mfrc522_get_crc_preset(mfrc522_handle_t* handle, mfrc522_crc_preset_t* preset);
uint8_t mfrc522_set_tx_crc_generation(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_tx_crc_generation(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_tx_speed(mfrc522_handle_t* handle, mfrc522_speed_t speed);
uint8_t mfrc522_get_tx_speed(mfrc522_handle_t* handle, mfrc522_speed_t* speed);
uint8_t mfrc522_set_modulation_invert(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_modulation_invert(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_rx_crc_generation(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_rx_crc_generation(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_rx_speed(mfrc522_handle_t* handle, mfrc522_speed_t speed);
uint8_t mfrc522_get_rx_speed(mfrc522_handle_t* handle, mfrc522_speed_t* speed);
uint8_t mfrc522_set_rx_no_error(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_rx_no_error(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_rx_multiple(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_rx_multiple(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_antenna_driver(mfrc522_handle_t* handle, mfrc522_antenna_driver_t driver, mfrc522_bool_t enable);
uint8_t mfrc522_get_antenna_driver(mfrc522_handle_t* handle, mfrc522_antenna_driver_t driver, mfrc522_bool_t* enable);
uint8_t mfrc522_set_force_100_ask(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_force_100_ask(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_tx_input(mfrc522_handle_t* handle, mfrc522_tx_input_t input);
uint8_t mfrc522_get_tx_input(mfrc522_handle_t* handle, mfrc522_tx_input_t* input);
uint8_t mfrc522_set_mfout_input(mfrc522_handle_t* handle, mfrc522_mfout_input_t input);
uint8_t mfrc522_get_mfout_input(mfrc522_handle_t* handle, mfrc522_mfout_input_t* input);
uint8_t mfrc522_set_contactless_uart_input(mfrc522_handle_t* handle, mfrc522_contactless_uart_input_t input);
uint8_t mfrc522_get_contactless_uart_input(mfrc522_handle_t* handle, mfrc522_contactless_uart_input_t* input);
uint8_t mfrc522_set_rx_wait(mfrc522_handle_t* handle, uint8_t t);
uint8_t mfrc522_get_rx_wait(mfrc522_handle_t* handle, uint8_t* t);
uint8_t mfrc522_set_min_level(mfrc522_handle_t* handle, uint8_t level);
uint8_t mfrc522_get_min_level(mfrc522_handle_t* handle, uint8_t* level);
uint8_t mfrc522_set_collision_level(mfrc522_handle_t* handle, uint8_t level);
uint8_t mfrc522_get_collision_level(mfrc522_handle_t* handle, uint8_t* level);
uint8_t mfrc522_set_channel_reception(mfrc522_handle_t* handle, mfrc522_channel_reception_t reception);
uint8_t mfrc522_get_channel_reception(mfrc522_handle_t* handle, mfrc522_channel_reception_t* reception);
uint8_t mfrc522_set_fix_iq(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_fix_iq(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_timer_prescal_even(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_timer_prescal_even(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_timer_constant_reception(mfrc522_handle_t* handle, uint8_t t);
uint8_t mfrc522_get_timer_constant_reception(mfrc522_handle_t* handle, uint8_t* t);
uint8_t mfrc522_set_timer_constant_sync(mfrc522_handle_t* handle, uint8_t t);
uint8_t mfrc522_get_timer_constant_sync(mfrc522_handle_t* handle, uint8_t* t);
uint8_t mfrc522_set_tx_wait(mfrc522_handle_t* handle, uint8_t t);
uint8_t mfrc522_get_tx_wait(mfrc522_handle_t* handle, uint8_t* t);
uint8_t mfrc522_set_parity_disable(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_parity_disable(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_serial_speed(mfrc522_handle_t* handle, uint8_t t0, uint8_t t1);
uint8_t mfrc522_get_serial_speed(mfrc522_handle_t* handle, uint8_t* t0, uint8_t* t1);
uint8_t mfrc522_get_crc(mfrc522_handle_t* handle, uint16_t* crc);
uint8_t mfrc522_set_modulation_width(mfrc522_handle_t* handle, uint8_t width);
uint8_t mfrc522_get_modulation_width(mfrc522_handle_t* handle, uint8_t* width);
uint8_t mfrc522_set_rx_gain(mfrc522_handle_t* handle, mfrc522_rx_gain_t gain);
uint8_t mfrc522_get_rx_gain(mfrc522_handle_t* handle, mfrc522_rx_gain_t* gain);
uint8_t mfrc522_set_cwgsn(mfrc522_handle_t* handle, uint8_t n);
uint8_t mfrc522_get_cwgsn(mfrc522_handle_t* handle, uint8_t* n);
uint8_t mfrc522_set_modgsn(mfrc522_handle_t* handle, uint8_t n);
uint8_t mfrc522_get_modgsn(mfrc522_handle_t* handle, uint8_t* n);
uint8_t mfrc522_set_cwgsp(mfrc522_handle_t* handle, uint8_t n);
uint8_t mfrc522_get_cwgsp(mfrc522_handle_t* handle, uint8_t* n);
uint8_t mfrc522_set_modgsp(mfrc522_handle_t* handle, uint8_t n);
uint8_t mfrc522_get_modgsp(mfrc522_handle_t* handle, uint8_t* n);
uint8_t mfrc522_set_timer_auto(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_timer_auto(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_timer_gated_mode(mfrc522_handle_t* handle, mfrc522_timer_gated_mode_t mode);
uint8_t mfrc522_get_timer_gated_mode(mfrc522_handle_t* handle, mfrc522_timer_gated_mode_t* mode);
uint8_t mfrc522_set_timer_auto_restart(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_timer_auto_restart(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_timer_prescaler(mfrc522_handle_t* handle, uint16_t t);
uint8_t mfrc522_get_timer_prescaler(mfrc522_handle_t* handle, uint16_t* t);
uint8_t mfrc522_set_timer_reload(mfrc522_handle_t* handle, uint16_t reload);
uint8_t mfrc522_get_timer_reload(mfrc522_handle_t* handle, uint16_t* reload);
uint8_t mfrc522_get_timer_counter(mfrc522_handle_t* handle, uint16_t* cnt);
uint8_t mfrc522_set_test_bus_signal_1(mfrc522_handle_t* handle, uint8_t s);
uint8_t mfrc522_get_test_bus_signal_1(mfrc522_handle_t* handle, uint8_t* s);
uint8_t mfrc522_set_test_bus_signal_2(mfrc522_handle_t* handle, uint8_t s);
uint8_t mfrc522_get_test_bus_signal_2(mfrc522_handle_t* handle, uint8_t* s);
uint8_t mfrc522_set_test_bus_flip(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_bus_flip(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_test_prbs9(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_prbs9(mfrc522_handle_t* handle, mfrc522_bool_t* enable);

uint8_t mfrc522_set_test_prbs15(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_prbs15(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_test_rs232_line(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_rs232_line(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_test_pin_enable(mfrc522_handle_t* handle, uint8_t pin);
uint8_t mfrc522_get_test_pin_enable(mfrc522_handle_t* handle, uint8_t* pin);
uint8_t mfrc522_set_test_port_io(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_port_io(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_test_pin_value(mfrc522_handle_t* handle, uint8_t value);
uint8_t mfrc522_get_test_pin_value(mfrc522_handle_t* handle, uint8_t* value);
uint8_t mfrc522_get_test_bus(mfrc522_handle_t* handle, uint8_t* bus);
uint8_t mfrc522_set_test_amp_rcv(mfrc522_handle_t* handle, mfrc522_bool_t enable);
uint8_t mfrc522_get_test_amp_rcv(mfrc522_handle_t* handle, mfrc522_bool_t* enable);
uint8_t mfrc522_set_self_test(mfrc522_handle_t* handle, uint8_t test);
uint8_t mfrc522_get_self_test(mfrc522_handle_t* handle, uint8_t* test);
uint8_t mfrc522_get_version(mfrc522_handle_t* handle, uint8_t* id, uint8_t* version);
uint8_t mfrc522_set_test_analog_control_aux_1(mfrc522_handle_t* handle, mfrc522_test_analog_control_t control);
uint8_t mfrc522_get_test_analog_control_aux_1(mfrc522_handle_t* handle, mfrc522_test_analog_control_t* control);
uint8_t mfrc522_set_test_analog_control_aux_2(mfrc522_handle_t* handle, mfrc522_test_analog_control_t control);
uint8_t mfrc522_get_test_analog_control_aux_2(mfrc522_handle_t* handle, mfrc522_test_analog_control_t* control);
uint8_t mfrc522_set_test_dac_1(mfrc522_handle_t* handle, uint8_t dac);
uint8_t mfrc522_get_test_dac_1(mfrc522_handle_t* handle, uint8_t* dac);
uint8_t mfrc522_set_test_dac_2(mfrc522_handle_t* handle, uint8_t dac);
uint8_t mfrc522_get_test_dac_2(mfrc522_handle_t* handle, uint8_t* dac);
uint8_t mfrc522_get_test_adc(mfrc522_handle_t* handle, uint8_t* adc_i, uint8_t* adc_q);
uint8_t mfrc522_set_reg(mfrc522_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t mfrc522_get_reg(mfrc522_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
