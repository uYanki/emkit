
#ifndef DRIVER_MFRC522_REGISTER_TEST_H
#define DRIVER_MFRC522_REGISTER_TEST_H
#include "driver_mfrc522_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mfrc522_register_test(mfrc522_interface_t interface, uint8_t addr);
#ifdef __cplusplus
}
#endif
#endif
