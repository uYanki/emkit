
#ifndef DRIVER_INA219_REGISTER_TEST_H
#define DRIVER_INA219_REGISTER_TEST_H
#include "driver_ina219_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t ina219_register_test(ina219_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
