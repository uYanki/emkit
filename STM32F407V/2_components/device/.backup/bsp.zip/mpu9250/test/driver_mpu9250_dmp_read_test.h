
#ifndef DRIVER_MPU9250_DMP_READ_TEST_H
#define DRIVER_MPU9250_DMP_READ_TEST_H
#include "driver_mpu9250_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mpu9250_dmp_read_test_irq_handler(void);
uint8_t mpu9250_dmp_read_test(mpu9250_interface_t interface, mpu9250_address_t addr, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
