
#ifndef DRIVER_MPU9250_REGISTER_TEST_H
#define DRIVER_MPU9250_REGISTER_TEST_H
#include "driver_mpu9250_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mpu9250_register_test(mpu9250_interface_t interface, mpu9250_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
