
#ifndef DRIVER_MPU9250_DMP_TAP_ORIENT_MOTION_TEST_H
#define DRIVER_MPU9250_DMP_TAP_ORIENT_MOTION_TEST_H
#include "driver_mpu9250_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t mpu9250_dmp_tap_orient_motion_test_irq_handler(void);
uint8_t mpu9250_dmp_tap_orient_motion_test(mpu9250_interface_t interface, mpu9250_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
