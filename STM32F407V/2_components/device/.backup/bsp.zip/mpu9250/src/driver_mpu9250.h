
#ifndef DRIVER_MPU9250_H
#define DRIVER_MPU9250_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    MPU9250_INTERFACE_IIC = 0x00,  // iic interface function
    MPU9250_INTERFACE_SPI = 0x01,  // spi interface function
} mpu9250_interface_t;
typedef enum {
    MPU9250_ADDRESS_AD0_LOW  = 0xD0,  // AD0 pin set LOW
    MPU9250_ADDRESS_AD0_HIGH = 0xD2,  // AD0 pin set HIGH
} mpu9250_address_t;
typedef enum {
    MPU9250_BOOL_FALSE = 0x00,  // disable function
    MPU9250_BOOL_TRUE  = 0x01,  // enable function
} mpu9250_bool_t;
typedef enum {
    MPU9250_SOURCE_ACC_X  = 0x05,  // accelerometer x
    MPU9250_SOURCE_ACC_Y  = 0x04,  // accelerometer y
    MPU9250_SOURCE_ACC_Z  = 0x03,  // accelerometer z
    MPU9250_SOURCE_GYRO_X = 0x02,  // gyroscope x
    MPU9250_SOURCE_GYRO_Y = 0x01,  // gyroscope y
    MPU9250_SOURCE_GYRO_Z = 0x00,  // gyroscope z
} mpu9250_source_t;
typedef enum {
    MPU9250_CLOCK_SOURCE_INTERNAL_20MHZ = 0x00,  // internal 20MHz
    MPU9250_CLOCK_SOURCE_PLL            = 0x01,  // pll reference
    MPU9250_CLOCK_SOURCE_STOP_CLOCK     = 0x07,  // stop the clock
} mpu9250_clock_source_t;
typedef enum {
    MPU9250_SIGNAL_PATH_RESET_TEMP  = 0x00,  // temperature sensor analog and digital signal paths
    MPU9250_SIGNAL_PATH_RESET_ACCEL = 0x01,  // accelerometer analog and digital signal paths
    MPU9250_SIGNAL_PATH_RESET_GYRO  = 0x02,  // gyroscope analog and digital signal paths
} mpu9250_signal_path_reset_t;
typedef enum {
    MPU9250_EXTERN_SYNC_INPUT_DISABLED = 0x00,  // input disabled
    MPU9250_EXTERN_SYNC_TEMP_OUT_L     = 0x01,  // temp out low
    MPU9250_EXTERN_SYNC_GYRO_XOUT_L    = 0x02,  // gyro xout low
    MPU9250_EXTERN_SYNC_GYRO_YOUT_L    = 0x03,  // gyro yout low
    MPU9250_EXTERN_SYNC_GYRO_ZOUT_L    = 0x04,  // gyro zout low
    MPU9250_EXTERN_SYNC_ACCEL_XOUT_L   = 0x05,  // accel xout low
    MPU9250_EXTERN_SYNC_ACCEL_YOUT_L   = 0x06,  // accel yout low
    MPU9250_EXTERN_SYNC_ACCEL_ZOUT_L   = 0x07,  // accel zout low
} mpu9250_extern_sync_t;
typedef enum                           // fchoice_b              gyroscope                    temperature
{                                      //            bandwidth(Hz) fs(KHz) delay(ms)   bandwidth(Hz) delay(ms)
                                       //  11/01          8800        32     0.064         4000        0.04
                                       //   10            3600        32     0.11         4000         0.04
    MPU9250_LOW_PASS_FILTER_0 = 0x00,  //   00            250         8      0.97          4000        0.04
    MPU9250_LOW_PASS_FILTER_1 = 0x01,  //   00            184         1      2.9           188         1.9
    MPU9250_LOW_PASS_FILTER_2 = 0x02,  //   00            92          1      3.9           98          2.8
    MPU9250_LOW_PASS_FILTER_3 = 0x03,  //   00            41          1      5.9           42          4.8
    MPU9250_LOW_PASS_FILTER_4 = 0x04,  //   00            20          1      9.9           20          8.3
    MPU9250_LOW_PASS_FILTER_5 = 0x05,  //   00            10          1      17.85         10          13.4
    MPU9250_LOW_PASS_FILTER_6 = 0x06,  //   00            5           1      33.48         5           18.6
    MPU9250_LOW_PASS_FILTER_7 = 0x07,  //   00            3600        8      0.17          4000        0.04
} mpu9250_low_pass_filter_t;
typedef enum                                         // accelerometer fchoice              accelerometer
{                                                    //                          3db BW(Hz) rate(KHz) delay(ms)
                                                     //              1             1046         4      0.503
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_0 = 0x00,  //              0             218.1        1      1.88
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_1 = 0x01,  //              0             218.1        1      1.88
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_2 = 0x02,  //              0             99           1      2.88
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_3 = 0x03,  //              0             44.8         1      4.88
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_4 = 0x04,  //              0             21.2         1      8.87
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_5 = 0x05,  //              0             10.2         1      16.83
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_6 = 0x06,  //              0             5.05         1      32.48
    MPU9250_ACCELEROMETER_LOW_PASS_FILTER_7 = 0x07,  //              0             420          1      1.38
} mpu9250_accelerometer_low_pass_filter_t;
typedef enum {
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_0P24  = 0x00,  // 0.24Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_0P49  = 0x01,  // 0.49Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_0P98  = 0x02,  // 0.98Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_1P95  = 0x03,  // 1.95Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_3P91  = 0x04,  // 3.91Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_7P81  = 0x05,  // 7.81Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_15P63 = 0x06,  // 15.63Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_31P25 = 0x07,  // 31.25Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_62P50 = 0x08,  // 62.50Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_125   = 0x09,  // 125Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_250   = 0x0A,  // 250Hz
    MPU9250_LOW_POWER_ACCEL_OUTPUT_RATE_500   = 0x0B,  // 500Hz
} mpu9250_low_power_accel_output_rate_t;
typedef enum {
    MPU9250_AXIS_Z = 0x05,  // z
    MPU9250_AXIS_Y = 0x06,  // y
    MPU9250_AXIS_X = 0x07,  // x
} mpu9250_axis_t;
typedef enum {
    MPU9250_GYROSCOPE_RANGE_250DPS  = 0x00,  // ±250 dps
    MPU9250_GYROSCOPE_RANGE_500DPS  = 0x01,  // ±500 dps
    MPU9250_GYROSCOPE_RANGE_1000DPS = 0x02,  // ±1000 dps
    MPU9250_GYROSCOPE_RANGE_2000DPS = 0x03,  // ±2000 dps
} mpu9250_gyroscope_range_t;
typedef enum {
    MPU9250_ACCELEROMETER_RANGE_2G  = 0x00,  // ±2 g
    MPU9250_ACCELEROMETER_RANGE_4G  = 0x01,  // ±4 g
    MPU9250_ACCELEROMETER_RANGE_8G  = 0x02,  // ±8 g
    MPU9250_ACCELEROMETER_RANGE_16G = 0x03,  // ±16 g
} mpu9250_accelerometer_range_t;
typedef enum {
    MPU9250_FIFO_TEMP  = 0x07,  // temperature
    MPU9250_FIFO_XG    = 0x06,  // gyroscope x
    MPU9250_FIFO_YG    = 0x05,  // gyroscope y
    MPU9250_FIFO_ZG    = 0x04,  // gyroscope z
    MPU9250_FIFO_ACCEL = 0x03,  // accelerometer
} mpu9250_fifo_t;
typedef enum {
    MPU9250_FIFO_MODE_STREAM = 0x00,  /**< when the fifo is full, additional writes will be written to the fifo,
                                           replacing the oldest data */
    MPU9250_FIFO_MODE_NORMAL = 0x01,  // when the fifo is full, additional writes will not be written to fifo
} mpu9250_fifo_mode;
typedef enum {
    MPU9250_PIN_LEVEL_HIGH = 0x00,  // active low
    MPU9250_PIN_LEVEL_LOW  = 0x01,  // active high
} mpu9250_pin_level_t;
typedef enum {
    MPU9250_PIN_TYPE_PUSH_PULL  = 0x00,  // push pull
    MPU9250_PIN_TYPE_OPEN_DRAIN = 0x01,  // open drain
} mpu9250_pin_type_t;
typedef enum {
    MPU9250_INTERRUPT_MOTION        = 6,  // motion
    MPU9250_INTERRUPT_FIFO_OVERFLOW = 4,  // fifo overflow
    MPU9250_INTERRUPT_FSYNC_INT     = 3,  // fsync int
    MPU9250_INTERRUPT_DMP           = 1,  // dmp
    MPU9250_INTERRUPT_DATA_READY    = 0,  // data ready
} mpu9250_interrupt_t;
typedef enum {
    MPU9250_IIC_SLAVE_0 = 0x00,  // slave0
    MPU9250_IIC_SLAVE_1 = 0x01,  // slave1
    MPU9250_IIC_SLAVE_2 = 0x02,  // slave2
    MPU9250_IIC_SLAVE_3 = 0x03,  // slave3
    MPU9250_IIC_SLAVE_4 = 0x04,  // slave4
} mpu9250_iic_slave_t;
typedef enum {
    MPU9250_IIC_CLOCK_348_KHZ = 0x00,  // 348 kHz
    MPU9250_IIC_CLOCK_333_KHZ = 0x01,  // 333 kHz
    MPU9250_IIC_CLOCK_320_KHZ = 0x02,  // 320 kHz
    MPU9250_IIC_CLOCK_308_KHZ = 0x03,  // 308 kHz
    MPU9250_IIC_CLOCK_296_KHZ = 0x04,  // 296 kHz
    MPU9250_IIC_CLOCK_286_KHZ = 0x05,  // 286 kHz
    MPU9250_IIC_CLOCK_276_KHZ = 0x06,  // 276 kHz
    MPU9250_IIC_CLOCK_267_KHZ = 0x07,  // 267 kHz
    MPU9250_IIC_CLOCK_258_KHZ = 0x08,  // 258 kHz
    MPU9250_IIC_CLOCK_500_KHZ = 0x09,  // 500 kHz
    MPU9250_IIC_CLOCK_471_KHZ = 0x0A,  // 471 kHz
    MPU9250_IIC_CLOCK_444_KHZ = 0x0B,  // 444 kHz
    MPU9250_IIC_CLOCK_421_KHZ = 0x0C,  // 421 kHz
    MPU9250_IIC_CLOCK_400_KHZ = 0x0D,  // 400 kHz
    MPU9250_IIC_CLOCK_381_KHZ = 0x0E,  // 381 kHz
    MPU9250_IIC_CLOCK_364_KHZ = 0x0F,  // 364 kHz
} mpu9250_iic_clock_t;
typedef enum {
    MPU9250_IIC_READ_MODE_RESTART        = 0x00,  // restart
    MPU9250_IIC_READ_MODE_STOP_AND_START = 0x01,  // stop and start
} mpu9250_iic_read_mode_t;
typedef enum {
    MPU9250_IIC_MODE_WRITE = 0x00,  // write
    MPU9250_IIC_MODE_READ  = 0x01,  // read
} mpu9250_iic_mode_t;
typedef enum {
    MPU9250_IIC_TRANSACTION_MODE_DATA     = 0x00,  // data only
    MPU9250_IIC_TRANSACTION_MODE_REG_DATA = 0x01,  // write a register address prior to reading or writing data
} mpu9250_iic_transaction_mode_t;
typedef enum {
    MPU9250_IIC4_TRANSACTION_MODE_DATA = 0x00,  // data only
    MPU9250_IIC4_TRANSACTION_MODE_REG  = 0x01,  // register only
} mpu9250_iic4_transaction_mode_t;
typedef enum {
    MPU9250_IIC_GROUP_ORDER_EVEN = 0x00, /**< when cleared to 0, bytes from register addresses 0 and 1, 2 and 3,
                                              etc (even, then odd register addresses) are paired to form a word */
    MPU9250_IIC_GROUP_ORDER_ODD = 0x01,  /**< when set to 1, bytes from register addresses are paired 1 and 2, 3 and 4,
                                              etc (odd, then even register addresses) are paired to form a word */
} mpu9250_iic_group_order_t;
typedef enum {
    MPU9250_IIC_STATUS_PASS_THROUGH  = 0x80,  // pass through
    MPU9250_IIC_STATUS_IIC_SLV4_DONE = 0x40,  // slave4 done
    MPU9250_IIC_STATUS_IIC_LOST_ARB  = 0x20,  // lost arbitration
    MPU9250_IIC_STATUS_IIC_SLV4_NACK = 0x10,  // slave4 nack
    MPU9250_IIC_STATUS_IIC_SLV3_NACK = 0x08,  // slave3 nack
    MPU9250_IIC_STATUS_IIC_SLV2_NACK = 0x04,  // slave2 nack
    MPU9250_IIC_STATUS_IIC_SLV1_NACK = 0x02,  // slave1 nack
    MPU9250_IIC_STATUS_IIC_SLV0_NACK = 0x01,  // slave0 nack
} mpu9250_iic_status_t;
typedef enum {
    MPU9250_IIC_DELAY_ES_SHADOW = 7, /**< delays shadowing of external sensor data until
                                          all data has been received */
    MPU9250_IIC_DELAY_SLAVE_4 = 4,   // slave 4
    MPU9250_IIC_DELAY_SLAVE_3 = 3,   // slave 3
    MPU9250_IIC_DELAY_SLAVE_2 = 2,   // slave 2
    MPU9250_IIC_DELAY_SLAVE_1 = 1,   // slave 1
    MPU9250_IIC_DELAY_SLAVE_0 = 0,   // slave 0
} mpu9250_iic_delay_t;
typedef enum {
    MPU9250_MAGNETOMETER_STATUS1_DRDY = (1 << 0),  // data is ready
    MPU9250_MAGNETOMETER_STATUS1_DOR  = (1 << 1),  // data overrun
} mpu9250_magnetometer_status1_t;
typedef enum {
    MPU9250_MAGNETOMETER_STATUS2_HOFL = (1 << 3),  // magnetic sensor overflow occurred
    MPU9250_MAGNETOMETER_STATUS2_BITM = (1 << 4),  // 0: 14bits / 1: 16bits
} mpu9250_magnetometer_status2_t;
typedef enum {
    MPU9250_MAGNETOMETER_MODE_POWER_DOWN  = 0x00,  // power down mode
    MPU9250_MAGNETOMETER_MODE_SINGLE      = 0x01,  // single measurement mode
    MPU9250_MAGNETOMETER_MODE_CONTINUOUS1 = 0x02,  // continuous measurement mode 1
    MPU9250_MAGNETOMETER_MODE_CONTINUOUS2 = 0x06,  // continuous measurement mode 2
    MPU9250_MAGNETOMETER_MODE_EXT_TRIGGER = 0x04,  // external trigger measurement mode
    MPU9250_MAGNETOMETER_MODE_SELF_TEST   = 0x08,  // self test mode
    MPU9250_MAGNETOMETER_MODE_FUSE_ROM    = 0x0F,  // fuse rom access mode
} mpu9250_magnetometer_mode_t;
typedef enum {
    MPU9250_MAGNETOMETER_BITS_14 = 0x00,  // 14 bits output
    MPU9250_MAGNETOMETER_BITS_16 = 0x01,  // 16 bits output
} mpu9250_magnetometer_bits_t;
typedef enum {
    MPU9250_DMP_INTERRUPT_MODE_CONTINUOUS = 0x00,  // continuous mode
    MPU9250_DMP_INTERRUPT_MODE_GESTURE    = 0x01,  // gesture mode
} mpu9250_dmp_interrupt_mode_t;
typedef enum {
    MPU9250_DMP_FEATURE_TAP            = 0x001,  // feature tap
    MPU9250_DMP_FEATURE_ORIENT         = 0x002,  // feature orient
    MPU9250_DMP_FEATURE_3X_QUAT        = 0x004,  // feature 3x quat
    MPU9250_DMP_FEATURE_PEDOMETER      = 0x008,  // feature pedometer
    MPU9250_DMP_FEATURE_6X_QUAT        = 0x010,  // feature 6x quat
    MPU9250_DMP_FEATURE_GYRO_CAL       = 0x020,  // feature gyro cal
    MPU9250_DMP_FEATURE_SEND_RAW_ACCEL = 0x040,  // feature send raw accel
    MPU9250_DMP_FEATURE_SEND_RAW_GYRO  = 0x080,  // feature send raw gyro
    MPU9250_DMP_FEATURE_SEND_CAL_GYRO  = 0x100,  // feature send cal gyro
} mpu9250_dmp_feature_t;
typedef enum {
    MPU9250_DMP_TAP_X_UP   = 0x01,  // tap x up
    MPU9250_DMP_TAP_X_DOWN = 0x02,  // tap x down
    MPU9250_DMP_TAP_Y_UP   = 0x03,  // tap y up
    MPU9250_DMP_TAP_Y_DOWN = 0x04,  // tap y down
    MPU9250_DMP_TAP_Z_UP   = 0x05,  // tap z up
    MPU9250_DMP_TAP_Z_DOWN = 0x06,  // tap z down
} mpu9250_dmp_tap_t;
typedef enum {
    MPU9250_DMP_ORIENT_PORTRAIT          = 0x00,  // portrait
    MPU9250_DMP_ORIENT_LANDSCAPE         = 0x01,  // landscape
    MPU9250_DMP_ORIENT_REVERSE_PORTRAIT  = 0x02,  // reverse portrait
    MPU9250_DMP_ORIENT_REVERSE_LANDSCAPE = 0x03,  // reverse landscape
} mpu9250_dmp_orient_t;
typedef struct mpu9250_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t  inited;      // inited flag
    uint8_t  mag_inited;  // magnetometer inited flag
    uint8_t  mag_asa[3];  // magnetometer asa
    uint8_t  iic_spi;     // iic spi interface type
    uint8_t  dmp_inited;  // dmp inited flag
    uint16_t orient;      // orient
    uint16_t mask;        // mask
    uint8_t  buf[1024];   // inner buffer
} mpu9250_handle_t;

uint8_t mpu9250_info(mpu9250_info_t* info);
uint8_t mpu9250_set_interface(mpu9250_handle_t* handle, mpu9250_interface_t interface);
uint8_t mpu9250_get_interface(mpu9250_handle_t* handle, mpu9250_interface_t* interface);
uint8_t mpu9250_set_addr_pin(mpu9250_handle_t* handle, mpu9250_address_t addr_pin);
uint8_t mpu9250_get_addr_pin(mpu9250_handle_t* handle, mpu9250_address_t* addr_pin);
uint8_t mpu9250_irq_handler(mpu9250_handle_t* handle);
uint8_t mpu9250_init(mpu9250_handle_t* handle);
uint8_t mpu9250_deinit(mpu9250_handle_t* handle);
uint8_t mpu9250_read(mpu9250_handle_t* handle,
                     int16_t (*accel_raw)[3],
                     float (*accel_g)[3],
                     int16_t (*gyro_raw)[3],
                     float (*gyro_dps)[3],
                     int16_t (*mag_raw)[3],
                     float (*mag_ut)[3],
                     uint16_t* len);
uint8_t mpu9250_read_temperature(mpu9250_handle_t* handle, int16_t(*raw), float* degrees);
uint8_t mpu9250_set_fifo(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_fifo(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_force_fifo_reset(mpu9250_handle_t* handle);
uint8_t mpu9250_set_iic_master(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_master(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_disable_iic_slave(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_disable_iic_slave(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_fifo_reset(mpu9250_handle_t* handle);
uint8_t mpu9250_get_fifo_reset(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_iic_master_reset(mpu9250_handle_t* handle);
uint8_t mpu9250_get_iic_master_reset(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_sensor_reset(mpu9250_handle_t* handle);
uint8_t mpu9250_get_sensor_reset(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_device_reset(mpu9250_handle_t* handle);
uint8_t mpu9250_get_device_reset(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_clock_source(mpu9250_handle_t* handle, mpu9250_clock_source_t clock_source);
uint8_t mpu9250_get_clock_source(mpu9250_handle_t* handle, mpu9250_clock_source_t* clock_source);
uint8_t mpu9250_set_ptat(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_ptat(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_cycle_wake_up(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_cycle_wake_up(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_sleep(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_sleep(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_gyro_standby(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_gyro_standby(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_standby_mode(mpu9250_handle_t* handle, mpu9250_source_t source, mpu9250_bool_t enable);
uint8_t mpu9250_get_standby_mode(mpu9250_handle_t* handle, mpu9250_source_t source, mpu9250_bool_t* enable);
uint8_t mpu9250_get_fifo_count(mpu9250_handle_t* handle, uint16_t* count);
uint8_t mpu9250_fifo_get(mpu9250_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t mpu9250_fifo_set(mpu9250_handle_t* handle, uint8_t* buf, uint16_t len);
uint8_t mpu9250_set_signal_path_reset(mpu9250_handle_t* handle, mpu9250_signal_path_reset_t path);
uint8_t mpu9250_set_sample_rate_divider(mpu9250_handle_t* handle, uint8_t d);
uint8_t mpu9250_get_sample_rate_divider(mpu9250_handle_t* handle, uint8_t* d);
uint8_t mpu9250_set_extern_sync(mpu9250_handle_t* handle, mpu9250_extern_sync_t sync);
uint8_t mpu9250_get_extern_sync(mpu9250_handle_t* handle, mpu9250_extern_sync_t* sync);
uint8_t mpu9250_set_low_pass_filter(mpu9250_handle_t* handle, mpu9250_low_pass_filter_t filter);
uint8_t mpu9250_get_low_pass_filter(mpu9250_handle_t* handle, mpu9250_low_pass_filter_t* filter);
uint8_t mpu9250_set_fifo_mode(mpu9250_handle_t* handle, mpu9250_fifo_mode mode);
uint8_t mpu9250_get_fifo_mode(mpu9250_handle_t* handle, mpu9250_fifo_mode* mode);
uint8_t mpu9250_set_gyroscope_test(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t enable);
uint8_t mpu9250_get_gyroscope_test(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t* enable);
uint8_t mpu9250_set_gyroscope_range(mpu9250_handle_t* handle, mpu9250_gyroscope_range_t range);
uint8_t mpu9250_get_gyroscope_range(mpu9250_handle_t* handle, mpu9250_gyroscope_range_t* range);
uint8_t mpu9250_set_gyroscope_choice(mpu9250_handle_t* handle, uint8_t choice);
uint8_t mpu9250_get_gyroscope_choice(mpu9250_handle_t* handle, uint8_t* choice);
uint8_t mpu9250_set_accelerometer_test(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t enable);
uint8_t mpu9250_get_accelerometer_test(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t* enable);
uint8_t mpu9250_set_accelerometer_range(mpu9250_handle_t* handle, mpu9250_accelerometer_range_t range);
uint8_t mpu9250_get_accelerometer_range(mpu9250_handle_t* handle, mpu9250_accelerometer_range_t* range);
uint8_t mpu9250_set_fifo_1024kb(mpu9250_handle_t* handle);
uint8_t mpu9250_set_accelerometer_choice(mpu9250_handle_t* handle, uint8_t choice);
uint8_t mpu9250_get_accelerometer_choice(mpu9250_handle_t* handle, uint8_t* choice);
uint8_t mpu9250_set_accelerometer_low_pass_filter(mpu9250_handle_t* handle, mpu9250_accelerometer_low_pass_filter_t filter);
uint8_t mpu9250_get_accelerometer_low_pass_filter(mpu9250_handle_t* handle, mpu9250_accelerometer_low_pass_filter_t* filter);
uint8_t mpu9250_set_low_power_accel_output_rate(mpu9250_handle_t* handle, mpu9250_low_power_accel_output_rate_t rate);
uint8_t mpu9250_get_low_power_accel_output_rate(mpu9250_handle_t* handle, mpu9250_low_power_accel_output_rate_t* rate);
uint8_t mpu9250_set_wake_on_motion(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_wake_on_motion(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_accel_compare_with_previous_sample(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_accel_compare_with_previous_sample(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_accelerometer_x_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_accelerometer_x_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_set_accelerometer_y_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_accelerometer_y_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_set_accelerometer_z_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_accelerometer_z_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_accelerometer_offset_convert_to_register(mpu9250_handle_t* handle, float mg, int16_t* reg);
uint8_t mpu9250_accelerometer_offset_convert_to_data(mpu9250_handle_t* handle, int16_t reg, float* mg);
uint8_t mpu9250_set_gyro_x_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_gyro_x_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_set_gyro_y_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_gyro_y_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_set_gyro_z_offset(mpu9250_handle_t* handle, int16_t offset);
uint8_t mpu9250_get_gyro_z_offset(mpu9250_handle_t* handle, int16_t* offset);
uint8_t mpu9250_gyro_offset_convert_to_register(mpu9250_handle_t* handle, float dps, int16_t* reg);
uint8_t mpu9250_gyro_offset_convert_to_data(mpu9250_handle_t* handle, int16_t reg, float* dps);
uint8_t mpu9250_set_fifo_enable(mpu9250_handle_t* handle, mpu9250_fifo_t fifo, mpu9250_bool_t enable);
uint8_t mpu9250_get_fifo_enable(mpu9250_handle_t* handle, mpu9250_fifo_t fifo, mpu9250_bool_t* enable);
uint8_t mpu9250_set_interrupt_level(mpu9250_handle_t* handle, mpu9250_pin_level_t level);
uint8_t mpu9250_get_interrupt_level(mpu9250_handle_t* handle, mpu9250_pin_level_t* level);
uint8_t mpu9250_set_interrupt_pin_type(mpu9250_handle_t* handle, mpu9250_pin_type_t type);
uint8_t mpu9250_get_interrupt_pin_type(mpu9250_handle_t* handle, mpu9250_pin_type_t* type);
uint8_t mpu9250_set_interrupt_latch(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_interrupt_latch(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_interrupt_read_clear(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_interrupt_read_clear(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_fsync_interrupt_level(mpu9250_handle_t* handle, mpu9250_pin_level_t level);
uint8_t mpu9250_get_fsync_interrupt_level(mpu9250_handle_t* handle, mpu9250_pin_level_t* level);
uint8_t mpu9250_set_fsync_interrupt(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_fsync_interrupt(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_bypass(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_bypass(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_interrupt(mpu9250_handle_t* handle, mpu9250_interrupt_t type, mpu9250_bool_t enable);
uint8_t mpu9250_get_interrupt(mpu9250_handle_t* handle, mpu9250_interrupt_t type, mpu9250_bool_t* enable);
uint8_t mpu9250_get_interrupt_status(mpu9250_handle_t* handle, uint8_t* status);
uint8_t mpu9250_set_gyroscope_x_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_gyroscope_x_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_gyroscope_y_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_gyroscope_y_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_gyroscope_z_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_gyroscope_z_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_accelerometer_x_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_accelerometer_x_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_accelerometer_y_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_accelerometer_y_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_accelerometer_z_test(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_accelerometer_z_test(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_motion_threshold(mpu9250_handle_t* handle, uint8_t threshold);
uint8_t mpu9250_get_motion_threshold(mpu9250_handle_t* handle, uint8_t* threshold);
uint8_t mpu9250_motion_threshold_convert_to_register(mpu9250_handle_t* handle, float mg, uint8_t* reg);
uint8_t mpu9250_motion_threshold_convert_to_data(mpu9250_handle_t* handle, uint8_t reg, float* mg);
uint8_t mpu9250_self_test(mpu9250_handle_t* handle, int32_t gyro_offset_raw[3], int32_t accel_offset_raw[3]);
uint8_t mpu9250_set_iic_clock(mpu9250_handle_t* handle, mpu9250_iic_clock_t clk);
uint8_t mpu9250_get_iic_clock(mpu9250_handle_t* handle, mpu9250_iic_clock_t* clk);
uint8_t mpu9250_set_iic_multi_master(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_multi_master(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_wait_for_external_sensor(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_wait_for_external_sensor(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_read_mode(mpu9250_handle_t* handle, mpu9250_iic_read_mode_t mode);
uint8_t mpu9250_get_iic_read_mode(mpu9250_handle_t* handle, mpu9250_iic_read_mode_t* mode);
uint8_t mpu9250_set_iic_fifo_enable(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_fifo_enable(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_mode(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_mode_t mode);
uint8_t mpu9250_get_iic_mode(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_mode_t* mode);
uint8_t mpu9250_set_iic_address(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t addr_7bit);
uint8_t mpu9250_get_iic_address(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t* addr_7bit);
uint8_t mpu9250_set_iic_register(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t reg);
uint8_t mpu9250_get_iic_register(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t* reg);
uint8_t mpu9250_set_iic_data_out(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t data);
uint8_t mpu9250_get_iic_data_out(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t* data);
uint8_t mpu9250_set_iic_enable(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_enable(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_byte_swap(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_byte_swap(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic_transaction_mode(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_transaction_mode_t mode);
uint8_t mpu9250_get_iic_transaction_mode(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_transaction_mode_t* mode);
uint8_t mpu9250_set_iic_group_order(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_group_order_t order);
uint8_t mpu9250_get_iic_group_order(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, mpu9250_iic_group_order_t* order);
uint8_t mpu9250_set_iic_transferred_len(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t len);
uint8_t mpu9250_get_iic_transferred_len(mpu9250_handle_t* handle, mpu9250_iic_slave_t slave, uint8_t* len);
uint8_t mpu9250_get_iic_status(mpu9250_handle_t* handle, uint8_t* status);
uint8_t mpu9250_set_iic_delay_enable(mpu9250_handle_t* handle, mpu9250_iic_delay_t delay, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic_delay_enable(mpu9250_handle_t* handle, mpu9250_iic_delay_t delay, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic4_enable(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic4_enable(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic4_interrupt(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_get_iic4_interrupt(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_set_iic4_transaction_mode(mpu9250_handle_t* handle, mpu9250_iic4_transaction_mode_t mode);
uint8_t mpu9250_get_iic4_transaction_mode(mpu9250_handle_t* handle, mpu9250_iic4_transaction_mode_t* mode);
uint8_t mpu9250_set_iic_delay(mpu9250_handle_t* handle, uint8_t delay);
uint8_t mpu9250_get_iic_delay(mpu9250_handle_t* handle, uint8_t* delay);
uint8_t mpu9250_set_iic4_data_out(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_iic4_data_out(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_set_iic4_data_in(mpu9250_handle_t* handle, uint8_t data);
uint8_t mpu9250_get_iic4_data_in(mpu9250_handle_t* handle, uint8_t* data);
uint8_t mpu9250_read_extern_sensor_data(mpu9250_handle_t* handle, uint8_t* data, uint8_t len);
uint8_t mpu9250_dmp_load_firmware(mpu9250_handle_t* handle);
uint8_t mpu9250_dmp_set_pedometer_walk_time(mpu9250_handle_t* handle, uint32_t ms);
uint8_t mpu9250_dmp_get_pedometer_walk_time(mpu9250_handle_t* handle, uint32_t* ms);
uint8_t mpu9250_dmp_set_pedometer_step_count(mpu9250_handle_t* handle, uint32_t count);
uint8_t mpu9250_dmp_get_pedometer_step_count(mpu9250_handle_t* handle, uint32_t* count);
uint8_t mpu9250_dmp_set_shake_reject_timeout(mpu9250_handle_t* handle, uint16_t ms);
uint8_t mpu9250_dmp_get_shake_reject_timeout(mpu9250_handle_t* handle, uint16_t* ms);
uint8_t mpu9250_dmp_set_shake_reject_time(mpu9250_handle_t* handle, uint16_t ms);
uint8_t mpu9250_dmp_get_shake_reject_time(mpu9250_handle_t* handle, uint16_t* ms);
uint8_t mpu9250_dmp_set_shake_reject_thresh(mpu9250_handle_t* handle, uint16_t dps);
uint8_t mpu9250_dmp_get_shake_reject_thresh(mpu9250_handle_t* handle, uint16_t* dps);
uint8_t mpu9250_dmp_set_tap_time_multi(mpu9250_handle_t* handle, uint16_t ms);
uint8_t mpu9250_dmp_get_tap_time_multi(mpu9250_handle_t* handle, uint16_t* ms);
uint8_t mpu9250_dmp_set_tap_time(mpu9250_handle_t* handle, uint16_t ms);
uint8_t mpu9250_dmp_get_tap_time(mpu9250_handle_t* handle, uint16_t* ms);
uint8_t mpu9250_dmp_set_min_tap_count(mpu9250_handle_t* handle, uint8_t cnt);
uint8_t mpu9250_dmp_get_min_tap_count(mpu9250_handle_t* handle, uint8_t* cnt);
uint8_t mpu9250_dmp_set_gyro_calibrate(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_dmp_set_3x_quaternion(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_dmp_set_6x_quaternion(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_dmp_set_interrupt_mode(mpu9250_handle_t* handle, mpu9250_dmp_interrupt_mode_t mode);
uint8_t mpu9250_dmp_set_gyro_bias(mpu9250_handle_t* handle, int32_t bias[3]);
uint8_t mpu9250_dmp_set_accel_bias(mpu9250_handle_t* handle, int32_t bias[3]);
uint8_t mpu9250_dmp_set_orientation(mpu9250_handle_t* handle, int8_t mat[9]);
uint8_t mpu9250_dmp_set_feature(mpu9250_handle_t* handle, uint16_t mask);
uint8_t mpu9250_dmp_set_fifo_rate(mpu9250_handle_t* handle, uint16_t rate);
uint8_t mpu9250_dmp_get_fifo_rate(mpu9250_handle_t* handle, uint16_t* rate);
uint8_t mpu9250_dmp_set_tap_axes(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t enable);
uint8_t mpu9250_dmp_get_tap_axes(mpu9250_handle_t* handle, mpu9250_axis_t axis, mpu9250_bool_t* enable);
uint8_t mpu9250_dmp_set_tap_thresh(mpu9250_handle_t* handle, mpu9250_axis_t axis, uint16_t mg_ms);
uint8_t mpu9250_dmp_get_tap_thresh(mpu9250_handle_t* handle, mpu9250_axis_t axis, uint16_t* mg_ms);
uint8_t mpu9250_dmp_read(mpu9250_handle_t* handle,
                         int16_t (*accel_raw)[3],
                         float (*accel_g)[3],
                         int16_t (*gyro_raw)[3],
                         float (*gyro_dps)[3],
                         int32_t (*quat)[4],
                         float*    pitch,
                         float*    roll,
                         float*    yaw,
                         uint16_t* l);
uint8_t mpu9250_dmp_set_tap_callback(mpu9250_handle_t* handle, void (*callback)(uint8_t count, uint8_t direction));
uint8_t mpu9250_dmp_set_orient_callback(mpu9250_handle_t* handle, void (*callback)(uint8_t orientation));
uint8_t mpu9250_dmp_set_enable(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_dmp_gyro_accel_raw_offset_convert(mpu9250_handle_t* handle,
                                                  int32_t           gyro_offset_raw[3],
                                                  int32_t           accel_offset_raw[3],
                                                  int32_t           gyro_offset[3],
                                                  int32_t           accel_offset[3]);
uint8_t mpu9250_mag_init(mpu9250_handle_t* handle);
uint8_t mpu9250_mag_deinit(mpu9250_handle_t* handle);
uint8_t mpu9250_mag_read(mpu9250_handle_t* handle, int16_t mag_raw[3], float mag_ut[3]);
uint8_t mpu9250_mag_get_info(mpu9250_handle_t* handle, uint8_t* info);
uint8_t mpu9250_mag_get_status1(mpu9250_handle_t* handle, uint8_t* status);
uint8_t mpu9250_mag_get_status2(mpu9250_handle_t* handle, uint8_t* status);
uint8_t mpu9250_mag_set_mode(mpu9250_handle_t* handle, mpu9250_magnetometer_mode_t mode);
uint8_t mpu9250_mag_get_mode(mpu9250_handle_t* handle, mpu9250_magnetometer_mode_t* mode);
uint8_t mpu9250_mag_set_bits(mpu9250_handle_t* handle, mpu9250_magnetometer_bits_t bits);
uint8_t mpu9250_mag_get_bits(mpu9250_handle_t* handle, mpu9250_magnetometer_bits_t* bits);
uint8_t mpu9250_mag_set_reset(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_mag_get_reset(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_mag_set_self_test(mpu9250_handle_t* handle, mpu9250_bool_t enable);
uint8_t mpu9250_mag_get_self_test(mpu9250_handle_t* handle, mpu9250_bool_t* enable);
uint8_t mpu9250_mag_iic_disable(mpu9250_handle_t* handle);
uint8_t mpu9250_mag_get_asa(mpu9250_handle_t* handle, uint8_t asa[3]);
uint8_t mpu9250_mag_set_fifo_mode(mpu9250_handle_t* handle);
uint8_t mpu9250_set_reg(mpu9250_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t mpu9250_get_reg(mpu9250_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
