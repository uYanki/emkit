
#include "driver_lm75b_interrupt.h"
static lm75b_handle_t gs_handle;        // lm75b handle
uint8_t lm75b_interrupt_init(lm75b_address_t addr, lm75b_os_operation_mode_t mode, 
                             float low_threshold, float high_threshold)
{
    uint8_t res;
    uint16_t reg;
    /* link interface function */
    DRIVER_LM75B_LINK_INIT(&gs_handle, lm75b_handle_t);
    DRIVER_LM75B_LINK_IIC_INIT(&gs_handle, lm75b_interface_iic_init);
    DRIVER_LM75B_LINK_IIC_DEINIT(&gs_handle, lm75b_interface_iic_deinit);
    DRIVER_LM75B_LINK_IIC_READ(&gs_handle, lm75b_interface_iic_read);
    DRIVER_LM75B_LINK_IIC_WRITE(&gs_handle, lm75b_interface_iic_write);
    DRIVER_LM75B_LINK_DELAY_MS(&gs_handle, lm75b_interface_delay_ms);
    DRIVER_LM75B_LINK_DEBUG_PRINT(&gs_handle, lm75b_interface_debug_print);
    /* set addr pin */
    res = lm75b_set_addr_pin(&gs_handle, addr);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set addr pin failed.\n");
        
        return 1;
    }
    /* lm75b init */
    res = lm75b_init(&gs_handle);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: init failed.\n");
       
        return 1;
    }
    /* set interrupt mode */
    res = lm75b_set_interrupt_mode(&gs_handle, mode);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set interrupt mode failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set fault queue 1 */
    res = lm75b_set_fault_queue(&gs_handle, LM75B_FAULT_QUEUE_1);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set fault queue failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set os polarity low */
    res = lm75b_set_os_polarity(&gs_handle, LM75B_OS_POLARITY_LOW);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set os polarity failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* over temperature threshold convert to register */
    res = lm75b_over_temperature_threshold_convert_to_register(&gs_handle, high_threshold, (uint16_t *)&reg);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: over temperature threshold convert to register failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set over temperature threshold */
    res = lm75b_set_over_temperature_threshold(&gs_handle, reg);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set over temperature threshold failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* hysteresis convert to register */
    res = lm75b_hysteresis_convert_to_register(&gs_handle, low_threshold, (uint16_t *)&reg);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: hysteresis convert to register failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set hysteresis */
    res = lm75b_set_hysteresis(&gs_handle, reg);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set hysteresis failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set normal mode */
    res = lm75b_set_mode(&gs_handle, LM75B_MODE_NORMAL);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set mode failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    return 0;
}
uint8_t lm75b_interrupt_read(float *s)
{
    uint16_t raw;
    /* read adc data */
    if (lm75b_read(&gs_handle, (uint16_t *)&raw, (float *)s) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
uint8_t lm75b_interrupt_deinit(void)
{
    uint8_t res;
    /* set mode */
    res = lm75b_set_mode(&gs_handle, LM75B_MODE_SHUTDOWN);
    if (res != 0)
    {
        return 1;
    }
    /* close lm75b */
    if (lm75b_deinit(&gs_handle) != 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
