
#ifndef DRIVER_LM75B_BASIC_H
#define DRIVER_LM75B_BASIC_H
#include "driver_lm75b_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t lm75b_basic_init(lm75b_address_t addr);
uint8_t lm75b_basic_deinit(void);
uint8_t lm75b_basic_read(float *s);
#ifdef __cplusplus
}
#endif
#endif
