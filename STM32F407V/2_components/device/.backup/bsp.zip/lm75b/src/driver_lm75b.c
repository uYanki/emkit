
#include "driver_lm75b.h"

#define MANUFACTURER_NAME         "NXP"              // manufacturer name
#define SUPPLY_VOLTAGE_MIN        2.8f               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f               // chip max supply voltage




#define LM75B_REG_CONF         0x01        // configure register
#define LM75B_REG_TEMP         0x00        // temperature register
#define LM75B_REG_TOS          0x03        // TOS register
#define LM75B_REG_THYST        0x02        // THYST register
uint8_t lm75b_set_addr_pin(lm75b_handle_t *handle, lm75b_address_t addr_pin)
{
    
    {
        
    }
    iic_addr = 0x90;                  /* set iic addr */
    iic_addr |= addr_pin << 1;        /* set iic address */
    return 0;                                 /* success return 0 */
}
uint8_t lm75b_get_addr_pin(lm75b_handle_t *handle, lm75b_address_t *addr_pin)
{
    
    {
        
    }
    *addr_pin = (lm75b_address_t)((iic_addr&(~0x90)) >> 1);        /* get iic address */
    return 0;                                                              /* success return 0 */
}
uint8_t lm75b_hysteresis_convert_to_register(lm75b_handle_t *handle, float c, uint16_t *reg)
{
    
    {
        
    }
    
    {
        
    }
    if (c > 0)                                                             /* if positive */
    {
        *reg = ((uint16_t)(c / 0.5f) & 0xFF) << 7;                         /* get reg */
    }
    else                                                                   /* if negtive */
    {
        *reg = (1<<15) | (~(((uint16_t)(-c /0.5f) & 0xFF) - 1))<<7;        /* get reg */
    }
    return 0;                                                              /* success return 0 */
}
uint8_t lm75b_hysteresis_convert_to_data(lm75b_handle_t *handle, uint16_t reg, float *c)
{
    
    {
        
    }
    
    {
        
    }
    reg = reg >> 7;                                                /* right shift 7 */
    if ((reg & 0x0100) != 0)                                       /* check first bit */
    {
        *c= -0.5f * (float)((uint16_t)((~(reg))&0xFF) + 1);        /* if negtive set convert temp */
    }
    else
    {
        *c = (float)(reg) * 0.5f;                                  /* if positive set convert temp */
    }
    return 0;                                                      /* success return 0 */
}
uint8_t lm75b_set_hysteresis(lm75b_handle_t *handle, uint16_t hysteresis)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    buf[0] = (hysteresis >> 8) & 0xFF;                                                    /* set MSB */
    buf[1] = hysteresis & 0xFF;                                                           /* set LSB */
    res = iic_write(iic_addr, LM75B_REG_THYST, (uint8_t *)buf, 2);        /* set hysteresis */
    if (res != 0)                                                                         /* check result */
    {
        
       
        
    }
    return 0;                                                                             /* success return 0 */
}
uint8_t lm75b_get_hysteresis(lm75b_handle_t *handle, uint16_t *hysteresis)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_THYST, (uint8_t *)buf, 2);        /* get hysteresis */
    if (res != 0)                                                                        /* check result */
    {
        
       
        
    }
    *hysteresis = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                          /* set data */
    return 0;                                                                            /* success return 0 */
}
uint8_t lm75b_over_temperature_threshold_convert_to_register(lm75b_handle_t *handle, float c, uint16_t *reg)
{
    
    {
        
    }
    
    {
        
    }
    if (c > 0)                                                             /* if positive */
    {
        *reg = ((uint16_t)(c / 0.5f) & 0xFF) << 7;                         /* get reg */
    }
    else                                                                   /* if negtive */
    {
        *reg = (1<<15) | (~(((uint16_t)(-c /0.5f) & 0xFF) - 1))<<7;        /* get reg */
    }
    return 0;                                                              /* success return 0 */
}
uint8_t lm75b_over_temperature_threshold_convert_to_data(lm75b_handle_t *handle, uint16_t reg, float *c)
{
    
    {
        
    }
    
    {
        
    }
    reg = reg >> 7;                                                /* right shift 7 */
    if ((reg & 0x0100) != 0)                                       /* check first bit */
    {
        *c= -0.5f * (float)((uint16_t)((~(reg))&0xFF) + 1);        /* if negtive set convert temp */
    }
    else
    {
        *c = (float)(reg) * 0.5f;                                  /* if positive set convert temp */
    }
    return 0;                                                      /* success return 0 */
}
uint8_t lm75b_set_over_temperature_threshold(lm75b_handle_t *handle, uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    buf[0] = (threshold >> 8) & 0xFF;                                                   /* set MSB */
    buf[1] = threshold & 0xFF;                                                          /* set LSB */
    res = iic_write(iic_addr, LM75B_REG_TOS, (uint8_t *)buf, 2);        /* set threshold */
    if (res != 0)                                                                       /* check result */
    {
        
       
        
    }
    return 0;                                                                           /* success return 0 */
}
uint8_t lm75b_get_over_temperature_threshold(lm75b_handle_t *handle, uint16_t *threshold)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_TOS, (uint8_t *)buf, 2);        /* get threshold */
    if (res != 0)                                                                      /* check result */
    {
        
       
        
    }
    *threshold = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                         /* set data */
    return 0;                                                                          /* success return 0 */
}
uint8_t lm75b_set_fault_queue(lm75b_handle_t *handle, lm75b_fault_queue_t fault_queue)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    prev &= ~ (0x03 << 3);                                                                 /* clear fault queue */
    prev |= fault_queue << 3;                                                              /* set queue */
    res = iic_write(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);        /* write conf */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_get_fault_queue(lm75b_handle_t *handle, lm75b_fault_queue_t *fault_queue)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    *fault_queue = (lm75b_fault_queue_t)((prev >> 3) & 0x03);                              /* get fault queue */
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_set_os_polarity(lm75b_handle_t *handle, lm75b_os_polarity_t polarity)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    prev &= ~ (1 << 2);                                                                    /* clear polarity */
    prev |= polarity << 2;                                                                 /* set polarity */
    res = iic_write(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);        /* write confure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_get_os_polarity(lm75b_handle_t *handle, lm75b_os_polarity_t *polarity)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    *polarity = (lm75b_os_polarity_t)((prev >> 2) & 0x01);                                 /* get polarity */
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_set_interrupt_mode(lm75b_handle_t *handle, lm75b_os_operation_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    prev &= ~ (1 << 1);                                                                    /* clear mode */
    prev |= mode << 1;                                                                     /* set mode */
    res = iic_write(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);        /* write configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_get_interrupt_mode(lm75b_handle_t *handle, lm75b_os_operation_mode_t *mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    *mode = (lm75b_os_operation_mode_t)((prev >> 1) & 0x01);                               /* get mode */
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_set_mode(lm75b_handle_t *handle, lm75b_mode_t mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    prev &= ~ (1 << 0);                                                                    /* clear mode */
    prev |= mode << 0;                                                                     /* set mode */
    res = iic_write(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);        /* write conf */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_get_mode(lm75b_handle_t *handle, lm75b_mode_t *mode)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read configure */
    
    {
        
       
        
    }
    *mode = (lm75b_mode_t)((prev >> 0) & 0x01);                                            /* get mode */
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_init(lm75b_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                /* check debug_print */
    {
        
    }
    if (iic_init == NULL)                                   /* check iic_init */
    {
        
       
        
    }
    if (iic_deinit == NULL)                                 /* check iic_deinit */
    {
        
       
        
    }
    if (iic_read == NULL)                                   /* check iic_read */
    {
        
       
        
    }
    if (iic_write == NULL)                                  /* check iic_write */
    {
        
       
        
    }
    if (delay_ms == NULL)                                   /* check delay_ms */
    {
        
       
        
    }
    if (iic_init() != 0)                                    /* initialize iic bus */
    {
        
        
        
    }
    inited = 1;                                             /* flag finish initialization */
    return 0;                                                       /* success return 0 */
}
uint8_t lm75b_deinit(lm75b_handle_t *handle)
{
    uint8_t res;
    uint8_t prev;
    
    {
        
    }
    
    {
        
    }
    res = iic_read(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);         /* read config */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    prev &= ~(1 << 0);                                                                     /* clear mode */
    res = iic_write(iic_addr, LM75B_REG_CONF, (uint8_t *)&prev, 1);        /* write configure */
    if (res != 0)                                                                          /* check result */
    {
        
       
        
    }
    if (iic_deinit() != 0)                                                         /* close iic bus */
    {
        
        
        
    }
    inited = 0;                                                                    /* flag close */
    return 0;                                                                              /* success return 0 */
}
uint8_t lm75b_read(lm75b_handle_t *handle, uint16_t *raw, float *s)
{
    uint8_t res;
    uint8_t buf[2];
    
    {
        
    }
    
    {
        
    }
    memset(buf, 0, sizeof(uint8_t) * 2);                                                /* clear the buffer */
    res = iic_read(iic_addr, LM75B_REG_TEMP, (uint8_t *)buf, 2);        /* get temperature */
    if (res != 0)                                                                       /* check result */
    {
        
       
        
    }
    *raw = (uint16_t)(((uint16_t)buf[0]) << 8) | buf[1];                                /* set raw data */
    *raw = (*raw) >> 5;                                                                 /* right shift 5 */
    if (((*raw) & 0x0400) != 0)                                                         /* check first bit */
    {
        *raw = (*raw) | 0xF800U;                                                        /* set negtive part */
        *s = (float)(-(~(*raw) + 1)) * 0.125f;                                          /* if negtive set convert temp */
    }
    else
    {
        *s = (float)(*raw) * 0.125f;                                                    /* if positive set convert temp */
    }
    return 0;                                                                           /* success return 0 */
}
uint8_t lm75b_set_reg(lm75b_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
  
    if (iic_write(iic_addr, reg, buf, len) != 0)    /* write register */
    {
        
       
        
    }
    else
    {
        return 0;                                                   /* success return 0 */
    }
}
uint8_t lm75b_get_reg(lm75b_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t len)
{
    
    {
        
    }
    
    {
        
    }
  
    if (iic_read(iic_addr, reg, buf, len) != 0)    /* read register */
    {
        
       
        
    }
    else
    {
        return 0;                                                  /* success return 0 */
    }
}
uint8_t lm75b_info(lm75b_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(lm75b_info_t));                          /* initialize lm75b info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                             /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
