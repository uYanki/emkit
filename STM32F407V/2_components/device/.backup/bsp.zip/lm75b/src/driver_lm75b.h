
#ifndef DRIVER_LM75B_H
#define DRIVER_LM75B_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    LM75B_ADDRESS_A000 = 0,  // A2A1A0 000
    LM75B_ADDRESS_A001 = 1,  // A2A1A0 001
    LM75B_ADDRESS_A010 = 2,  // A2A1A0 010
    LM75B_ADDRESS_A011 = 3,  // A2A1A0 011
    LM75B_ADDRESS_A100 = 4,  // A2A1A0 100
    LM75B_ADDRESS_A101 = 5,  // A2A1A0 101
    LM75B_ADDRESS_A110 = 6,  // A2A1A0 110
    LM75B_ADDRESS_A111 = 7,  // A2A1A0 111
} lm75b_address_t;
typedef enum {
    LM75B_FAULT_QUEUE_1 = 0,  // fault queue 1
    LM75B_FAULT_QUEUE_2 = 1,  // fault queue 2
    LM75B_FAULT_QUEUE_3 = 2,  // fault queue 3
    LM75B_FAULT_QUEUE_6 = 3,  // fault queue 6
} lm75b_fault_queue_t;
typedef enum {
    LM75B_OS_POLARITY_LOW  = 0,  // polarity low
    LM75B_OS_POLARITY_HIGH = 1,  // polarity high
} lm75b_os_polarity_t;
typedef enum {
    LM75B_MODE_NORMAL   = 0,  // normal mode
    LM75B_MODE_SHUTDOWN = 1,  // shutdown mode
} lm75b_mode_t;
typedef enum {
    LM75B_OS_OPERATION_COMPARATOR = 0,  // comparator operation mode
    LM75B_OS_OPERATION_INTERRUPT  = 1,  // interrupt operation mode
} lm75b_os_operation_mode_t;
typedef struct lm75b_handle_s {
    uint8_t iic_addr;  // iic device address

    uint8_t inited;  // inited flag
} lm75b_handle_t;

uint8_t lm75b_info(lm75b_info_t* info);
uint8_t lm75b_set_addr_pin(lm75b_handle_t* handle, lm75b_address_t addr_pin);
uint8_t lm75b_get_addr_pin(lm75b_handle_t* handle, lm75b_address_t* addr_pin);
uint8_t lm75b_init(lm75b_handle_t* handle);
uint8_t lm75b_deinit(lm75b_handle_t* handle);
uint8_t lm75b_read(lm75b_handle_t* handle, uint16_t* raw, float* s);
uint8_t lm75b_set_mode(lm75b_handle_t* handle, lm75b_mode_t mode);
uint8_t lm75b_get_mode(lm75b_handle_t* handle, lm75b_mode_t* mode);
uint8_t lm75b_set_fault_queue(lm75b_handle_t* handle, lm75b_fault_queue_t fault_queue);
uint8_t lm75b_get_fault_queue(lm75b_handle_t* handle, lm75b_fault_queue_t* fault_queue);
uint8_t lm75b_hysteresis_convert_to_register(lm75b_handle_t* handle, float c, uint16_t* reg);
uint8_t lm75b_hysteresis_convert_to_data(lm75b_handle_t* handle, uint16_t reg, float* c);
uint8_t lm75b_set_hysteresis(lm75b_handle_t* handle, uint16_t hysteresis);
uint8_t lm75b_get_hysteresis(lm75b_handle_t* handle, uint16_t* hysteresis);
uint8_t lm75b_over_temperature_threshold_convert_to_register(lm75b_handle_t* handle, float c, uint16_t* reg);
uint8_t lm75b_over_temperature_threshold_convert_to_data(lm75b_handle_t* handle, uint16_t reg, float* c);
uint8_t lm75b_set_over_temperature_threshold(lm75b_handle_t* handle, uint16_t threshold);
uint8_t lm75b_get_over_temperature_threshold(lm75b_handle_t* handle, uint16_t* threshold);
uint8_t lm75b_set_os_polarity(lm75b_handle_t* handle, lm75b_os_polarity_t polarity);
uint8_t lm75b_get_os_polarity(lm75b_handle_t* handle, lm75b_os_polarity_t* polarity);
uint8_t lm75b_set_interrupt_mode(lm75b_handle_t* handle, lm75b_os_operation_mode_t mode);
uint8_t lm75b_get_interrupt_mode(lm75b_handle_t* handle, lm75b_os_operation_mode_t* mode);
uint8_t lm75b_set_reg(lm75b_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t lm75b_get_reg(lm75b_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
