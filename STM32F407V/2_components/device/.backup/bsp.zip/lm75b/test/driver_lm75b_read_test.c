
#include "driver_lm75b_read_test.h"
static lm75b_handle_t gs_handle;        // lm75b handle
uint8_t lm75b_read_test(lm75b_address_t addr, uint32_t times)
{
    uint8_t res;
    uint32_t i;
    uint16_t raw;
    float s;
    lm75b_info_t info;
    /* link interface function */
    DRIVER_LM75B_LINK_INIT(&gs_handle, lm75b_handle_t);
    DRIVER_LM75B_LINK_IIC_INIT(&gs_handle, lm75b_interface_iic_init);
    DRIVER_LM75B_LINK_IIC_DEINIT(&gs_handle, lm75b_interface_iic_deinit);
    DRIVER_LM75B_LINK_IIC_READ(&gs_handle, lm75b_interface_iic_read);
    DRIVER_LM75B_LINK_IIC_WRITE(&gs_handle, lm75b_interface_iic_write);
    DRIVER_LM75B_LINK_DELAY_MS(&gs_handle, lm75b_interface_delay_ms);
    DRIVER_LM75B_LINK_DEBUG_PRINT(&gs_handle, lm75b_interface_debug_print);
    /* get lm75b info */
    res = lm75b_info(&info);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: get info failed.\n");
        
        return 1;
    }
    else
    {
        /* print chip information */
        lm75b_interface_debug_print("lm75b: chip is %s.\n", info.chip_name);
        lm75b_interface_debug_print("lm75b: manufacturer is %s.\n", info.manufacturer_name);
        lm75b_interface_debug_print("lm75b: interface is %s.\n", info.interface);
        lm75b_interface_debug_print("lm75b: driver version is %d.%d.\n", info.driver_version / 1000, (info.driver_version % 1000) / 100);
        lm75b_interface_debug_print("lm75b: min supply voltage is %0.1fV.\n", info.supply_voltage_min_v);
        lm75b_interface_debug_print("lm75b: max supply voltage is %0.1fV.\n", info.supply_voltage_max_v);
        lm75b_interface_debug_print("lm75b: max current is %0.2fmA.\n", info.max_current_ma);
        lm75b_interface_debug_print("lm75b: max temperature is %0.1fC.\n", info.temperature_max);
        lm75b_interface_debug_print("lm75b: min temperature is %0.1fC.\n", info.temperature_min);
    }
    /* set addr pin */
    res = lm75b_set_addr_pin(&gs_handle, addr);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set addr pin failed.\n");
        
        return 1;
    }
    /* lm75b init */
    res = lm75b_init(&gs_handle);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: init failed.\n");
       
        return 1;
    }
    /* set interrupt mode */
    res = lm75b_set_interrupt_mode(&gs_handle, LM75B_OS_OPERATION_INTERRUPT);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set interrupt mode failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set fault queue 1 */
    res = lm75b_set_fault_queue(&gs_handle, LM75B_FAULT_QUEUE_1);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set fault queue failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set os polarity low*/
    res = lm75b_set_os_polarity(&gs_handle, LM75B_OS_POLARITY_LOW);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set os polarity failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set over temperature threshold */
    res = lm75b_set_over_temperature_threshold(&gs_handle, 0xFF80U);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set over temperature threshold failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set hysteresis */
    res = lm75b_set_hysteresis(&gs_handle, 0x0000U);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set hysteresis failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* set normal mode */
    res = lm75b_set_mode(&gs_handle, LM75B_MODE_NORMAL);
    if (res != 0)
    {
        lm75b_interface_debug_print("lm75b: set mode failed.\n");
        (void)lm75b_deinit(&gs_handle);
        
        return 1;
    }
    /* start read test */
    lm75b_interface_debug_print("lm75b: start read test.\n");
    for (i = 0; i < times; i++)
    {
        lm75b_interface_delay_ms(1000);
        /* read data */
        res = lm75b_read(&gs_handle, (uint16_t *)&raw, (float *)&s);
        if (res != 0)
        {
            lm75b_interface_debug_print("lm75b: read failed.\n");
            (void)lm75b_deinit(&gs_handle);
            
            return 1;
        }
        lm75b_interface_debug_print("lm75b: temperature is %0.3fC.\n", s);
    }
    /* finish read test */
    lm75b_interface_debug_print("lm75b: finish read test.\n");
    (void)lm75b_deinit(&gs_handle);
    return 0;
}
