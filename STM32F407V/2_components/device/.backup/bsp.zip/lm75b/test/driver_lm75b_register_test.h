
#ifndef DRIVER_LM75B_REGISTER_TEST_H
#define DRIVER_LM75B_REGISTER_TEST_H
#include "driver_lm75b_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t lm75b_register_test(lm75b_address_t addr);
#ifdef __cplusplus
}
#endif
#endif
