
#ifndef DRIVER_LM75B_INTERRUPT_TEST_H
#define DRIVER_LM75B_INTERRUPT_TEST_H
#include "driver_lm75b_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t lm75b_interrupt_test(lm75b_address_t addr, lm75b_os_operation_mode_t mode, 
                             float low_threshold, float high_threshold, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
