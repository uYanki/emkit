
#ifndef DRIVER_ADXL345_H
#define DRIVER_ADXL345_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    ADXL345_INTERFACE_IIC = 0x00,  // iic interface function
    ADXL345_INTERFACE_SPI = 0x01,  // spi interface function
} adxl345_interface_t;

typedef enum {
    ADXL345_ADDRESS_ALT_0 = 0xA6,  // addr pin connected to the GND
    ADXL345_ADDRESS_ALT_1 = 0x3A,  // addr pin connected to the VCC
} adxl345_address_t;

typedef enum {
    ADXL345_BOOL_FALSE = 0x00,  // false
    ADXL345_BOOL_TRUE  = 0x01,  // true
} adxl345_bool_t;

typedef enum {
    ADXL345_COUPLED_DC = 0x00,  // DC coupled
    ADXL345_COUPLED_AC = 0x01,  // AC coupled
} adxl345_coupled_t;

typedef enum {
    ADXL345_ACTION_X   = 0x06,  // x axis action
    ADXL345_ACTION_Y   = 0x05,  // y axis action
    ADXL345_ACTION_Z   = 0x04,  // z axis action
    ADXL345_INACTION_X = 0x02,  // x axis inaction
    ADXL345_INACTION_Y = 0x01,  // y axis inaction
    ADXL345_INACTION_Z = 0x00,  // z axis inaction
} adxl345_action_inaction_t;

typedef enum {
    ADXL345_TAP_AXIS_X = 0x02,  // x axis tap
    ADXL345_TAP_AXIS_Y = 0x01,  // y axis tap
    ADXL345_TAP_AXIS_Z = 0x00,  // z axis tap
} adxl345_tap_axis_t;

typedef enum {
    ADXL345_ACTION_TAP_STATUS_ACT_X  = (1 << 6),  // x axis action status
    ADXL345_ACTION_TAP_STATUS_ACT_Y  = (1 << 5),  // y axis action status
    ADXL345_ACTION_TAP_STATUS_ACT_Z  = (1 << 4),  // z axis action status
    ADXL345_ACTION_TAP_STATUS_ASLEEP = (1 << 3),  // asleep status
    ADXL345_ACTION_TAP_STATUS_TAP_X  = (1 << 2),  // x axis tap status
    ADXL345_ACTION_TAP_STATUS_TAP_Y  = (1 << 1),  // y axis tap status
    ADXL345_ACTION_TAP_STATUS_TAP_Z  = (1 << 0),  // z axis tap status
} adxl345_action_tap_status_t;

typedef enum {
    ADXL345_RATE_0P1            = 0x00,  // 0.1Hz
    ADXL345_RATE_0P2            = 0x01,  // 0.2Hz
    ADXL345_RATE_0P39           = 0x02,  // 0.39Hz
    ADXL345_RATE_0P78           = 0x03,  // 0.78Hz
    ADXL345_RATE_1P56           = 0x04,  // 1.56Hz
    ADXL345_RATE_3P13           = 0x05,  // 3.13Hz
    ADXL345_RATE_6P25           = 0x06,  // 6.25Hz
    ADXL345_RATE_12P5           = 0x07,  // 12.5Hz
    ADXL345_RATE_25             = 0x08,  // 25Hz
    ADXL345_RATE_50             = 0x09,  // 50Hz
    ADXL345_RATE_100            = 0x0A,  // 100Hz
    ADXL345_RATE_200            = 0x0B,  // 200Hz
    ADXL345_RATE_400            = 0x0C,  // 400Hz
    ADXL345_RATE_800            = 0x0D,  // 800Hz
    ADXL345_RATE_1600           = 0x0E,  // 1600Hz
    ADXL345_RATE_3200           = 0x0F,  // 3200Hz
    ADXL345_LOW_POWER_RATE_12P5 = 0x17,  // low power 12.5Hz
    ADXL345_LOW_POWER_RATE_25   = 0x18,  // low power 25Hz
    ADXL345_LOW_POWER_RATE_50   = 0x19,  // low power 50Hz
    ADXL345_LOW_POWER_RATE_100  = 0x1A,  // low power 100Hz
    ADXL345_LOW_POWER_RATE_200  = 0x1B,  // low power 200Hz
    ADXL345_LOW_POWER_RATE_400  = 0x1C,  // low power 400Hz
} adxl345_rate_t;

typedef enum {
    ADXL345_SPI_WIRE_4 = 0x00,  // wire 4
    ADXL345_SPI_WIRE_3 = 0x01,  // wire 3
} adxl345_spi_wire_t;

typedef enum {
    ADXL345_JUSTIFY_RIGHT = 0x00,  // right justify
    ADXL345_JUSTIFY_LEFT  = 0x01,  // left justify
} adxl345_justify_t;

typedef enum {
    ADXL345_RANGE_2G  = 0x00,  // ±2G
    ADXL345_RANGE_4G  = 0x01,  // ±4G
    ADXL345_RANGE_8G  = 0x02,  // ±8G
    ADXL345_RANGE_16G = 0x03,  // ±16G
} adxl345_range_t;

typedef enum {
    ADXL345_SLEEP_FREQUENCY_8HZ = 0x00,  // sleep 8Hz
    ADXL345_SLEEP_FREQUENCY_4HZ = 0x01,  // sleep 4Hz
    ADXL345_SLEEP_FREQUENCY_2HZ = 0x02,  // sleep 2Hz
    ADXL345_SLEEP_FREQUENCY_1HZ = 0x03,  // sleep 1Hz
} adxl345_sleep_frequency_t;

typedef enum {
    ADXL345_MODE_BYPASS  = 0x00,  // bypass mode
    ADXL345_MODE_FIFO    = 0x01,  // fifo mode
    ADXL345_MODE_STREAM  = 0x02,  // stream mode
    ADXL345_MODE_TRIGGER = 0x03,  // trigger mode
} adxl345_mode_t;

typedef enum {
    ADXL345_TRIGGER_NOT_OCCURRED = 0x00,  // not occurred
    ADXL345_TRIGGER_OCCURRED     = 0x01,  // occurred
} adxl345_trigger_status_t;

typedef enum {
    ADXL345_INTERRUPT_DATA_READY = 0x07,  // data ready
    ADXL345_INTERRUPT_SINGLE_TAP = 0x06,  // single tap
    ADXL345_INTERRUPT_DOUBLE_TAP = 0x05,  // double tap
    ADXL345_INTERRUPT_ACTIVITY   = 0x04,  // activity
    ADXL345_INTERRUPT_INACTIVITY = 0x03,  // inactivity
    ADXL345_INTERRUPT_FREE_FALL  = 0x02,  // free fall
    ADXL345_INTERRUPT_WATERMARK  = 0x01,  // watermark
    ADXL345_INTERRUPT_OVERRUN    = 0x00,  // overrun
} adxl345_interrupt_t;

typedef enum {
    ADXL345_INTERRUPT_PIN1 = 0x00,  // interrupt pin 1
    ADXL345_INTERRUPT_PIN2 = 0x01,  // interrupt pin 2
} adxl345_interrupt_pin_t;

typedef enum {
    ADXL345_INTERRUPT_ACTIVE_LEVEL_HIGH = 0x00,  // interrupt active level high
    ADXL345_INTERRUPT_ACTIVE_LEVEL_LOW  = 0x01,  // interrupt active level low
} adxl345_interrupt_active_level_t;

typedef struct adxl345_handle_s {
    uint8_t iic_addr;  // iic address

    uint8_t inited;   // inited flag
    uint8_t iic_spi;  // iic spi interface type
} adxl345_handle_t;

uint8_t adxl345_info();
uint8_t adxl345_init();
uint8_t adxl345_deinit();
uint8_t adxl345_set_interface(adxl345_interface_t interface);
uint8_t adxl345_get_interface(adxl345_interface_t* interface);
uint8_t adxl345_set_addr_pin(adxl345_address_t addr_pin);
uint8_t adxl345_get_addr_pin(adxl345_address_t* addr_pin);
uint8_t adxl345_read(int16_t (*raw)[3], float (*g)[3], uint16_t* len);
uint8_t adxl345_irq_handler();
uint8_t adxl345_set_tap_threshold(uint8_t threshold);
uint8_t adxl345_get_tap_threshold(uint8_t* threshold);
uint8_t adxl345_tap_threshold_convert_to_register(float g, uint8_t* reg);
uint8_t adxl345_tap_threshold_convert_to_data(uint8_t reg, float* g);
uint8_t adxl345_set_offset(int8_t x, int8_t y, int8_t z);
uint8_t adxl345_get_offset(int8_t* x, int8_t* y, int8_t* z);
uint8_t adxl345_offset_convert_to_register(float g, int8_t* reg);
uint8_t adxl345_offset_convert_to_data(int8_t reg, float* g);
uint8_t adxl345_set_duration(uint8_t t);
uint8_t adxl345_get_duration(uint8_t* t);
uint8_t adxl345_duration_convert_to_register(uint32_t us, uint8_t* reg);
uint8_t adxl345_duration_convert_to_data(uint8_t reg, uint32_t* us);
uint8_t adxl345_set_latent(uint8_t t);
uint8_t adxl345_get_latent(uint8_t* t);
uint8_t adxl345_latent_convert_to_register(float ms, uint8_t* reg);
uint8_t adxl345_latent_convert_to_data(uint8_t reg, float* ms);
uint8_t adxl345_set_window(uint8_t t);
uint8_t adxl345_get_window(uint8_t* t);
uint8_t adxl345_window_convert_to_register(float ms, uint8_t* reg);
uint8_t adxl345_window_convert_to_data(uint8_t reg, float* ms);
uint8_t adxl345_set_action_threshold(uint8_t threshold);
uint8_t adxl345_get_action_threshold(uint8_t* threshold);
uint8_t adxl345_action_threshold_convert_to_register(float g, uint8_t* reg);
uint8_t adxl345_action_threshold_convert_to_data(uint8_t reg, float* g);
uint8_t adxl345_set_inaction_threshold(uint8_t threshold);
uint8_t adxl345_get_inaction_threshold(uint8_t* threshold);
uint8_t adxl345_inaction_threshold_convert_to_register(float g, uint8_t* reg);
uint8_t adxl345_inaction_threshold_convert_to_data(uint8_t reg, float* g);
uint8_t adxl345_set_inaction_time(uint8_t t);
uint8_t adxl345_get_inaction_time(uint8_t* t);
uint8_t adxl345_inaction_time_convert_to_register(uint8_t s, uint8_t* reg);
uint8_t adxl345_inaction_time_convert_to_data(uint8_t reg, uint8_t* s);
uint8_t adxl345_set_action_inaction(adxl345_action_inaction_t type, adxl345_bool_t enable);
uint8_t adxl345_get_action_inaction(adxl345_action_inaction_t type, adxl345_bool_t* enable);
uint8_t adxl345_set_action_coupled(adxl345_coupled_t coupled);
uint8_t adxl345_get_action_coupled(adxl345_coupled_t* coupled);
uint8_t adxl345_set_inaction_coupled(adxl345_coupled_t coupled);
uint8_t adxl345_get_inaction_coupled(adxl345_coupled_t* coupled);
uint8_t adxl345_set_free_fall_threshold(uint8_t threshold);
uint8_t adxl345_get_free_fall_threshold(uint8_t* threshold);
uint8_t adxl345_free_fall_threshold_convert_to_register(float g, uint8_t* reg);
uint8_t adxl345_free_fall_threshold_convert_to_data(uint8_t reg, float* g);
uint8_t adxl345_set_free_fall_time(uint8_t t);
uint8_t adxl345_get_free_fall_time(uint8_t* t);
uint8_t adxl345_free_fall_time_convert_to_register(uint16_t ms, uint8_t* reg);
uint8_t adxl345_free_fall_time_convert_to_data(uint8_t reg, uint16_t* ms);
uint8_t adxl345_set_tap_axis(adxl345_tap_axis_t axis, adxl345_bool_t enable);
uint8_t adxl345_get_tap_axis(adxl345_tap_axis_t axis, adxl345_bool_t* enable);
uint8_t adxl345_set_tap_suppress(adxl345_bool_t enable);
uint8_t adxl345_get_tap_suppress(adxl345_bool_t* enable);
uint8_t adxl345_get_tap_status(uint8_t* status);
uint8_t adxl345_set_rate(adxl345_rate_t rate);
uint8_t adxl345_get_rate(adxl345_rate_t* rate);
uint8_t adxl345_set_self_test(adxl345_bool_t enable);
uint8_t adxl345_get_self_test(adxl345_bool_t* enable);
uint8_t adxl345_set_spi_wire(adxl345_spi_wire_t wire);
uint8_t adxl345_get_spi_wire(adxl345_spi_wire_t* wire);
uint8_t adxl345_set_full_resolution(adxl345_bool_t enable);
uint8_t adxl345_get_full_resolution(adxl345_bool_t* enable);
uint8_t adxl345_set_justify(adxl345_justify_t enable);
uint8_t adxl345_get_justify(adxl345_justify_t* enable);
uint8_t adxl345_set_range(adxl345_range_t range);
uint8_t adxl345_get_range(adxl345_range_t* range);
uint8_t adxl345_set_mode(adxl345_mode_t mode);
uint8_t adxl345_get_mode(adxl345_mode_t* mode);
uint8_t adxl345_set_trigger_pin(adxl345_interrupt_pin_t pin);
uint8_t adxl345_get_trigger_pin(adxl345_interrupt_pin_t* pin);
uint8_t adxl345_get_trigger_status(adxl345_trigger_status_t* status);
uint8_t adxl345_set_link_activity_inactivity(adxl345_bool_t enable);
uint8_t adxl345_get_link_activity_inactivity(adxl345_bool_t* enable);
uint8_t adxl345_set_auto_sleep(adxl345_bool_t enable);
uint8_t adxl345_get_auto_sleep(adxl345_bool_t* enable);
uint8_t adxl345_set_measure(adxl345_bool_t enable);
uint8_t adxl345_get_measure(adxl345_bool_t* enable);
uint8_t adxl345_set_sleep(adxl345_bool_t enable);
uint8_t adxl345_get_sleep(adxl345_bool_t* enable);
uint8_t adxl345_set_sleep_frequency(adxl345_sleep_frequency_t sleep_frequency);
uint8_t adxl345_set_sleep_frequency(adxl345_sleep_frequency_t sleep_frequency);
uint8_t adxl345_get_sleep_frequency(adxl345_sleep_frequency_t* sleep_frequency);
uint8_t adxl345_set_interrupt(adxl345_interrupt_t type, adxl345_bool_t enable);
uint8_t adxl345_get_interrupt(adxl345_interrupt_t type, adxl345_bool_t* enable);
uint8_t adxl345_get_interrupt_source(uint8_t* source);
uint8_t adxl345_set_interrupt_map(adxl345_interrupt_t type, adxl345_interrupt_pin_t pin);
uint8_t adxl345_get_interrupt_map(adxl345_interrupt_t type, adxl345_interrupt_pin_t* pin);
uint8_t adxl345_set_interrupt_active_level(adxl345_interrupt_active_level_t active_level);
uint8_t adxl345_get_interrupt_active_level(adxl345_interrupt_active_level_t* active_level);
uint8_t adxl345_set_watermark(uint8_t level);
uint8_t adxl345_get_watermark(uint8_t* level);
uint8_t adxl345_get_watermark_level(uint8_t* level);
uint8_t adxl345_set_reg(uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t adxl345_get_reg(uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
