
#include "driver_adxl345.h"

#define MANUFACTURER_NAME          "Analog Devices"          // manufacturer name
#define SUPPLY_VOLTAGE_MIN         2.0f                      // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX         3.6f                      // chip max supply voltage




#define ADXL345_REG_DEVID          0x00                      // device id register
#define ADXL345_REG_THRESH_TAP     0x1D                      // thresh tap register
#define ADXL345_REG_OFSX           0x1E                      // x offset register
#define ADXL345_REG_OFSY           0x1F                      // y offset register
#define ADXL345_REG_OFSZ           0x20                      // z offset register
#define ADXL345_REG_DUR            0x21                      // duration time register
#define ADXL345_REG_LATENT         0x22                      // latent register
#define ADXL345_REG_WINDOW         0x23                      // window register
#define ADXL345_REG_THRESH_ACT     0x24                      // act thresh register
#define ADXL345_REG_THRESH_INACT   0x25                      // inact thresh register
#define ADXL345_REG_TIME_INACT     0x26                      // inact time register
#define ADXL345_REG_ACT_INACT_CTL  0x27                      // act inact ctl register
#define ADXL345_REG_THRESH_FF      0x28                      // free fall thresh register
#define ADXL345_REG_TIME_FF        0x29                      // free fall time register
#define ADXL345_REG_TAP_AXES       0x2A                      // tap axes register
#define ADXL345_REG_ACT_TAP_STATUS 0x2B                      // act tap status register
#define ADXL345_REG_BW_RATE        0x2C                      // bandwidth rate register
#define ADXL345_REG_POWER_CTL      0x2D                      // power control register
#define ADXL345_REG_INT_ENABLE     0x2E                      // interrupt enable register
#define ADXL345_REG_INT_MAP        0x2F                      // interrupt map register
#define ADXL345_REG_INT_SOURCE     0x30                      // interrrupt source register
#define ADXL345_REG_DATA_FORMAT    0x31                      // data format register
#define ADXL345_REG_DATAX0         0x32                      // data X0 register
#define ADXL345_REG_DATAX1         0x33                      // data X1 register
#define ADXL345_REG_DATAY0         0x34                      // data Y0 register
#define ADXL345_REG_DATAY1         0x35                      // data Y1 register
#define ADXL345_REG_DATAZ0         0x36                      // data Z0 register
#define ADXL345_REG_DATAZ1         0x37                      // data Z1 register
#define ADXL345_REG_FIFO_CTL       0x38                      // fifo control register
#define ADXL345_REG_FIFO_STATUS    0x39                      // fifo status register
static uint8_t a_adxl345_iic_spi_read( uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (iic_spi == ADXL345_INTERFACE_IIC) /* iic interface */
    {
        if (iic_read(iic_addr, reg, buf, len) != 0) /* read data */
 else {
            return 0; /* success return 0 */
        }
    } else /* spi interface */
    {
        if (len > 1) /* if length > 1 */
        {
            reg |= 1 << 6; /* flag length > 1 */
        }
        reg |= 1 << 7;                            /* flag read */
        if (spi_read(reg, buf, len) != 0) /* read data */
 else {
            return 0; /* success return 0 */
        }
    }
}
static uint8_t a_adxl345_iic_spi_write( uint8_t reg, uint8_t* buf, uint16_t len)
{
    if (iic_spi == ADXL345_INTERFACE_IIC) /* iic interface */
    {
        if (iic_write(iic_addr, reg, buf, len) != 0) /* write data */
 else {
            return 0; /* success return 0 */
        }
    } else /* spi interface */
    {
        if (len > 1) /* if length > 1 */
        {
            reg |= 1 << 6; /* flag length > 1 */
        }
        if (spi_write(reg, buf, len) != 0) /* wrtie data */
 else {
            return 0; /* success return 0 */
        }
    }
}
uint8_t adxl345_set_interface( adxl345_interface_t interface)
{

    iic_spi = (uint8_t)interface; /* set interface */
    return 0;                             /* success return 0 */
}
uint8_t adxl345_get_interface( adxl345_interface_t* interface)
{
    {

    }* interface = (adxl345_interface_t)(iic_spi); /* get interface */
    return 0;                                              /* success return 0 */
}
uint8_t adxl345_set_addr_pin( adxl345_address_t addr_pin)
{

    iic_addr = (uint8_t)addr_pin; /* set pin */
    return 0;                             /* success return 0 */
}
uint8_t adxl345_get_addr_pin( adxl345_address_t* addr_pin)
{
    {

    }* addr_pin = (adxl345_address_t)(iic_addr); /* get pin */
    return 0;                                            /* success return 0 */
}
uint8_t adxl345_set_tap_threshold( uint8_t threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_THRESH_TAP, &threshold, 1); /* write config */
}
uint8_t adxl345_get_tap_threshold( uint8_t* threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_THRESH_TAP, threshold, 1); /* read config */
}
uint8_t adxl345_tap_threshold_convert_to_register( float g, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(g / 0.0625f); /* convert real data to register data */
    return 0;                        /* success return 0 */
}
uint8_t adxl345_tap_threshold_convert_to_data( uint8_t reg, float* g)
{
    {

    } {

    }* g = (float)(reg)*0.0625f; /* convert raw data to real data */
    return 0;                    /* success return 0 */
}
uint8_t adxl345_set_offset( int8_t x, int8_t y, int8_t z)
{
    uint8_t res;
    {

    } {
    }
    res = a_adxl345_iic_spi_write( ADXL345_REG_OFSX, (uint8_t*)&x, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
    }
    res = a_adxl345_iic_spi_write( ADXL345_REG_OFSY, (uint8_t*)&y, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
    }
    res = a_adxl345_iic_spi_write( ADXL345_REG_OFSZ, (uint8_t*)&z, 1); /* write config */
    if (res != 0)                                                             /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t adxl345_get_offset( int8_t* x, int8_t* y, int8_t* z)
{
    uint8_t res;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_OFSX, (uint8_t*)x, 1); /* read config */
    if (res != 0)                                                           /* check result */
    {
        
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_OFSY, (uint8_t*)y, 1); /* read config */
    if (res != 0)                                                           /* check result */
    {
        
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_OFSZ, (uint8_t*)z, 1); /* read config */
    if (res != 0)                                                           /* check result */
    {
        
    }
    return 0; /* success return 0 */
}
uint8_t adxl345_offset_convert_to_register( float g, int8_t* reg)
{
    {

    } {

    }* reg = (int8_t)(g / 0.0156f); /* convert real data to register data */
    return 0;                       /* success return 0 */
}
uint8_t adxl345_offset_convert_to_data( int8_t reg, float* g)
{
    {

    } {

    }* g = (float)(reg)*0.0156f; /* convert raw data to real data */
    return 0;                    /* success return 0 */
}
uint8_t adxl345_set_duration( uint8_t t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_DUR, &t, 1); /* write config */
}
uint8_t adxl345_get_duration( uint8_t* t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_DUR, t, 1); /* read config */
}
uint8_t adxl345_duration_convert_to_register( uint32_t us, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(us / 625); /* convert real data to register data */
    return 0;                     /* success return 0 */
}
uint8_t adxl345_duration_convert_to_data( uint8_t reg, uint32_t* us)
{
    {

    } {

    }* us = (uint32_t)((float)(reg)*625.0f); /* convert raw data to real data */
    return 0;                                /* success return 0 */
}
uint8_t adxl345_set_latent( uint8_t t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_LATENT, &t, 1); /* write config */
}
uint8_t adxl345_get_latent( uint8_t* t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_LATENT, t, 1); /* read config */
}
uint8_t adxl345_latent_convert_to_register( float ms, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(ms / 1.25f); /* convert real data to register data */
    return 0;                       /* success return 0 */
}
uint8_t adxl345_latent_convert_to_data( uint8_t reg, float* ms)
{
    {

    } {

    }* ms = (float)(reg)*1.25f; /* convert raw data to real data */
    return 0;                   /* success return 0 */
}
uint8_t adxl345_set_window( uint8_t t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_WINDOW, &t, 1); /* write config */
}
uint8_t adxl345_get_window( uint8_t* t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_WINDOW, t, 1); /* read config */
}
uint8_t adxl345_window_convert_to_register( float ms, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(ms / 1.25f); /* convert real data to register data */
    return 0;                       /* success return 0 */
}
uint8_t adxl345_window_convert_to_data( uint8_t reg, float* ms)
{
    {

    } {

    }* ms = (float)(reg)*1.25f; /* convert raw data to real data */
    return 0;                   /* success return 0 */
}
uint8_t adxl345_set_action_threshold( uint8_t threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_THRESH_ACT, &threshold, 1); /* write config */
}
uint8_t adxl345_get_action_threshold( uint8_t* threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_THRESH_ACT, threshold, 1); /* read config */
}
uint8_t adxl345_action_threshold_convert_to_register( float g, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(g / 0.0625f); /* convert real data to register data */
    return 0;                        /* success return 0 */
}
uint8_t adxl345_action_threshold_convert_to_data( uint8_t reg, float* g)
{
    {

    } {

    }* g = (float)(reg)*0.0625f; /* convert raw data to real data */
    return 0;                    /* success return 0 */
}
uint8_t adxl345_set_inaction_threshold( uint8_t threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_THRESH_INACT, &threshold, 1); /* write config */
}
uint8_t adxl345_get_inaction_threshold( uint8_t* threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_THRESH_INACT, threshold, 1); /* read config */
}
uint8_t adxl345_inaction_threshold_convert_to_register( float g, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(g / 0.0625f); /* convert real data to register data */
    return 0;                        /* success return 0 */
}
uint8_t adxl345_inaction_threshold_convert_to_data( uint8_t reg, float* g)
{
    {

    } {

    }* g = (float)(reg)*0.0625f; /* convert raw data to real data */
    return 0;                    /* success return 0 */
}
uint8_t adxl345_set_inaction_time( uint8_t t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_TIME_INACT, &t, 1); /* write config */
}
uint8_t adxl345_get_inaction_time( uint8_t* t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_TIME_INACT, t, 1); /* read config */
}
uint8_t adxl345_inaction_time_convert_to_register( uint8_t s, uint8_t* reg)
{
    {

    } {

    }* reg = s; /* convert real data to register data */
    return 0;   /* success return 0 */
}
uint8_t adxl345_inaction_time_convert_to_data( uint8_t reg, uint8_t* s)
{
    {

    } {

    }* s = reg; /* convert raw data to real data */
    return 0;   /* success return 0 */
}
uint8_t adxl345_set_action_inaction( adxl345_action_inaction_t type, adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= ~(1 << type);                                                                  /* clear type */
    prev |= (enable << type);                                                              /* set type */
    return a_adxl345_iic_spi_write( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_action_inaction( adxl345_action_inaction_t type, adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= (1 << type);                      /* get type */
    *enable = (adxl345_bool_t)(prev >> type); /* set type */
    return 0;                                 /* success return 0 */
}
uint8_t adxl345_set_action_coupled( adxl345_coupled_t coupled)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= ~(1 << 7);                                                                     /* clear coupled */
    prev |= (coupled << 7);                                                                /* set coupled */
    return a_adxl345_iic_spi_write( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_action_coupled( adxl345_coupled_t* coupled)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= (1 << 7);                          /* clear config */
    *coupled = (adxl345_coupled_t)(prev >> 7); /* set config */
    return 0;                                  /* success return 0 */
}
uint8_t adxl345_set_inaction_coupled( adxl345_coupled_t coupled)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                                                     /* clear config */
    prev |= (coupled << 3);                                                                /* set inaction coupled */
    return a_adxl345_iic_spi_write( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_inaction_coupled( adxl345_coupled_t* coupled)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_ACT_INACT_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                        /* check result */
    {
        
    }
    prev &= (1 << 3);                          /* clear config */
    *coupled = (adxl345_coupled_t)(prev >> 3); /* get inaction coupled */
    return 0;                                  /* success return 0 */
}
uint8_t adxl345_set_free_fall_threshold( uint8_t threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_THRESH_FF, &threshold, 1); /* write config */
}
uint8_t adxl345_get_free_fall_threshold( uint8_t* threshold)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_THRESH_FF, threshold, 1); /* read config */
}
uint8_t adxl345_free_fall_threshold_convert_to_register( float g, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(g / 0.0625f); /* convert real data to register data */
    return 0;                        /* success return 0 */
}
uint8_t adxl345_free_fall_threshold_convert_to_data( uint8_t reg, float* g)
{
    {

    } {

    }* g = (float)(reg)*0.0625f; /* convert raw data to real data */
    return 0;                    /* success return 0 */
}
uint8_t adxl345_set_free_fall_time( uint8_t t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( ADXL345_REG_TIME_FF, &t, 1); /* write config */
}
uint8_t adxl345_get_free_fall_time( uint8_t* t)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_TIME_FF, t, 1); /* read config */
}
uint8_t adxl345_free_fall_time_convert_to_register( uint16_t ms, uint8_t* reg)
{
    {

    } {

    }* reg = (uint8_t)(ms / 5); /* convert real data to register data */
    return 0;                   /* success return 0 */
}
uint8_t adxl345_free_fall_time_convert_to_data( uint8_t reg, uint16_t* ms)
{
    {

    } {

    }* ms = reg * 5; /* convert raw data to real data */
    return 0;        /* success return 0 */
}
uint8_t adxl345_set_tap_axis( adxl345_tap_axis_t axis, adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= ~(1 << axis);                                                             /* clear axis */
    prev |= enable << axis;                                                           /* set axis */
    return a_adxl345_iic_spi_write( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_tap_axis( adxl345_tap_axis_t axis, adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= (1 << axis);                      /* clear axis */
    *enable = (adxl345_bool_t)(prev >> axis); /* set axis */
    return 0;                                 /* success return 0 */
}
uint8_t adxl345_set_tap_suppress( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                                                /* clear suppress */
    prev |= enable << 3;                                                              /* set suppress */
    return a_adxl345_iic_spi_write( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_tap_suppress( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_TAP_AXES, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= (1 << 3);                      /* clear config */
    *enable = (adxl345_bool_t)(prev >> 3); /* set config */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_get_tap_status( uint8_t* status)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_ACT_TAP_STATUS, (uint8_t*)status, 1); /* read config */
}
uint8_t adxl345_set_rate( adxl345_rate_t rate)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_BW_RATE, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                  /* check result */
    {
        
    }
    prev &= ~(0x1F);                                                                 /* clear rate */
    prev |= rate;                                                                    /* set rate */
    return a_adxl345_iic_spi_write( ADXL345_REG_BW_RATE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_rate( adxl345_rate_t* rate)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_BW_RATE, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                  /* check result */
    {
        
    }
    prev &= 0x1F;                   /* clear config */
    *rate = (adxl345_rate_t)(prev); /* get rate */
    return 0;                       /* success return 0 */
}
uint8_t adxl345_set_interrupt( adxl345_interrupt_t type, adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_INT_ENABLE, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= ~(1 << type);                                                               /* clear interrupt */
    prev |= enable << type;                                                             /* set interrupt */
    return a_adxl345_iic_spi_write( ADXL345_REG_INT_ENABLE, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_interrupt( adxl345_interrupt_t type, adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_INT_ENABLE, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    prev &= (1 << type);                      /* clear config */
    *enable = (adxl345_bool_t)(prev >> type); /* set config */
    return 0;                                 /* success return 0 */
}
uint8_t adxl345_set_interrupt_map( adxl345_interrupt_t type, adxl345_interrupt_pin_t pin)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_INT_MAP, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                  /* check result */
    {
        
    }
    prev &= ~(1 << type);                                                            /* clear type */
    prev |= pin << type;                                                             /* set interrupt map */
    return a_adxl345_iic_spi_write( ADXL345_REG_INT_MAP, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_interrupt_map( adxl345_interrupt_t type, adxl345_interrupt_pin_t* pin)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_INT_MAP, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                  /* check result */
    {
        
    }
    prev &= (1 << type);                            /* clear config */
    *pin = (adxl345_interrupt_pin_t)(prev >> type); /* set interrupt map */
    return 0;                                       /* success return 0 */
}
uint8_t adxl345_get_interrupt_source( uint8_t* source)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( ADXL345_REG_INT_ENABLE, (uint8_t*)source, 1); /* read config */
}
uint8_t adxl345_set_self_test( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(1 << 7);                                                                   /* clear config */
    prev |= (enable << 7);                                                               /* set self test */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_self_test( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 7);                      /* clear config */
    *enable = (adxl345_bool_t)(prev >> 7); /* set self test */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_spi_wire( adxl345_spi_wire_t wire)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(1 << 6);                                                                   /* clear config */
    prev |= (wire << 6);                                                                 /* set wire */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_spi_wire( adxl345_spi_wire_t* wire)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 6);                        /* clear config */
    *wire = (adxl345_spi_wire_t)(prev >> 6); /* set wire */
    return 0;                                /* success return 0 */
}
uint8_t adxl345_set_interrupt_active_level( adxl345_interrupt_active_level_t active_level)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(1 << 5);                                                                   /* clear config */
    prev |= (active_level << 5);                                                         /* set active level */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_interrupt_active_level( adxl345_interrupt_active_level_t* active_level)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 5);                                              /* get config */
    *active_level = (adxl345_interrupt_active_level_t)(prev >> 5); /* get active level */
    return 0;                                                      /* success return 0 */
}
uint8_t adxl345_set_full_resolution( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                                                   /* clear resolution */
    prev |= (enable << 3);                                                               /* set resolution */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_full_resolution( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 3);                      /* clear config */
    *enable = (adxl345_bool_t)(prev >> 3); /* set resolution */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_justify( adxl345_justify_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(1 << 2);                                                                   /* clear config */
    prev |= (enable << 2);                                                               /* set justify */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_justify( adxl345_justify_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 2);                         /* get config */
    *enable = (adxl345_justify_t)(prev >> 2); /* get justify */
    return 0;                                 /* success return 0 */
}
uint8_t adxl345_set_range( adxl345_range_t range)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= ~(3 << 0);                                                                   /* clear config */
    prev |= (range << 0);                                                                /* set range */
    return a_adxl345_iic_spi_write( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_range( adxl345_range_t* range)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (3 << 0);                      /* get config */
    *range = (adxl345_range_t)(prev >> 0); /* set range */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_mode( adxl345_mode_t mode)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= ~(3 << 6);                                                                /* clear config */
    prev |= (mode << 6);                                                              /* set mode */
    return a_adxl345_iic_spi_write( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_mode( adxl345_mode_t* mode)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= (3 << 6);                    /* get config */
    *mode = (adxl345_mode_t)(prev >> 6); /* set mode */
    return 0;                            /* success return 0 */
}
uint8_t adxl345_set_trigger_pin( adxl345_interrupt_pin_t pin)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= ~(1 << 5);                                                                /* clear config */
    prev |= (pin << 5);                                                               /* set pin */
    return a_adxl345_iic_spi_write( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_trigger_pin( adxl345_interrupt_pin_t* pin)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= (1 << 5);                            /* clear config */
    *pin = (adxl345_interrupt_pin_t)(prev >> 5); /* set pin */
    return 0;                                    /* success return 0 */
}
uint8_t adxl345_set_watermark( uint8_t level)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= ~(0x1F);                                                                  /* clear config */
    prev |= (level & 0x1F);                                                           /* set watermark */
    return a_adxl345_iic_spi_write( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_watermark( uint8_t* level)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    prev &= (0x1F);       /* get config */
    *level = prev & 0x1F; /* get watermark */
    return 0;             /* success return 0 */
}
uint8_t adxl345_get_watermark_level( uint8_t* level)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_STATUS, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (0x3F);       /* get config */
    *level = prev & 0x3F; /* get level */
    return 0;             /* success return 0 */
}
uint8_t adxl345_get_trigger_status( adxl345_trigger_status_t* status)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_STATUS, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                      /* check result */
    {
        
    }
    prev &= (1 << 7);                                         /* get config */
    *status = (adxl345_trigger_status_t)((prev >> 7) & 0x01); /* get status */
    return 0;                                                 /* success return 0 */
}
uint8_t adxl345_set_link_activity_inactivity( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 5);                                                                 /* clear config */
    prev |= enable << 5;                                                               /* set enable */
    return a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_link_activity_inactivity( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= 1 << 5;                        /* get config */
    *enable = (adxl345_bool_t)(prev >> 5); /* get enable */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_auto_sleep( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 4);                                                                 /* get config */
    prev |= enable << 4;                                                               /* set enable */
    return a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_auto_sleep( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= 1 << 4;                        /* get config */
    *enable = (adxl345_bool_t)(prev >> 4); /* get auto sleep */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_measure( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                                                 /* clear config */
    prev |= enable << 3;                                                               /* set measure */
    return a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_measure( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= 1 << 3;                        /* get config */
    *enable = (adxl345_bool_t)(prev >> 3); /* get measure */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_sleep( adxl345_bool_t enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 2);                                                                 /* clear config */
    prev |= enable << 2;                                                               /* set sleep */
    return a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_sleep( adxl345_bool_t* enable)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= 1 << 2;                        /* get config */
    *enable = (adxl345_bool_t)(prev >> 2); /* get sleep */
    return 0;                              /* success return 0 */
}
uint8_t adxl345_set_sleep_frequency( adxl345_sleep_frequency_t sleep_frequency)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~0x03;                                                                     /* clear config */
    prev |= sleep_frequency;                                                           /* set frequency */
    return a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
}
uint8_t adxl345_get_sleep_frequency( adxl345_sleep_frequency_t* sleep_frequency)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= 0x03;                                                /* get config */
    *sleep_frequency = (adxl345_sleep_frequency_t)(prev & 0x03); /* get frequency */
    return 0;                                                    /* success return 0 */
}
static uint8_t a_adxl345_close(adxl345_handle_t* handle)
{
    if (iic_spi == ADXL345_INTERFACE_IIC) /* iic interface */
    {
        if (iic_deinit() != 0) /* iic deinit */
        {
            

        } else {
            return 0; /* success return 0 */
        }
    } else /* spi interface */
    {
        if (spi_deinit() != 0) /* spi deinit */
        {
            

        } else {
            return 0; /* success return 0 */
        }
    }
}
uint8_t adxl345_init(adxl345_handle_t* handle)
{
    uint8_t id;

    if (debug_print == NULL) /* check debug_print */

    if (iic_init == NULL) /* check iic_init */
    {
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
    }
    if (spi_init == NULL) /* check spi_init */
    {
        
    }
    if (spi_deinit == NULL) /* check spi_deinit */
    {
        
    }
    if (spi_read == NULL) /* check spi_read */
    {
        
    }
    if (spi_write == NULL) /* check spi_write */
    {
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
    }
    if (receive_callback == NULL) /* check receive_callback */
    {
        
    }
    if (iic_spi == ADXL345_INTERFACE_IIC) /* iic interface */
    {
        if (iic_init() != 0) /* initialize iic bus */
        {
            
        }
    } else /* spi interface */
    {
        if (spi_init() != 0) /* initialize spi bus */
        {
            
        }
    }
    if (a_adxl345_iic_spi_read( ADXL345_REG_DEVID, (uint8_t*)&id, 1) != 0) /* read id */
    {
        
        (void)a_adxl345_close(handle);                  /* close */
    }
    if (id != 0xE5) /* check id */
    {
        
        (void)a_adxl345_close(handle);                    /* close */
    }
    inited = 1; /* flag finish initialization */
    return 0;           /* success return 0 */
}
uint8_t adxl345_deinit(adxl345_handle_t* handle)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                    /* check result */
    {
        
    }
    prev &= ~(1 << 3);                                                                /* stop measure */
    prev |= 1 << 2;                                                                   /* sleep */
    res = a_adxl345_iic_spi_write( ADXL345_REG_POWER_CTL, (uint8_t*)&prev, 1); /* write config */
    if (res != 0)                                                                     /* check result */
    {
        

    } else {
        res = a_adxl345_close(handle); /* close */
        if (res != 0)                  /* check result */
 else {
            inited = 0; /* flag close */
            return 0;           /* success return 0 */
        }
    }
}
uint8_t adxl345_read( int16_t (*raw)[3], float (*g)[3], uint16_t* len)
{
    uint8_t res, prev;
    uint8_t mode, cnt, i;
    uint8_t justify, full_res, range;
    uint8_t buf[32 * 6];
    {

    } {
    }
    if ((*len) == 0) /* check length */
    {
        
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_CTL, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                   /* check result */
    {
        
    }
    mode = prev >> 6;                                                                   /* get mode */
    res  = a_adxl345_iic_spi_read( ADXL345_REG_DATA_FORMAT, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                       /* check result */
    {
        
    }
    full_res = (prev >> 3) & 0x01;   /* get full reselution */
    justify  = (prev >> 2) & 0x01;   /* get justify */
    range    = prev & 0x03;          /* get range */
    if (mode == ADXL345_MODE_BYPASS) /* bypass */
    {
        *len = 1;                                                                    /* set length 1 */
        res  = a_adxl345_iic_spi_read( ADXL345_REG_DATAX0, (uint8_t*)buf, 6); /* read data */
        if (res != 0)                                                                /* check result */
        {
            
        }
        raw[0][0] = (int16_t)(buf[1] << 8) | buf[0]; /* set raw z */
        raw[0][1] = (int16_t)(buf[3] << 8) | buf[2]; /* set raw y */
        raw[0][2] = (int16_t)(buf[5] << 8) | buf[4]; /* set raw z */
        if (full_res == 1)                           /* if full reselution */
        {
            if (justify == 1) /* if justify */
            {
                raw[0][0] = (raw[0][0] & 0x80) | (raw[0][0] & (~0x80)) >> (16 - 10 - range); /* set raw x */
                raw[0][1] = (raw[0][1] & 0x80) | (raw[0][1] & (~0x80)) >> (16 - 10 - range); /* set raw y */
                raw[0][2] = (raw[0][2] & 0x80) | (raw[0][2] & (~0x80)) >> (16 - 10 - range); /* set raw z */
            }
            g[0][0] = (float)(raw[0][0]) * 0.0039f; /* convert x */
            g[0][1] = (float)(raw[0][1]) * 0.0039f; /* convert y */
            g[0][2] = (float)(raw[0][2]) * 0.0039f; /* convert z */
        } else {
            if (justify == 1) /* if justify */
            {
                raw[0][0] = (raw[0][0] & 0x80) | (raw[0][0] & (~0x80)) >> (16 - 10); /* set raw z */
                raw[0][1] = (raw[0][1] & 0x80) | (raw[0][1] & (~0x80)) >> (16 - 10); /* set raw y */
                raw[0][2] = (raw[0][2] & 0x80) | (raw[0][2] & (~0x80)) >> (16 - 10); /* set raw z */
            }
            if (range == 0x00) /* if 2g */
            {
                g[0][0] = (float)(raw[0][0]) * 0.0039f; /* convert x */
                g[0][1] = (float)(raw[0][1]) * 0.0039f; /* convert y */
                g[0][2] = (float)(raw[0][2]) * 0.0039f; /* convert z */
            } else if (range == 0x01)                   /* if 4g */
            {
                g[0][0] = (float)(raw[0][0]) * 0.0078f; /* convert x */
                g[0][1] = (float)(raw[0][1]) * 0.0078f; /* convert y */
                g[0][2] = (float)(raw[0][2]) * 0.0078f; /* convert z */
            } else if (range == 0x02)                   /* if 8g */
            {
                g[0][0] = (float)(raw[0][0]) * 0.0156f; /* convert x */
                g[0][1] = (float)(raw[0][1]) * 0.0156f; /* convert y */
                g[0][2] = (float)(raw[0][2]) * 0.0156f; /* convert z */
            } else                                      /* if 16g */
            {
                g[0][0] = (float)(raw[0][0]) * 0.0312f; /* convert x */
                g[0][1] = (float)(raw[0][1]) * 0.0312f; /* convert y */
                g[0][2] = (float)(raw[0][2]) * 0.0312f; /* convert z */
            }
        }
    } else /* fifo mode */
    {
        res = a_adxl345_iic_spi_read( ADXL345_REG_FIFO_STATUS, (uint8_t*)&prev, 1); /* read fifo status */
        if (res != 0)                                                                      /* check result */
        {
            
        }
        cnt  = prev & 0x3F;                                                                   /* get cnt */
        *len = ((*len) < cnt) ? (*len) : cnt;                                                 /* get min cnt */
        res  = a_adxl345_iic_spi_read( ADXL345_REG_DATAX0, (uint8_t*)buf, 6 * (*len)); /* read data */
        if (res != 0)                                                                         /* check result */
        {
            
        }
        for (i = 0; i < (*len); i++) /* read length */
        {
            raw[i][0] = (int16_t)(buf[1 + i * 6] << 8) | buf[0 + i * 6]; /* set raw x */
            raw[i][1] = (int16_t)(buf[3 + i * 6] << 8) | buf[2 + i * 6]; /* set raw y */
            raw[i][2] = (int16_t)(buf[5 + i * 6] << 8) | buf[4 + i * 6]; /* set raw z */
            if (full_res == 1)                                           /* if full resolution */
            {
                if (justify == 1) /* if justify */
                {
                    raw[i][0] = (raw[i][0] & 0x80) | (raw[i][0] & (~0x80)) >> (16 - 10 - range); /* get raw x */
                    raw[i][1] = (raw[i][1] & 0x80) | (raw[i][1] & (~0x80)) >> (16 - 10 - range); /* get raw y */
                    raw[i][2] = (raw[i][2] & 0x80) | (raw[i][2] & (~0x80)) >> (16 - 10 - range); /* get raw z */
                }
                g[i][0] = (float)(raw[i][0]) * 0.0039f; /* convert x */
                g[i][1] = (float)(raw[i][1]) * 0.0039f; /* convert y */
                g[i][2] = (float)(raw[i][2]) * 0.0039f; /* convert z */
            } else {
                if (justify == 1) /* if justify */
                {
                    raw[i][0] = (raw[i][0] & 0x80) | (raw[i][0] & (~0x80)) >> (16 - 10); /* set raw x */
                    raw[i][1] = (raw[i][1] & 0x80) | (raw[i][1] & (~0x80)) >> (16 - 10); /* set raw y */
                    raw[i][2] = (raw[i][2] & 0x80) | (raw[i][2] & (~0x80)) >> (16 - 10); /* set raw z */
                }
                if (range == 0x00) /* if 2g */
                {
                    g[i][0] = (float)(raw[i][0]) * 0.0039f; /* convert x */
                    g[i][1] = (float)(raw[i][1]) * 0.0039f; /* convert y */
                    g[i][2] = (float)(raw[i][2]) * 0.0039f; /* convert z */
                } else if (range == 0x01)                   /* if 4g */
                {
                    g[i][0] = (float)(raw[i][0]) * 0.0078f; /* convert x */
                    g[i][1] = (float)(raw[i][1]) * 0.0078f; /* convert y */
                    g[i][2] = (float)(raw[i][2]) * 0.0078f; /* convert z */
                } else if (range == 0x02)                   /* if 8g */
                {
                    g[i][0] = (float)(raw[i][0]) * 0.0156f; /* convert x */
                    g[i][1] = (float)(raw[i][1]) * 0.0156f; /* convert y */
                    g[i][2] = (float)(raw[i][2]) * 0.0156f; /* convert z */
                } else                                      /* if 16g */
                {
                    g[i][0] = (float)(raw[i][0]) * 0.0312f; /* convert x */
                    g[i][1] = (float)(raw[i][1]) * 0.0312f; /* convert y */
                    g[i][2] = (float)(raw[i][2]) * 0.0312f; /* convert z */
                }
            }
        }
    }
    return 0; /* success return 0 */
}
uint8_t adxl345_irq_handler(adxl345_handle_t* handle)
{
    uint8_t res, prev;
    {

    } {
    }
    res = a_adxl345_iic_spi_read( ADXL345_REG_INT_SOURCE, (uint8_t*)&prev, 1); /* read config */
    if (res != 0)                                                                     /* check result */
    {
        
    }
    if ((prev & (1 << ADXL345_INTERRUPT_DATA_READY)) != 0) /* if data ready */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_DATA_READY); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_SINGLE_TAP)) != 0) /* if single tap */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_SINGLE_TAP); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_DOUBLE_TAP)) != 0) /* if double tap */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_DOUBLE_TAP); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_ACTIVITY)) != 0) /* if activity */
    {
        if (receive_callback != NULL) /*if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_ACTIVITY); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_INACTIVITY)) != 0) /* if inactivity */
    {
        if (receive_callback != NULL) /*if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_INACTIVITY); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_FREE_FALL)) != 0) /* if free fall */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_FREE_FALL); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_WATERMARK)) != 0) /* if wartermark */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_WATERMARK); /* run callback */
        }
    }
    if ((prev & (1 << ADXL345_INTERRUPT_OVERRUN)) != 0) /* if overrun */
    {
        if (receive_callback != NULL) /* if receive callback */
        {
            receive_callback(ADXL345_INTERRUPT_OVERRUN); /* run callback */
        }
    }
    return 0; /* success return 0 */
}
uint8_t adxl345_set_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {

    } {
    }
    return a_adxl345_iic_spi_write( reg, buf, len); /* write data */
}
uint8_t adxl345_get_reg( uint8_t reg, uint8_t* buf, uint16_t len)
{
    {

    } {
    }
    return a_adxl345_iic_spi_read( reg, buf, len); /* read data */
}
uint8_t adxl345_info(adxl345_info_t* info)
{
    

    memset(info, 0, sizeof(adxl345_info_t));                 /* initialize adxl345 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC SPI", 8);                  /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0;                                                /* success return 0 */
}
