
#ifndef DRIVER_ADXL345_TAP_ACTION_FALL_TEST_H
#define DRIVER_ADXL345_TAP_ACTION_FALL_TEST_H
#include "driver_adxl345_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t adxl345_action_test_irq_handler(void);
uint8_t adxl345_tap_action_fall_test(adxl345_interface_t interface, adxl345_address_t addr_pin);
#ifdef __cplusplus
}
#endif
#endif
