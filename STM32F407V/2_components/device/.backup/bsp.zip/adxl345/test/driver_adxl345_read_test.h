
#ifndef DRIVER_ADXL345_READ_TEST_H
#define DRIVER_ADXL345_READ_TEST_H
#include "driver_adxl345_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t adxl345_read_test(adxl345_interface_t interface, adxl345_address_t addr_pin, uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
