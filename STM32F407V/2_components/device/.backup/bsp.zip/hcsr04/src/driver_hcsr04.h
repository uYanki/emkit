
#ifndef DRIVER_HCSR04_H
#define DRIVER_HCSR04_H
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
#ifndef HCSR04_READ_RETRY_TIMES
#define HCSR04_READ_RETRY_TIMES 3  // retry 3 times
#endif
typedef struct hcsr04_time_s {
    uint32_t microsecond;  // microsecond
    uint32_t millisecond;  // millisecond
} hcsr04_time_t;
typedef struct hcsr04_handle_s {
    uint8_t inited;  // inited flag
} hcsr04_handle_t;

uint8_t hcsr04_info(hcsr04_info_t* info);
uint8_t hcsr04_init(hcsr04_handle_t* handle);
uint8_t hcsr04_deinit(hcsr04_handle_t* handle);
uint8_t hcsr04_read(hcsr04_handle_t* handle, uint32_t* time_us, float* m);
#ifdef __cplusplus
}
#endif
#endif
