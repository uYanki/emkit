
#include "driver_hcsr04.h"

#define MANUFACTURER_NAME  "JieShenna"        // manufacturer name
#define SUPPLY_VOLTAGE_MIN 4.8f               // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 5.0f               // chip max supply voltage




uint8_t hcsr04_init(hcsr04_handle_t* handle)
{
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (trig_init == NULL) /* check trig_init */
    {
        
        
    }
    if (trig_deinit == NULL) /* check trig_deinit */
    {
        
        
    }
    if (trig_write == NULL) /* check trig_write */
    {
        
        
    }
    if (echo_init == NULL) /* check echo_init */
    {
        
        
    }
    if (echo_deinit == NULL) /* check echo_deinit */
    {
        
        
    }
    if (echo_read == NULL) /* check echo_read */
    {
        
        
    }
    if (delay_us == NULL) /* check delay_us */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (timestamp_read == NULL) /* check timestamp_read */
    {
        
        
    }
    if (trig_init() != 0) /* initialize trig */
    {
        
        
    }
    if (echo_init() != 0) /* initialize echo */
    {
        
        (void)trig_deinit();                   /* deinit trig */
        
    }
    inited = 1; /* flag finish initialization */
    return 0; /* success return 0 */
}
uint8_t hcsr04_deinit(hcsr04_handle_t* handle)
{
    {
        
    }
    {
        
    }
    if (echo_deinit() != 0) /* echo deinit */
    {
        
        
    }
    if (trig_deinit() != 0) /* trig deinit */
    {
        
        
    }
    inited = 0; /* flag close */
    return 0; /* success return 0 */
}
uint8_t hcsr04_read( uint32_t* time_us, float* m)
{
    uint8_t       res, value;
    hcsr04_time_t time_start;
    hcsr04_time_t time_stop;
    uint32_t      timeout;
    uint8_t       retry = HCSR04_READ_RETRY_TIMES;
    {
        
    }
    {
        
    }
    while (1) /* loop */
    {
        res = trig_write(1); /* write trig 1 */
        if (res != 0)                /* check result */
        {
            
            
        }
        delay_us(20);        /* delay 20 us */
        res = trig_write(0); /* write trig 0 */
        if (res != 0)                /* check result */
        {
            
            
        }
        value   = 0;           /* reset value */
        timeout = 1000 * 5000; /* set timeout */
        while (value == 0)     /* wait 5 s */
        {
            res = echo_read((uint8_t*)&value); /* read echo data */
            if (res != 0)                              /* check result */
            {
                
                
            }
            delay_us(1); /* delay 1 us */
            timeout--;           /* timeout-- */
            if (timeout == 0)    /* if timeout */
            {
                
                
            }
        }
        res = timestamp_read((hcsr04_time_t*)&time_start); /* read timestamp */
        if (res != 0)                                              /* check result */
        {
            
            
        }
        value   = 1;           /* reset value */
        timeout = 1000 * 5000; /* wait 5 s */
        while (value != 0)     /* check value */
        {
            res = echo_read((uint8_t*)&value); /* read echo data */
            if (res != 0)                              /* check result */
            {
                
                
            }
            delay_us(1); /* delay 1 us */
            timeout--;           /* timeout-- */
            if (timeout == 0)    /* if timeout */
            {
                
                
            }
        }
        res = timestamp_read((hcsr04_time_t*)&time_stop); /* read timestamp */
        if (res != 0)                                             /* check result */
        {
            
            
        }
        if (time_stop.millisecond < time_start.millisecond) /* check timestamp */
        {
            
            
        }
        *time_us = (time_stop.millisecond - time_start.millisecond) * 1000 + (int32_t)(time_stop.microsecond - time_start.microsecond); /* get time */
        if ((*time_us) > 150 * 1000)                                                                                                    /* check time */
        {
            if (retry != 0) /* check remain retry times */
            {
                retry--;                              /* retry times-- */
                delay_ms(150 + rand() % 100); /* delay rand time */
            } else {
                
                
            }
        } else {
            break; /* successful */
        }
    }
    *m = 340.0f / 2.0f * (float)(*time_us) / 1000000.0f; /* calculate distance */
    return 0; /* success return 0 */
}
uint8_t hcsr04_info(hcsr04_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(hcsr04_info_t));                  /* initialize hcsr04 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "GPIO", 8);                     /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
