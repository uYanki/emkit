
#ifndef DRIVER_HCSR04_READ_TEST_H
#define DRIVER_HCSR04_READ_TEST_H
#include <driver_hcsr04_interface.h>
#ifdef __cplusplus
extern "C"{
#endif
uint8_t hcsr04_read_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
