
#ifndef DRIVER_HCSR04_BASIC_H
#define DRIVER_HCSR04_BASIC_H
#include "driver_hcsr04_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t hcsr04_basic_init(void);
uint8_t hcsr04_basic_deinit(void);
uint8_t hcsr04_basic_read(float *m);
#ifdef __cplusplus
}
#endif
#endif
