
#ifndef DRIVER_HX711_BASIC_H
#define DRIVER_HX711_BASIC_H
#include "driver_hx711_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
#define HX711_BASIC_DEFAULT_MODE HX711_MODE_CHANNEL_A_GAIN_128        // 128 gain 
uint8_t hx711_basic_init(void);
uint8_t hx711_basic_deinit(void);
uint8_t hx711_basic_read(int32_t *raw_voltage, double *voltage_v);
#ifdef __cplusplus
}
#endif
#endif
