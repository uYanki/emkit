
#ifndef DRIVER_HX711_READ_TEST_H
#define DRIVER_HX711_READ_TEST_H
#include "driver_hx711_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t hx711_read_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
