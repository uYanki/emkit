
  
#include "driver_hx711.h"

#define MANUFACTURER_NAME         "Aviaic"              // manufacturer name
#define SUPPLY_VOLTAGE_MIN        2.6f                  // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX        5.5f                  // chip max supply voltage




static uint8_t a_hx711_read_ad(hx711_handle_t *handle, uint8_t len, int32_t *value)
{
    uint32_t val = 0;
    uint32_t cnt = 0;
    uint8_t i;
    uint8_t v;
    if (clock_write(0) != 0)                                      /* write clock 0 */
    {
        
        
        
    }
    while (1)                                                             /* loop */
    {
        delay_us(100);                                            /* wait 100 us */
        if (bus_read((uint8_t *)&v) != 0)                         /* bus read failed */
        {
            
            
            
        }
        cnt++;                                                            /* increase timeout cnt */
        if (v == 1)                                                       /* if v==1 */
        {
            if (cnt >= 50000)                                             /* check timeout */
            {
                
                
                
            }
        }
        else
        {
            break;                                                        /* break */
        }
    }
    disable_irq();                                                /* disable interrupt */
    delay_us(1);                                                  /* wait 1 us */
    for (i = 0; i < 24; i++)                                              /* read 24 bits */
    {
        if (clock_write(1) != 0)                                  /* write clock 1 */
        {
            enable_irq();                                         /* enable interrupt */
            
            
            
        }
        val = val << 1;                                                   /* left shift 1 */
        delay_us(1);                                              /* wait 1 us */
        if (clock_write(0) != 0)                                  /* write clock 0 */
        {
            enable_irq();                                         /* enable interrupt */
            
            
            
        }
        if (bus_read((uint8_t *)&v) != 0)                         /* read 1 bit */
        {
            enable_irq();                                         /* enable interrupt */
            
            
            
        }
        if (v != 0)                                                       /* check v */
        {
            val++;                                                        /* value++ */
        }
        delay_us(1);                                              /* wait 1 us */
    }
    while (len != 0)                                                      /* send pulses */
    {
        if (clock_write(1) != 0)                                  /* write clock 1 */
        {
            enable_irq();                                         /* enable interrupt */
            
            
            
        }
        delay_us(1);                                              /* wait 1 us */
        if (clock_write(0) != 0)                                  /* write clock 0 */
        {
            enable_irq();                                         /* enable interrupt */
            
            
            
        }
        delay_us(1);                                              /* wait 1 us */
        len--;                                                            /* length-- */
    }
    enable_irq();                                                 /* enable interrupt */
    if ((val & 0x800000) != 0)                                            /* check negtive bit */
    {
        union 
        {
            int32_t i_f;
            uint32_t u_f;
        } u;
        val = 0xFF000000U | val;                                          /* set negtive value */
        u.u_f = val;                                                      /* set negtive value */
        *value = (int32_t)u.i_f;                                          /* set negtive value */
    }
    else
    {
        *value = (int32_t)val;                                            /* set positive value */
    }
    return 0;                                                             /* success return 0 */
}
uint8_t hx711_init(hx711_handle_t *handle)
{
    
    {
        
    }
    if (debug_print == NULL)                                 /* check debug_print */
    {
        
    }
    if (bus_init == NULL)                                    /* check bus_init */
    {
        
        
        
    }
    if (bus_deinit == NULL)                                  /* check bus_deinit */
    {
        
        
        
    }
    if (bus_read == NULL)                                    /* check bus_read */
    {
        
        
        
    }
    if (clock_init == NULL)                                  /* check clock_init */
    {
        
        
        
    }
    if (clock_deinit == NULL)                                /* check clock_deinit */
    {
        
        
        
    }
    if (clock_write == NULL)                                 /* check clock_write */
    {
        
        
        
    }
    if (delay_us == NULL)                                    /* check delay_us */
    {
        
        
        
    }
    if (enable_irq == NULL)                                  /* check enable_irq */
    {
        
        
        
    }
    if (disable_irq == NULL)                                 /* check disable_irq */
    {
        
        
        
    }
    if (clock_init() != 0)                                   /* initialize clock */
    {
        
        
        
    }
    if (bus_init() != 0)                                     /* initialize bus */
    {
        
        (void)clock_deinit();                                /* deinit clock */
        
        
    }
    inited = 1;                                              /* flag finish initialization */
    mode = 1;                                                /* set mode */
    return 0;                                                        /* success return 0 */
}
uint8_t hx711_deinit(hx711_handle_t *handle)
{
    
    {
        
    }
    
    {
        
    }
    if (bus_deinit() != 0)                                   /* deinit bus */
    {
        
        
        
    }   
    if (clock_deinit() != 0)                                 /* deinit clock */
    {
        
        
    } 
    inited = 0;                                              /* flag close */
    return 0;                                                        /* success return 0 */
}
uint8_t hx711_set_mode(hx711_handle_t *handle, hx711_mode_t mode)
{
    int32_t value; 
    
    {
        
    }
    
    {
        
    }
    mode = (uint8_t)mode;                                             /* set mode */
    if (a_hx711_read_ad( mode, (int32_t *)&value) != 0)        /* make mode valid */
    {
        
        
        
    }
    return 0;                                                                 /* success return 0 */
}
uint8_t hx711_get_mode(hx711_handle_t *handle, hx711_mode_t *mode)
{
    
    {
        
    }
    
    {
        
    }
    *mode = (hx711_mode_t)(mode);        /* get mode */
    return 0;                                    /* success return 0 */
}
uint8_t hx711_read(hx711_handle_t *handle, int32_t *raw, double *voltage_v)
{
    
    {
        
    }
    
    {
        
    }
    if (a_hx711_read_ad( mode, (int32_t *)raw) != 0)          /* read ad */
    {
        
        
        
    }
    if (mode == (uint8_t)HX711_MODE_CHANNEL_A_GAIN_128)              /* if gain 128 */
    {
        *voltage_v = (double)(*raw) * (20.0 / (pow(2.0, 24.0))) / 1000.0;    /* calculate gain 128 */
        
        return 0;                                                            /* success return 0 */
    }
    else if (mode == (uint8_t)HX711_MODE_CHANNEL_B_GAIN_32)          /* if gain 32 */
    {
        *voltage_v = (double)(*raw) * (80.0 / (pow(2.0, 24.0))) / 1000.0;    /* calculate gain 32 */
        
        return 0;                                                            /* success return 0 */
    }
    else if (mode == (uint8_t)HX711_MODE_CHANNEL_A_GAIN_64)          /* if gain 64 */
    {
        *voltage_v = (double)(*raw) * (40.0 / (pow(2.0, 24.0))) / 1000.0;    /* calculate gain 64 */
        
        return 0;                                                            /* success return 0 */
    }
    else
    {
        
        
        
    }
}
uint8_t hx711_info(hx711_info_t *info)
{
    
    {
        
    }
    memset(info, 0, sizeof(hx711_info_t));                          /* initialize hx711 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                        /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32);        /* copy manufacturer name */
    strncpy(info->interface, "GPIO", 8);                            /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;                /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;                /* set maximum supply voltage */
    info->max_current_ma = MAX_CURRENT;                             /* set maximum current */
    info->temperature_max = TEMPERATURE_MAX;                        /* set minimal temperature */
    info->temperature_min = TEMPERATURE_MIN;                        /* set maximum temperature */
    info->driver_version = DRIVER_VERSION;                          /* set driver verison */
    return 0;                                                       /* success return 0 */
}
