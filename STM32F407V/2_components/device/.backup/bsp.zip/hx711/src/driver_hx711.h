
#ifndef DRIVER_HX711_H
#define DRIVER_HX711_H
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    HX711_MODE_CHANNEL_A_GAIN_128 = 0x01,  // channel A 128 gain
    HX711_MODE_CHANNEL_B_GAIN_32  = 0x02,  // channel B 32 gain
    HX711_MODE_CHANNEL_A_GAIN_64  = 0x03,  // channel A 64 gain
} hx711_mode_t;
typedef struct hx711_handle_s {
    uint8_t inited;  // inited flag
    uint8_t mode;    // chip mode
} hx711_handle_t;

uint8_t hx711_info(hx711_info_t* info);
uint8_t hx711_init(hx711_handle_t* handle);
uint8_t hx711_deinit(hx711_handle_t* handle);
uint8_t hx711_set_mode(hx711_handle_t* handle, hx711_mode_t mode);
uint8_t hx711_get_mode(hx711_handle_t* handle, hx711_mode_t* mode);
uint8_t hx711_read(hx711_handle_t* handle, int32_t* raw, double* voltage_v);
#ifdef __cplusplus
}
#endif
#endif
