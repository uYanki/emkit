
#ifndef DRIVER_APDS9960_H
#define DRIVER_APDS9960_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif
#ifndef APDS9960_GESTURE_THRESHOLD
#define APDS9960_GESTURE_THRESHOLD 10  // 10
#endif
#ifndef APDS9960_GESTURE_SENSITIVITY_1
#define APDS9960_GESTURE_SENSITIVITY_1 50  // 50
#endif
#ifndef APDS9960_GESTURE_SENSITIVITY_2
#define APDS9960_GESTURE_SENSITIVITY_2 20  // 20
#endif
typedef enum {
    APDS9960_BOOL_FALSE = 0x00,  // false
    APDS9960_BOOL_TRUE  = 0x01,  // true
} apds9960_bool_t;
typedef enum {
    APDS9960_CONF_GESTURE_ENABLE             = 6,  // gesture enable
    APDS9960_CONF_PROXIMITY_INTERRUPT_ENABLE = 5,  // proximity interrupt enable
    APDS9960_CONF_ALS_INTERRUPT_ENABLE       = 4,  // als interrupt enable
    APDS9960_CONF_WAIT_ENABLE                = 3,  // wait enable
    APDS9960_CONF_PROXIMITY_DETECT_ENABLE    = 2,  // proximity detect enable
    APDS9960_CONF_ALS_ENABLE                 = 1,  // als enable
    APDS9960_CONF_POWER_ON                   = 0,  // power on
} apds9960_conf_t;
typedef enum {
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_EVERY = 0,   // every proximity cycle
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_ANY   = 1,   // any proximity value outside of threshold range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_2     = 2,   // 2 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_3     = 3,   // 3 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_4     = 4,   // 4 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_5     = 5,   // 5 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_6     = 6,   // 6 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_7     = 7,   // 7 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_8     = 8,   // 8 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_9     = 9,   // 9 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_10    = 10,  // 10 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_11    = 11,  // 11 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_12    = 12,  // 12 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_13    = 13,  // 13 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_14    = 14,  // 14 consecutive proximity values out of range
    APDS9960_PROXIMITY_INTERRUPT_CYCLE_15    = 15,  // 15 consecutive proximity values out of range
} apds9960_proximity_interrupt_cycle_t;
typedef enum {
    APDS9960_ALS_INTERRUPT_CYCLE_EVERY = 0,   // every als cycle
    APDS9960_ALS_INTERRUPT_CYCLE_ANY   = 1,   // any als value outside of threshold range
    APDS9960_ALS_INTERRUPT_CYCLE_2     = 2,   // 2 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_3     = 3,   // 3 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_5     = 4,   // 5 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_10    = 5,   // 10 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_15    = 6,   // 15 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_20    = 7,   // 20 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_25    = 8,   // 25 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_30    = 9,   // 30 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_35    = 10,  // 35 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_40    = 11,  // 40 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_45    = 12,  // 45 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_50    = 13,  // 50 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_55    = 14,  // 55 consecutive als values out of range
    APDS9960_ALS_INTERRUPT_CYCLE_60    = 15,  // 60 consecutive als values out of range
} apds9960_als_interrupt_cycle_t;
typedef enum {
    APDS9960_PROXIMITY_PULSE_LENGTH_4_US  = 0x00,  // 4 us
    APDS9960_PROXIMITY_PULSE_LENGTH_8_US  = 0x01,  // 8 us
    APDS9960_PROXIMITY_PULSE_LENGTH_16_US = 0x02,  // 16 us
    APDS9960_PROXIMITY_PULSE_LENGTH_32_US = 0x03,  // 32 us
} apds9960_proximity_pulse_length_t;
typedef enum {
    APDS9960_LED_CURRENT_100_MA  = 0x00,  // 100 mA
    APDS9960_LED_CURRENT_50_MA   = 0x01,  // 50 mA
    APDS9960_LED_CURRENT_25_MA   = 0x02,  // 25 mA
    APDS9960_LED_CURRENT_12P5_MA = 0x03,  // 12.5 mA
} apds9960_led_current_t;
typedef enum {
    APDS9960_PROXIMITY_GAIN_1X = 0x00,  // 1x
    APDS9960_PROXIMITY_GAIN_2X = 0x01,  // 2x
    APDS9960_PROXIMITY_GAIN_4X = 0x02,  // 4x
    APDS9960_PROXIMITY_GAIN_8X = 0x03,  // 8x
} apds9960_proximity_gain_t;
typedef enum {
    APDS9960_ALS_COLOR_GAIN_1X  = 0x00,  // 1x
    APDS9960_ALS_COLOR_GAIN_4X  = 0x01,  // 4x
    APDS9960_ALS_COLOR_GAIN_16X = 0x02,  // 16x
    APDS9960_ALS_COLOR_GAIN_64X = 0x03,  // 64x
} apds9960_als_color_gain_t;
typedef enum {
    APDS9960_SATURATION_INTERRUPT_PROXIMITY        = 7,  // proximity saturation interrupt
    APDS9960_SATURATION_INTERRUPT_CLEAR_PHOTODIODE = 6,  // clear photodiode saturation interrupt
} apds9960_saturation_interrupt_t;
typedef enum {
    APDS9960_LED_BOOST_100_PERCENTAGE = 0x00,  // 100%
    APDS9960_LED_BOOST_150_PERCENTAGE = 0x01,  // 150%
    APDS9960_LED_BOOST_200_PERCENTAGE = 0x02,  // 200%
    APDS9960_LED_BOOST_300_PERCENTAGE = 0x03,  // 300%
} apds9960_led_boost_t;
typedef enum {
    APDS9960_STATUS_CPSAT  = 7,  // clear photodiode saturation
    APDS9960_STATUS_PGSAT  = 6,  // indicates that an analog saturation event occurred during a previous proximity or gesture cycle
    APDS9960_STATUS_PINT   = 5,  // proximity interrupt
    APDS9960_STATUS_AINT   = 4,  // als interrupt
    APDS9960_STATUS_GINT   = 2,  // gesture interrupt
    APDS9960_STATUS_PVALID = 1,  // proximity valid
    APDS9960_STATUS_AVALID = 0,  // als valid
} apds9960_status_t;
typedef enum {
    APDS9960_PROXIMITY_MASK_UP    = 3,  // proximity mask up
    APDS9960_PROXIMITY_MASK_DOWN  = 2,  // proximity mask down
    APDS9960_PROXIMITY_MASK_LEFT  = 1,  // proximity mask left
    APDS9960_PROXIMITY_MASK_RIGHT = 0,  // proximity mask right
} apds9960_proximity_mask_t;
typedef enum {
    APDS9960_GESTURE_FIFO_THRESHOLD_1_DATASET  = 0,  // interrupt is generated after 1 dataset is added to fifo
    APDS9960_GESTURE_FIFO_THRESHOLD_4_DATASET  = 1,  // interrupt is generated after 4 dataset is added to fifo
    APDS9960_GESTURE_FIFO_THRESHOLD_8_DATASET  = 2,  // interrupt is generated after 8 dataset is added to fifo
    APDS9960_GESTURE_FIFO_THRESHOLD_16_DATASET = 3,  // interrupt is generated after 16 dataset is added to fifo
} apds9960_gesture_fifo_threshold_t;
typedef enum {
    APDS9960_GESTURE_EXIT_PERSISTENCE_1ST = 0,  // 1st 'gesture end' occurrence results in gesture state machine exit
    APDS9960_GESTURE_EXIT_PERSISTENCE_2ND = 1,  // 2nd 'gesture end' occurrence results in gesture state machine exit
    APDS9960_GESTURE_EXIT_PERSISTENCE_4TH = 2,  // 4th 'gesture end' occurrence results in gesture state machine exit
    APDS9960_GESTURE_EXIT_PERSISTENCE_7TH = 3,  // 7th 'gesture end' occurrence results in gesture state machine exit
} apds9960_gesture_exit_persistence_t;
typedef enum {
    APDS9960_GESTURE_GAIN_1X = 0,  // 1x
    APDS9960_GESTURE_GAIN_2X = 1,  // 2x
    APDS9960_GESTURE_GAIN_4X = 2,  // 4x
    APDS9960_GESTURE_GAIN_8X = 3,  // 8x
} apds9960_gesture_gain_control_t;
typedef enum {
    APDS9960_GESTURE_LED_CURRENT_100_MA  = 0x00,  // 100 mA
    APDS9960_GESTURE_LED_CURRENT_50_MA   = 0x01,  // 50 mA
    APDS9960_GESTURE_LED_CURRENT_25_MA   = 0x02,  // 25 mA
    APDS9960_GESTURE_LED_CURRENT_12P5_MA = 0x03,  // 12.5 mA
} apds9960_gesture_led_current_t;
typedef enum {
    APDS9960_GESTURE_WAIT_TIME_0_MS    = 0x00,  // 0 ms
    APDS9960_GESTURE_WAIT_TIME_2P8_MS  = 0x01,  // 2.8 ms
    APDS9960_GESTURE_WAIT_TIME_5P6_MS  = 0x02,  // 5.6 ms
    APDS9960_GESTURE_WAIT_TIME_8P4_MS  = 0x03,  // 8.4 ms
    APDS9960_GESTURE_WAIT_TIME_14_MS   = 0x04,  // 14 ms
    APDS9960_GESTURE_WAIT_TIME_22P4_MS = 0x05,  // 22.4 ms
    APDS9960_GESTURE_WAIT_TIME_30P8_MS = 0x06,  // 30.8 ms
    APDS9960_GESTURE_WAIT_TIME_39P2_MS = 0x07,  // 39.2 ms
} apds9960_gesture_wait_time_t;
typedef enum {
    APDS9960_GESTURE_PULSE_LENGTH_4_US  = 0x00,  // 4 us
    APDS9960_GESTURE_PULSE_LENGTH_8_US  = 0x01,  // 8 us
    APDS9960_GESTURE_PULSE_LENGTH_16_US = 0x02,  // 16 us
    APDS9960_GESTURE_PULSE_LENGTH_32_US = 0x03,  // 32 us
} apds9960_gesture_pulse_length_t;
typedef enum {
    APDS9960_GESTURE_DIMENSION_SELECT_BOTH_PAIRS_ACTIVE            = 0x00,  // both pairs are active
    APDS9960_GESTURE_DIMENSION_SELECT_ONLY_UP_DOWN_PAIRS_ACTIVE    = 0x01,  // only the up down pair is active
    APDS9960_GESTURE_DIMENSION_SELECT_ONLY_LEFT_RIGHT_PAIRS_ACTIVE = 0x02,  // only the left right pair is active
} apds9960_gesture_dimension_select_t;
typedef enum {
    APDS9960_GESTURE_STATUS_FIFO_OVERFLOW = 0x01,  // gesture fifo overflow
    APDS9960_GESTURE_STATUS_FIFO_VALID    = 0x00,  // gesture fifo data
} apds9960_gesture_status_t;
typedef enum {
    APDS9960_INTERRUPT_STATUS_GESTURE_LEFT  = 15,  // gesture left
    APDS9960_INTERRUPT_STATUS_GESTURE_RIGHT = 14,  // gesture right
    APDS9960_INTERRUPT_STATUS_GESTURE_UP    = 13,  // gesture up
    APDS9960_INTERRUPT_STATUS_GESTURE_DOWN  = 12,  // gesture down
    APDS9960_INTERRUPT_STATUS_GESTURE_NEAR  = 11,  // gesture near
    APDS9960_INTERRUPT_STATUS_GESTURE_FAR   = 10,  // gesture far
    APDS9960_INTERRUPT_STATUS_GFOV          = 9,   // gesture fifo overflow
    APDS9960_INTERRUPT_STATUS_GVALID        = 8,   // gesture fifo data
    APDS9960_INTERRUPT_STATUS_CPSAT         = 7,   // clear photodiode saturation
    APDS9960_INTERRUPT_STATUS_PGSAT         = 6,   // indicates that an analog saturation event occurred during a previous proximity or gesture cycle
    APDS9960_INTERRUPT_STATUS_PINT          = 5,   // proximity interrupt
    APDS9960_INTERRUPT_STATUS_AINT          = 4,   // als interrupt
    APDS9960_INTERRUPT_STATUS_GINT          = 2,   // gesture interrupt
    APDS9960_INTERRUPT_STATUS_PVALID        = 1,   // proximity valid
    APDS9960_INTERRUPT_STATUS_AVALID        = 0,   // als valid
} apds9960_interrupt_status_t;
typedef struct apds9960_handle_s {
    uint8_t inited;                 // inited flag
    uint8_t gesture_status;         // gesture status
    uint8_t gesture_threshold;      // gesture threshold
    int32_t gesture_sensitivity_1;  // gesture sensitivity 1
    int32_t gesture_sensitivity_2;  // gesture sensitivity 2
    int32_t gesture_ud_delta;       // gesture ud delta
    int32_t gesture_lr_delta;       // gesture lr delta
    int32_t gesture_ud_count;       // gesture ud count
    int32_t gesture_lr_count;       // gesture lr count
    int32_t gesture_near_count;     // gesture near count
    int32_t gesture_far_count;      // gesture far count
} apds9960_handle_t;

uint8_t apds9960_info(apds9960_info_t* info);
uint8_t apds9960_irq_handler(apds9960_handle_t* handle);
uint8_t apds9960_init(apds9960_handle_t* handle);
uint8_t apds9960_deinit(apds9960_handle_t* handle);
uint8_t apds9960_read_rgbc(apds9960_handle_t* handle, uint16_t* red, uint16_t* green, uint16_t* blue, uint16_t* clear);
uint8_t apds9960_read_proximity(apds9960_handle_t* handle, uint8_t* proximity);
uint8_t apds9960_read_gesture_fifo(apds9960_handle_t* handle, uint8_t (*data)[4], uint8_t* len);
uint8_t apds9960_gesture_decode(apds9960_handle_t* handle, uint8_t (*data)[4], uint8_t len);
uint8_t apds9960_set_gesture_decode_threshold(apds9960_handle_t* handle, uint8_t threshold);
uint8_t apds9960_get_gesture_decode_threshold(apds9960_handle_t* handle, uint8_t* threshold);
uint8_t apds9960_set_gesture_decode_sensitivity_1(apds9960_handle_t* handle, int32_t sensitivity);
uint8_t apds9960_get_gesture_decode_sensitivity_1(apds9960_handle_t* handle, int32_t* sensitivity);
uint8_t apds9960_set_gesture_decode_sensitivity_2(apds9960_handle_t* handle, int32_t sensitivity);
uint8_t apds9960_get_gesture_decode_sensitivity_2(apds9960_handle_t* handle, int32_t* sensitivity);
uint8_t apds9960_set_conf(apds9960_handle_t* handle, apds9960_conf_t conf, apds9960_bool_t enable);
uint8_t apds9960_get_conf(apds9960_handle_t* handle, apds9960_conf_t conf, apds9960_bool_t* enable);
uint8_t apds9960_set_adc_integration_time(apds9960_handle_t* handle, uint8_t integration_time);
uint8_t apds9960_get_adc_integration_time(apds9960_handle_t* handle, uint8_t* integration_time);
uint8_t apds9960_adc_integration_time_convert_to_register(apds9960_handle_t* handle, float ms, uint8_t* reg);
uint8_t apds9960_adc_integration_time_convert_to_data(apds9960_handle_t* handle, uint8_t reg, float* ms);
uint8_t apds9960_set_wait_time(apds9960_handle_t* handle, uint8_t wait_time);
uint8_t apds9960_get_wait_time(apds9960_handle_t* handle, uint8_t* wait_time);
uint8_t apds9960_wait_time_convert_to_register(apds9960_handle_t* handle, float ms, uint8_t* reg);
uint8_t apds9960_wait_time_convert_to_data(apds9960_handle_t* handle, uint8_t reg, float* ms);
uint8_t apds9960_set_als_interrupt_low_threshold(apds9960_handle_t* handle, uint16_t threshold);
uint8_t apds9960_get_als_interrupt_low_threshold(apds9960_handle_t* handle, uint16_t* threshold);
uint8_t apds9960_set_als_interrupt_high_threshold(apds9960_handle_t* handle, uint16_t threshold);
uint8_t apds9960_get_als_interrupt_high_threshold(apds9960_handle_t* handle, uint16_t* threshold);
uint8_t apds9960_set_proximity_interrupt_low_threshold(apds9960_handle_t* handle, uint8_t threshold);
uint8_t apds9960_get_proximity_interrupt_low_threshold(apds9960_handle_t* handle, uint8_t* threshold);
uint8_t apds9960_set_proximity_interrupt_high_threshold(apds9960_handle_t* handle, uint8_t threshold);
uint8_t apds9960_get_proximity_interrupt_high_threshold(apds9960_handle_t* handle, uint8_t* threshold);
uint8_t apds9960_set_proximity_interrupt_cycle(apds9960_handle_t* handle, apds9960_proximity_interrupt_cycle_t cycle);
uint8_t apds9960_get_proximity_interrupt_cycle(apds9960_handle_t* handle, apds9960_proximity_interrupt_cycle_t* cycle);
uint8_t apds9960_set_als_interrupt_cycle(apds9960_handle_t* handle, apds9960_als_interrupt_cycle_t cycle);
uint8_t apds9960_get_als_interrupt_cycle(apds9960_handle_t* handle, apds9960_als_interrupt_cycle_t* cycle);
uint8_t apds9960_set_wait_long(apds9960_handle_t* handle, apds9960_bool_t enable);
uint8_t apds9960_get_wait_long(apds9960_handle_t* handle, apds9960_bool_t* enable);
uint8_t apds9960_set_proximity_pulse_length(apds9960_handle_t* handle, apds9960_proximity_pulse_length_t len);
uint8_t apds9960_get_proximity_pulse_length(apds9960_handle_t* handle, apds9960_proximity_pulse_length_t* len);
uint8_t apds9960_set_proximity_pulse_count(apds9960_handle_t* handle, uint16_t count);
uint8_t apds9960_get_proximity_pulse_count(apds9960_handle_t* handle, uint16_t* count);
uint8_t apds9960_set_led_current(apds9960_handle_t* handle, apds9960_led_current_t current);
uint8_t apds9960_get_led_current(apds9960_handle_t* handle, apds9960_led_current_t* current);
uint8_t apds9960_set_proximity_gain(apds9960_handle_t* handle, apds9960_proximity_gain_t gain);
uint8_t apds9960_get_proximity_gain(apds9960_handle_t* handle, apds9960_proximity_gain_t* gain);
uint8_t apds9960_set_als_color_gain(apds9960_handle_t* handle, apds9960_als_color_gain_t gain);
uint8_t apds9960_get_als_color_gain(apds9960_handle_t* handle, apds9960_als_color_gain_t* gain);
uint8_t apds9960_set_saturation_interrupt(apds9960_handle_t* handle, apds9960_saturation_interrupt_t saturation, apds9960_bool_t enable);
uint8_t apds9960_get_saturation_interrupt(apds9960_handle_t* handle, apds9960_saturation_interrupt_t saturation, apds9960_bool_t* enable);
uint8_t apds9960_set_led_boost(apds9960_handle_t* handle, apds9960_led_boost_t boost);
uint8_t apds9960_get_led_boost(apds9960_handle_t* handle, apds9960_led_boost_t* boost);
uint8_t apds9960_get_status(apds9960_handle_t* handle, uint8_t* status);
uint8_t apds9960_set_proximity_up_right_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_proximity_up_right_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_proximity_down_left_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_proximity_down_left_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_proximity_gain_compensation(apds9960_handle_t* handle, apds9960_bool_t enable);
uint8_t apds9960_get_proximity_gain_compensation(apds9960_handle_t* handle, apds9960_bool_t* enable);
uint8_t apds9960_set_sleep_after_interrupt(apds9960_handle_t* handle, apds9960_bool_t enable);
uint8_t apds9960_get_sleep_after_interrupt(apds9960_handle_t* handle, apds9960_bool_t* enable);
uint8_t apds9960_set_proximity_mask(apds9960_handle_t* handle, apds9960_proximity_mask_t mask, apds9960_bool_t enable);
uint8_t apds9960_get_proximity_mask(apds9960_handle_t* handle, apds9960_proximity_mask_t mask, apds9960_bool_t* enable);
uint8_t apds9960_set_gesture_proximity_enter_threshold(apds9960_handle_t* handle, uint8_t threshold);
uint8_t apds9960_get_gesture_proximity_enter_threshold(apds9960_handle_t* handle, uint8_t* threshold);
uint8_t apds9960_set_gesture_proximity_exit_threshold(apds9960_handle_t* handle, uint8_t threshold);
uint8_t apds9960_get_gesture_proximity_exit_threshold(apds9960_handle_t* handle, uint8_t* threshold);
uint8_t apds9960_set_gesture_fifo_threshold(apds9960_handle_t* handle, apds9960_gesture_fifo_threshold_t threshold);
uint8_t apds9960_get_gesture_fifo_threshold(apds9960_handle_t* handle, apds9960_gesture_fifo_threshold_t* threshold);
uint8_t apds9960_set_gesture_exit_persistence(apds9960_handle_t* handle, apds9960_gesture_exit_persistence_t persistence);
uint8_t apds9960_get_gesture_exit_persistence(apds9960_handle_t* handle, apds9960_gesture_exit_persistence_t* persistence);
uint8_t apds9960_set_gesture_exit_mask(apds9960_handle_t* handle, uint8_t mask);
uint8_t apds9960_get_gesture_exit_mask(apds9960_handle_t* handle, uint8_t* mask);
uint8_t apds9960_set_gesture_gain(apds9960_handle_t* handle, apds9960_gesture_gain_control_t gain);
uint8_t apds9960_get_gesture_gain(apds9960_handle_t* handle, apds9960_gesture_gain_control_t* gain);
uint8_t apds9960_set_gesture_led_current(apds9960_handle_t* handle, apds9960_gesture_led_current_t current);
uint8_t apds9960_get_gesture_led_current(apds9960_handle_t* handle, apds9960_gesture_led_current_t* current);
uint8_t apds9960_set_gesture_wait_time(apds9960_handle_t* handle, apds9960_gesture_wait_time_t t);
uint8_t apds9960_get_gesture_wait_time(apds9960_handle_t* handle, apds9960_gesture_wait_time_t* t);
uint8_t apds9960_set_gesture_up_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_gesture_up_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_gesture_down_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_gesture_down_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_gesture_left_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_gesture_left_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_gesture_right_offset(apds9960_handle_t* handle, int8_t offset);
uint8_t apds9960_get_gesture_right_offset(apds9960_handle_t* handle, int8_t* offset);
uint8_t apds9960_set_gesture_pulse_length(apds9960_handle_t* handle, apds9960_gesture_pulse_length_t len);
uint8_t apds9960_get_gesture_pulse_length(apds9960_handle_t* handle, apds9960_gesture_pulse_length_t* len);
uint8_t apds9960_set_gesture_pulse_count(apds9960_handle_t* handle, uint16_t count);
uint8_t apds9960_get_gesture_pulse_count(apds9960_handle_t* handle, uint16_t* count);
uint8_t apds9960_set_gesture_dimension(apds9960_handle_t* handle, apds9960_gesture_dimension_select_t s);
uint8_t apds9960_get_gesture_dimension_select(apds9960_handle_t* handle, apds9960_gesture_dimension_select_t* s);
uint8_t apds9960_gesture_fifo_clear(apds9960_handle_t* handle);
uint8_t apds9960_set_gesture_interrupt(apds9960_handle_t* handle, apds9960_bool_t enable);
uint8_t apds9960_get_gesture_interrupt(apds9960_handle_t* handle, apds9960_bool_t* enable);
uint8_t apds9960_set_gesture_mode(apds9960_handle_t* handle, apds9960_bool_t enable);
uint8_t apds9960_get_gesture_mode(apds9960_handle_t* handle, apds9960_bool_t* enable);
uint8_t apds9960_get_gesture_fifo_level(apds9960_handle_t* handle, uint8_t* level);
uint8_t apds9960_get_gesture_status(apds9960_handle_t* handle, uint8_t* status);
uint8_t apds9960_force_interrupt(apds9960_handle_t* handle);
uint8_t apds9960_proximity_interrupt_clear(apds9960_handle_t* handle);
uint8_t apds9960_als_interrupt_clear(apds9960_handle_t* handle);
uint8_t apds9960_all_non_gesture_interrupt_clear(apds9960_handle_t* handle);
uint8_t apds9960_set_reg(apds9960_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
uint8_t apds9960_get_reg(apds9960_handle_t* handle, uint8_t reg, uint8_t* buf, uint16_t len);
#ifdef __cplusplus
}
#endif
#endif
