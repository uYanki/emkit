
#include "driver_apds9960.h"
#include <stdlib.h>

#define MANUFACTURER_NAME  "Broadcom"          // manufacturer name
#define SUPPLY_VOLTAGE_MIN 2.4f                // chip min supply voltage
#define SUPPLY_VOLTAGE_MAX 3.6f                // chip max supply voltage




#define APDS9960_ADDRESS 0x72 // iic address
#define APDS9960_REG_ENABLE     0x80 // enable states and interrupts register
#define APDS9960_REG_ATIME      0x81 // adc integration time register
#define APDS9960_REG_WTIME      0x83 // wait time register
#define APDS9960_REG_AILTL      0x84 // als interrupt low threshold low byte register
#define APDS9960_REG_AILTH      0x85 // als interrupt low threshold high byte register
#define APDS9960_REG_AIHTL      0x86 // als interrupt high threshold low byte register
#define APDS9960_REG_AIHTH      0x87 // als interrupt high threshold high byte register
#define APDS9960_REG_PILT       0x89 // proximity interrupt low threshold register
#define APDS9960_REG_PIHT       0x8B // proximity interrupt high threshold register
#define APDS9960_REG_PERS       0x8C // interrupt persistence filters register
#define APDS9960_REG_CONFIG1    0x8D // configuration register one register
#define APDS9960_REG_PPULSE     0x8E // proximity pulse count and length register
#define APDS9960_REG_CONTROL    0x8F // gain control register
#define APDS9960_REG_CONFIG2    0x90 // configuration register two register
#define APDS9960_REG_ID         0x92 // device id register
#define APDS9960_REG_STATUS     0x93 // device status register
#define APDS9960_REG_CDATAL     0x94 // low byte of clear channel data register
#define APDS9960_REG_CDATAH     0x95 // high byte of clear channel data register
#define APDS9960_REG_RDATAL     0x96 // low byte of red channel data register
#define APDS9960_REG_RDATAH     0x97 // high byte of red channel data register
#define APDS9960_REG_GDATAL     0x98 // low byte of green channel data register
#define APDS9960_REG_GDATAH     0x99 // high byte of green channel data register
#define APDS9960_REG_BDATAL     0x9A // low byte of blue channel data register
#define APDS9960_REG_BDATAH     0x9B // high byte of blue channel data register
#define APDS9960_REG_PDATA      0x9C // proximity data register
#define APDS9960_REG_POFFSET_UR 0x9D // proximity offset for UP and RIGHT photodiodes register
#define APDS9960_REG_POFFSET_DL 0x9E // proximity offset for DOWN and LEFT photodiodes register
#define APDS9960_REG_CONFIG3    0x9F // configuration register three register
#define APDS9960_REG_GPENTH     0xA0 // gesture proximity enter threshold register
#define APDS9960_REG_GEXTH      0xA1 // gesture exit threshold register
#define APDS9960_REG_GCONF1     0xA2 // gesture configuration one register
#define APDS9960_REG_GCONF2     0xA3 // gesture configuration two register
#define APDS9960_REG_GOFFSET_U  0xA4 // gesture UP offset register
#define APDS9960_REG_GOFFSET_D  0xA5 // gesture DOWN offset register
#define APDS9960_REG_GOFFSET_L  0xA7 // gesture LEFT offset register
#define APDS9960_REG_GOFFSET_R  0xA9 // gesture RIGHT offset register
#define APDS9960_REG_GPULSE     0xA6 // gesture pulse count and length register
#define APDS9960_REG_GCONF3     0xAA // gesture configuration three register
#define APDS9960_REG_GCONF4     0xAB // gesture configuration four register
#define APDS9960_REG_GFLVL      0xAE // gesture fifo level register
#define APDS9960_REG_GSTATUS    0xAF // gesture status register
#define APDS9960_REG_IFORCE     0xE4 // force interrupt register
#define APDS9960_REG_PICLEAR    0xE5 // proximity interrupt clear register
#define APDS9960_REG_CICLEAR    0xE6 // als clear channel interrupt clear register
#define APDS9960_REG_AICLEAR    0xE7 // all non-gesture interrupts clear register
#define APDS9960_REG_GFIFO_U    0xFC // gesture fifo UP value register
#define APDS9960_REG_GFIFO_D    0xFD // gesture fifo DOWN value register
#define APDS9960_REG_GFIFO_L    0xFE // gesture fifo LEFT value register
#define APDS9960_REG_GFIFO_R    0xFF // gesture fifo RIGHT value register
static uint8_t a_apds9960_iic_read( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_read(APDS9960_ADDRESS, reg, data, len) != 0) /* read the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
static uint8_t a_apds9960_iic_write( uint8_t reg, uint8_t* data, uint16_t len)
{
    if (iic_write(APDS9960_ADDRESS, reg, data, len) != 0) /* write the register */
    {
        
    } else {
        return 0; /* success return 0 */
    }
}
uint8_t apds9960_init(apds9960_handle_t* handle)
{
    uint8_t id;
    {
        
    }
    if (debug_print == NULL) /* check debug_print */
    {
        
    }
    if (iic_init == NULL) /* check iic_init */
    {
        
        
    }
    if (iic_deinit == NULL) /* check iic_deinit */
    {
        
        
    }
    if (iic_read == NULL) /* check iic_read */
    {
        
        
    }
    if (iic_write == NULL) /* check iic_write */
    {
        
        
    }
    if (delay_ms == NULL) /* check delay_ms */
    {
        
        
    }
    if (receive_callback == NULL) /* check receive_callback */
    {
        
        
    }
    if (iic_init() != 0) /* iic init */
    {
        
        
    }
    if (a_apds9960_iic_read( APDS9960_REG_ID, (uint8_t*)&id, 1) != 0) /* read id */
    {
        
        
        
    }
    if (id != 0xAB) /* check id */
    {
        
        
        
    }
    gesture_status        = 0;                              /* clear the gesture status */
    gesture_threshold     = APDS9960_GESTURE_THRESHOLD;     /* set the default gesture threshold */
    gesture_sensitivity_1 = APDS9960_GESTURE_SENSITIVITY_1; /* set the default gesture sensitivity 1 */
    gesture_sensitivity_2 = APDS9960_GESTURE_SENSITIVITY_2; /* set the default gesture sensitivity 2 */
    gesture_ud_delta      = 0;                              /* set gesture_ud_delta 0 */
    gesture_lr_delta      = 0;                              /* set gesture_lr_delta 0 */
    gesture_ud_count      = 0;                              /* set gesture_ud_count 0 */
    gesture_lr_count      = 0;                              /* set gesture_lr_count 0 */
    gesture_near_count    = 0;                              /* set gesture_near_count 0 */
    gesture_far_count     = 0;                              /* set gesture_far_count 0 */
    inited                = 1;                              /* flag inited */
    return 0; /* success return 0 */
}
uint8_t apds9960_deinit(apds9960_handle_t* handle)
{
    uint8_t res, prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_ENABLE, (uint8_t*)&prev, 1); /* read enable register */
    
    {
        
        
    }
    prev &= ~(1 << 0);                                                           /* set power down */
    res = a_apds9960_iic_write( APDS9960_REG_ENABLE, (uint8_t*)&prev, 1); /* write enable register */
    
    {
        
        
    }
    res = iic_deinit(); /* iic deinit */
    
    {
        
        
    } else {
        inited = 0; /* flag closed */
        return 0; /* success return 0 */
    }
}
uint8_t apds9960_irq_handler(apds9960_handle_t* handle)
{
    uint8_t res, prev, prev1;
    uint8_t times;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_STATUS, (uint8_t*)&prev, 1); /* read status */
    
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GSTATUS, (uint8_t*)&prev1, 1); /* read gesture status */
    
    {
        
        
    }
    if ((prev & (1 << APDS9960_STATUS_CPSAT)) != 0) /* check clear photodiode saturation */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_CPSAT); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_PGSAT)) != 0) /* check analog saturation */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_PGSAT); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_PINT)) != 0) /* check proximity interrupt */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_PINT); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_AINT)) != 0) /* check als interrupt */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_AINT); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_GINT)) != 0) /* gesture interrupt */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GINT); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_PVALID)) != 0) /* check proximity valid */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_PVALID); /* run the callback */
        }
    }
    if ((prev & (1 << APDS9960_STATUS_AVALID)) != 0) /* check als valid */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_AVALID); /* run the callback */
        }
    }
    if ((prev1 & (1 << APDS9960_GESTURE_STATUS_FIFO_OVERFLOW)) != 0) /* check gesture fifo overflow */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GFOV); /* run the callback */
        }
    }
    if ((prev1 & (1 << APDS9960_GESTURE_STATUS_FIFO_VALID)) != 0) /* check gesture fifo data */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GVALID); /* run the callback */
        }
    }
    times = 3; /* set retry times */
    while (1)  /* retry label */
    {
        prev = 0xFF;                                                                   /* set 0xFF */
        res  = a_apds9960_iic_write( APDS9960_REG_AICLEAR, (uint8_t*)&prev, 1); /* clear all non-gesture interrupts */
        if (res != 0)                                                                  /* check result */
        {
            if (times != 0) /* check retry times */
            {
                times--; /* times-- */
                continue; /* continue */
            }
            
            
        }
        res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
        if (res != 0)                                                               /* check result */
        {
            if (times != 0) /* check retry times */
            {
                times--; /* times-- */
                continue; /* continue */
            }
            
            
        }
        prev &= ~(1 << 2);                                                           /* clear config */
        prev |= 1 << 2;                                                              /* set config */
        res = a_apds9960_iic_write( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* set gesture conf 4 register */
        if (res != 0)                                                                /* check result */
        {
            if (times != 0) /* check retry times */
            {
                times--; /* times-- */
                continue; /* continue */
            }
            
            
        }
        break; /* break */
    }
    prev = gesture_status; /* get the gesture status */
    if ((prev & (1 << 0)) != 0)    /* check far */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_FAR); /* run the callback */
        }
    }
    if ((prev & (1 << 1)) != 0) /* check near */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_NEAR); /* run the callback */
        }
    }
    if ((prev & (1 << 2)) != 0) /* check down */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_DOWN); /* run the callback */
        }
    }
    if ((prev & (1 << 3)) != 0) /* check up */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_UP); /* run the callback */
        }
    }
    if ((prev & (1 << 4)) != 0) /* check right */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_RIGHT); /* run the callback */
        }
    }
    if ((prev & (1 << 5)) != 0) /* check left */
    {
        if (receive_callback != NULL) /* if valid */
        {
            receive_callback(APDS9960_INTERRUPT_STATUS_GESTURE_LEFT); /* run the callback */
        }
    }
    gesture_status = 0; /* clear the gesture status */
    if (prev != 0)              /* if find gesture */
    {
        gesture_ud_delta   = 0; /* set gesture_ud_delta 0 */
        gesture_lr_delta   = 0; /* set gesture_lr_delta 0 */
        gesture_ud_count   = 0; /* set gesture_ud_count 0 */
        gesture_lr_count   = 0; /* set gesture_lr_count 0 */
        gesture_near_count = 0; /* set gesture_near_count 0 */
        gesture_far_count  = 0; /* set gesture_far_count 0 */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_gesture_decode( uint8_t (*data)[4], uint8_t len)
{
    int8_t  i;
    uint8_t u_first, d_first, l_first, r_first;
    uint8_t u_last, d_last, l_last, r_last;
    int32_t ud_ratio_first, lr_ratio_first, ud_ratio_last, lr_ratio_last;
    int32_t ud_delta, lr_delta;
    {
        
    }
    {
        
    }
    if (len < 4) /* check len */
    {
        
        
    }
    u_first = 0;              /* clear up first */
    d_first = 0;              /* clear down first */
    l_first = 0;              /* clear left first */
    r_first = 0;              /* clear right first */
    u_last  = 0;              /* clear up last */
    d_last  = 0;              /* clear down last */
    l_last  = 0;              /* clear left last */
    r_last  = 0;              /* clear right last */
    for (i = 0; i < len; i++) /* run len times */
    {
        if ((data[i][0] > gesture_threshold) && /* check gesture threshold */
            (data[i][1] > gesture_threshold) && /* check gesture threshold */
            (data[i][2] > gesture_threshold) && /* check gesture threshold */
            (data[i][3] > gesture_threshold)    /* check gesture threshold */
        ) {
            u_first = data[i][0]; /* set up first */
            d_first = data[i][1]; /* set down first */
            l_first = data[i][2]; /* set left first */
            r_first = data[i][3]; /* set right first */
            break; /* break */
        }
    }
    if ((u_first == 0) || /* check up first */
        (d_first == 0) || /* check down first */
        (l_first == 0) || /* check left first */
        (r_first == 0)    /* check right first */
    ) {
        goto decode; /* go to decode */
    }
    for (i = len - 1; i >= 0; i--) /* run len times */
    {
        if ((data[i][0] > gesture_threshold) && /* check gesture threshold */
            (data[i][1] > gesture_threshold) && /* check gesture threshold */
            (data[i][2] > gesture_threshold) && /* check gesture threshold */
            (data[i][3] > gesture_threshold)    /* check gesture threshold */
        ) {
            u_last = data[i][0]; /* set up last */
            d_last = data[i][1]; /* set down last */
            l_last = data[i][2]; /* set left last */
            r_last = data[i][3]; /* set right last */
            break; /* break */
        }
    }
    ud_ratio_first = ((u_first - d_first) * 100) / (u_first + d_first); /* get ud ratio first */
    lr_ratio_first = ((l_first - r_first) * 100) / (l_first + r_first); /* get lr ratio first */
    ud_ratio_last  = ((u_last - d_last) * 100) / (u_last + d_last);     /* get ud ratio last */
    lr_ratio_last  = ((l_last - r_last) * 100) / (l_last + r_last);     /* get lr ratio last */
    ud_delta       = ud_ratio_last - ud_ratio_first;                    /* get ud delta */
    lr_delta       = lr_ratio_last - lr_ratio_first;                    /* get lr delta */
    gesture_ud_delta += ud_delta;                               /* gesture_ud_delta++ */
    gesture_lr_delta += lr_delta;                               /* gesture_lr_delta++ */
    if (gesture_ud_delta >= gesture_sensitivity_1) /* check gesture_ud_delta */
    {
        gesture_ud_count = 1;                                      /* set gesture_ud_count 1 */
    } else if (gesture_ud_delta <= -gesture_sensitivity_1) /* check gesture_ud_delta */
    {
        gesture_ud_count = -1; /* set gesture_ud_count -1 */
    } else {
        gesture_ud_count = 0; /* set gesture_ud_count 0 */
    }
    if (gesture_lr_delta >= gesture_sensitivity_1) /* check gesture_lr_delta */
    {
        gesture_lr_count = 1;                                      /* set gesture_lr_count 1 */
    } else if (gesture_lr_delta <= -gesture_sensitivity_1) /* check gesture_lr_delta */
    {
        gesture_lr_count = -1; /* set gesture_lr_count -1 */
    } else {
        gesture_lr_count = 0; /* set gesture_lr_count 0 */
    }
    if ((gesture_ud_count == 0) && (gesture_lr_count == 0)) /* check gesture_ud_count && gesture_lr_count */
    {
        if ((abs(ud_delta) < gesture_sensitivity_2) && /* check ud_delta */
            (abs(lr_delta) < gesture_sensitivity_2))   /* check lr_delta */
        {
            if ((ud_delta == 0) && (lr_delta == 0)) /* if ud_delta == 0 && lr_delta == 0 */
            {
                gesture_near_count++;              /* gesture_near_count++ */
            } else if ((ud_delta != 0) || (lr_delta != 0)) /* if ud_delta != 0 && lr_delta != 0 */
            {
                gesture_far_count++; /* gesture_far_count++ */
            } else {
            }
            if ((gesture_near_count >= 10) && /* check gesture_near_count */
                (gesture_far_count >= 2))     /* check gesture_far_count */
            {
                if ((ud_delta == 0) && (lr_delta == 0)) /* if ud_delta == 0 && lr_delta == 0 */
                {
                    gesture_status |= 1 << 1;          /* near */
                } else if ((ud_delta != 0) && (lr_delta != 0)) /* if ud_delta != 0 && lr_delta != 0 */
                {
                    gesture_status |= 1 << 0; /* far */
                } else {
                    /* do nothing */
                }
            }
        }
    } else {
        if ((abs(ud_delta) < gesture_sensitivity_2) && /* check ud_delta */
            (abs(lr_delta) < gesture_sensitivity_2))   /* check lr_delta */
        {
            if ((ud_delta == 0) && (lr_delta == 0)) /* if ud_delta == 0 && lr_delta == 0 */
            {
                gesture_near_count++; /* gesture_near_count++ */
            }
            if (gesture_near_count >= 10) /* if gesture_near_count >= 10 */
            {
                gesture_ud_count = 0; /* set gesture_ud_count 0 */
                gesture_lr_count = 0; /* set gesture_lr_count 0 */
                gesture_ud_delta = 0; /* set gesture_ud_delta 0 */
                gesture_lr_delta = 0; /* set gesture_lr_delta 0 */
            }
        }
    }
decode:
    if ((gesture_ud_count == -1) && (gesture_lr_count == 0)) /* if gesture_ud_count == -1 && gesture_lr_count == 0 */
    {
        gesture_status |= 1 << 4;                                          /* right */
    } else if ((gesture_ud_count == 1) && (gesture_lr_count == 0)) /* if gesture_ud_count == 1 && gesture_lr_count == 0 */
    {
        gesture_status |= 1 << 5;                                          /* left */
    } else if ((gesture_ud_count == 0) && (gesture_lr_count == 1)) /* if gesture_ud_count == 0 && gesture_lr_count == 1 */
    {
        gesture_status |= 1 << 2;                                           /* down */
    } else if ((gesture_ud_count == 0) && (gesture_lr_count == -1)) /* if gesture_ud_count == 0 && gesture_lr_count == -1 */
    {
        gesture_status |= 1 << 3;                                           /* up */
    } else if ((gesture_ud_count == -1) && (gesture_lr_count == 1)) /* if gesture_ud_count == -1 && gesture_lr_count == 1 */
    {
        if (abs(gesture_ud_delta) > abs(gesture_lr_delta)) /* check gesture_ud_delta && gesture_lr_delta */
        {
            gesture_status |= 1 << 4; /* right */
        } else {
            gesture_status |= 1 << 2; /* down */
        }
    } else if ((gesture_ud_count == 1) && (gesture_lr_count == -1)) /* if gesture_ud_count == 1 && gesture_lr_count == -1 */
    {
        if (abs(gesture_ud_delta) > abs(gesture_lr_delta)) /* check gesture_ud_delta && gesture_lr_delta */
        {
            gesture_status |= 1 << 5; /* left */
        } else {
            gesture_status |= 1 << 3; /* up */
        }
    } else if ((gesture_ud_count == -1) && (gesture_lr_count == -1)) /* if gesture_ud_count == -1 && gesture_lr_count == -1 */
    {
        if (abs(gesture_ud_delta) > abs(gesture_lr_delta)) /* check gesture_ud_delta && gesture_lr_delta */
        {
            gesture_status |= 1 << 4; /* right */
        } else {
            gesture_status |= 1 << 3; /* up */
        }
    } else if ((gesture_ud_count == 1) && (gesture_lr_count == 1)) /* if gesture_ud_count == 1 && gesture_lr_count == 1 */
    {
        if (abs(gesture_ud_delta) > abs(gesture_lr_delta)) /* check gesture_ud_delta && gesture_lr_delta */
        {
            gesture_status |= 1 << 5; /* left */
        } else {
            gesture_status |= 1 << 2; /* down */
        }
    } else {
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_decode_threshold( uint8_t threshold)
{
    {
        
    }
    {
        
    }
    gesture_threshold = threshold; /* set threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_decode_threshold( uint8_t* threshold)
{
    {
        
    }
    {
        
    }
    *threshold = gesture_threshold; /* get threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_decode_sensitivity_1( int32_t sensitivity)
{
    {
        
    }
    {
        
    }
    gesture_sensitivity_1 = sensitivity; /* set sensitivity */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_decode_sensitivity_1( int32_t* sensitivity)
{
    {
        
    }
    {
        
    }
    *sensitivity = gesture_sensitivity_1; /* get sensitivity */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_decode_sensitivity_2( int32_t sensitivity)
{
    {
        
    }
    {
        
    }
    gesture_sensitivity_2 = sensitivity; /* set sensitivity */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_decode_sensitivity_2( int32_t* sensitivity)
{
    {
        
    }
    {
        
    }
    *sensitivity = gesture_sensitivity_2; /* get sensitivity */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_conf( apds9960_conf_t conf, apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_ENABLE, (uint8_t*)&prev, 1); /* get enable */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(1 << conf);                                                        /* clear conf */
    prev |= enable << conf;                                                      /* set conf */
    res = a_apds9960_iic_write( APDS9960_REG_ENABLE, (uint8_t*)&prev, 1); /* set enable */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_conf( apds9960_conf_t conf, apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_ENABLE, (uint8_t*)&prev, 1); /* get enable */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> conf) & 0x01); /* get bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_adc_integration_time( uint8_t integration_time)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = integration_time;                                                     /* set integration time */
    res  = a_apds9960_iic_write( APDS9960_REG_ATIME, (uint8_t*)&prev, 1); /* set atime */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_adc_integration_time( uint8_t* integration_time)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_ATIME, (uint8_t*)&prev, 1); /* get atime */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *integration_time = prev; /* get integration time */
    return 0; /* success return 0 */
}
uint8_t apds9960_adc_integration_time_convert_to_register( float ms, uint8_t* reg)
{
    {
        
    }
    {
        
    }
    *reg = (uint8_t)(256.0f - ms / 2.78f); /* convert real data to register data */
    return 0; /* success return 0 */
}
uint8_t apds9960_adc_integration_time_convert_to_data( uint8_t reg, float* ms)
{
    {
        
    }
    {
        
    }
    *ms = (float)(256 - reg) * 2.78f; /* convert raw data to real data */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_wait_time( uint8_t wait_time)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = wait_time;                                                            /* set wait time */
    res  = a_apds9960_iic_write( APDS9960_REG_WTIME, (uint8_t*)&prev, 1); /* set wtime */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_wait_time( uint8_t* wait_time)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_WTIME, (uint8_t*)&prev, 1); /* get wtime */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *wait_time = prev; /* get wait time */
    return 0; /* success return 0 */
}
uint8_t apds9960_wait_time_convert_to_register( float ms, uint8_t* reg)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG1, (uint8_t*)&prev, 1); /* get configuration register 1 */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    if ((prev & (1 << 1)) != 0) /* check wait long */
    {
        *reg = (uint8_t)(256.0f - ms / (2.78f * 12.0f)); /* convert real data to register data */
    } else {
        *reg = (uint8_t)(256.0f - ms / 2.78f); /* convert real data to register data */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_wait_time_convert_to_data( uint8_t reg, float* ms)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG1, (uint8_t*)&prev, 1); /* get configuration register 1 */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    if ((prev & (1 << 1)) != 0) /* check wait long */
    {
        *ms = (float)(256 - reg) * 2.78f * 12.0f; /* convert raw data to real data */
    } else {
        *ms = (float)(256 - reg) * 2.78f; /* convert raw data to real data */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_als_interrupt_low_threshold( uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (threshold >> 0) & 0xFF;                                            /* set lsb */
    buf[1] = (threshold >> 8) & 0xFF;                                            /* set msb */
    res    = a_apds9960_iic_write( APDS9960_REG_AILTL, (uint8_t*)buf, 2); /* set ailtl */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_als_interrupt_low_threshold( uint16_t* threshold)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_AILTL, (uint8_t*)buf, 2); /* get ailtl */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    *threshold = (uint16_t)(((uint16_t)buf[1] << 8) | buf[0]); /* set threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_als_interrupt_high_threshold( uint16_t threshold)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    buf[0] = (threshold >> 0) & 0xFF;                                            /* set lsb */
    buf[1] = (threshold >> 8) & 0xFF;                                            /* set msb */
    res    = a_apds9960_iic_write( APDS9960_REG_AIHTL, (uint8_t*)buf, 2); /* set aihtl */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_als_interrupt_high_threshold( uint16_t* threshold)
{
    uint8_t res;
    uint8_t buf[2];
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_AIHTL, (uint8_t*)buf, 2); /* get aihtl */
    if (res != 0)                                                            /* check result */
    {
        
        
    }
    *threshold = (uint16_t)(((uint16_t)buf[1] << 8) | buf[0]); /* set threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_interrupt_low_threshold( uint8_t threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = threshold;                                                           /* set low threshold */
    res  = a_apds9960_iic_write( APDS9960_REG_PILT, (uint8_t*)&prev, 1); /* set pilt */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_interrupt_low_threshold( uint8_t* threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PILT, (uint8_t*)&prev, 1); /* get pilt */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    *threshold = prev; /* get low threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_interrupt_high_threshold( uint8_t threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = threshold;                                                           /* set high threshold */
    res  = a_apds9960_iic_write( APDS9960_REG_PIHT, (uint8_t*)&prev, 1); /* set piht */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_interrupt_high_threshold( uint8_t* threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PIHT, (uint8_t*)&prev, 1); /* get piht */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    *threshold = prev; /* get high threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_interrupt_cycle( apds9960_proximity_interrupt_cycle_t cycle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* get persistence register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    prev &= ~(0xF << 4);                                                       /* clear config */
    prev |= cycle << 4;                                                        /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* set persistence register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_interrupt_cycle( apds9960_proximity_interrupt_cycle_t* cycle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* get persistence register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    *cycle = (apds9960_proximity_interrupt_cycle_t)((prev >> 4) & 0xF); /* set cycle */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_als_interrupt_cycle( apds9960_als_interrupt_cycle_t cycle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* get persistence register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    prev &= ~(0xF << 0);                                                       /* clear config */
    prev |= cycle << 0;                                                        /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* set persistence register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_als_interrupt_cycle( apds9960_als_interrupt_cycle_t* cycle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PERS, (uint8_t*)&prev, 1); /* get persistence register */
    if (res != 0)                                                             /* check result */
    {
        
        
    }
    *cycle = (apds9960_als_interrupt_cycle_t)((prev >> 0) & 0xF); /* get als interrupt cycle */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_wait_long( apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG1, (uint8_t*)&prev, 1); /* get configuration register 1 */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                            /* clear config */
    prev |= enable << 1;                                                          /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG1, (uint8_t*)&prev, 1); /* set configuration register 1 */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_wait_long( apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG1, (uint8_t*)&prev, 1); /* get configuration register 1 */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> 1) & 0x1); /* get bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_pulse_length( apds9960_proximity_pulse_length_t len)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* get proximity pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(3 << 6);                                                           /* clear config */
    prev |= len << 6;                                                            /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* set proximity pulse count register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_pulse_length( apds9960_proximity_pulse_length_t* len)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* get proximity pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *len = (apds9960_proximity_pulse_length_t)((prev >> 6) & 0x3); /* get length */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_pulse_count( uint16_t count)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (count > 0x3F) /* check count */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* get proximity pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x3F << 0);                                                        /* clear config */
    prev |= (count & 0x3F) << 0;                                                 /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* set proximity pulse count register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_pulse_count( uint16_t* count)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PPULSE, (uint8_t*)&prev, 1); /* get proximity pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *count = prev & 0x3F; /* get count */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_led_current( apds9960_led_current_t current)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 6);                                                          /* clear config */
    prev |= current << 6;                                                         /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* set contorl register register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_led_current( apds9960_led_current_t* current)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *current = (apds9960_led_current_t)((prev >> 6) & 0x3); /* get the current */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_gain( apds9960_proximity_gain_t gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 2);                                                          /* clear config */
    prev |= gain << 2;                                                            /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* set contorl register register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_gain( apds9960_proximity_gain_t* gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *gain = (apds9960_proximity_gain_t)((prev >> 2) & 0x3); /* get the gain */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_als_color_gain( apds9960_als_color_gain_t gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 0);                                                          /* clear config */
    prev |= gain << 0;                                                            /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* set contorl register register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_als_color_gain( apds9960_als_color_gain_t* gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONTROL, (uint8_t*)&prev, 1); /* get contorl register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *gain = (apds9960_als_color_gain_t)((prev >> 0) & 0x3); /* get the gain */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_saturation_interrupt( apds9960_saturation_interrupt_t saturation, apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* get contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << saturation);                                                   /* clear config */
    prev |= enable << saturation;                                                 /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* set contorl register 2 register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_saturation_interrupt( apds9960_saturation_interrupt_t saturation, apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* get contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> saturation) & 0x01); /* get the saturation */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_led_boost( apds9960_led_boost_t boost)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* get contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 4);                                                          /* clear config */
    prev |= boost << 4;                                                           /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* set contorl register 2 register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_led_boost( apds9960_led_boost_t* boost)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG2, (uint8_t*)&prev, 1); /* get contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *boost = (apds9960_led_boost_t)((prev >> 4) & 0x3); /* set the led boost */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_status( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_STATUS, (uint8_t*)&prev, 1); /* get status register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *status = prev; /* set the status */
    return 0; /* success return 0 */
}
uint8_t apds9960_read_rgbc( uint16_t* red, uint16_t* green, uint16_t* blue, uint16_t* clear)
{
    uint8_t res;
    uint8_t buf[8];
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CDATAL, (uint8_t*)&buf[0], 2); /* get cdatal register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_RDATAL, (uint8_t*)&buf[2], 2); /* get rdatal register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GDATAL, (uint8_t*)&buf[4], 2); /* get gdatal register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_BDATAL, (uint8_t*)&buf[6], 2); /* get bdatal register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    *red   = (uint16_t)(((uint16_t)buf[3] << 0) | buf[2]); /* set the red */
    *green = (uint16_t)(((uint16_t)buf[5] << 0) | buf[4]); /* set the green */
    *blue  = (uint16_t)(((uint16_t)buf[7] << 0) | buf[6]); /* set the blue */
    *clear = (uint16_t)(((uint16_t)buf[1] << 0) | buf[0]); /* set the clear */
    return 0; /* success return 0 */
}
uint8_t apds9960_read_proximity( uint8_t* proximity)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_PDATA, (uint8_t*)&prev, 1); /* get proximity data register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *proximity = prev; /* set the proximity */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_up_right_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* < 0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_POFFSET_UR, (uint8_t*)&prev, 1); /* set proximity offset up right register */
    if (res != 0)                                                                    /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_up_right_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_POFFSET_UR, (uint8_t*)&prev, 1); /* get proximity offset up right register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_down_left_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* <0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_POFFSET_DL, (uint8_t*)&prev, 1); /* set proximity offset down left register */
    if (res != 0)                                                                    /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_down_left_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_POFFSET_DL, (uint8_t*)&prev, 1); /* get proximity offset down left register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_gain_compensation( apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 5);                                                            /* clear config */
    prev |= enable << 5;                                                          /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* set contorl register 3 register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_gain_compensation( apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> 5) & 0x01); /* get bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_sleep_after_interrupt( apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << 4);                                                            /* clear config */
    prev |= enable << 4;                                                          /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* set contorl register 3 register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_sleep_after_interrupt( apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> 4) & 0x01); /* get bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_proximity_mask( apds9960_proximity_mask_t mask, apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    prev &= ~(1 << mask);                                                         /* clear config */
    prev |= enable << mask;                                                       /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* set contorl register 3 register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_proximity_mask( apds9960_proximity_mask_t mask, apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_CONFIG3, (uint8_t*)&prev, 1); /* get contorl 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> mask) & 0x01); /* get bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_proximity_enter_threshold( uint8_t threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = threshold;                                                             /* set threshold */
    res  = a_apds9960_iic_write( APDS9960_REG_GPENTH, (uint8_t*)&prev, 1); /* set gesture proximity enter threshold register */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_proximity_enter_threshold( uint8_t* threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GPENTH, (uint8_t*)&prev, 1); /* get gesture proximity enter threshold register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *threshold = prev; /* set threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_proximity_exit_threshold( uint8_t threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = threshold;                                                            /* set threshold */
    res  = a_apds9960_iic_write( APDS9960_REG_GEXTH, (uint8_t*)&prev, 1); /* set gesture proximity exit threshold register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_proximity_exit_threshold( uint8_t* threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GEXTH, (uint8_t*)&prev, 1); /* get gesture proximity exit threshold register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *threshold = prev; /* set the threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_fifo_threshold( apds9960_gesture_fifo_threshold_t threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(3 << 6);                                                           /* clear config */
    prev |= threshold << 6;                                                      /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* set gesture contorl 1 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_fifo_threshold( apds9960_gesture_fifo_threshold_t* threshold)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *threshold = (apds9960_gesture_fifo_threshold_t)((prev >> 6) & 0x3); /* set the threshold */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_exit_persistence( apds9960_gesture_exit_persistence_t persistence)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(3 << 0);                                                           /* clear config */
    prev |= persistence << 0;                                                    /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* set gesture contorl 1 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_exit_persistence( apds9960_gesture_exit_persistence_t* persistence)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *persistence = (apds9960_gesture_exit_persistence_t)((prev >> 0) & 0x3); /* set the persistence */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_exit_mask( uint8_t mask)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (mask > 0xF) /* check result */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0xF << 2);                                                         /* clear config */
    prev |= (mask & 0xF) << 2;                                                   /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* set gesture contorl 1 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_exit_mask( uint8_t* mask)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF1, (uint8_t*)&prev, 1); /* get gesture contorl 1 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *mask = (prev >> 2) & 0xF; /* set the mask */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_gain( apds9960_gesture_gain_control_t gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 5);                                                         /* clear config */
    prev |= gain << 5;                                                           /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* set gesture contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_gain( apds9960_gesture_gain_control_t* gain)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *gain = (apds9960_gesture_gain_control_t)((prev >> 5) & 0x3); /* set the gain */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_led_current( apds9960_gesture_led_current_t current)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x3 << 3);                                                         /* clear config */
    prev |= current << 3;                                                        /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* set gesture contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_led_current( apds9960_gesture_led_current_t* current)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *current = (apds9960_gesture_led_current_t)((prev >> 3) & 0x3); /* set the current */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_wait_time( apds9960_gesture_wait_time_t t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x7 << 0);                                                         /* clear config */
    prev |= t << 0;                                                              /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* set gesture contorl 2 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_wait_time( apds9960_gesture_wait_time_t* t)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF2, (uint8_t*)&prev, 1); /* get gesture contorl 2 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *t = (apds9960_gesture_wait_time_t)((prev >> 0) & 0x7); /* set the wait time */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_up_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* <0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_GOFFSET_U, (uint8_t*)&prev, 1); /* set gesture up offset register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_up_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GOFFSET_U, (uint8_t*)&prev, 1); /* get gesture up offset register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_down_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* <0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_GOFFSET_D, (uint8_t*)&prev, 1); /* set gesture down offset register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_down_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GOFFSET_D, (uint8_t*)&prev, 1); /* get gesture down offset register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_left_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* <0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_GOFFSET_L, (uint8_t*)&prev, 1); /* set gesture left offset register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_left_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GOFFSET_L, (uint8_t*)&prev, 1); /* get gesture left offset register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_right_offset( int8_t offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (offset >= 0) /* if >= 0 */
    {
        prev = offset; /* set the positive */
    } else             /* <0 */
    {
        prev = 0x80;       /* set the 0x80 */
        prev |= (-offset); /* set the negtive */
    }
    res = a_apds9960_iic_write( APDS9960_REG_GOFFSET_R, (uint8_t*)&prev, 1); /* set gesture right offset register */
    if (res != 0)                                                                   /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_right_offset( int8_t* offset)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GOFFSET_R, (uint8_t*)&prev, 1); /* get gesture right offset register */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    if ((prev & 0x80) != 0) /* if < 0 */
    {
        prev &= ~0x80;             /* clear 0x80 */
        *offset = -(int8_t)(prev); /* set the offset */
    } else                         /* >= 0 */
    {
        *offset = (int8_t)(prev); /* set the offset */
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_pulse_length( apds9960_gesture_pulse_length_t len)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* get gesture pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(3 << 6);                                                           /* clear config */
    prev |= len << 6;                                                            /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* set gesture pulse count register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_pulse_length( apds9960_gesture_pulse_length_t* len)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* get gesture pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *len = (apds9960_gesture_pulse_length_t)((prev >> 6) & 0x3); /* get length */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_pulse_count( uint16_t count)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    if (count > 0x3F) /* check count */
    {
        
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* get gesture pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(0x3F << 0);                                                        /* clear config */
    prev |= (count & 0x3F) << 0;                                                 /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* set gesture pulse count register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_pulse_count( uint16_t* count)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GPULSE, (uint8_t*)&prev, 1); /* get gesture pulse count register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *count = prev & 0x3F; /* get count */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_dimension( apds9960_gesture_dimension_select_t s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF3, (uint8_t*)&prev, 1); /* get gesture conf 3 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(3 << 0);                                                           /* clear config */
    prev |= s << 0;                                                              /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF3, (uint8_t*)&prev, 1); /* set gesture conf 3 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_dimension_select( apds9960_gesture_dimension_select_t* s)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF3, (uint8_t*)&prev, 1); /* get gesture conf 3 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *s = (apds9960_gesture_dimension_select_t)(prev & 0x3); /* get the select */
    return 0; /* success return 0 */
}
uint8_t apds9960_gesture_fifo_clear(apds9960_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(1 << 2);                                                           /* clear config */
    prev |= 1 << 2;                                                              /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* set gesture conf 4 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_interrupt( apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(1 << 1);                                                           /* clear config */
    prev |= enable << 1;                                                         /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* set gesture conf 4 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_interrupt( apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> 1) & 0x1); /* set bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_set_gesture_mode( apds9960_bool_t enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    prev &= ~(1 << 0);                                                           /* clear config */
    prev |= enable << 0;                                                         /* set config */
    res = a_apds9960_iic_write( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* set gesture conf 4 register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_mode( apds9960_bool_t* enable)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GCONF4, (uint8_t*)&prev, 1); /* get gesture conf 4 register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *enable = (apds9960_bool_t)((prev >> 0) & 0x1); /* set bool */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_fifo_level( uint8_t* level)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GFLVL, (uint8_t*)&prev, 1); /* get gesture fifo level register */
    if (res != 0)                                                              /* check result */
    {
        
        
    }
    *level = prev; /* set fifo level */
    return 0; /* success return 0 */
}
uint8_t apds9960_get_gesture_status( uint8_t* status)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GSTATUS, (uint8_t*)&prev, 1); /* get gesture status register */
    if (res != 0)                                                                /* check result */
    {
        
        
    }
    *status = prev; /* set status */
    return 0; /* success return 0 */
}
uint8_t apds9960_force_interrupt(apds9960_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xFF;                                                                  /* set 0xFF */
    res  = a_apds9960_iic_write( APDS9960_REG_IFORCE, (uint8_t*)&prev, 1); /* forces an interrupt */
    if (res != 0)                                                                 /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_proximity_interrupt_clear(apds9960_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xFF;                                                                   /* set 0xFF */
    res  = a_apds9960_iic_write( APDS9960_REG_PICLEAR, (uint8_t*)&prev, 1); /* proximity interrupt clear */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_als_interrupt_clear(apds9960_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xFF;                                                                   /* set 0xFF */
    res  = a_apds9960_iic_write( APDS9960_REG_CICLEAR, (uint8_t*)&prev, 1); /* als interrupt clear */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_all_non_gesture_interrupt_clear(apds9960_handle_t* handle)
{
    uint8_t res;
    uint8_t prev;
    {
        
    }
    {
        
    }
    prev = 0xFF;                                                                   /* set 0xFF */
    res  = a_apds9960_iic_write( APDS9960_REG_AICLEAR, (uint8_t*)&prev, 1); /* clear all non-gesture interrupts */
    if (res != 0)                                                                  /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_read_gesture_fifo( uint8_t (*data)[4], uint8_t* len)
{
    uint8_t res;
    uint8_t level;
    {
        
    }
    {
        
    }
    res = a_apds9960_iic_read( APDS9960_REG_GFLVL, (uint8_t*)&level, 1); /* get gesture fifo level register */
    if (res != 0)                                                               /* check result */
    {
        
        
    }
    *len = level < (*len) ? level : (*len);
    res  = a_apds9960_iic_read( APDS9960_REG_GFIFO_U, (uint8_t*)data, (*len) * 4); /* read gesture fifo */
    if (res != 0)                                                                         /* check result */
    {
        
        
    }
    return 0; /* success return 0 */
}
uint8_t apds9960_info(apds9960_info_t* info)
{
    
    {
        
    }
    memset(info, 0, sizeof(apds9960_info_t));                /* initialize apds9960 info structure */
    strncpy(info->chip_name, CHIP_NAME, 32);                 /* copy chip name */
    strncpy(info->manufacturer_name, MANUFACTURER_NAME, 32); /* copy manufacturer name */
    strncpy(info->interface, "IIC", 8);                      /* copy interface name */
    info->supply_voltage_min_v = SUPPLY_VOLTAGE_MIN;         /* set minimal supply voltage */
    info->supply_voltage_max_v = SUPPLY_VOLTAGE_MAX;         /* set maximum supply voltage */
    info->max_current_ma       = MAX_CURRENT;                /* set maximum current */
    info->temperature_max      = TEMPERATURE_MAX;            /* set minimal temperature */
    info->temperature_min      = TEMPERATURE_MIN;            /* set maximum temperature */
    info->driver_version       = DRIVER_VERSION;             /* set driver verison */
    return 0; /* success return 0 */
}
