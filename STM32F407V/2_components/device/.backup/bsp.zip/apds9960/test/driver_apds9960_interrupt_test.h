
#ifndef DRIVER_APDS9960_INTERRUPT_TEST_H
#define DRIVER_APDS9960_INTERRUPT_TEST_H
#include "driver_apds9960_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t apds9960_interrupt_test_irq_handler(void);
uint8_t apds9960_interrupt_test(uint32_t times, uint16_t als_low_threshold, uint16_t als_high_threshold,
                                uint8_t proximity_low_threshold, uint8_t proximity_high_threshold);
#ifdef __cplusplus
}
#endif
#endif
