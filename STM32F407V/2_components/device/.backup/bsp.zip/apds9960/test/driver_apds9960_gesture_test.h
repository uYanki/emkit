
#ifndef DRIVER_APDS9960_GESTURE_TEST_H
#define DRIVER_APDS9960_GESTURE_TEST_H
#include "driver_apds9960_interface.h"
#ifdef __cplusplus
extern "C"{
#endif
uint8_t apds9960_gesture_test_irq_handler(void);
uint8_t apds9960_gesture_test(uint32_t times);
#ifdef __cplusplus
}
#endif
#endif
