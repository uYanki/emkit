void pinMode(int pin, int mode) {

}

int digitalPinToInterrupt(int pin) {
    return 0;
}

void attachInterrupt(int ii, void (*param)(void), int i) {
}


