class EEPROM {
public:
    void write(int address, int data) {

    }

    int read(int address) {
        return 0;
    }

} EEPROM;