#define KEY_ESC 0
#define KEY_F1 0
#define KEY_F2 0
#define KEY_F3 0
#define KEY_F4 0
#define KEY_F5 0
#define KEY_F6 0
#define KEY_F7 0
#define KEY_F8 0
#define KEY_F9 0
#define KEY_F10 0
#define KEY_F11 0
#define KEY_F12 0
#define KEY_LEFT_CTRL 0
#define KEY_LEFT_SHIFT 0
#define KEY_LEFT_ALT 0
#define KEY_LEFT_GUI 0
#define KEY_RIGHT_CTRL 0
#define KEY_RIGHT_SHIFT 0
#define KEY_RIGHT_ALT 0
#define KEY_RIGHT_GUI 0
#define KEY_CAPS_LOCK 0
#define KEY_BACKSPACE 0
#define KEY_RETURN 0
#define KEY_INSERT 0
#define KEY_DELETE 0
#define KEY_TAB 0
#define KEY_HOME 0
#define KEY_END 0
#define KEY_PAGE_UP 0
#define KEY_PAGE_DOWN 0
#define KEY_UP_ARROW 0
#define KEY_DOWN_ARROW 0
#define KEY_LEFT_ARROW 0
#define KEY_RIGHT_ARROW 0

#define PA0 0
#define PA1 0
#define PA2 0
#define PA3 0
#define PA4 0
#define PA5 0
#define PA6 0
#define PA7 0
#define PB0 0
#define PB1 0


#include <SDL_keycode.h>

#define PB12 SDLK_q
#define PB13 SDLK_w
#define PB14 SDLK_e

#define      PB6 0
#define      PB7 0
#define      U8X8_PIN_NONE (-1)

#define U8G2_SSD1306_128X64_NONAME_F_HW_I2C U8G2_SDL_128X64

void ui_param_init();


