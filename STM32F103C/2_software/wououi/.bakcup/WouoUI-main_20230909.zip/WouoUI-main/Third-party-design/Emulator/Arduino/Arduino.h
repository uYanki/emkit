#ifdef __cplusplus
#include "ArduinoCompatible.h"
extern "C"
{
#endif

void setup();
void loop();


#ifdef __cplusplus
}
#endif