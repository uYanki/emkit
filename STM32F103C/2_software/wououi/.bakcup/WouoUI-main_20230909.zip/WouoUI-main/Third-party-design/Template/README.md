# 作者
RQNG

# 说明
第三方项目模板

# 开源协议
关于常见的开源协议，请参考这篇文章：http://switch.linesno.com/?p=2745
