#ifndef __DEBUG_UART_H__
#define __DEBUG_UART_H__

#include "air001xx_ll_usart.h"
#include "air001xx_ll_bus.h"
#include "air001xx_ll_gpio.h"

void DebugUART_Init(uint32_t baudrate);


#endif
