#include "shell_port.h"
#include "stdio.h"

UART_HandleTypeDef ShellUartHandle;
Shell shell;
char shell_buffer[512];

///////////////log部分
//log使能
#if SHELL_USING_CMD_LOG

#include "log.h"
#define true 1

void uartLogWrite(char * buffer,short len);
Log uartLog = {
    .write = uartLogWrite,
    .active = true,
    .level = LOG_DEBUG
};
void uartLogWrite(char * buffer,short len)
{
    if(uartLog.shell)
    {
        shellWriteEndLine(uartLog.shell,buffer,len);
    }
}
#endif

///////////////接口部分
// shell写函数
signed short User_Shell_Write(char * data, unsigned short len)              
{
    int i = 0;
    for (i =0;i<len;i++)
    {
		HAL_UART_Transmit(&ShellUartHandle, (uint8_t *)&(data[i]), 1, 1000);
    }
    return i+1;
}

uint8_t recv_buf = 0;
static void user_uart_init(uint32_t baudrate)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    __HAL_RCC_USART1_CLK_ENABLE();
    ShellUartHandle.Instance = SHELL_USART;
    ShellUartHandle.Init.BaudRate = baudrate;
    ShellUartHandle.Init.WordLength = UART_WORDLENGTH_8B;
    ShellUartHandle.Init.StopBits = UART_STOPBITS_1;
    ShellUartHandle.Init.Parity = UART_PARITY_NONE;
    ShellUartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    ShellUartHandle.Init.Mode = UART_MODE_TX_RX;
    ShellUartHandle.Init.OverSampling = UART_OVERSAMPLING_16;

    HAL_UART_Init(&ShellUartHandle);

    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF1_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_3;
    GPIO_InitStruct.Alternate = GPIO_AF1_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);  

     /* ENABLE NVIC */
    HAL_NVIC_SetPriority(SHELL_USART_IRQ, 0, 1);
    HAL_NVIC_EnableIRQ(SHELL_USART_IRQ);
	__HAL_UART_ENABLE_IT(&ShellUartHandle,UART_IT_RXNE);              
    
}

void USART1_IRQHandler(void) 
{
    if (__HAL_UART_GET_FLAG(&ShellUartHandle,UART_FLAG_RXNE) != RESET) 
   {
	    recv_buf = ShellUartHandle.Instance->DR; 
       shellHandler(&shell,recv_buf);
       __HAL_UART_CLEAR_FLAG(&ShellUartHandle,UART_FLAG_RXNE);
   }
}


////////////////////////////外部调用函数
void User_Shell_Init(uint32_t baudrate)
{
    user_uart_init(baudrate);
    shell.write = User_Shell_Write;
    shellInit(&shell,shell_buffer,512);
#ifdef SHELL_USING_CMD_LOG
    logRegister(&uartLog,&shell);
#endif
}


