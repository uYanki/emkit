#include "debug_uart.h"
#include "stdio.h"

#define DEBUG_UART      USART1
#define DEBUG_UART_IRQn USART1_IRQn
#define DEBUG_UART_TX_PORT GPIOA
#define DEBUG_UART_TX_PIN  LL_GPIO_PIN_2
#define DEBUG_UART_RX_PORT GPIOA
#define DEBUG_UART_RX_PIN  LL_GPIO_PIN_3

void DebugUART_Init(uint32_t baudrate)
{
    LL_APB1_GRP2_EnableClock(LL_APB1_GRP2_PERIPH_USART1);           
    LL_USART_InitTypeDef USART_InitStruct = {0};
    // LL_USART_StructInit(&USART_InitStruct); 
    // // //默认初始化结构体，9600 8 1 无校验 TXRX NOHWCtrl 16bit过采样
    // USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
    // USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
    // USART_InitStruct.Parity = LL_USART_PARITY_NONE;
    // USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;  //以上结构体的赋值均为0，已在初始化中为0，不影响
    USART_InitStruct.BaudRate = baudrate;
    USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
    LL_USART_Init(DEBUG_UART, &USART_InitStruct);

    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA); 
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DEBUG_UART_TX_PIN|DEBUG_UART_RX_PIN;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
    // GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH; //默认为FREQ_LOW
    GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
    GPIO_InitStruct.Alternate = LL_GPIO_AF_1;
    LL_GPIO_Init(DEBUG_UART_TX_PORT,&GPIO_InitStruct);

    NVIC_SetPriority(DEBUG_UART_IRQn, 0x0F);
    NVIC_EnableIRQ(DEBUG_UART_IRQn);

    LL_USART_EnableIT_RXNE(DEBUG_UART);
    LL_USART_Enable(DEBUG_UART);
    LL_USART_ClearFlag_TC(DEBUG_UART);
}

void USART1_IRQHandler(void) 
{
    uint8_t recv_buf = 0;
    if (LL_USART_IsActiveFlag_RXNE(DEBUG_UART)) 
    {
	    recv_buf = LL_USART_ReceiveData8(DEBUG_UART);
        //printf("char = %c",recv_buf);
       LL_USART_ClearFlag_RXNE(DEBUG_UART);
    }
}    

int fputc(int c, FILE * f)
{
    LL_USART_TransmitData8(DEBUG_UART, c);
    while (!LL_USART_IsActiveFlag_TC(DEBUG_UART));
    LL_USART_ClearFlag_TC(DEBUG_UART);
    return c;
}


