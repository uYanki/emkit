#ifndef __TEST_UI_H__
#define __TEST_UI_H__

#include "oled_port.h"
#include "oled_g.h"
#include "oled_ui.h"


void TestUI_Init(void);
void TestUI_Proc(void);

#endif
