#ifndef __SYSTEM_H__
#define __SYSTEM_H__


#include "air001xx_ll_utils.h"
#include "air001xx_ll_rcc.h"
#include "air001xx_ll_cortex.h"


void SystemClock_Init(void);


#endif
