#include "DS3231_port.h"
#include "air001xx_ll_utils.h"

//IIC初始化
void DS3231_IICInit(void)
{
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_I2C1);
    LL_I2C_InitTypeDef I2C_InitStruct ={0};
    LL_I2C_StructInit(&I2C_InitStruct);
    LL_I2C_Init(I2C1,&I2C_InitStruct);
    LL_I2C_Enable(I2C1);
    
    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOF); //使能GPIOF的时钟
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS3231_SCL_PIN|DS3231_SDA_PIN;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
    // GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_OPENDRAIN;
    GPIO_InitStruct.Alternate = LL_GPIO_AF_12;
    LL_GPIO_Init(DS3231_SCL_PORT,&GPIO_InitStruct);
}

uint16_t ds3231_timeout = DS3231_TIMEOUT; 
static void ds3231_delay(void)
{
   ds3231_timeout--;LL_mDelay(1);
}


uint16_t I2C_WriteData(uint8_t slaveAddr, uint8_t regAddr, uint8_t *pData, uint16_t dataLen)
{
    LL_I2C_GenerateStartCondition(I2C1);
    while((LL_I2C_IsActiveFlag_SB(I2C1) != 1) && (ds3231_timeout >= 1)){ds3231_delay();}  //等待StartBit置位
    LL_I2C_TransmitData8(I2C1,slaveAddr&0xFE); //写地址
    ds3231_timeout = DS3231_TIMEOUT; 
    while((LL_I2C_IsActiveFlag_ADDR(I2C1) != 1) && (ds3231_timeout >= 1)){ds3231_delay();}  //等待地址位置位
    LL_I2C_ClearFlag_ADDR(I2C1); //清除地址位进入发送模式
    LL_I2C_TransmitData8(I2C1,regAddr); //写寄存器地址
    ds3231_timeout = DS3231_TIMEOUT; 
    while((LL_I2C_IsActiveFlag_TXE(I2C1) != 1) && (ds3231_timeout >= 1)){ds3231_delay();}  //等待ack
    for(uint8_t i = 0; i < dataLen; i++)
    {
        LL_I2C_TransmitData8(I2C1,pData[i]); //写数据
        ds3231_timeout = DS3231_TIMEOUT; 
        while((LL_I2C_IsActiveFlag_TXE(I2C1) != 1) && (ds3231_timeout >= 1)){ds3231_delay();}  //等待ack
    }
    ds3231_timeout = DS3231_TIMEOUT; 
    while((LL_I2C_IsActiveFlag_BTF(I2C1) != 1) && (ds3231_timeout >= 1)){ds3231_delay();}  //等待传输完成
    LL_I2C_GenerateStopCondition(I2C1); //生成一个停止条件
    return 0;
}
// uint16_t I2C_WriteData(uint8_t slaveAddr, uint8_t regAddr, uint8_t *pData, uint16_t dataLen)
// {
//     LL_I2C_GenerateStartCondition(I2C1);
//     while((LL_I2C_IsActiveFlag_SB(I2C1) != 1) )DS3231_LOG("while sb\r\n"); //等待StartBit置位
//     LL_I2C_TransmitData8(I2C1,slaveAddr&0xFE); //写地址
//     while((LL_I2C_IsActiveFlag_ADDR(I2C1) != 1) )DS3231_LOG("while addr\r\n"); //等待地址位置位
//     LL_I2C_ClearFlag_ADDR(I2C1); //清除地址位进入发送模式
//     LL_I2C_TransmitData8(I2C1,regAddr); //写寄存器地址
//     while((LL_I2C_IsActiveFlag_TXE(I2C1) != 1) )DS3231_LOG("while TXE\r\n"); //等待ack
//     for(uint8_t i = 0; i < dataLen; i++)
//     {
//         LL_I2C_TransmitData8(I2C1,pData[i]); //写数据

//         while((LL_I2C_IsActiveFlag_TXE(I2C1) != 1) )DS3231_LOG("while TXE\r\n"); //等待ack
//     }
//     while((LL_I2C_IsActiveFlag_BTF(I2C1) != 1) )DS3231_LOG("while BTF\r\n"); //等待传输完成
//     LL_I2C_GenerateStopCondition(I2C1); //生成一个停止条件
//     return 0;
// }

uint16_t I2C_ReadByte(uint8_t slaveAddr, uint8_t regAddr, uint8_t *Data)
{
    LL_I2C_GenerateStartCondition(I2C1);
    while(LL_I2C_IsActiveFlag_SB(I2C1) != 1); //等待StartBit置位
    LL_I2C_TransmitData8(I2C1,slaveAddr&0xFE); //Dummy Write
    while(LL_I2C_IsActiveFlag_ADDR(I2C1) != 1); //等待地址位置位
    LL_I2C_ClearFlag_ADDR(I2C1); //清除地址位进入发送模式
    LL_I2C_TransmitData8(I2C1,regAddr); //写寄存器地址
    while(LL_I2C_IsActiveFlag_TXE(I2C1) != 1); //等待ack
    //ReStart
    LL_I2C_GenerateStartCondition(I2C1);
    while(LL_I2C_IsActiveFlag_SB(I2C1) != 1); //等待StartBit置位
    LL_I2C_TransmitData8(I2C1,slaveAddr|0x01); //读地址
    while(LL_I2C_IsActiveFlag_ADDR(I2C1) != 1); //等待地址位置位
    // LL_I2C_AcknowledgeNextData(I2C1,LL_I2C_NACK); //只接收一个字节 不需要ACK
    LL_I2C_ClearFlag_ADDR(I2C1); //清除地址位进接收模式
    LL_I2C_GenerateStopCondition(I2C1); //生成一个停止条件，在接收一个字节后会发送一个停止条件
    ds3231_timeout = DS3231_TIMEOUT; 
    while((LL_I2C_IsActiveFlag_RXNE(I2C1)!=1) && (ds3231_timeout >= 1)){ds3231_delay();} //等待一个字节接收完成
    *Data = LL_I2C_ReceiveData8(I2C1); 
    return 0;
}

void DS3231_IntInit(void)
{
    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA); //使能GPIOA的时钟
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DS3231_INT_PIN;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
    // GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
    // GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;  //默认就是推挽，low
    GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
    LL_GPIO_Init(DS3231_INT_PORT,&GPIO_InitStruct);

    LL_EXTI_ClearFlag(LL_EXTI_LINE_0);
    LL_EXTI_SetEXTISource(LL_EXTI_CONFIG_PORTA,LL_EXTI_CONFIG_LINE0);
    LL_EXTI_EnableFallingTrig(LL_EXTI_LINE_0);

    LL_EXTI_EnableIT(LL_EXTI_LINE_0);
    
    NVIC_SetPriority(EXTI0_1_IRQn, 0x0F);
    NVIC_EnableIRQ(EXTI0_1_IRQn);
}


