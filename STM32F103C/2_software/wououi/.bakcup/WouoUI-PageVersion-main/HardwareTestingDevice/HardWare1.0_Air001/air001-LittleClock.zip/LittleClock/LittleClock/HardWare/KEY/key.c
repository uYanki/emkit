#include "key.h"

Key gkey[KEY_NUM] = {
    {DKEY_PORT,DKEY_PIN,0,0,key_none},
    {CKEY_PORT,CKEY_PIN,0,0,key_none},
    {UKEY_PORT,UKEY_PIN,0,0,key_none},
    // {RKEY_PORT,RKEY_PIN,0,0,key_none},
};

void Key_Init(void)
{
    // GPIO_InitTypeDef GPIO_InitStruct;
    // __HAL_RCC_GPIOA_CLK_ENABLE();
    // /* Configure the GPIO_LED pin */
    // GPIO_InitStruct.Pin = DKEY_PIN;
    // GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    // GPIO_InitStruct.Pull = GPIO_PULLUP;
    // GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    // for (uint8_t i = 0; i < KEY_NUM; i++)
    // {
    //     GPIO_InitStruct.Pin = gkey[i].key_pin;
    //     HAL_GPIO_Init(gkey[i].key_port, &GPIO_InitStruct);        
    // }
    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB); //使能GPIOB的时钟
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = DKEY_PIN | CKEY_PIN | UKEY_PIN;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
//    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
//    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_UP; //上拉输入
    LL_GPIO_Init(DKEY_PORT,&GPIO_InitStruct);
}


void Key_Scan(void)
{
    for (uint8_t i = 0; i < KEY_NUM; i++)
    {
        switch (gkey[i].key_state)
        {
        case 0: //等待状态
            if(LL_GPIO_IsInputPinSet(gkey[i].key_port,gkey[i].key_pin) == 0) //按下
                gkey[i].key_state = 1;
            break;
        case 1 : //消抖状态
            if(LL_GPIO_IsInputPinSet(gkey[i].key_port,gkey[i].key_pin) == 0)
            {
                gkey[i].key_tick++;
                gkey[i].key_state = 2;
            }
            else{gkey[i].key_state = 0; gkey[i].key_tick = 0;} 
            break;
        case 2: //计时状态
            if(LL_GPIO_IsInputPinSet(gkey[i].key_port,gkey[i].key_pin) == 0)    
            {
                gkey[i].key_tick++;
                if(KEY_LONG_HOLD(gkey[i].key_tick))gkey[i].key = key_long_hold; //长按保持中
            }
            else 
            {
                if(KEY_SHORT_PRESS(gkey[i].key_tick))gkey[i].key = key_short; //短按松开
                if(KEY_LONG_HOLD(gkey[i].key_tick))gkey[i].key = key_long_release; //长按松开
                gkey[i].key_tick = 0;
                gkey[i].key_state = 0;
            }
            break;
        default:
            break;
        }
    }
}

//用于读取数值后清空状态使用
void Key_Reset(void)
{
    for (uint8_t i = 0; i < KEY_NUM; i++)
    {
        gkey[i].key = key_none;
    }
}

