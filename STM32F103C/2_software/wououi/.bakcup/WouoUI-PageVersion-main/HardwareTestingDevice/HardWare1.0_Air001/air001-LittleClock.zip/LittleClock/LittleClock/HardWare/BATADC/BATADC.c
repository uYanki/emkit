#include "BATADC.h"



void BATADC_Init(void)
{
    //uint16_t time_out = 1000;
    LL_APB1_GRP2_EnableClock(LL_APB1_GRP2_PERIPH_ADC1);
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = LL_GPIO_PIN_1;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
    // GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;  //输出推挽就可以
    LL_GPIO_Init(GPIOA,&GPIO_InitStruct);

    LL_ADC_StartCalibration(ADC1);
    while (LL_ADC_IsCalibrationOnGoing(ADC1));
    // while (LL_ADC_IsCalibrationOnGoing(ADC1) && (time_out > 0)) {
    //     time_out--;
    //     LL_mDelay(10);
    // }

    LL_ADC_InitTypeDef ADC_InitStruct = {0};
    LL_ADC_StructInit(&ADC_InitStruct);
    LL_ADC_Init(ADC1, &ADC_InitStruct); //adc_init
    
    LL_ADC_REG_InitTypeDef ADC_REG_InitStruct = {0};
    LL_ADC_REG_StructInit(&ADC_REG_InitStruct);
    LL_ADC_SetSamplingTimeCommonChannels(ADC1, LL_ADC_SAMPLINGTIME_41CYCLES_5);
    LL_ADC_REG_SetSequencerChAdd(ADC1, LL_ADC_CHANNEL_1);
    LL_ADC_REG_Init(ADC1, &ADC_REG_InitStruct);

    LL_ADC_Disable(ADC1);
}

uint16_t BATADC_Read(void)
{
    //uint16_t time_out = 100;
    uint16_t ret = 0;
    LL_ADC_Enable(ADC1);
    LL_ADC_REG_StartConversion(ADC1);
    while(LL_ADC_REG_IsConversionOngoing(ADC1));
    // LL_ADC_ClearFlag_EOC(ADC1);
    // LL_ADC_ClearFlag_EOS(ADC1);
    // while(LL_ADC_REG_IsConversionOngoing(ADC1) && (time_out>0))
    // {
    //     time_out--;
    //     LL_mDelay(10);
    // }
    ret = LL_ADC_REG_ReadConversionData12(ADC1)*892/4096 - 446;//(1.65-2.02)
    LL_ADC_Disable(ADC1);
    // ret = LL_ADC_REG_ReadConversionData12(ADC1)*1320/4096 - 740;//(1.85-2.1)
    // ret = LL_ADC_REG_ReadConversionData12(ADC1);
    return ret;
}
