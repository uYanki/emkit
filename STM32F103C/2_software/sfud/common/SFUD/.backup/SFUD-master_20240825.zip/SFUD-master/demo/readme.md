|File or folder name                     |Description|
|:-----                                  |:----|
|stm32f10x_non_os                        |STM32F10X non-os platform demo|
|stm32f2xx_rtt                           |STM32F2XX for [RT-Thread](http://www.rt-thread.org/) operating system platform demo|
|stm32l475_non_os_qspi                   |STM32L475 non-os platform QSPI mode demo|
|esp32_ext_spi_flash |ESP32C3 esp-idf platform external spi flash demo|

