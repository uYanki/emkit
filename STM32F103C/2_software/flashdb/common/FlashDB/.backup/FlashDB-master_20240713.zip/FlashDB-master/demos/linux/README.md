# linux demo

## What

KVDB  and TSDB demo on linux platform

## How

### Step1: build

Run `make` command on terminal. The generated executable program is located in the `out` folder.

### Step2: run demo

Switch to the `out` folder. Then run the `./FlashDBLinuxDemo` file multiple times.

### Step3: check the log

This demo's log will output to terminal.