| folder name           | storage type        |
| :-------------------- | :------------------ |
| stm32f103ve           | stm32 on-chip flash |
| stm32f405rg           | stm32 on-chip flash |
| stm32f405rg_spi_flash | spi flash           |
| esp8266_spi_flash     | spi flash           |
| esp32_spi_flash       | spi flash           |
| linux                 | posix file          |

