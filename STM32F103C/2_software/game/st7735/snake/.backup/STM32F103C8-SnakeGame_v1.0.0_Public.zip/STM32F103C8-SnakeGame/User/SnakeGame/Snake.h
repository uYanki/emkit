/**
  ******************************************************************************
  * @file         Snake.h
  * @brief        《贪吃蛇》游戏头文件
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 MICESPRING.
  * All rights reserved.
  *
  * This file is part of <SnakeGame>.
  *
  * <SnakeGame> is free software: you can redistribute it and/or modify it under the
  * terms of the GNU General Public License as published by the Free Software
  * Foundation, either version 3 of the License, or (at your option) any later
  * version.
  *
  * <SnakeGame> is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
  * Public License for more details.
  *
  * You should have received a copy of the GNU General Public License along
  * with <SnakeGame>. If not, see <https://www.gnu.org/licenses/>.
  *
  ******************************************************************************
  * @version 1.0.0
  *          + 发布第一版
  ******************************************************************************
  */
#ifndef SNAKE_H_
#define SNAKE_H_

#include "stdint.h"
#include "stddef.h"
#include "stdbool.h"
#include "stdio.h"

#define SNAKE_SCR_WIDTH                 160  // 屏幕宽度
#define SNAKE_SCR_HEIGHT                128  // 屏幕高度
#define SNAKE_TILE_WIDTH                6    // 块大小（游戏基本绘制单位）
#define SNAKE_FRAME_TIME                17   // 帧时间（~60FPS)
#define SNAKE_BODY_MAX_LENGTH           60   // “蛇”身体的最大长度（包括蛇头）
#define SNAKE_SCORE_AREA_HEIGHT         10   // 分数区高度
#define SNAKE_TOTAL_LEVELS              3    // 总游戏等级
#define SNAKE_CAN_CROSS_WALL            0    // 蛇是否可以穿越墙（当前版本未实现
#define SNAKE_HIGH_SCORE_RECORDS_CNT    10   // 高分榜项目总数

typedef enum{
	SnakeButtonNone,
	SnakeButtonLeft,
	SnakeButtonRight,
	SnakeButtonUp,
	SnakeButtonDown,
	SnakeButtonAccept,
}SnakeButton;

typedef struct{
    char name[4];
    uint32_t score;
}ScoreRecord;

// ******************************************************************************
// 游戏入口函数
// ******************************************************************************

/**
  * @brief  游戏入口函数，此函数不会返回
  *
  * @param  None： 延迟时间，单位毫秒
  *
  * @retval None
  */
void Snake_GameStart(void);

// ******************************************************************************
// 必须实现的接口函数。
// 这些函数用来与具体的硬件平台对接，如需移植到其他平台则必须自行实现
// ******************************************************************************

/**
  * @brief  延迟函数
  *
  * @param  xms： 延迟时间，单位毫秒
  *
  * @retval None
  */
void Snake_Ports_Delay(uint32_t xms);

/**
  * @brief  系统滴答时间获取
  *
  * @note   无论硬件滴答的时间间隔为多少，此处都应该返回以1ms为单位的滴答数。
  *
  * @param  None
  *
  * @retval 返回以1ms为单位滴答数
  */
uint32_t Snake_Ports_Ticks(void);

/**
  * @brief  随机数获取
  *
  * @param  None
  *
  * @retval 随机数
  */
int32_t Snake_Ports_Random(void);

/**
  * @brief  矩形填充函数
  *
  * @note   此函数是游戏主要的绘制函数，其性能会大幅度英雄游戏运行的流畅度。
  *
  * @param  x： 矩形左上角x坐标
  * @param  y： 矩形左上角y坐标
  * @param  w： 矩形宽度
  * @param  h： 矩形高度
  * @param  color： 填充的颜色，格式RGB565（LE）
  *
  * @retval 无
  */
void Snake_Ports_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);

/**
  * @brief  4bit灰阶位图填充函数
  *
  * @param  x： 位图左上角x坐标
  * @param  y： 位图左上角y坐标
  * @param  w： 位图宽度
  * @param  h： 位图高度
  * @param  data：位图数据，MSB
  * @param  palette： 默认灰阶调色板，可以自行实现
  *
  * @retval 无
  */
void Snake_Ports_DrawBitmap4bpp(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t* data, const uint16_t* palette);

/**
  * @brief  RGB565位图填充函数
  *
  * @param  x： 位图左上角x坐标
  * @param  y： 位图左上角y坐标
  * @param  w： 位图宽度
  * @param  h： 位图高度
  * @param  data：位图数据，格式RGB565(LE)
  *
  * @retval 无
  */
void Snake_Ports_DrawBitmapRGB565(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t* data);

/**
  * @brief  按键读取函数
  *
  * @param  None
  *
  * @retval 返回当前按下的按键代码，代码请参考枚举"SnakeButton"的定义
  *         如果无按键按下，则返回SnakeButtonNone
  */
SnakeButton Snake_Ports_ReadButton(void);

// ******************************************************************************
// 可选实现的接口函数。
// ******************************************************************************

/**
  * @brief  加载高分记录。
  *
  * @param  records： 高分记录数组指针。该数组的大小等于SNAKE_HIGH_SCORE_RECORDS_CNT的定义
  *
  * @retval 无
  */
void Snake_Ports_LoadHighScoreRecords(ScoreRecord* records);

/**
  * @brief  保存高分记录。
  *
  * @param  records： 高分记录数组指针。该数组的大小等于SNAKE_HIGH_SCORE_RECORDS_CNT的定义
  *
  * @retval 无
  */
void Snake_Ports_SaveHighScoreRecords(ScoreRecord* records);

#endif /* SNAKE_H_ */
