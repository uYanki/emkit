/* vim: set ai et ts=4 sw=4: */
#ifndef __FONTS_H__
#define __FONTS_H__

#include <stdint.h>

//Font data must contains below(exclude quote)
//" !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~"

#define USE_FONT_SONG_6_12
#define USE_FONT_SONG_8_16
#define USE_FONT_SONG_12_24
#define USE_FONT_SONG_16_32

typedef struct {
    const uint8_t width;
    const uint8_t height;
    const uint8_t *data;
} FontDef;


//extern FontDef Font_7x10;
//extern FontDef Font_11x18;
//extern FontDef Font_16x26;

#ifdef USE_FONT_SONG_6_12
extern FontDef FONT_SONG_6X12;
#endif
#ifdef USE_FONT_SONG_8_16
extern FontDef FONT_SONG_8X16;
#endif
#ifdef USE_FONT_SONG_12_24
extern FontDef FONT_SONG_12X24;
#endif
#ifdef USE_FONT_SONG_16_32
extern FontDef FONT_SONG_16X32;
#endif



#endif // __FONTS_H__
