/*
 * printf_gcc.c
 *
 *  Created on: Nov 6, 2021
 *      Author: mlian
 */
#if 0
#include "main.h"
#include "usart.h"


#define STDOUT_FILENO   1
#define STDERR_FILENO   2

int _write(int file, char *ptr, int len)
{
    switch (file)
    {
    case STDOUT_FILENO: /*stdout*/
        HAL_UART_Transmit(&huart3, (uint8_t*)ptr, len, 0xFF);
        break;
    case STDERR_FILENO: /* stderr */
        // Send the string somewhere
        break;
    default:
        return -1;
    }
    return len;
}
#endif
