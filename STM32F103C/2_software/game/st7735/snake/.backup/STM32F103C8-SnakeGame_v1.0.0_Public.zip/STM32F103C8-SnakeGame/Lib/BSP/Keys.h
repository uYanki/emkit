/*
 * Keys.h
 *
 *  Created on: Oct 4, 2022
 *      Author: Geralt
 */

#ifndef BSP_KEYS_H_
#define BSP_KEYS_H_

#include "main.h"
#include "adc.h"

typedef enum{
	KEY_NONE   = 0,
	KEY_UP     = 0x01,
	KEY_DOWN   = 0x02,
	KEY_LEFT   = 0x04,
	KEY_RIGHT  = 0x08,
	KEY_CENTER = 0x10,
}KeyCode;


#define JOYSTICK_ADCVAL_SEQ    {200, 1000, 1600, 2300, 3700, }
#define JOYSTICK_KEY_SEQ_NONE  {KEY_UP, KEY_LEFT, KEY_CENTER, KEY_DOWN, KEY_RIGHT,}
#define JOYSTICK_KEY_SEQ_ACW   {KEY_RIGHT, KEY_UP, KEY_CENTER, KEY_LEFT, KEY_DOWN,}
#define JOYSTICK_KEY_SEQ_UD    {KEY_DOWN, KEY_RIGHT, KEY_CENTER, KEY_UP, KEY_LEFT,}
#define JOYSTICK_KEY_SEQ_CW    {KEY_LEFT, KEY_DOWN, KEY_CENTER, KEY_RIGHT, KEY_UP,}

/** 逆时针旋转时的顺序 */
#define JOYSTICK_KEY_SEQ       JOYSTICK_KEY_SEQ_ACW

KeyCode BSP_Keys_CheckState(void);
KeyCode BSP_Keys_Read(void);

#endif /* BSP_KEYS_H_ */
