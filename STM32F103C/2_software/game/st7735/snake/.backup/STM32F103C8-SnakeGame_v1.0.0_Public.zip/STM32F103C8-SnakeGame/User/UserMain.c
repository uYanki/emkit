/*
 * UserMain.c
 *
 *  Created on: 2022年10月3日
 *      Author: Geralt
 */

#include "UserMain.h"
#include "ctype.h"
#include "Keys.h"

#include "Snake.h"

static void  SetSpiPrescaler(uint32_t psc);

/**
 * 用户主程序入口
 */
void UserMain(void){

	// SPI速度不高于6MHz
	SetSpiPrescaler(SPI_BAUDRATEPRESCALER_16);

	// 初始化LCD
	ST7735_Init();
	HAL_Delay(100);

	// 清空屏幕
	ST7735_FillScreen(0x0);

	Snake_GameStart();

	return;
}

static void SetSpiPrescaler(uint32_t psc){
	MODIFY_REG(hspi1.Instance->CR1, SPI_CR1_BR_Msk, (psc & SPI_CR1_BR_Msk));
}

