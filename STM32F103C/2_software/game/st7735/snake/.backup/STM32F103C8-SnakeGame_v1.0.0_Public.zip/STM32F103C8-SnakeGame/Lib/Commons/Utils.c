/*
 * Utils.c
 *
 *  Created on: 2020��5��13��
 *      Author: Desktop-01
 */


#include "Utils.h"


int64_t Util_Map(int64_t x, int64_t in_min, int64_t in_max, int64_t out_min, int64_t out_max){
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
