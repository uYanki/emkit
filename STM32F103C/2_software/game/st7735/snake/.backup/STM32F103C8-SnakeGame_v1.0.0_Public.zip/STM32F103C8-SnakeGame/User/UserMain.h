/*
 * UserMain.h
 *
 *  Created on: 2022年10月3日
 *      Author: Geralt
 */

#ifndef USERMAIN_H_
#define USERMAIN_H_

#include "main.h"
#include "adc.h"
#include "spi.h"
#include "gpio.h"
#include "Debug.h"
#include "Utils.h"

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#include "st7735.h"

void UserMain(void);


#endif /* USERMAIN_H_ */
