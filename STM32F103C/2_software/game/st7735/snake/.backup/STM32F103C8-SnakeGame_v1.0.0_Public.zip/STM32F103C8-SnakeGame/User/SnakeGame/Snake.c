/**
  ******************************************************************************
  * @file         Snake.c
  * @brief        《贪吃蛇》主要游戏逻辑实现
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 MICESPRING.
  * All rights reserved.
  *
  * This file is part of <SnakeGame>.
  *
  * <SnakeGame> is free software: you can redistribute it and/or modify it under the
  * terms of the GNU General Public License as published by the Free Software
  * Foundation, either version 3 of the License, or (at your option) any later
  * version.
  *
  * <SnakeGame> is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
  * Public License for more details.
  *
  * You should have received a copy of the GNU General Public License along
  * with <SnakeGame>. If not, see <https://www.gnu.org/licenses/>.
  *
  ******************************************************************************
  * @version 1.0.0
  *          + 发布第一版
  ******************************************************************************
  */
#include "Snake.h"

typedef enum{
	SnakeScreenStart,
	SnakeScreenGame,
	SnakeScreenHighScore,
	SnakeScreenGameOver,
}SnakeScreen;

typedef enum{
	SnakeGoLeft,
	SnakeGoRight,
	SnakeGoUp,
	SnakeGoDown,
}SnakeDirection;

typedef struct _SankePart{
	uint16_t x;
	uint16_t y;
	struct _SankePart *next;
	struct _SankePart *prev;
}SnakePart;

static const uint16_t bgColor = 0;
static const uint16_t wallColor = 0xC618;
static const uint16_t snakeHeadColor = 0x26CD;
static const uint16_t snakeBodyColor = 0xFD0C;
static const uint16_t foodColor = 0xF800;
static const uint16_t scoreColor = 0xFFFF;
static const uint16_t levelColor = 0xFFFF;
static const uint16_t pauseColor = 0xF800;

extern const uint8_t gImage_Snake_17x19_RGB565[646];
extern const uint8_t gImage_MainImage_160x128_4bpp[10240];
extern const uint8_t gImage_HighScore_50x18_4bpp[450];
extern const uint8_t SnakeBuildInFont[];

static const uint16_t greyScale4bppPalette[16] = {
		0xFFFF, 0xE71C, 0xD69A, 0xC618, 0xB596, 0xA514, 0x9492, 0x8410,
		0x738E, 0x630C, 0x528A, 0x4208, 0x3186, 0x2104, 0x1082, 0x0000,
};

static const uint16_t levelFrameIntervalMap[SNAKE_TOTAL_LEVELS] = {
		3,
		2,
		1,
};
static const uint16_t levelScoreMap[SNAKE_TOTAL_LEVELS] = {
		10,
		50,
		0xFFFF,
};

static uint32_t ticks = 0;
static uint32_t frameCount = 0;
static SnakeButton lastButton = SnakeButtonNone;

static ScoreRecord highScoreRecords[SNAKE_HIGH_SCORE_RECORDS_CNT];

static uint16_t memPoolPos = 0;
static SnakePart snakePartMemPool[SNAKE_BODY_MAX_LENGTH];

static SnakePart* snakeHead, *snakeTail;
static uint16_t activeAreaCols, activeAreaRows;
static uint16_t activeAreaWidth, activeAreaHeight;
static uint16_t activeAreaStartX, activeAreaStartY;

static uint16_t nextX, nextY;
static SnakeDirection nextDir, headDir;
static uint16_t moveDistance;

static int16_t foodX, foodY;
static bool snakeIsGrowing = false;

static uint16_t score, level;
static uint16_t scoreX, scoreY, levelX;

// ********************************************************
// 游戏画面主函数
// ********************************************************

static SnakeScreen Snake_StartScreen();
static SnakeScreen Snake_GameScreen();
static SnakeScreen Snake_GameOverScreen();
static SnakeScreen Snake_HighScoreScreen();

// ********************************************************
// 其他函数
// ********************************************************

static void Snake_DrawChar(char c, uint16_t x, uint16_t y, uint8_t xSize, uint8_t ySize, uint16_t fg, uint16_t bg);
static void Snake_DrawString(const char* str, uint16_t x, uint16_t y, uint8_t xSize, uint8_t ySize, uint16_t fg, uint16_t bg);
static void Snake_CreateScene();
static SnakePart* Snake_NewSnakePart();
static void Snake_PutFood();
static void Snake_DrawFood();
static void Snake_ResetGame();
static void Snake_DrawSnake();
static bool Snake_DrawMove();
static void Snake_CalcNextHeadPos();
static bool Snake_CheckCollision();
static void Snake_DrawScoreAndLevel();
static void Snake_Goal();
static void Snake_CheckFood();
static void Snake_ChangeDir();
static void Snake_GameReadyAnim();
static void Snake_GamePause();

static void Snake_DrawChar(char c, uint16_t x, uint16_t y, uint8_t xSize, uint8_t ySize, uint16_t fg, uint16_t bg){
    for (int8_t i = 0; i < 5; i++) {
        uint8_t line = SnakeBuildInFont[c * 5 + i];
        for (int8_t j = 0; j < 8; j++, line >>= 1) {
            if (line & 1) {
                if (xSize == 1 && ySize == 1)
                    Snake_Ports_FillRect(x + i, y + j, 1, 1, fg);
                else
                    Snake_Ports_FillRect(x + i * xSize, y + j * ySize, xSize, ySize, fg);
            }
            else if (bg != fg) {
                if (xSize == 1 && ySize == 1)
                    Snake_Ports_FillRect(x + i, y + j, 1, 1, bg);
                else
                    Snake_Ports_FillRect(x + i * xSize, y + j * ySize, xSize, ySize, bg);
            }
        }
    }
    if (bg != fg) {
        if (xSize == 1 && ySize == 1){
            Snake_Ports_FillRect(x + 5, y, 1, 8, bg);
        }
        else{
            Snake_Ports_FillRect(x + 5 * xSize, y, xSize, 8 * ySize, bg);
        }
    }
}

static void Snake_DrawString(const char* str, uint16_t x, uint16_t y, uint8_t xSize, uint8_t ySize, uint16_t fg, uint16_t bg){
    char c;
    while((c = *str++)!='\0') {
        Snake_DrawChar(c, x, y, xSize, ySize, fg, bg);
        x += 6 * xSize;
    }
}

static SnakeScreen Snake_StartScreen(){

	uint8_t currentIndex = 0;

	uint16_t iconX = 25;
	uint16_t iconY = 66;

	Snake_Ports_DrawBitmap4bpp(0, 0, SNAKE_SCR_WIDTH, SNAKE_SCR_HEIGHT, gImage_MainImage_160x128_4bpp, greyScale4bppPalette);
	Snake_Ports_DrawBitmapRGB565(iconX, iconY, 17, 19, gImage_Snake_17x19_RGB565);


	while(1){
		ticks = Snake_Ports_Ticks();

		// 读取按键
		SnakeButton btn = Snake_Ports_ReadButton();
		// 消除连按
		if(lastButton != SnakeButtonNone && btn == lastButton){
			ticks = Snake_Ports_Ticks() - ticks;
			if(ticks < SNAKE_FRAME_TIME){
				Snake_Ports_Delay(SNAKE_FRAME_TIME - ticks);
				continue;
			}
		}

		lastButton = btn;

		// 更改选项
		if(btn == SnakeButtonUp || btn == SnakeButtonDown){
			// 清除原来的选择标志
			Snake_Ports_FillRect(iconX, iconY, 17, 19, bgColor);
			// 更新选择标志
			currentIndex = currentIndex ? 0 : 1;
			iconY = currentIndex ? 94 : 66;
			Snake_Ports_DrawBitmapRGB565(iconX, iconY, 17, 19, gImage_Snake_17x19_RGB565);
		}
		// 选择了选项
		else if(btn == SnakeButtonAccept){
			return currentIndex ? SnakeScreenHighScore : SnakeScreenGame;
		}

		ticks = Snake_Ports_Ticks() - ticks;
		if(ticks < SNAKE_FRAME_TIME){
			Snake_Ports_Delay(SNAKE_FRAME_TIME - ticks);
		}
	}
}

static void Snake_CreateScene(){
	// 背景色
	Snake_Ports_FillRect(0, 0, SNAKE_SCR_WIDTH, SNAKE_SCR_HEIGHT, bgColor);
	// 墙的厚度等于Tile大小的一半
	uint16_t wallThickness = SNAKE_TILE_WIDTH / 2;
	// 墙的高度等于屏幕高度减去分数区高度，然后向下取tile宽度的整倍数
	uint16_t wallHeight = (SNAKE_SCR_HEIGHT - SNAKE_SCORE_AREA_HEIGHT) / SNAKE_TILE_WIDTH;
	wallHeight *= SNAKE_TILE_WIDTH;
	// 墙的宽度等于屏幕宽度向下取tile宽度的整倍数
	uint16_t wallWidth = SNAKE_SCR_WIDTH / SNAKE_TILE_WIDTH;
	wallWidth *= SNAKE_TILE_WIDTH;
	// 绘制墙
	uint16_t xOff = (SNAKE_SCR_WIDTH - wallWidth) / 2;
	Snake_Ports_FillRect(xOff, 0, wallWidth, wallThickness, wallColor);
	Snake_Ports_FillRect(xOff, wallHeight - wallThickness, wallWidth, wallThickness, wallColor);
	Snake_Ports_FillRect(xOff, wallThickness, wallThickness, wallHeight - SNAKE_TILE_WIDTH, wallColor);
	Snake_Ports_FillRect(xOff + wallWidth - wallThickness, wallThickness, wallThickness, wallHeight - SNAKE_TILE_WIDTH, wallColor);
	// 分数区
	scoreX = 42 + xOff;
	levelX = 126 + xOff;
	scoreY = SNAKE_SCR_HEIGHT - 10;
	Snake_DrawString("SCORE:        LEVEL:  ", xOff, scoreY, 1, 1, scoreColor, scoreColor);
	Snake_DrawScoreAndLevel();
	// 活动区域大小
	activeAreaStartX = xOff + wallThickness;
	activeAreaStartY = wallThickness;
	activeAreaCols = wallWidth / SNAKE_TILE_WIDTH - 1;
	activeAreaRows = wallHeight / SNAKE_TILE_WIDTH - 1;
	activeAreaWidth = activeAreaCols * SNAKE_TILE_WIDTH;
	activeAreaHeight = activeAreaRows * SNAKE_TILE_WIDTH;
}

static SnakePart* Snake_NewSnakePart(){
	if(memPoolPos < SNAKE_BODY_MAX_LENGTH){
		return &snakePartMemPool[memPoolPos++];
	}
	return NULL;
}

static void Snake_PutFood(){

    while(1){
        uint32_t v = Snake_Ports_Random();
        foodX = (v % activeAreaCols) * SNAKE_TILE_WIDTH + activeAreaStartX;
        foodY = (v % activeAreaRows) * SNAKE_TILE_WIDTH + activeAreaStartY;

        // 检查食物是否正好在下一个移动位置
        if(foodX == nextX && foodY == nextY){
            continue;
        }

        // 检查食物是否生成在身体内
        bool isFoodInBody = false;
        SnakePart *part = snakeHead;
        while (part) {
            if(part->x == foodX && part->y == foodY){
                isFoodInBody = true;
                break;
            }
            part = part->next;
        }

        if(!isFoodInBody){
            break;
        }
    }
}

static void Snake_DrawFood(){
    Snake_Ports_FillRect(foodX, foodY, SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, foodColor);
}

static void Snake_ResetGame(){
	memPoolPos = 0;
	frameCount = 0;
	score = 0;
	level = 0;
	score = 0;
	level = 0;

	// 将蛇初始化到初始位置及大小
	snakeHead = Snake_NewSnakePart();
	snakeHead->x = activeAreaCols / 2 * SNAKE_TILE_WIDTH + activeAreaStartX;
	snakeHead->y = activeAreaRows / 2 * SNAKE_TILE_WIDTH + activeAreaStartY;
	snakeHead->next = Snake_NewSnakePart();
	snakeHead->prev = NULL;

	SnakePart* middle = snakeHead->next;
	middle->x = snakeHead->x - SNAKE_TILE_WIDTH;
	middle->y = snakeHead->y;
	middle->prev = snakeHead;
	middle->next = Snake_NewSnakePart();

	snakeTail = middle->next;
	snakeTail->x = middle->x - SNAKE_TILE_WIDTH;
	snakeTail->y = middle->y;
	snakeTail->prev = middle;
	snakeTail->next = NULL;

	// 方向数据
	nextX = snakeHead->x + SNAKE_TILE_WIDTH;
	nextY = snakeHead->y;
	nextDir = SnakeGoRight;
	headDir = SnakeGoRight;
	moveDistance = 0;

	// 放置食物
	Snake_PutFood();
	snakeIsGrowing = false;
}

static void Snake_DrawSnake(){
	Snake_Ports_FillRect(snakeHead->x, snakeHead->y, SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, snakeHeadColor);
	SnakePart *part = snakeHead->next;
	while (part) {
		Snake_Ports_FillRect(part->x, part->y, SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, snakeBodyColor);
		part = part->next;
	}
}

static bool Snake_DrawMove(){
    // 如果已经移动到目的地，则不需要移动
	if(moveDistance >= SNAKE_TILE_WIDTH){
		return true;
	}

	if(frameCount % levelFrameIntervalMap[level] == 0){
#if SNAKE_CAN_CROSS_WALL
		// Cross Wall codes
#error "not impl"
#else
	    // 移动头部
		if(headDir == SnakeGoRight){
			Snake_Ports_FillRect(snakeHead->x + moveDistance, snakeHead->y, 1, SNAKE_TILE_WIDTH, snakeBodyColor);
			Snake_Ports_FillRect(snakeHead->x + moveDistance + SNAKE_TILE_WIDTH, snakeHead->y, 1, SNAKE_TILE_WIDTH, snakeHeadColor);
		}
		else if(headDir == SnakeGoLeft){
			Snake_Ports_FillRect(snakeHead->x - moveDistance - 1, snakeHead->y, 1, SNAKE_TILE_WIDTH, snakeHeadColor);
			Snake_Ports_FillRect(snakeHead->x - moveDistance + SNAKE_TILE_WIDTH - 1, snakeHead->y, 1, SNAKE_TILE_WIDTH, snakeBodyColor);
		}
		else if(headDir == SnakeGoUp){
			Snake_Ports_FillRect(snakeHead->x, snakeHead->y - moveDistance - 1, SNAKE_TILE_WIDTH, 1, snakeHeadColor);
			Snake_Ports_FillRect(snakeHead->x, snakeHead->y - moveDistance + SNAKE_TILE_WIDTH - 1, SNAKE_TILE_WIDTH, 1, snakeBodyColor);
		}
		else if(headDir == SnakeGoDown){
		    Snake_Ports_FillRect(snakeHead->x, snakeHead->y + moveDistance, SNAKE_TILE_WIDTH, 1, snakeBodyColor);
            Snake_Ports_FillRect(snakeHead->x, snakeHead->y + moveDistance + SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, 1, snakeHeadColor);
        }

		// 仅在非生长模式下移动尾部
		if(!snakeIsGrowing){
	        if(snakeTail->prev->x > snakeTail->x){
	            Snake_Ports_FillRect(snakeTail->x + moveDistance, snakeTail->y, 1, SNAKE_TILE_WIDTH, bgColor);
	        }
	        else if(snakeTail->prev->x < snakeTail->x){
	            Snake_Ports_FillRect(snakeTail->x - moveDistance + SNAKE_TILE_WIDTH - 1, snakeTail->y, 1, SNAKE_TILE_WIDTH, bgColor);
	        }
	        else if(snakeTail->prev->y < snakeTail->y){
	            Snake_Ports_FillRect(snakeTail->x, snakeTail->y - moveDistance + SNAKE_TILE_WIDTH - 1, SNAKE_TILE_WIDTH, 1, bgColor);
	        }
	        else if(snakeTail->prev->y > snakeTail->y){
	            Snake_Ports_FillRect(snakeTail->x, snakeTail->y + moveDistance, SNAKE_TILE_WIDTH, 1, bgColor);
	        }
		}

		return ++moveDistance >= SNAKE_TILE_WIDTH;
#endif
	}

	return false;
}

static void Snake_CalcNextHeadPos(){

    SnakePart* newHead = snakeTail;
    snakeTail = snakeTail->prev;
    snakeTail->next = NULL;

    newHead->x = nextX;
    newHead->y = nextY;
    newHead->next = snakeHead;
    newHead->prev = NULL;

    snakeHead->prev = newHead;
    snakeHead = newHead;

    if (nextDir == SnakeGoRight) {
        nextX += SNAKE_TILE_WIDTH;
    } else if (nextDir == SnakeGoLeft) {
        nextX -= SNAKE_TILE_WIDTH;
    } else if (nextDir == SnakeGoUp) {
        nextY -= SNAKE_TILE_WIDTH;
    } else if (nextDir == SnakeGoDown){
        nextY += SNAKE_TILE_WIDTH;
    }

    headDir = nextDir;
    moveDistance = 0;
}

static bool Snake_CheckCollision(){

#if !SNAKE_CAN_CROSS_WALL
    if ((nextX < activeAreaStartX)
            || (nextX >= (activeAreaStartX + activeAreaWidth))
            || (nextY < activeAreaStartY)
            || (nextY >= (activeAreaStartY + activeAreaHeight))){
        return true;
    }
#endif

    SnakePart *part = snakeHead;
    while (part) {
        if(part->x == nextX && part->y == nextY){
            return true;
        }
        part = part->next;
    }

    return false;
}

static void Snake_DrawScoreAndLevel(){
	Snake_DrawChar(level + '1', levelX, scoreY, 1, 1, levelColor, bgColor);
    char strbuf[16];
    sprintf(strbuf, "%05u", score);
    Snake_DrawString(strbuf, scoreX, scoreY, 1, 1, scoreColor, bgColor);
}

static void Snake_Goal(){
    score += (level + 1);
    if(score > levelScoreMap[level] && (level < SNAKE_TOTAL_LEVELS - 1)){
        level ++;

    }
    Snake_DrawScoreAndLevel();
}

static void Snake_CheckFood(){
    // 碰触到了食物
    if(foodX == nextX && foodY == nextY){
        Snake_Goal();
        // 创建一个新的食物
        Snake_PutFood();
        Snake_DrawFood();
        // 如果蛇没有长到最大长度，则标记蛇开始生长
        if(memPoolPos < SNAKE_BODY_MAX_LENGTH){
            snakeIsGrowing = true;
        }
    }
}

static void Snake_ChangeDir(){
    SnakeButton btn = Snake_Ports_ReadButton();

    if (btn == SnakeButtonRight && headDir != SnakeGoLeft) {
        nextDir = SnakeGoRight;
    } else if (btn == SnakeButtonLeft && headDir != SnakeGoRight) {
        nextDir = SnakeGoLeft;
    } else if (btn == SnakeButtonUp && headDir != SnakeGoDown) {
        nextDir = SnakeGoUp;
    } else if (btn == SnakeButtonDown && headDir != SnakeGoUp) {
        nextDir = SnakeGoDown;
    }
}

static void Snake_GameReadyAnim(){
    uint16_t x = activeAreaStartX + (activeAreaWidth - 72) / 2;
    uint16_t y = activeAreaStartY + (activeAreaHeight - 16) / 2;

    Snake_DrawString("READY?", x, y, 2, 2, scoreColor, bgColor);
    Snake_Ports_Delay(1000);

    Snake_Ports_FillRect(x, y, 72, 16, bgColor);
    x = activeAreaStartX + (activeAreaWidth - 36) / 2;
    Snake_DrawString("Go!", x, y, 2, 2, scoreColor, bgColor);
    Snake_Ports_Delay(1000);
    Snake_Ports_FillRect(x, y, 36, 16, bgColor);
}

static void Snake_GamePause(){
    uint16_t x = activeAreaStartX + (activeAreaWidth - 60) / 2;
    uint16_t y = activeAreaStartY + (activeAreaHeight - 16) / 2;

    Snake_DrawString("PAUSE", x, y, 2, 2, pauseColor, pauseColor);
    Snake_Ports_Delay(500);

    while(1){
        if(Snake_Ports_ReadButton() == SnakeButtonAccept){
            break;
        }
    }
    Snake_Ports_Delay(100);
}

static SnakeScreen Snake_GameScreen(){
	Snake_CreateScene();
	Snake_ResetGame();
	Snake_DrawScoreAndLevel();
	Snake_GameReadyAnim();
	Snake_DrawSnake();
	Snake_DrawFood();

	bool isMoveCplt = false;
	while(1){
		ticks = Snake_Ports_Ticks();

		if(Snake_Ports_ReadButton() == SnakeButtonAccept){
		    Snake_GamePause();
		    Snake_CreateScene();
		    Snake_DrawSnake();
		    Snake_DrawFood();
		    moveDistance = 0;
		}

		Snake_ChangeDir();

		isMoveCplt = Snake_DrawMove();

		// 已经移动到新的目的地
		if(isMoveCplt){
		    SnakePart *newTail = NULL;
		    // 如果是生长结束，则创建一个新的蛇尾
            if(snakeIsGrowing) {
                snakeIsGrowing = false;
                newTail = Snake_NewSnakePart();
                if(newTail != NULL) {
                    // 记录原来尾部的位置
                    newTail->x = snakeTail->x;
                    newTail->y = snakeTail->y;
                    newTail->next = NULL;
                }
            }
		    // 移动蛇
		    Snake_CalcNextHeadPos();
		    // 如果有新的蛇尾，添加它
		    if(newTail != NULL){
		        newTail->prev = snakeTail;
		        snakeTail->next = newTail;
		        snakeTail = newTail;
		    }

		    // 检查是否会发生碰撞
		    if(Snake_CheckCollision()){
		        break;
		    }
		    // 检查是否吃到食物或放置新的食物
		    Snake_CheckFood();
		}

		ticks = Snake_Ports_Ticks() - ticks;
		if(ticks < SNAKE_FRAME_TIME){
			Snake_Ports_Delay(SNAKE_FRAME_TIME - ticks);
		}
		frameCount ++ ;
	};

	return SnakeScreenGameOver;
}

static SnakeScreen Snake_GameOverScreen(){
    Snake_Ports_Delay(1000);

    // 以动画形式消除活动区的元素
    Snake_Ports_FillRect(foodX, foodY, SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, bgColor);
    Snake_Ports_Delay(20);

    SnakePart *part = snakeHead;
    while(part != NULL){
        Snake_Ports_FillRect(part->x, part->y, SNAKE_TILE_WIDTH, SNAKE_TILE_WIDTH, bgColor);
        part = part->next;
        Snake_Ports_Delay(20);
    }

    // 显示GameOver
    uint16_t x = activeAreaStartX + (activeAreaWidth - 108) / 2;
    uint16_t y = activeAreaStartY + (activeAreaHeight - 16) / 2;

    Snake_DrawString("GAME OVER", x, y, 2, 2, scoreColor, bgColor);
    Snake_Ports_Delay(1000);

    // 记录新的高分
    if (score > highScoreRecords[SNAKE_HIGH_SCORE_RECORDS_CNT - 1].score) {
        uint16_t distY = activeAreaStartY + (activeAreaHeight - 16) / 3;
        for (int i = y; i >= distY; i--) {
            Snake_DrawString("GAME OVER", x, i, 2, 2, scoreColor, bgColor);
            Snake_Ports_FillRect(x, i + 16, 108, 1, bgColor);
            Snake_Ports_Delay(3);
        }

        x = activeAreaStartX + (activeAreaWidth - 60) / 2;
        Snake_DrawString("New Record!", x, y + 36, 1, 1, scoreColor, bgColor);

        x = activeAreaStartX + (activeAreaWidth - 18) / 2;
        y = activeAreaStartY + (activeAreaHeight - 16) * 2 / 3;

        // 等待用户输入名字
        uint32_t loops = 0;
        uint8_t editingDig = 0;
        char name[] = { 'A', 'A', 'A' };
        bool blink = false;
        while(1) {
            if(loops % 5 == 0) {
                for(int i = 0; i < 3; i++) {
                    bool reverse = (editingDig == i) && blink;
                    Snake_DrawChar(name[i], x + i * 6, y, 1, 1, reverse ? 0 : 0xFFFF, reverse ? 0xFFFF : 0);
                }
            }

            SnakeButton btn = Snake_Ports_ReadButton();
            if(btn == SnakeButtonNone || lastButton != btn) {
                lastButton = btn;
                if(btn == SnakeButtonRight) {
                    editingDig ++;
                    if(editingDig > 2) {
                        editingDig = 0;
                    }
                }
                else if(btn == SnakeButtonLeft) {
                    if(editingDig != 0) {
                        editingDig --;
                    }
                    else {
                        editingDig = 2;
                    }
                }
                else if(btn == SnakeButtonUp) {
                    name[editingDig] --;
                    if(name[editingDig] < 'A') {
                        name[editingDig] = 'Z';
                    }
                }
                else if(btn == SnakeButtonDown) {
                    name[editingDig] ++;
                    if(name[editingDig] > 'Z') {
                        name[editingDig] = 'A';
                    }
                }
                else if(btn == SnakeButtonAccept) {
                    break;
                }
            }

            if(loops % 10 == 9) {
                blink = !blink;
            }

            loops ++;
            Snake_Ports_Delay(20);
        }

        for (int i = 0; i < 3; i++) {
            Snake_DrawChar(name[i], x + i * 6, y, 1, 1, 0xFFFF, 0);
        }

        Snake_Ports_Delay(2000);

        // 计算新的排名
        int newRank = SNAKE_HIGH_SCORE_RECORDS_CNT;
        for (int i = 0; i < SNAKE_HIGH_SCORE_RECORDS_CNT; i++) {
            if (score > highScoreRecords[i].score) {
                newRank = i;
                break;
            }
        }

        // 插入排名
        for (int i = SNAKE_HIGH_SCORE_RECORDS_CNT - 1; i > newRank; i--) {
            highScoreRecords[i].name[0] = highScoreRecords[i - 1].name[0];
            highScoreRecords[i].name[1] = highScoreRecords[i - 1].name[1];
            highScoreRecords[i].name[2] = highScoreRecords[i - 1].name[2];
            highScoreRecords[i].name[3] = highScoreRecords[i - 1].name[3];
            highScoreRecords[i].score = highScoreRecords[i - 1].score;
        }

        highScoreRecords[newRank].name[0] = name[0];
        highScoreRecords[newRank].name[1] = name[1];
        highScoreRecords[newRank].name[2] = name[2];
        highScoreRecords[newRank].name[3] = '\0';
        highScoreRecords[newRank].score = score;

        // 保存排名
        Snake_Ports_SaveHighScoreRecords(highScoreRecords);
    }


    return SnakeScreenHighScore;
}

static SnakeScreen Snake_HighScoreScreen(){
    Snake_Ports_FillRect(0, 0, SNAKE_SCR_WIDTH, SNAKE_SCR_HEIGHT, bgColor);
    Snake_Ports_DrawBitmap4bpp(53, 3, 50, 18, gImage_HighScore_50x18_4bpp, greyScale4bppPalette);

    char strbuf[16];
    const uint16_t nameX = 20, scoreX = SNAKE_SCR_WIDTH - 50;
    uint16_t y = 24;

    for(int i = 0; i < 10; i++){
        Snake_DrawString(highScoreRecords[i].name, nameX, y, 1, 1, scoreColor, bgColor);
        sprintf(strbuf, "%05lu", highScoreRecords[i].score);
        Snake_DrawString(strbuf, scoreX, y, 1, 1, scoreColor, bgColor);
        y += 10;
    }

    while(1){
        if(Snake_Ports_ReadButton() == SnakeButtonAccept){
            while(Snake_Ports_ReadButton() == SnakeButtonAccept){
                Snake_Ports_Delay(1);
            }
            break;
        }
    }

    Snake_Ports_Delay(200);

    return SnakeScreenStart;
}

void Snake_GameStart(){
	SnakeScreen nextScreen = SnakeScreenStart;
	Snake_Ports_LoadHighScoreRecords(highScoreRecords);

	while(1){
		if(nextScreen == SnakeScreenStart){
			nextScreen = Snake_StartScreen();
		}
		else if(nextScreen == SnakeScreenGame){
			nextScreen = Snake_GameScreen();
		}
		else if(nextScreen == SnakeScreenGameOver){
		    nextScreen = Snake_GameOverScreen();
		}
		else if(nextScreen == SnakeScreenHighScore){
		    nextScreen = Snake_HighScoreScreen();
		}
	}
	Snake_StartScreen();
}


__attribute__((weak)) void Snake_Ports_LoadHighScoreRecords(ScoreRecord* records){
    for(int i = 0; i < SNAKE_HIGH_SCORE_RECORDS_CNT; i++){
        records[i].name[0] = 'M';
        records[i].name[1] = 'I';
        records[i].name[2] = 'S';
        records[i].name[3] = '\0';
        records[i].score = (9 - i) * 10;
    }
}
__attribute__((weak)) void Snake_Ports_SaveHighScoreRecords(ScoreRecord* records){

}
