/*
 * Utils.h
 *
 *  Created on: 2020��5��13��
 *      Author: Desktop-01
 */

#ifndef UTILS_H_
#define UTILS_H_

#include "main.h"

#define ABS(a) ((a) > 0 ? (a) : -(a))
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))

int64_t Util_Map(int64_t x, int64_t in_min, int64_t in_max, int64_t out_min, int64_t out_max);

#endif /* UTILS_H_ */
