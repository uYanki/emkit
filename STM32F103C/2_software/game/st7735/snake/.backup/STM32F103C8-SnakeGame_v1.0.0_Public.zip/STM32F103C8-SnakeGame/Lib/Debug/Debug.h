/*
 * Debug.h
 *
 *  Created on: 2021年11月17日
 *      Author: mlian
 */

#ifndef DEBUG_DEBUG_H_
#define DEBUG_DEBUG_H_

#include "stdio.h"

#define DEBUG_INFO(fmt,...) printf("[INFO][%s|%05d]"fmt,__func__,__LINE__,##__VA_ARGS__)
#define DEBUG_WARN(fmt,...) printf("[WARN][%s|%05d]"fmt,__func__,__LINE__,##__VA_ARGS__)
#define DEBUG_ERR(fmt,...)  printf("[ERR ][%s|%05d]"fmt,__func__,__LINE__,##__VA_ARGS__)

#define DEBUG_INFOL(fmt,...) printf("[INFO][%s|%05d]"fmt"\r\n",__func__,__LINE__,##__VA_ARGS__)
#define DEBUG_WARNL(fmt,...) printf("[WARN][%s|%05d]"fmt"\r\n",__func__,__LINE__,##__VA_ARGS__)
#define DEBUG_ERRL(fmt,...)  printf("[ERR ][%s|%05d]"fmt"\r\n",__func__,__LINE__,##__VA_ARGS__)


#endif /* DEBUG_DEBUG_H_ */
