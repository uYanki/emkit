/**
  ******************************************************************************
  * @file         SnakeAssets.c
  * @brief        《贪吃蛇》游戏接口函数针对STM32F103C8T6和Arduino 1.8'' TFT Shield的实现
  * @note         Arduino 1.8'' TFT Shield开源链接：
  *               https://oshwhub.com/micespring/adafruit-1-8-tft-shield-v1-clone
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 MICESPRING.
  * All rights reserved.
  *
  * This file is part of <SnakeGame>.
  *
  * <SnakeGame> is free software: you can redistribute it and/or modify it under the
  * terms of the GNU General Public License as published by the Free Software
  * Foundation, either version 3 of the License, or (at your option) any later
  * version.
  *
  * <SnakeGame> is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
  * Public License for more details.
  *
  * You should have received a copy of the GNU General Public License along
  * with <SnakeGame>. If not, see <https://www.gnu.org/licenses/>.
  *
  ******************************************************************************
  * @version 1.0.0
  *          + 发布第一版
  ******************************************************************************
  */
#include "Snake.h"

#include "st7735.h"
#include "Keys.h"

#include "stdlib.h"

#define LED_ON() HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET)
#define LED_OFF() HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET)

static uint16_t lineBuffer[160];

void Snake_Ports_Delay(uint32_t xms){
	HAL_Delay(xms);
}

void Snake_Ports_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color){
	LED_ON();
	ST7735_FillRectangle(x, y, w, h, color);
	LED_OFF();
}

void Snake_Ports_DrawBitmap4bpp(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t* data, const uint16_t* palette){
	LED_ON();
	while(h--){
		int i = 0;
		for(; i < w; i++){
			uint8_t val = *data;
			if((i%2) == 0){
				lineBuffer[i] = palette[val >> 4];
			}
			else{
				lineBuffer[i] = palette[val & 0x0F];
				data++;
			}
			lineBuffer[i] = (lineBuffer[i] >> 8) | (lineBuffer[i] << 8);
		}
		ST7735_DrawImage(x, y++, w, 1, (const uint8_t*)lineBuffer);
		if((i%2) == 1){
			data++;
		}
	}
	LED_OFF();
}

void Snake_Ports_DrawBitmapRGB565(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t* data){
	LED_ON();
	ST7735_DrawImage(x, y, w, h, data);
	LED_OFF();
}

uint32_t Snake_Ports_Ticks(void){
	return HAL_GetTick();
}

int32_t Snake_Ports_Random(void){
	return rand();
}

SnakeButton Snake_Ports_ReadButton(void){
	KeyCode code = BSP_Keys_CheckState();
	switch(code){
	case KEY_UP:
		return SnakeButtonUp;
	case KEY_DOWN:
		return SnakeButtonDown;
	case KEY_LEFT:
		return SnakeButtonLeft;
	case KEY_RIGHT:
		return SnakeButtonRight;
	case KEY_CENTER:
		return SnakeButtonAccept;
	default :
		break;
	}

	return SnakeButtonNone;
}
