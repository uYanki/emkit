/*
 * Keys.c
 *
 *  Created on: Oct 4, 2022
 *      Author: Geralt
 */

#include "Keys.h"

static const uint32_t keyAdcValueMap[] = JOYSTICK_ADCVAL_SEQ;
static const KeyCode keyIndex[] = JOYSTICK_KEY_SEQ;

KeyCode BSP_Keys_CheckState() {
//	 ADC_ChannelConfTypeDef sConfig;
//	  sConfig.Channel      = ADC_CHANNEL_9;
//	  sConfig.Rank         = 1;
//	  sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
//	  sConfig.Offset = 0;

	if (HAL_ADC_Start(&hadc1) != HAL_OK) {
		/* Start Conversation Error */
		Error_Handler();
	}

	if (HAL_ADC_PollForConversion(&hadc1, 0xFF) != HAL_OK) {
		return KEY_NONE;
	}

	uint32_t keyConvertedvalue = HAL_ADC_GetValue(&hadc1);

	for(int i = 0; i < 5; i++){
		if(keyConvertedvalue < keyAdcValueMap[i]){
			return keyIndex[i];
		}
	}

	return KEY_NONE;
}

KeyCode BSP_Keys_Read() {

	KeyCode code = KEY_NONE;
	if((code = BSP_Keys_CheckState()) != KEY_NONE){
		while(code == BSP_Keys_CheckState());
	}
	return code;
}
