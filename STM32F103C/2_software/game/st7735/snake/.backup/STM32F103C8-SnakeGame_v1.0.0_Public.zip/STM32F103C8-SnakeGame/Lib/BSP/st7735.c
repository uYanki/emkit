/* vim: set ai et ts=4 sw=4: */
#include "st7735.h"
#include "fonts.h"

extern void HAL_Delay(uint32_t n);

#define DELAY 0x80
#define swap_uint16_t(a, b) { uint16_t t = a; a = b; b = t; }
#define swap_int16_t(a, b) { int16_t t = a; a = b; b = t; }

static uint16_t lcdBuffer[ST7735_WIDTH > ST7735_HEIGHT ? ST7735_WIDTH : ST7735_HEIGHT];

// based on Adafruit ST7735 library for Arduino
static uint8_t
  init_cmds1[] = {            // Init for 7735R, part 1 (red or green tab)
    15,                       // 15 commands in list:
    ST7735_SWRESET,   DELAY,  //  1: Software reset, 0 args, w/delay
      150,                    //     150 ms delay
    ST7735_SLPOUT ,   DELAY,  //  2: Out of sleep mode, 0 args, w/delay
      255,                    //     500 ms delay
    ST7735_FRMCTR1, 3      ,  //  3: Frame rate ctrl - normal mode, 3 args:
      0x01, 0x2C, 0x2D,       //     Rate = fosc/(1x2+40) * (LINE+2C+2D)
    ST7735_FRMCTR2, 3      ,  //  4: Frame rate control - idle mode, 3 args:
      0x01, 0x2C, 0x2D,       //     Rate = fosc/(1x2+40) * (LINE+2C+2D)
    ST7735_FRMCTR3, 6      ,  //  5: Frame rate ctrl - partial mode, 6 args:
      0x01, 0x2C, 0x2D,       //     Dot inversion mode
      0x01, 0x2C, 0x2D,       //     Line inversion mode
    ST7735_INVCTR , 1      ,  //  6: Display inversion ctrl, 1 arg, no delay:
      0x07,                   //     No inversion
    ST7735_PWCTR1 , 3      ,  //  7: Power control, 3 args, no delay:
      0xA2,
      0x02,                   //     -4.6V
      0x84,                   //     AUTO mode
    ST7735_PWCTR2 , 1      ,  //  8: Power control, 1 arg, no delay:
      0xC5,                   //     VGH25 = 2.4C VGSEL = -10 VGH = 3 * AVDD
    ST7735_PWCTR3 , 2      ,  //  9: Power control, 2 args, no delay:
      0x0A,                   //     Opamp current small
      0x00,                   //     Boost frequency
    ST7735_PWCTR4 , 2      ,  // 10: Power control, 2 args, no delay:
      0x8A,                   //     BCLK/2, Opamp current small & Medium low
      0x2A,  
    ST7735_PWCTR5 , 2      ,  // 11: Power control, 2 args, no delay:
      0x8A, 0xEE,
    ST7735_VMCTR1 , 1      ,  // 12: Power control, 1 arg, no delay:
      0x0E,
    ST7735_INVOFF , 0      ,  // 13: Don't invert display, no args, no delay
    ST7735_MADCTL , 1      ,  // 14: Memory access control (directions), 1 arg:
      ST7735_ROTATION,        //     row addr/col addr, bottom to top refresh
    ST7735_COLMOD , 1      ,  // 15: set color mode, 1 arg, no delay:
      0x05 },                 //     16-bit color

#if (defined(ST7735_IS_128X128) || defined(ST7735_IS_160X128))
  init_cmds2[] = {            // Init for 7735R, part 2 (1.44" display)
    2,                        //  2 commands in list:
    ST7735_CASET  , 4      ,  //  1: Column addr set, 4 args, no delay:
      0x00, 0x00,             //     XSTART = 0
      0x00, 0x7F,             //     XEND = 127
    ST7735_RASET  , 4      ,  //  2: Row addr set, 4 args, no delay:
      0x00, 0x00,             //     XSTART = 0
      0x00, 0x7F },           //     XEND = 127
#endif // ST7735_IS_128X128

#ifdef ST7735_IS_160X80
  init_cmds2[] = {            // Init for 7735S, part 2 (160x80 display)
    3,                        //  3 commands in list:
    ST7735_CASET  , 4      ,  //  1: Column addr set, 4 args, no delay:
      0x00, 0x00,             //     XSTART = 0
      0x00, 0x4F,             //     XEND = 79
    ST7735_RASET  , 4      ,  //  2: Row addr set, 4 args, no delay:
      0x00, 0x00,             //     XSTART = 0
      0x00, 0x9F ,            //     XEND = 159
    ST7735_INVON, 0 },        //  3: Invert colors
#endif

  init_cmds3[] = {            // Init for 7735R, part 3 (red or green tab)
    4,                        //  4 commands in list:
    ST7735_GMCTRP1, 16      , //  1: Magical unicorn dust, 16 args, no delay:
      0x02, 0x1c, 0x07, 0x12,
      0x37, 0x32, 0x29, 0x2d,
      0x29, 0x25, 0x2B, 0x39,
      0x00, 0x01, 0x03, 0x10,
    ST7735_GMCTRN1, 16      , //  2: Sparkles and rainbows, 16 args, no delay:
      0x03, 0x1d, 0x07, 0x06,
      0x2E, 0x2C, 0x29, 0x2D,
      0x2E, 0x2E, 0x37, 0x3F,
      0x00, 0x00, 0x02, 0x10,
    ST7735_NORON  ,    DELAY, //  3: Normal display on, no args, w/delay
      10,                     //     10 ms delay
    ST7735_DISPON ,    DELAY, //  4: Main screen turn on, no args w/delay
      100 };                  //     100 ms delay

static void ST7735_Select() {
	HAL_GPIO_WritePin(ST7735_CS_GPIO_Port, ST7735_CS_Pin, GPIO_PIN_RESET);
}

void ST7735_Unselect() {
	HAL_GPIO_WritePin(ST7735_CS_GPIO_Port, ST7735_CS_Pin, GPIO_PIN_SET);
}

static void ST7735_Reset() {

}

static void ST7735_WriteCommand(uint8_t cmd) {
	HAL_GPIO_WritePin(ST7735_DC_GPIO_Port, ST7735_DC_Pin, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&ST7735_SPI_HANDLE, &cmd, sizeof(cmd), 0xFF);
}

static void ST7735_WriteData(uint8_t* buff, size_t buff_size) {
	HAL_GPIO_WritePin(ST7735_DC_GPIO_Port, ST7735_DC_Pin, GPIO_PIN_SET);
	while (buff_size--) {
		HAL_SPI_Transmit(&ST7735_SPI_HANDLE, buff++, 1, 0xFF);
	}
}

static void ST7735_ExecuteCommandList(const uint8_t *addr) {
    uint8_t numCommands, numArgs;
    uint16_t ms;

    numCommands = *addr;
    addr += 1;
    while(numCommands--) {
        uint8_t cmd = *addr;
        addr += 1;
        ST7735_WriteCommand(cmd);

        numArgs = *addr;
        addr += 1;
        // If high bit set, delay follows args
        ms = numArgs & DELAY;
        numArgs &= ~DELAY;
        if(numArgs) {
            ST7735_WriteData((uint8_t*)addr, numArgs);
            addr += (numArgs*1);
        }

        if(ms) {
            ms = *addr;
            addr += 1;
            if(ms == 255) ms = 500;
            HAL_Delay(ms);
        }
    }
}

static void ST7735_SetAddressWindow(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) {
    // column address set
    ST7735_WriteCommand(ST7735_CASET);
    uint8_t data[] = { 0x00, x0 + ST7735_XSTART, 0x00, x1 + ST7735_XSTART };
    ST7735_WriteData(data, sizeof(data));

    // row address set
    ST7735_WriteCommand(ST7735_RASET);
    data[1] = y0 + ST7735_YSTART;
    data[3] = y1 + ST7735_YSTART;
    ST7735_WriteData(data, sizeof(data));

    // write to RAM
    ST7735_WriteCommand(ST7735_RAMWR);
}

void ST7735_Init() {

	ST7735_Select();
	ST7735_Reset();
	ST7735_ExecuteCommandList(init_cmds1);
	ST7735_ExecuteCommandList(init_cmds2);
	ST7735_ExecuteCommandList(init_cmds3);
	ST7735_Unselect();
}

void ST7735_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    if((x >= ST7735_WIDTH) || (y >= ST7735_HEIGHT))
        return;

    ST7735_Select();

    ST7735_SetAddressWindow(x, y, x+1, y+1);
    uint8_t data[] = { color >> 8, color & 0xFF };
    ST7735_WriteData(data, sizeof(data));

    ST7735_Unselect();
}



static void ST7735_WriteChar(uint16_t x, uint16_t y, char ch, FontDef* font, uint16_t fg, uint16_t bg) {
	uint32_t i, j, length, baseIndex;
	uint8_t dat, bytesPerLine;
	uint8_t pixelOn[] = { fg >> 8, fg & 0xFF };
	uint8_t pixelOff[] = { bg >> 8, bg & 0xFF };

	bytesPerLine = (font->width + 7) / 8;
	ST7735_SetAddressWindow(x, y, x + font->width - 1, y + font->height - 1);

	baseIndex = (ch - 32) * font->height * bytesPerLine;
	// printf("baseIndex = %d \r\n", baseIndex);
	length = font->height * bytesPerLine;

	int16_t lineWidth = font->width;
	// printf("length = %d \r\n", unsend);
	for (i = 0; i < length; i++) {
		dat = font->data[baseIndex + i];
		for (j = 0; j < (lineWidth > 8 ? 8: lineWidth); j++) {
			if ((dat << j) & 0x80) {
				ST7735_WriteData(pixelOn, sizeof(pixelOn));
			} else {
				ST7735_WriteData(pixelOff, sizeof(pixelOff));
			}
		}
		lineWidth -= 8;
		if(lineWidth <= 0){
			lineWidth = font->width;
		}
	}
}

/*
Simpler (and probably slower) implementation:

static void ST7735_WriteChar(uint16_t x, uint16_t y, char ch, FontDef font, uint16_t color) {
    uint32_t i, b, j;

    for(i = 0; i < font->height; i++) {
        b = font->data[(ch - 32) * font->height + i];
        for(j = 0; j < font->width; j++) {
            if((b << j) & 0x8000)  {
                ST7735_DrawPixel(x + j, y + i, color);
            } 
        }
    }
}
*/
static void drawFastPixel(uint16_t x, uint16_t y, uint8_t *data) {
	if ((x >= ST7735_WIDTH) || (y >= ST7735_HEIGHT)) {
		return;
	}
	ST7735_SetAddressWindow(x, y, x + 1, y + 1);
	ST7735_WriteData(data, 2);
}

static void drawFastVLine(uint16_t x, uint16_t y0, uint16_t height, uint8_t *data) {
	ST7735_SetAddressWindow(x, y0, x, y0 + height);
	uint16_t i;
	for (i = 0; i < height; i++) {
		ST7735_WriteData(data, 2);
	}
}

static void drawFastHLine(uint16_t x, uint16_t y, uint16_t width, uint8_t *data) {
	ST7735_SetAddressWindow(x, y, x + width, y);
	uint16_t i;
	for (i = 0; i < width; i++) {
		ST7735_WriteData(data, 2);
	}
}

static void writeFastLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t *data) {
	int16_t steep = ((y1 - y0) > 0 ? (y1 - y0) : (y0 - y1)) > (x1 - x0 > 0 ? x1 - x0 : x0 - x1);
	if (steep) {
		swap_uint16_t(x0, y0);
		swap_uint16_t(x1, y1);
	}

	if (x0 > x1) {
		swap_uint16_t(x0, x1);
		swap_uint16_t(y0, y1);
	}

	int16_t dx, dy;
	dx = x1 - x0;
	dy = y1 - y0 > 0 ? y1 - y0 : y0 - y1;

	int16_t err = dx / 2;
	int16_t ystep;

	if (y0 < y1) {
		ystep = 1;
	} else {
		ystep = -1;
	}

	for (; x0 <= x1; x0++) {
		if (steep) {
			drawFastPixel(y0, x0, data);
		} else {
			drawFastPixel(x0, y0, data);
		}
		err -= dy;
		if (err < 0) {
			y0 += ystep;
			err += dx;
		}
	}
}

void ST7735_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color){
	uint8_t data[] = { color >> 8, color & 0xFF };
	ST7735_Select();
	if(x0 == x1){
		if(y0 > y1){
			swap_uint16_t(y0, y1);
		}
		drawFastVLine(x0, y0, y1 - y0 + 1, data);
	}
	else if(y0 == y1){
		if(x0 > x1){
			swap_uint16_t(x0, x1);
		}
		drawFastHLine(x0, y0, x1 - x0 + 1, data);
	}
	else{
		writeFastLine(x0, y0, x1, y1, data);
	}
	ST7735_Unselect();
}

void ST7735_DrawCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
	int16_t f = 1 - r;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * r;
	int16_t x = 0;
	int16_t y = r;
	uint8_t data[] = { color >> 8, color & 0xFF };

	ST7735_Select();

	drawFastPixel(x0  , y0+r, data);
	drawFastPixel(x0  , y0-r, data);
	drawFastPixel(x0+r, y0  , data);
	drawFastPixel(x0-r, y0  , data);

	while (x < y) {
		if (f >= 0) {
			y--;
			ddF_y += 2;
			f += ddF_y;
		}
		x++;
		ddF_x += 2;
		f += ddF_x;

		drawFastPixel(x0 + x, y0 + y, data);
		drawFastPixel(x0 - x, y0 + y, data);
		drawFastPixel(x0 + x, y0 - y, data);
		drawFastPixel(x0 - x, y0 - y, data);
		drawFastPixel(x0 + y, y0 + x, data);
		drawFastPixel(x0 - y, y0 + x, data);
		drawFastPixel(x0 + y, y0 - x, data);
		drawFastPixel(x0 - y, y0 - x, data);
	}
	ST7735_Unselect();
}

static void fillCircleHelper(int16_t x0, int16_t y0, int16_t r,
  uint8_t corners, int16_t delta, uint8_t *color) {

    int16_t f     = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x     = 0;
    int16_t y     = r;
    int16_t px    = x;
    int16_t py    = y;

    delta++; // Avoid some +1's in the loop

    while(x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f     += ddF_y;
        }
        x++;
        ddF_x += 2;
        f     += ddF_x;
        // These checks avoid double-drawing certain lines, important
        // for the SSD1306 library which has an INVERT drawing mode.
        if(x < (y + 1)) {
            if(corners & 1) drawFastVLine(x0+x, y0-y, 2*y+delta, color);
            if(corners & 2) drawFastVLine(x0-x, y0-y, 2*y+delta, color);
        }
        if(y != py) {
            if(corners & 1) drawFastVLine(x0+py, y0-px, 2*px+delta, color);
            if(corners & 2) drawFastVLine(x0-py, y0-px, 2*px+delta, color);
            py = y;
        }
        px = x;
    }
}

void ST7735_FillCircle(uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
	uint8_t data[] = { color >> 8, color & 0xFF };
	ST7735_Select();
	drawFastVLine(x0, y0 - r, 2 * r + 1, data);
	fillCircleHelper(x0, y0, r, 3, 0, data);
	ST7735_Unselect();
}

void ST7735_DrawTriangle(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1,uint16_t x2, uint16_t y2, uint16_t color){
	uint8_t data[] = { color >> 8, color & 0xFF };
	ST7735_Select();
	writeFastLine(x0, y0, x1, y1, data);
	writeFastLine(x1, y1, x2, y2, data);
	writeFastLine(x2, y2, x0, y0, data);
	ST7735_Unselect();
}

void ST7735_FillTriangle(uint16_t x0, uint16_t y0,
        uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color) {

    int16_t a, b, y, last;
    uint8_t data[] = { color >> 8, color & 0xFF };

    ST7735_Select();
    // Sort coordinates by Y order (y2 >= y1 >= y0)
    if (y0 > y1) {
    	swap_uint16_t(y0, y1); swap_uint16_t(x0, x1);
    }
    if (y1 > y2) {
    	swap_uint16_t(y2, y1); swap_uint16_t(x2, x1);
    }
    if (y0 > y1) {
    	swap_uint16_t(y0, y1); swap_uint16_t(x0, x1);
    }

    if(y0 == y2) { // Handle awkward all-on-same-line case as its own thing
        a = b = x0;
        if(x1 < a)      a = x1;
        else if(x1 > b) b = x1;
        if(x2 < a)      a = x2;
        else if(x2 > b) b = x2;
        drawFastHLine(a, y0, b-a+1, data);
        return;
    }

    int16_t
    dx01 = x1 - x0,
    dy01 = y1 - y0,
    dx02 = x2 - x0,
    dy02 = y2 - y0,
    dx12 = x2 - x1,
    dy12 = y2 - y1;
    int32_t
    sa   = 0,
    sb   = 0;

    // For upper part of triangle, find scanline crossings for segments
    // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
    // is included here (and second loop will be skipped, avoiding a /0
    // error there), otherwise scanline y1 is skipped here and handled
    // in the second loop...which also avoids a /0 error here if y0=y1
    // (flat-topped triangle).
    if(y1 == y2) last = y1;   // Include y1 scanline
    else         last = y1-1; // Skip it

    for(y=y0; y<=last; y++) {
        a   = x0 + sa / dy01;
        b   = x0 + sb / dy02;
        sa += dx01;
        sb += dx02;
        /* longhand:
        a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if(a > b) swap_int16_t(a,b);
        drawFastHLine(a, y, b-a+1, data);
    }

    // For lower part of triangle, find scanline crossings for segments
    // 0-2 and 1-2.  This loop is skipped if y1=y2.
    sa = (int32_t)dx12 * (y - y1);
    sb = (int32_t)dx02 * (y - y0);
    for(; y<=y2; y++) {
        a   = x1 + sa / dy12;
        b   = x0 + sb / dy02;
        sa += dx12;
        sb += dx02;
        /* longhand:
        a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if(a > b) swap_int16_t(a,b);
        drawFastHLine(a, y, b-a+1, data);
    }
    ST7735_Unselect();
}

void ST7735_WriteString(uint16_t x, uint16_t y, const char* str, FontDef* font, uint16_t color, uint16_t bgcolor) {
    ST7735_Select();

    while(*str) {
        if(x + font->width >= ST7735_WIDTH) {
            x = 0;
            y += font->height;
            if(y + font->height >= ST7735_HEIGHT) {
                break;
            }

            if(*str == ' ') {
                // skip spaces in the beginning of the new line
                str++;
                continue;
            }
        }

        ST7735_WriteChar(x, y, *str, font, color, bgcolor);
        x += font->width;
        str++;
    }

    ST7735_Unselect();
}

void ST7735_FillRectangle(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    // clipping
    if((x >= ST7735_WIDTH) || (y >= ST7735_HEIGHT)) return;
    if((x + w - 1) >= ST7735_WIDTH) w = ST7735_WIDTH - x;
    if((y + h - 1) >= ST7735_HEIGHT) h = ST7735_HEIGHT - y;

    ST7735_Select();
    ST7735_SetAddressWindow(x, y, x+w-1, y+h-1);

    uint8_t data[] = { color >> 8, color & 0xFF };
    for(int i = 0; i < w; i++){
    	lcdBuffer[i] = *((uint16_t*)(data));
    }

    HAL_GPIO_WritePin(ST7735_DC_GPIO_Port, ST7735_DC_Pin, GPIO_PIN_SET);
    for(y = h; y > 0; y--) {
		 HAL_SPI_Transmit(&ST7735_SPI_HANDLE, (uint8_t*)lcdBuffer, w*2, 0xFF);
    }

    ST7735_Unselect();
}

void ST7735_FillScreen(uint16_t color) {
    ST7735_FillRectangle(0, 0, ST7735_WIDTH, ST7735_HEIGHT, color);
}

void ST7735_DrawImage(uint8_t x, uint8_t y, uint8_t w, uint8_t h, const uint8_t* data) {
    if((x >= ST7735_WIDTH) || (y >= ST7735_HEIGHT)) return;
    if((x + w - 1) >= ST7735_WIDTH) return;
    if((y + h - 1) >= ST7735_HEIGHT) return;

    ST7735_Select();
    ST7735_SetAddressWindow(x, y, x+w-1, y+h-1);
    ST7735_WriteData((uint8_t *)data, sizeof(uint8_t)*w*h*2);
    ST7735_Unselect();
}

void ST7735_InvertColors(bool invert) {
    ST7735_Select();
    ST7735_WriteCommand(invert ? ST7735_INVON : ST7735_INVOFF);
    ST7735_Unselect();
}


