# AirISP
An ISP tool for AirMCU

Compatible with Arduino IDE 2.x and VScode Arduino plugin known. 

Some of errors have their exitcode. You can see the table in exitcode.txt. 

## Arch Linux and its derivatives can install [AUR airisp-git](https://aur.archlinux.org/packages/airisp-git)

**Note: Command line names should be lowercase according to the Arch Linux specification, after installation the command line will be: `airisp`**.

```bash
yay -Syu airisp
```
