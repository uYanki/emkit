# Note

## Support Chip List

- RP2040/RP2350