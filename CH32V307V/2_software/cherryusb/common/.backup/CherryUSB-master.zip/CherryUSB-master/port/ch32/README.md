# Note

## Support Chip List

- CH32V30x
