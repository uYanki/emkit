基于 ESP-Registry 开发指南
===========================

ESP-Registry 可以参考官方文档，推荐使用 vscode + esp-idf 的开发环境。

- ctrl + shift + p 选择 ESP-IDF 欢迎界面，然后选择 Component mananger

.. figure:: img/esp1.png

- 找到 cherryusb 并安装

.. figure:: img/esp2.png

- 打开 menuconfig，并打开 cherryusb 的配置，根据实际情况选择主机或者从机模式

.. figure:: img/esp3.png
.. figure:: img/esp4.png