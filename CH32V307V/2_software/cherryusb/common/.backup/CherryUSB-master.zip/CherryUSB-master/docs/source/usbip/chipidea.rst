CHIPIDEA
=================