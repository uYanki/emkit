#ifndef LWIP_ARCH_PERF_H
#define LWIP_ARCH_PERF_H

#define PERF_START    /* null definition */
#define PERF_STOP(x)  /* null definition */


#endif /* LWIP_ARCH_PERF_H */
