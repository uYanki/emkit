#!/bin/sh
ProjName="W806"

cp ./Obj/"$ProjName".elf ./"$ProjName".elf
mv ./Lst/"$ProjName".map ./"$ProjName".map