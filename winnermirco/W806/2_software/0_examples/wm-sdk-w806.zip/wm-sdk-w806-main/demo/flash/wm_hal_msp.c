#include "wm_hal.h"

void HAL_MspInit(void)
{

}

