#ifndef __MAIN_H
#define	__MAIN_H

#include "HAL_conf.h"
#include "sys.h"
#include "UART.h"
#include "LCD.h"
#include "stdio.h"
#endif


