#ifndef __MAIN_H
#define	__MAIN_H

#include "HAL_conf.h"
#include "led.h"
#include "sys.h"
#include "spi.h"
#include "TK499_Timer.h"
#include "UART.h"

#endif


