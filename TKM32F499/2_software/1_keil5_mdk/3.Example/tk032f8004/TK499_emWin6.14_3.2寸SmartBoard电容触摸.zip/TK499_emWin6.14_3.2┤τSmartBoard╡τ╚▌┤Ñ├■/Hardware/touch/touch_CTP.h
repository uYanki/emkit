//#ifdef  use_capacitive_touch_panel

#ifndef  __TOUCH_CTP_H__
#define  __TOUCH_CTP_H__

#include "GUICONF.H"
#include "gui.h"
#include "sys.h"
#include "tk499.h"
#include "HAL_conf.h"
#include "TK499_I2C.h"

#define FT6206_ADDR		0x70		//��ַΪ0x38Ҫ��һλ 
void I2CInitMasterMode(I2C_TypeDef *I2Cx);
int GUI_TOUCH_X_MeasureX(void); 
int GUI_TOUCH_X_MeasureY(void);

void TP_GetAdXY(unsigned int *x,unsigned int *y);
void Touch_CTP_Test(void);



#endif                                     
//#endif
