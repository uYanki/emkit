
#include  "touch_CTP.h"

#if USE_CTP | New_CTP
void GUI_TOUCH_X_ActivateX(void) {}
void GUI_TOUCH_X_ActivateY(void) {}

/********************************************************************************************************
**������Ϣ ��I2CInitMasterMode(I2C_TypeDef *I2Cx,unsigned long apb_mhz,unsigned long i2c_baud_rate) //unit is Khz                    
**�������� ����ʼ��I2C
**������� ��I2C_TypeDef *I2Cx��ѡ��I2C1,I2C2
**������� ����
********************************************************************************************************/
void I2CInitMasterMode(I2C_TypeDef *I2Cx) 
{
	I2C_InitTypeDef I2C_InitStructure;
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);  //i2c1 clk enable
		
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	
	GPIO_PinAFConfig(GPIOB, GPIO_Pin_0 | GPIO_Pin_2, GPIO_AF_I2C); //PB0��PB2����ΪIIC
	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0 | GPIO_Pin_2 ;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD; // ���ÿ�©���
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//========== PB1 ��ʼ��Ϊ��������
	GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//========== PB1 ��ʼ��Ϊ������� CTP  RESET
	GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB, GPIO_Pin_3);
	
  I2C_InitStructure.I2C_Mode = I2C_Mode_MASTER;//��ģʽ
  I2C_InitStructure.I2C_OwnAddress = FT6206_ADDR;
  I2C_InitStructure.I2C_Speed = I2C_Speed_STANDARD;
  I2C_InitStructure.I2C_ClockSpeed = 400000;   //�ٶ�����Ϊ400K
	I2C_Init(I2C1, &I2C_InitStructure);
	
	I2C_Send7bitAddress(I2C1, FT6206_ADDR, 0);
	I2C_Cmd(I2C1, ENABLE);
}

/****************************************************************************************
																	������ FT6336оƬ����

***************************************************************************************/
volatile static u16 touchX=0,touchY=0;
int GUI_TOUCH_X_MeasureX(void)
{
	char i,j;
	u8 buf[32];
//	I2C1->IC_DATA_CMD =FT6206_ADDR | 0x200;//д��ӻ���ַ��������ʼ�ź�
	I2CTXByte(I2C1,CMD_WRITE,0x01);

	*(buf)=I2CRXByte(I2C1);//�⺯������ȡIIC����
	*(buf+1)=I2CRXByte(I2C1);//�⺯������ȡIIC����
	if ((buf[1]&0x0f))
	{
		for(i=2;i<6;i++) 
			{
				*(buf+i)=I2CRXByte(I2C1);//�⺯������ȡIIC����
			}
		
		touchY = (buf[4] & 0x0F)<<8 | buf[5];//x����
		touchX = (buf[2] & 0x0F)<<8 | buf[3];//y����

		return touchX;
	}
	else
	{
		touchX = 8000;
		touchY = 8000;
		return touchX;
	}
}

int GUI_TOUCH_X_MeasureY(void)
{
	return touchY;
}

void Touch_Test(void)
{
  int16_t x1,y1;

	GUI_SetColor(GUI_BLUE);
	GUI_SetFont(&GUI_Font32B_1);
  GUI_DispStringAt("x =",60,0);
	GUI_DispStringAt("y =",160,0);
	while(1)
	{

	GUI_TOUCH_X_MeasureX();

	    if(touchX<=800)
			{
				GUI_DispDecAt(touchX, 100, 100, 3);
				GUI_DispDecAt(touchY, 200, 100, 3);
			}		


	}
}
		//=================touch Test=================//
void Touch_CTP_Test(void)
{
	volatile int i,X,Y;
	GUI_SetFont(&GUI_Font32_ASCII);//��������
	GUI_SetBkColor(GUI_LIGHTBLUE);//���ñ���ɫΪ����ɫ
	GUI_SetColor(GUI_BLUE);//����ǰ��ɫΪ��ɫ
	GUI_DispStringHCenterAt("press APP Button to skip",240,0);
	while(1)
		{
			X=GUI_TOUCH_X_MeasureX();
			Y=GUI_TOUCH_X_MeasureY();
//			GUI_DispDecAt( GUI_TOUCH_X_MeasureX() ,120,210,4);
//			GUI_DispDecAt( GUI_TOUCH_X_MeasureY() ,230,210,4);
			GUI_DrawRect(X, Y, X+2, Y+2);
			i=10000;while(--i);
			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==1)break;
		}

}

#endif
