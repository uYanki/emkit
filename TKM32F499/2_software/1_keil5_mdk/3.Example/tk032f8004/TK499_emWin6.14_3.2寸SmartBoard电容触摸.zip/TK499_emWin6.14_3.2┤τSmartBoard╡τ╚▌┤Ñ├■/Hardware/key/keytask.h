#ifndef _KEY_TASK_H_
#define _KEY_TASK_H_

#include "main.h"
#include "menutask.h"
extern volatile u8  keyResult;   //���ذ���״̬

#define KEYU  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3)
#define KEYD  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_1)
#define KEYL  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_5)
#define KEYR  GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_6)
#define KEYC  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)

#define KEYU_PORT      			GPIOE
#define KEYU_PIN       			GPIO_Pin_3
#define KEYU_PIN_SOURCE   	GPIO_PinSource3
#define EXTI_LINE_KEYU     	 EXTI_Line3

#define KEYD_PORT      			GPIOE
#define KEYD_PIN       			GPIO_Pin_1
#define KEYD_PIN_SOURCE   	GPIO_PinSource1
#define EXTI_LINE_KEYD      	EXTI_Line1

#define KEYL_PORT      			GPIOE
#define KEYL_PIN       			GPIO_Pin_5
#define KEYL_PIN_SOURCE   	GPIO_PinSource5
#define EXTI_LINE_KEYL      	EXTI_Line5

#define KEYR_PORT      			GPIOE
#define KEYR_PIN       			GPIO_Pin_6
#define KEYR_PIN_SOURCE   	GPIO_PinSource6
#define EXTI_LINE_KEYR      	EXTI_Line6

#define KEYC_PORT      			 GPIOA
#define KEYC_PIN       			 GPIO_Pin_0
#define KEYC_PIN_SOURCE    GPIO_PinSource0
#define EXTI_LINE_KEYC     	 EXTI_Line0

//����״̬
#define KEY_DOWN  0XA0   //����
#define KEY_LONG  0xB0   //����
#define KEY_LIAN  0XC0   //����
#define KEY_UP    0XD0   //�ͷŰ���

#define KEY_SERIES_FLAG   100   //��������ʱ��
#define KEY_SERIES_DELAY  2     //�̰�����ʱ��

//================================================================
typedef enum { 
  UP_KEY_LONGE_PRESS            = (u8)0,    
  UP_KEY_SHORT_PRESS            = (u8)1,   
	
  DOWN_KEY_SHORT_PRESS          = (u8)2,    
  DOWN_KEY_LONGE_PRESS          = (u8)3,   
	
  LEFT_KEY_SHORT_PRESS          = (u8)4,   
  LEFT_KEY_LONGE_PRESS          = (u8)5,   
	
  RIGHT_KEY_SHORT_PRESS         = (u8)6,   
  RIGHT_KEY_LONGE_PRESS         = (u8)7,    
	
  CENTER_KEY_SHORT_PRESS        = (u8)8,  
  CENTER_KEY_LONGE_PRESS        = (u8)9,   
	
  NO_PRESS                   		= (u8)127
}keyPreType;

extern void Init_KEY_GPIO(void);
extern u8 Key_Identify(u8 keyData);

#endif
