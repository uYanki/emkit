#ifndef _FONT_H_
#define _FONT_H_

#include "TK499.h"
#include "main.h"
extern GUI_FONT st16Font;
extern GUI_FONT xkf24Font;
extern GUI_FONT xkj32Font;
extern GUI_FONT smgFont24;
extern GUI_FONT smgFont36;
extern GUI_FONT smgFont48;
extern GUI_FONT smgFont64;
	
void init_all_Font_addr(void);
void Create_st16_Font(void);
void CreateXBF_FontXKF24(void);
void CreateXBF_FontXKJ32(void);
void XBF_Disp(void);//����16*16
void XKF24_Disp(void);//�����п���
void XKJ32_Disp(void);//������п�32
void XKF_NumAllDisp(void);
void innner_HZ(void);
#endif

