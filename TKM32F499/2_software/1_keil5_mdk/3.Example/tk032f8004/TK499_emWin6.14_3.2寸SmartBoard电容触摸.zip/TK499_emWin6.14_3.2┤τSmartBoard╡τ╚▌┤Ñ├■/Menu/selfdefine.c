#include "MenuTask.h"
#include "DIALOG.h"
#include "WM.h"
#include "BUTTON.h"
#include "FRAMEWIN.h"
//#include "GPS_tiky.h"
/*******************************************************************************
* Function Name  : _cbWinNull
* Description		 : ����ص�����  ģ��
* Input       	: 
* Return        : None
*******************************************************************************/
#if 0
static void _cbWinNull(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
      
      break;
    
    case WM_PAINT:
      
      break;
    
    default:
      WM_DefaultProc(pMsg);
  }
}
#endif


/*******************************************************************************
* Function Name  : _cbSelf1
* Description		 : �Զ������1 
* Input       	:  �Զ��尴������Ļص�����,�����һ�л�ͼ�������ڱ��������
* Return        : None
*******************************************************************************/
void _cbSelf1(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	WM_HWIN hButton;

//	int BUTTON_SKINFLEX_FOCUSSED;
//	BUTTON_SKINFLEX_PROPS Props;
///***************************����Ƥ��*****************************/
//   BUTTON_GetSkinFlexProps(&Props,BUTTON_SKINFLEX_FOCUSSED);
//   Props.aColorFrame[0]=GUI_BLACK;
//   Props.aColorFrame[1]=GUI_BLACK;
//   Props.Radius=6;
//   BUTTON_SetSkinFlexProps(&Props, BUTTON_SKINFLEX_FOCUSSED);
//	 WM_InvalidateWindow(hWin);	

	
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:    //�������ڳ�ʼ��
		  WM_SetFocus(hWin);  
			BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END); //����һ�����صİ�����Ϊ���ܽ���main����ʵ�尴�����ź���      
      
#if GUI_SUPPORT_TOUCH
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX);
			BUTTON_SetDefaultFont(&GUI_Font16_ASCII);
			hButton = BUTTON_CreateEx(500, 400 ,50, 30, hWin, WM_CF_SHOW, 0, GUI_KEY_UP);
			BUTTON_SetText(hButton,"Back");
#endif	
			
			break;
    case WM_PAINT:
//			GPS_inf();
//			GPS_RX();
//			GUI_SetBkColor(COLOR(0,76,152)); 			//��䱳��ɫ
//			GUI_Clear();      
      break;

#if GUI_SUPPORT_TOUCH		
		case WM_NOTIFY_PARENT:
		{
			int id = WM_GetId(pMsg->hWinSrc);
		
				if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
					{				
						switch(id)
						{
							case GUI_KEY_UP:					
								_DeleteFrame();  									//ɾ����ǰ����
								_CreateFrame(_cbKey,MENU_KEY); 		//�½�����
							break;
								
							default:
								WM_DefaultProc(pMsg);
								break;				
						}
					}
			}
#endif
		case WM_KEY:  													//����main���� ��������ź���	
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:  									//ʵ�尴����Ϣ�ź�
					_DeleteFrame();  									//ɾ����ǰ����
					_CreateFrame(_cbKey,MENU_KEY); 		//�½�����
					break;
			}	
			break;	
			
    default:
      WM_DefaultProc(pMsg);
  }
}

/*******************************************************************************
* Function Name  : _cbSelf2
* Description		 : �Զ������1
* Input       	: 
* Return        : None
*******************************************************************************/
void _cbSelf2(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
		  WM_SetFocus(hWin);  
			BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END);      
      break;
    
    case WM_PAINT:
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();      
      break;

		case WM_KEY:  //����main���� ��������ź���	
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:     //ʵ�尴����Ϣ�ź�
					_DeleteFrame();						
					_CreateFrame(_cbKey,MENU_KEY);
					break;
			}	
			break;	
			
    default:
      WM_DefaultProc(pMsg);
  }
}


/*******************************************************************************
* Function Name  : _cbSelf3
* Description		 : �Զ������1
* Input       	: 
* Return        : None
*******************************************************************************/
void _cbSelf3(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
		  WM_SetFocus(hWin);  
			BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END);      
      break;
    
    case WM_PAINT:
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();      
      break;

		case WM_KEY:  //����main���� ��������ź���	
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:
				_DeleteFrame();						
				_CreateFrame(_cbKey,MENU_KEY);
        break;				
			}	
			break;	
			
    default:
      WM_DefaultProc(pMsg);
  }
}




