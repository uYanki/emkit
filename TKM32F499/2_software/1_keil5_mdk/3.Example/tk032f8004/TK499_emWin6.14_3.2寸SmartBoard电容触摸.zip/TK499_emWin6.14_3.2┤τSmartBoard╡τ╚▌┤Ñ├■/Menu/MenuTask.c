#include "DIALOG.h"
#include "WM.h"
#include "BUTTON.h"
#include "FRAMEWIN.h"
#include "string.h"
#include "ff.h"
#include "tk499.h"
#include "main.h"
#include <string.h>
#include "menutask.h"
#include "selfdefine.h"
#include "keytask.h"

void _cbMain(WM_MESSAGE *pMsg);
static void _cbTickerWM(WM_MESSAGE * pMsg);
static void _cbTF(WM_MESSAGE *pMsg);

extern GUI_CONST_STORAGE GUI_BITMAP bmi1;
extern GUI_CONST_STORAGE GUI_BITMAP bmi2;
extern GUI_CONST_STORAGE GUI_BITMAP bmi3;
extern GUI_CONST_STORAGE GUI_BITMAP bmi4;
extern GUI_CONST_STORAGE GUI_BITMAP bmi5;
extern GUI_CONST_STORAGE GUI_BITMAP bmi6;
extern GUI_CONST_STORAGE GUI_BITMAP bmi7;
extern GUI_CONST_STORAGE GUI_BITMAP bmi8;
extern GUI_CONST_STORAGE GUI_BITMAP bmweb;


#define BITMAP

#define GUI_BK_CLOR     GUI_GREEN



volatile WM_HWIN  _hLastFrame;
volatile u8 keyPress;

DevCtr dev;



const GUI_POINT bPoint[]={
	{0,0},
	{8,-8},
	{11,-5},
  {6,0},
	{11,5},
	{8,8},
};

const GUI_POINT lPoints[]={
	{0,0},
	{0,20},
	{-10,10},
};

const GUI_POINT rPoints[]={
	{0,0},
	{0,20},
	{10,10},
};

const GUI_POINT ctrLPoints[]={
	{0,0},
	{0,30},
	{-15,15},
};

const GUI_POINT ctrRPoints[]={
	{0,0},
	{0,30},
	{15,15},
};

const GUI_POINT r[]={
	{0,0},
	{9,0},
	{9,-7},
  {21,5},
	{9,17},
	{9,9},
	{0,9},
};




/*触屏区域坐标 X0，Y0，X1，Y1*/
const u16 MainArea[][5]={
{46,90,158,170,TOUCH_PIC_ID}, 
{184,90,296,170,TOUCH_RGB_ID},
{322,90,433,170,TOUCH_KEY_ID}, 

{46,215,158,298,TOUCH_GUI_ID},
{184,215,296,298,TOUCH_CLOCK_ID}, 
{322,215,433,298,TOUCH_WEB_ID}, 
};

const u16 KeyArea[][5]={
	{322,90,433,170,TOUCH_UP_ID}, 
	{46,215,158,298,TOUCH_DW_ID},
	{184,215,296,298,TOUCH_LE_ID}, 
	{322,215,433,298,TOUCH_RI_ID}, 
};


/*min, max , 最小变化值*/
const u8 DateDatLimit[][3]=
{
{0,99,1},  //year
{1,12,1},  //month
{1,31,1},  //day
{0,23,1},  //hour
{0,59,1},  //minute
{0,59,1},  //second


//继续添加 数据限制....
};

/*******************************************************************************
* Function Name  : ModifyDat
* Description		 : 数据调整函数，根据DateDatLimit数组对数据进行限制修改
* Input       	:  dat->  原始参数
                   addr->  参数类型偏移地址,参照数组 DateDatLimit
									 isAdd-> TRUE: 递增 , FALSE :递减

* Return        :  dat  调整后的参数
*******************************************************************************/
static u16 ModifyDat(u16 dat,u8 addr,bool isAdd)
{
	u16 offset;

	offset = addr;
	
	if(isAdd){
		if(dat < DateDatLimit[offset][1])
			dat = dat + DateDatLimit[offset][2];
		else
			dat = DateDatLimit[offset][0];
	}
	else
	{
		if(dat> DateDatLimit[offset][0])
			dat = dat - DateDatLimit[offset][2];
		else
			dat = DateDatLimit[offset][1];
	}
	return dat;
}

static u8 GetTouchAreaID(GUI_PID_STATE *p)
{
  int xPos = p->x;
  int yPos = p->y;
	u8 i;
	switch(dev.curMenuId)
	{
		case MENU_MAIN:
			for(i=0;i<6;i++){
				if((xPos > MainArea[i][0])&&(xPos < MainArea[i][2])){
					if((yPos > MainArea[i][1])&&(yPos < MainArea[i][3])){
						return MainArea[i][4];
					}			
				}	
			}	
		break;
		
		case MENU_KEY:
			for(i=0;i<4;i++){
				if((xPos > KeyArea[i][0])&&(xPos < KeyArea[i][2])){
					if((yPos > KeyArea[i][1])&&(yPos < KeyArea[i][3])){
						return KeyArea[i][4];
					}			
				}	
			}				
			break;
			
		default:
			break;	
	}
	return TOUCH_NULL_ID;
}


void DrawTempUnit(u32 color,u16 x,u16 y)
{
	GUI_SetFont(&GUI_Font24_1);		
	GUI_SetColor(color);
	GUI_DrawCircle(x+3,y+3,3);
	GUI_DispCharAt('C',x+7,y-3);
}


void _DeleteFrame(void) 
{
	WM_DeleteWindow(_hLastFrame);
	_hLastFrame = 0;
}

WM_HWIN _CreateFrame(WM_CALLBACK* cb,u8 curId) 
{
	dev.curMenuId = curId;
	_hLastFrame = WM_CreateWindowAsChild(0,0, 854, 480, WM_HBKWIN, WM_CF_SHOW, cb, 0);
  return _hLastFrame;
}

static void _PaintFrame(void) 
{
	GUI_RECT r;
	WM_GetClientRect(&r);
	GUI_ClearRectEx(&r);
}

/*******************************************************************************
* Function Name  : _cbWinNull
* Description		 : 
* Input       	: 
* Return        : None
*******************************************************************************/
#if 0
static void _cbWinNull(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
      
      break;
    
    case WM_PAINT:
      
      break;
    
    default:
      WM_DefaultProc(pMsg);
  }
}
#endif


const GUI_ConstString listHead[1] = {0};

void ReadTF2(void)
{
 u16 cnt = 0;
	FRESULT result;
	FATFS fs;
	DIR dirInf;
	FILINFO fileInf;

	dev.tfBmpCnt=0;	
	dev.isTf = true;
	/* 挂载文件系统 */
	result = f_mount (&fs, "0:", 1);//挂载文件系统
	//失败取消挂载
	if (result != FR_OK){
		dev.isTf = false;
		goto MountFalse;
	}

	/* 打开根文件夹 */
	result = f_opendir(&dirInf, "/"); /* 如果不带参数，则从当前目录开始 */
	//失败取消挂载
	if(result != FR_OK){
		dev.isTf = false;
		goto MountFalse;
	}
	

	/* 读取当前文件夹下的文件和目录 */
	for (cnt = 0; ;cnt++)
	{
		result = f_readdir(&dirInf,&fileInf);   /* 读取目录项，索引会自动下移 */
		if (result != FR_OK || fileInf.fname[0] == 0)
		{
			goto MountFalse;
		}

		if (fileInf.fname[0] == '.')
		{
			continue;
		}
		
		if(strstr(fileInf.fname,"BMP")!=NULL)//识别bmp图片文件
		{
			dev.tfBmpCnt++;		
			memcpy(dev.tfBmpName[dev.tfBmpCnt-1],fileInf.fname,sizeof(fileInf.fname));
			if(dev.tfBmpCnt >200)  //图片数量超过缓存数
				goto MountFalse;
		}
	}		
MountFalse:
	/* 卸载文件系统 */
	f_mount (NULL, "0:", 1);//注销文件系统
}


static void _cbPicture(WM_MESSAGE *pMsg)
{
	u8 bmpC;
	WM_HWIN hWin = pMsg->hWin;
	
	bmpC = 0;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
			if(dev.isPPT == true)
				WM_CreateTimer(pMsg->hWin, 0, 500, 0);
      break;
    
    case WM_PAINT:	     
	
      break;
			
		case WM_TOUCH:
		{
			GUI_PID_STATE *pBtn = (GUI_PID_STATE *)pMsg->Data.p;
			if (pBtn->Pressed == 0){   //按键释放
				dev.isPPT = false;
				_DeleteFrame();
				_CreateFrame(_cbTF,MENU_TF);
			}
		}
		break;

	  case WM_TIMER: 
			dev.isDrawPic = false;
      WM_RestartTimer(pMsg->Data.v, 500);
			break;
			
    default:
      WM_DefaultProc(pMsg);
  }
}


static void _cbTF(WM_MESSAGE *pMsg)
{
	static u8 bmpNum;
	WM_HWIN hButton;
	static bool isFirstDraw=true,isPresEnter,isMountSuc;
	u8 i;
	
	WM_HWIN hWin = pMsg->hWin;
	static WM_HWIN hList;
	switch (pMsg->MsgId) 
	{
		case WM_CREATE:
			if(isFirstDraw == true)
			{
				isFirstDraw = false;
				bmpNum = 0;
			}
				
			isPresEnter = false;	
			isMountSuc = false;
//			LCD_SetHengPing();
			if(dev.isTf == false)
				break;

		  WM_SetFocus(hWin); 
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX); 
#if !GUI_SUPPORT_TOUCH 
			BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END);
#else
			BUTTON_SetDefaultFont(&GUI_Font24_ASCII);
			hButton = BUTTON_CreateEx(350, 160 ,100, 50, hWin, WM_CF_SHOW, 0, GUI_KEY_ENTER);
			BUTTON_SetText(hButton,"OK");
			
			hButton = BUTTON_CreateEx(350, 240 ,100, 50, hWin, WM_CF_SHOW, 0, GUI_KEY_END);
			BUTTON_SetText(hButton,"Back");

			hButton = BUTTON_CreateEx(350, 80 ,100, 50, hWin, WM_CF_SHOW, 0, GUI_KEY_CONTROL);
			BUTTON_SetText(hButton,"PPT");				
#endif
      
			hList = LISTBOX_CreateEx(20,40,300,250,hWin,WM_CF_SHOW,0,GUI_ID_LISTBOX0,listHead);
			LISTBOX_SetAutoScrollV(hList,1);
			LISTBOX_SetFont(hList,&GUI_Font24_1);
		
			//LISTBOX_SetScrollbarColor(hList,SCROLLBAR_CI_THUMB,GUI_YELLOW);
			LISTBOX_SetScrollbarWidth(hList,25);
			LISTBOX_SetBkColor(hList,LISTBOX_CI_SEL,GUI_BLUE);
		  
		  for(i=0;i<dev.tfBmpCnt;i++)
				LISTBOX_AddString(hList,(char *)dev.tfBmpName[i]);
			break;

		case WM_PAINT:
			// _PaintFrame();
			GUI_SetTextMode(GUI_TM_TRANS);
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();
			
			if (dev.isTf == false)  				//挂载文件系统失败
			{
				// 请插入TF卡
				GUI_SetColor(GUI_WHITE);
				GUI_FillRect(140,110,340,210);
			  GUI_UC_SetEncodeUTF8();  //显示中文，不管外部还是内部字库，都要加上本函数
				GUI_SetFont(&st16Font);	
				GUI_SetColor(GUI_RED);
				GUI_SetTextMode(GUI_TM_TRANS);
				GUI_DispStringHCenterAt("请插入TF卡",240,150); 
				WM_CreateTimer(pMsg->hWin, 0, 2500, 0);
				break;
			}	

			LISTBOX_SetSel(hList,bmpNum);
			GUI_UC_SetEncodeUTF8();  //显示中文，不管外部还是内部字库，都要加上本函数
			GUI_SetFont(&st16Font);	
			GUI_SetColor(GUI_WHITE);
			GUI_DispStringHCenterAt("TF卡图片目录",240,10); 
			
#if !GUI_SUPPORT_TOUCH
			GUI_DispStringAt("温馨提示：",330,100);
			GUI_DispStringAt("1.左键退出",330,120);
			GUI_DispStringAt("2.上下键切换选择",330,140);
			GUI_DispStringAt("3.中心键打开图片",330,160);	
#else   
      

#endif
			break;

		case WM_TIMER:
			_DeleteFrame();						
			_CreateFrame(&_cbMain,MENU_MAIN);			
			break;

#if !GUI_SUPPORT_TOUCH
		case WM_KEY:
			switch (((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:
					// WM_CreateTimer(pMsg->hWin, 0, 2500, 0);
					
					if(isPresEnter == false){
						LISTBOX_Delete(hList);
						_DeleteFrame();													
						_CreateFrame(&_cbMain,MENU_MAIN);					
					}
				  else{ //退出TF图片显示 重新绘图 , 初始化标志参数
						LISTBOX_Delete(hList);
						_DeleteFrame();						
						_CreateFrame(&_cbTF,MENU_TF);						
					}
					break;
					
				case GUI_KEY_SUB:
					if(isPresEnter == false){
						bmpNum++;
						bmpNum = bmpNum%dev.tfBmpCnt;	
						
						WM_Paint(pMsg->hWin);	
					}
					break;
					
				case GUI_KEY_ADD:
					if(isPresEnter == false){
						if(bmpNum>0)bmpNum--;
						else bmpNum = dev.tfBmpCnt-1;
						WM_Paint(pMsg->hWin);						
					}
					break;
					
				case GUI_KEY_ENTER:
					display_picture((char *)&dev.tfBmpName[bmpNum]);
//					LCD_SetHengPing();
					isPresEnter = true;
				break;
			}
			break;
#else		
		case WM_NOTIFY_PARENT:
			if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
			{
				int id = WM_GetId(pMsg->hWinSrc);
				switch(id)
				{
				  case GUI_KEY_END:	 				//退出按钮											
						_DeleteFrame(); 
				    _CreateFrame(_cbMain,MENU_MAIN);												
					break;

					case GUI_KEY_ENTER:				//确认按钮		
						_DeleteFrame(); 
//					  Tp_TIM5_Close();
						TIM_Cmd(TIM3, DISABLE);  //使能TIM3
						display_picture((char *)&dev.tfBmpName[bmpNum]);
						TIM_Cmd(TIM3, ENABLE);  //使能TIM3
//					  Tp_TIM5_Open();
//						LCD_SetHengPing();
						isPresEnter = true;	
					
					  _CreateFrame(_cbPicture,MENU_PIC);																	
						break;
					
          case GUI_KEY_CONTROL:
						_DeleteFrame(); 
					  dev.isPPT = true;
					  dev.isDrawPic= false;
					  _CreateFrame(_cbPicture,MENU_PIC);
					  
						break;
					
				  case GUI_ID_LISTBOX0:{
						int sel;
						sel = LISTBOX_GetSel(hList);	
						if( sel!=(-1)) bmpNum = (u8)sel; 
					}
						break;
					
					default:
						WM_DefaultProc(pMsg);
				}
			}				
			break;
#endif			
			
    default:
      WM_DefaultProc(pMsg);
  }
}


const char *cmpTxt[]={
"好钜润科技是由原翠绿科技，咏联科",
"技组建而成，专业生产TFT、IPS液晶屏，",
"拥有雄厚的研发生产能力，主打高清1600",
"万色IPS屏，以emWin等图形界面为技术背",
"景,为客户快速出成品做好软件基础。",
"公司主页：www.hjrkj.com",
"官方淘宝：http://tiky.taobao.com",
"联系电话：0755-33561760",
"电子邮箱：MKT@hjrkj.com",
};

static void _cbAboutUs(WM_MESSAGE *pMsg)
{
	u8 lineNum;
	WM_HWIN hButton;	
	WM_HWIN hWin = pMsg->hWin;
	GUI_RECT rect;
	
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX); 
	    BUTTON_SetDefaultFont(&GUI_Font16_ASCII);
			
			WM_SetFocus(hWin); 
#if  GUI_SUPPORT_TOUCH			
			hButton = BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_SHOW, 0, GUI_KEY_END);
			BUTTON_SetText(hButton,"Back");	
#else
			hButton = BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END);
#endif			
      break; 
				
    case WM_PAINT:	
		  GUI_SetTextMode(GUI_TM_TRANS);
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();

		  GUI_UC_SetEncodeUTF8();  //显示中文，不管外部还是内部字库，都要加上本函数
			GUI_SetFont(&st16Font);	
		  
      rect.y0 = 50;
		  rect.x1 = 385;

		  GUI_SetColor(GUI_WHITE);
      GUI_DispStringHCenterAt("深圳好钜润科技有限公司",240,15);

			rect.x0 = 95+32;
			rect.y0 = 50;
			rect.y1 = rect.y0 + 22;
			GUI_DispStringInRect(cmpTxt[0],&rect,GUI_TA_LEFT | GUI_TA_VCENTER);
		
		  rect.x0 = 95;
		  for(lineNum = 1;lineNum<5;lineNum++){
				rect.y0 = 50 + 22*lineNum;
				rect.y1 = rect.y0 + 22;
				GUI_DispStringInRect(cmpTxt[lineNum],&rect,GUI_TA_LEFT | GUI_TA_VCENTER);
			}
			
			for(lineNum = 5;lineNum<9;lineNum++){
				rect.y0 = 60 + 22*lineNum;
				rect.y1 = rect.y0 + 22;
				GUI_DispStringInRect(cmpTxt[lineNum],&rect,GUI_TA_LEFT | GUI_TA_VCENTER);
			}
			
			GUI_DrawBitmap(&bmweb,380,220);
      break;
			
		case WM_KEY:	
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:  
						_DeleteFrame(); 
				    _CreateFrame(_cbMain,MENU_MAIN);					
					break;
							
			}
			break;	

		case WM_NOTIFY_PARENT:
			if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
			{
				int id = WM_GetId(pMsg->hWinSrc);
				switch(id)
				{
				  case GUI_KEY_END:	 				//退出按钮											
						_DeleteFrame(); 
				    _CreateFrame(_cbMain,MENU_MAIN);												
					break;
				
					default:
						WM_DefaultProc(pMsg);
				}
			}				
			break;
			
	  case WM_TIMER: 
			WM_RestartTimer(pMsg->Data.v, 1000);
			WM_Paint(pMsg->hWin);
			break;
			
    default:
      WM_DefaultProc(pMsg);
  }
}


//滚动字符
TICKER_CONTEXT_WM  ContextWM = { 0 };	
const char  pTextWM[] = "深圳市好钜润科技有限公司  www.hjrkj.com";

static void _cbTickerWM(WM_MESSAGE * pMsg){
  TICKER_CONTEXT_WM * pContext;
  WM_GetUserData(pMsg->hWin, &pContext, sizeof(pContext));
  switch (pMsg->MsgId) {
		
		case WM_CREATE:
			WM_CreateTimer(pMsg->hWin, 0, 500, 0);
		break;
		
		case WM_TIMER:
			pContext->Ticker.vxPos += pContext->Ticker.dx;
			if ((pContext->Ticker.vxPos) >= pContext->Ticker.xSize) {
				pContext->Ticker.vxPos = -(pContext->Ticker.xSizeText - 1);
			}
			if ((pContext->Ticker.vxPos) <= -pContext->Ticker.xSizeText) {
				pContext->Ticker.vxPos = (pContext->Ticker.xSize - 1);
			}
			
			WM_RestartTimer(pMsg->Data.v, 50);
			WM_Paint(pMsg->hWin);				
			break;
			
		case WM_PAINT:  
			GUI_SetBkColor(GUI_WHITE);
			GUI_Clear();
			
		  GUI_UC_SetEncodeUTF8();
			GUI_SetFont(&st16Font);
			GUI_SetTextMode(GUI_TM_TRANS);
			GUI_SetColor(GUI_RED);
			GUI_DispStringAt(pTextWM, pContext->Ticker.vxPos, 0);//pContext->Ticker.vyPos
			break;
		
		default:
			WM_DefaultProc(pMsg);
  }
}

			
//日期配置界面参数坐标
const u16 dateAddr[][2]={
{160,30},  //year
{230,30},  //month
{300,30},  //day
{160,80},  //hour
{240,80},  //minute
};

typedef struct _Date_
{
	u8   year;
	u8   month;
	u8   day;
	u8   hour;
	u8   minute;
	u8   second;
	u8   week;
}Date;

	
//配置RTC时钟 
void _cbSetDate(WM_MESSAGE *pMsg)
{
	WM_HWIN hWin = pMsg->hWin;
	WM_HWIN hButton;
	static u8 setAdr = 0; 
  static Date temp;
	static bool isFirstDraw,isOK;
	
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:		 
		  isFirstDraw = true;
		  setAdr = 0;
			isOK = false;
			WM_EnableMemdev(hWin);
						
			BUTTON_SetDefaultFont(&GUI_Font32B_ASCII);
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX);
			hButton = BUTTON_CreateEx(210, 143 ,60, 40, hWin, WM_CF_SHOW, 0, GUI_KEY_UP);
			BUTTON_SetText(hButton,"+");
		  BUTTON_SetFocussable(hButton,0);
			hButton = BUTTON_CreateEx(210, 265 ,60, 40, hWin, WM_CF_SHOW, 0,GUI_KEY_DOWN);
			BUTTON_SetText(hButton,"-");
		  BUTTON_SetFocussable(hButton,0);
			hButton = BUTTON_CreateEx(130, 205 ,60, 40, hWin, WM_CF_SHOW, 0, GUI_KEY_LEFT);
			BUTTON_SetText(hButton,"<");
		  BUTTON_SetFocussable(hButton,0);
			hButton = BUTTON_CreateEx(290, 205 ,60, 40, hWin, WM_CF_SHOW, 0, GUI_KEY_RIGHT);
			BUTTON_SetText(hButton,">");
		  BUTTON_SetFocussable(hButton,0);

			hButton = BUTTON_CreateEx(210, 205 ,60, 40, hWin, WM_CF_SHOW, 0, GUI_KEY_ENTER);
			BUTTON_SetText(hButton,"OK");		
			BUTTON_SetFocussable(hButton,0);
			
			WM_SetFocus(hWin);  
#if GUI_SUPPORT_TOUCH			
			 
	    BUTTON_SetDefaultFont(&GUI_Font16_ASCII);
			hButton = BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_SHOW, 0, GUI_KEY_END);
			BUTTON_SetText(hButton,"Back");
#endif			

      temp.year = dev.year-2000;
			temp.month = dev.month;
			temp.day = dev.day;
			temp.hour = dev.hour;
			temp.minute = dev.minute;
			temp.second = dev.second;
			temp.week = dev.week;
      break;
    
    case WM_PAINT:
		  GUI_SetTextMode(GUI_TM_TRANS);
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();

		  GUI_SetColor(GUI_BLACK);
			GUI_SetFont(&GUI_Font32B_1);	
			GUI_DispDecAt(20,120,30,2); 						//year		
			GUI_DispDecAt(temp.year,160,30,2); 			//year
			GUI_DispDecAt(temp.month,230,30,2);			//month
			GUI_DispDecAt(temp.day,300,30,2);			  //day
			
			GUI_DispDecAt(temp.hour,160,80,2);			//hour
			GUI_DispDecAt(temp.minute,240,80,2);		//minute		

		  GUI_UC_SetEncodeUTF8();  //显示中文，不管外部还是内部字库，都要加上本函数
			GUI_SetFont(&st16Font);	
			GUI_DispStringAt("年",200,40);
			GUI_DispStringAt("月",270,40);
			GUI_DispStringAt("日",338,40);
			
			GUI_DispStringAt("时",205,85);
			GUI_DispStringAt("分",285,85);

			//选中颜色翻转
			GUI_SetBkColor(GUI_WHITE);
			GUI_SetTextMode(GUI_TM_NORMAL);
			GUI_SetColor(GUI_BLACK);
			GUI_SetFont(&GUI_Font32B_1);	
			GUI_DispDecAt(*(&temp.year+(setAdr)),dateAddr[setAdr][0],dateAddr[setAdr][1],2); 
			
			GUI_SetTextMode(GUI_TM_TRANS);  //颜色恢复
			GUI_SetColor(GUI_BLACK);	
			
			if(isOK)
			{
				GUI_SetColor(GUI_WHITE);
				GUI_FillRect(120,10,360,110);
				GUI_UC_SetEncodeUTF8();  		//显示中文，不管外部还是内部字库，都要加上本函数
				GUI_SetFont(&st16Font);
				GUI_SetColor(GUI_BLACK);
				GUI_DispStringHCenterAt("设置已生效",240,50);	
				WM_CreateTimer(pMsg->hWin, 0, 2000, 0);
			}
      break;

#if GUI_SUPPORT_TOUCH
		case WM_NOTIFY_PARENT:
			if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
			{
				int id = WM_GetId(pMsg->hWinSrc);
				switch(id)
				{
					case GUI_KEY_UP:
						*(&temp.year+setAdr) = ModifyDat(*(&temp.year+setAdr),setAdr,true);
					
						WM_Paint(hWin);
						break;
						
					case GUI_KEY_DOWN:
						*(&temp.year+setAdr) = ModifyDat(*(&temp.year+setAdr),setAdr,false);
					
						WM_Paint(hWin);
						break;
						
					case GUI_KEY_LEFT:					
					  if(setAdr==0)setAdr = 4;
						else setAdr--;
					
						WM_Paint(hWin);
						break;
						
					case GUI_KEY_RIGHT:
					  if(setAdr==4)setAdr = 0;
						else setAdr++;
					
						WM_Paint(hWin);
						break;
					
				  case GUI_KEY_END:	 				//退出按钮											
						_DeleteFrame(); 
				    _CreateFrame(_cbMain,MENU_MAIN);												
					break;

					case GUI_KEY_ENTER:				//确认按钮		
						isOK = true;
						dev.year = temp.year+2000;
						dev.month = temp.month;
						dev.day = temp.day;
						dev.hour = temp.hour;
						dev.minute = temp.minute;
						dev.second = temp.second;
						dev.week = temp.week;
//						RTC_Set(dev.year,dev.month,dev.day,dev.hour,dev.minute,0);					
						WM_Paint(hWin);	
											
						break;
					
					default:
						WM_DefaultProc(pMsg);
				}
			}				
			break;
#else
		case WM_KEY:
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_ADD:
					*(&temp.year+setAdr) = ModifyDat(*(&temp.year+setAdr),setAdr,true);
					WM_Paint(hWin);
					break;
					
				case GUI_KEY_SUB:
					*(&temp.year+setAdr) = ModifyDat(*(&temp.year+setAdr),setAdr,false);
					WM_Paint(hWin);
					break;
					
				case GUI_KEY_LE:
					if(setAdr==0)setAdr = 4;
					else setAdr--;		
					WM_Paint(hWin);					
					break;
					
				case GUI_KEY_RI:
					if(setAdr==4)setAdr = 0;
					else setAdr++;				
					WM_Paint(hWin);					
					break;
					
				case GUI_KEY_ENTER:
					isOK = true;
					dev.year = temp.year+2000;
					dev.month = temp.month;
					dev.day = temp.day;
					dev.hour = temp.hour;
					dev.minute = temp.minute;
					dev.second = temp.second;
					dev.week = temp.week;
					RTC_Set(dev.year,dev.month,dev.day,dev.hour,dev.minute,0);					
				  WM_Paint(hWin);	
					break;
			}
			break;
#endif
			
    case WM_TOUCH:

			break;
    
    case WM_TIMER:					
			_DeleteFrame();
			_CreateFrame(_cbMain,MENU_MAIN);		
			break;
      
    default:
      WM_DefaultProc(pMsg);
  }	
}

//总共25种颜色
const u32 BkColor[5]={COLOR(0,76,152),
GUI_BLUE, GUI_GREEN,  GUI_RED,GUI_YELLOW};


//上下调亮度 左右换背景纯色
void _cbKey(WM_MESSAGE *pMsg)
{
	u8 i;
	u8 f=2;
	u8 second,minute;
	WM_HWIN hWin = pMsg->hWin;
	GUI_MEMDEV_Handle hMem1;
	WM_HWIN hButton;
	static u8 colorNum;
	static u8 bkLight;
	static u8 sta;   //菜单状态
	
  static bool isFirstDraw;
	static bool isBlink;
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
			isFirstDraw = true;
			isBlink = false;
			bkLight = 7;
			dev.keyNum = 0;
			colorNum = 0;
			sta = 1;			
		  WM_SetFocus(hWin);  
			
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX);
			GUI_UC_SetEncodeUTF8();  //显示中文，不管外部还是内部字库，都要加上本函数
			GUI_SetColor(GUI_BLACK);
//			BUTTON_SetDefaultFont(SetFont_Xbf());
			
			// hButton = BUTTON_CreateEx(50, 290 ,50, 30, hWin, WM_CF_SHOW, 0, GUI_KEY_END);
			
#if GUI_SUPPORT_TOUCH	
			hButton = BUTTON_CreateEx(100, 50 ,100, 40, hWin, WM_CF_SHOW, 0, GUI_ID_BUTTON0);//创建按键1
			BUTTON_SetText(hButton, "GPS"); 
			
			hButton = BUTTON_CreateEx(200, 50 ,100, 40, hWin, WM_CF_SHOW, 0, GUI_ID_BUTTON1);
			BUTTON_SetText(hButton, "自定义2"); 
			hButton = BUTTON_CreateEx(300, 50 ,100, 40, hWin, WM_CF_SHOW, 0, GUI_ID_BUTTON2);
			BUTTON_SetText(hButton, "自定义3"); 
			
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX); 
			BUTTON_SetDefaultFont(&GUI_Font16_ASCII);
			hButton = BUTTON_CreateEx(315, 220 ,80, 40, hWin, WM_CF_SHOW, 0, GUI_KEY_UP);
			BUTTON_SetText(hButton,"Back");
#endif
			hButton = BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_HIDE, 0, GUI_KEY_END);
		break;
    
    case WM_PAINT:	

			GUI_SetTextMode(GUI_TM_TRANS);	
			GUI_UC_SetEncodeUTF8();
			GUI_SetFont(&st16Font);
				
      if(sta==1){
				GUI_SetBkColor(COLOR(0,76,152));
		    GUI_Clear();
				GUI_SetColor(GUI_RED);
				GUI_FillRect(70,130,170,190); //左
				GUI_SetColor(GUI_WHITE);
				GUI_FillRect(310,130,410,190);//右

			  GUI_SetColor(GUI_WHITE);
				GUI_DispStringHCenterAt("亮度调节",120,150);
				GUI_SetColor(GUI_BLACK);
				GUI_DispStringHCenterAt("纯色测试",360,150);
				
				GUI_SetColor(GUI_WHITE);
				GUI_DispStringAt("温馨提示:",20,305);
				GUI_DispStringAt("1.左键退出,右键切换选中状态,中心键进入指定状态.",56,330);
				GUI_DispStringAt("2.进入指定状态后,左键退出,上下键调整状态参数",56,355);
			}
			else if(sta==2){
				GUI_SetBkColor(COLOR(0,76,152));
		    GUI_Clear();
				GUI_SetColor(GUI_WHITE);
				GUI_FillRect(70,130,170,190); //左
				GUI_SetColor(GUI_RED);
				GUI_FillRect(310,130,410,190);//右

			  GUI_SetColor(GUI_BLACK);
				GUI_DispStringHCenterAt("亮度调节",120,150);
				GUI_SetColor(GUI_WHITE);
				GUI_DispStringHCenterAt("纯色测试",360,150);	
				
				GUI_SetColor(GUI_WHITE);
				GUI_DispStringAt("温馨提示:",20,245);
				GUI_DispStringAt("1.左键退出,右键切换选中状态,中心键进入指定状态.",56,270);
				GUI_DispStringAt("2.进入指定状态后,左键退出,上下键调整状态参数",56,295);
			}
			else if(sta == 3) //亮度测试
			{
				GUI_SetBkColor(BkColor[colorNum]);
		    GUI_Clear();			
			}
			else if(sta == 4){
				GUI_SetBkColor(BkColor[colorNum]);
		    GUI_Clear();				
			}
			break;
			

		case WM_NOTIFY_PARENT: //用户按键之后，控件返回消息变量
		{
			int id = WM_GetId(pMsg->hWinSrc);				
			if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
			{		
				switch(id)
				{
					case GUI_KEY_UP:					
								_DeleteFrame();  									//删除当前界面
								_CreateFrame(_cbMain,MENU_MAIN); 		//返回主界面
							break;
				  case GUI_KEY_END:												
						_DeleteFrame();
//						Lcd_BL_Lum(7);
				    _CreateFrame(_cbMain,MENU_MAIN);											
					break;
					
					case GUI_ID_BUTTON0:
						_DeleteFrame(); //删除当前窗口
				    _CreateFrame(_cbSelf1,MENU_SELF1);	//建立自定义窗口							
						break;
						
					case GUI_ID_BUTTON1:
						_DeleteFrame();
				    _CreateFrame(_cbSelf2,MENU_SELF1);									
						break;

					case GUI_ID_BUTTON2:
						_DeleteFrame();
				    _CreateFrame(_cbSelf3,MENU_SELF1);									
						break;
						
					default:
						WM_DefaultProc(pMsg);
						break;				
				}
			}
		}
		break;	
		
		
		case WM_KEY:
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_BACKSPACE:  					
		
					break;
					
				case GUI_KEY_ENTER:  					
          if(sta==1)sta =3;
					else if(sta==2)sta = 4;					
					WM_Paint(hWin);	
					break;		
					
				case GUI_KEY_ADD:	
					if(sta == 4){
						colorNum++;
						colorNum = colorNum%5;
						WM_Paint(hWin);							
					}
					else if(sta == 3)
					{
						bkLight++;
						bkLight = bkLight%8;
//						Lcd_BL_Lum(bkLight);										
					}
					
				break;
				
				case GUI_KEY_SUB:
					if(sta == 4){
						if(colorNum>0)colorNum--;
						else colorNum = 4;	
						
						WM_Paint(hWin);
					}
					else if(sta == 3)
					{
						if(bkLight>0)bkLight--;
						else bkLight = 7;
//						Lcd_BL_Lum(bkLight);					
					}						
				break;
					
				case GUI_KEY_LE: //左键退出
          if(sta==3){
//						Lcd_BL_Lum(7);
						sta=1;
						WM_Paint(hWin);
					}
					else if(sta == 4){
						sta = 2;
						WM_Paint(hWin);
					}
					else if((sta == 1)||(sta ==2)){
						_DeleteFrame();						
						_CreateFrame(&_cbMain,MENU_MAIN);							
					}
				break;
					
				case GUI_KEY_RI:
					if(sta==1)sta=2;
					else if(sta==2)sta =1;
					WM_Paint(hWin);	
				break;					
			}
			break;	
				
	  case WM_TIMER: 
			WM_RestartTimer(pMsg->Data.v, 500);
			WM_Paint(pMsg->hWin);
			break;
			
    default:
      WM_DefaultProc(pMsg);
	}
}

//运行状态
static void _cbRGB(WM_MESSAGE *pMsg)
{
	u8 i;
	WM_HWIN hWin = pMsg->hWin;
  static bool isFirstDraw;
	SLIDER_Handle hSlider;
	WM_HWIN hButton;
	
	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
		  dev.keyNum = 0;
		  dev.colorR = 255;
			dev.colorG = 255;
			dev.colorB = 255;
			//GUI_SetFont(&GUI_FontST16);
	    WM_EnableMemdev(hWin);
      WM_SetFocus(hWin);  
		  BUTTON_CreateEx(0, 0, 2, 2, hWin, WM_CF_HIDE, 0, GUI_ID_BUTTON1); 

#if GUI_SUPPORT_TOUCH
			BUTTON_SetDefaultSkin(BUTTON_SKIN_FLEX); 
	    BUTTON_SetDefaultFont(&GUI_Font16_ASCII);
			hButton = BUTTON_CreateEx(0, 290 ,50, 30, hWin, WM_CF_SHOW, 0, GUI_KEY_UP);
			BUTTON_SetText(hButton,"Back");
#endif			
		
			//RED
		  SLIDER_SetDefaultSkin (SLIDER_SKIN_FLEX); 
      hSlider = SLIDER_Create(320,40,30,240,hWin,GUI_ID_SLIDER0,WM_CF_SHOW,SLIDER_CF_VERTICAL);    
      SLIDER_SetRange(hSlider,0,255);
      SLIDER_SetNumTicks(hSlider,5);          
      SLIDER_SetWidth(hSlider,10);
			SLIDER_SetValue(hSlider,dev.colorR);
			
			//GREEN
			SLIDER_SetDefaultSkin (SLIDER_SKIN_FLEX); 
      hSlider = SLIDER_Create(380,40,30,240,hWin,GUI_ID_SLIDER1,WM_CF_SHOW,SLIDER_CF_VERTICAL);    
      SLIDER_SetRange(hSlider,0,255);
      SLIDER_SetNumTicks(hSlider,5);          
      SLIDER_SetWidth(hSlider,10);
			SLIDER_SetValue(hSlider,dev.colorG);
	
			//BLUE
			SLIDER_SetDefaultSkin (SLIDER_SKIN_FLEX); 
      hSlider = SLIDER_Create(440,40,30,240,hWin,GUI_ID_SLIDER2,WM_CF_SHOW,SLIDER_CF_VERTICAL);    
      SLIDER_SetRange(hSlider,0,255);
      SLIDER_SetNumTicks(hSlider,5);          
      SLIDER_SetWidth(hSlider,10);
			SLIDER_SetValue(hSlider,dev.colorB);

			break;
    
    case WM_PAINT:	
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_Clear();			
			GUI_SetColor(COLOR(dev.colorR,dev.colorG,dev.colorB));
			GUI_FillRect(0,0,300,319);

			GUI_SetColor(COLOR(0,76,152));
			GUI_FillRect(301,0,479,319);

			//RED
			GUI_SetColor(COLOR(dev.colorR,0,0));
			GUI_AA_FillCircle(150,103,65);
		  //GREEN
			GUI_SetColor(COLOR(0,0,dev.colorB));
			GUI_AA_FillCircle(85,216,65);
			//BLUE
			GUI_SetColor(COLOR(0,dev.colorG,0));
			GUI_AA_FillCircle(215,216,65);

//#if GUI_SUPPORT_TOUCH
//#endif		
		
			GUI_SetFont(&GUI_Font20B_1);
			GUI_SetTextMode(GUI_TM_NORMAL);
			GUI_SetBkColor(COLOR(0,76,152));
			GUI_SetColor(GUI_WHITE);
			GUI_DispDecAt(dev.colorR,320,290,3);
			GUI_DispDecAt(dev.colorG,380,290,3);
			GUI_DispDecAt(dev.colorB,440,290,3);

			
		  GUI_DispStringAt("R",326,10);
			GUI_DispStringAt("G",386,10);
			GUI_DispStringAt("B",446,10);

			break;

#if GUI_SUPPORT_TOUCH		
		case WM_NOTIFY_PARENT:
		{
			int id = WM_GetId(pMsg->hWinSrc);
			switch(id)
			{
				case GUI_ID_SLIDER0:  //R
					hSlider = WM_GetDialogItem(hWin, GUI_ID_SLIDER0);
					dev.colorR = SLIDER_GetValue(hSlider);
					WM_Paint(hWin);	
					break;

				case GUI_ID_SLIDER1:  //G
					hSlider = WM_GetDialogItem(hWin, GUI_ID_SLIDER1);
					dev.colorG = SLIDER_GetValue(hSlider);
					WM_Paint(hWin);	
					break;

				case GUI_ID_SLIDER2:  //B
					hSlider = WM_GetDialogItem(hWin, GUI_ID_SLIDER2);
					dev.colorB = SLIDER_GetValue(hSlider);
					WM_Paint(hWin);	
					break;
			}
			
			if (pMsg->Data.v == WM_NOTIFICATION_RELEASED)
			{				
				switch(id)
				{
				  case GUI_KEY_UP:					
						_DeleteFrame();
				    _CreateFrame(_cbMain,MENU_MAIN); 
					break;
						
					default:
						WM_DefaultProc(pMsg);
						break;				
				}
			}
		}
		break;	
#endif
		
		case WM_KEY:	
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_LE:
					_DeleteFrame();
					_CreateFrame(_cbMain,MENU_MAIN); 
					break;
			}	
			break;	
				
	  case WM_TIMER: 

			break;
			
    default:
      WM_DefaultProc(pMsg);
  }
}


const u16 bkAddr[][4]={
{46,90,158+5,175},
{184,90,296+5,175},
{322,90,433+5,175},
{46,215,158+5,298+5},
{184,215,296+5,298+5},
{322,215,433+5,298+5},
};

void _cbMain(WM_MESSAGE *pMsg)
{
	static u8 lastMainNum,lastSta;
	static bool isFirstDraw,isDelay;
	static bool isPress,isDrawTim,isBlink;
	GUI_MEMDEV_Handle hMem0,hMem1;
	WM_HWIN hWin = pMsg->hWin;
	u8 i;
	TICKER_CONTEXT_WM * pContext = &ContextWM;

	int xPos = 105;
	int yPos = 44;
	int xSize = 270;
  int ySize = 0;
	int dx = -2;

	switch (pMsg->MsgId) 
	{
    case WM_CREATE:
			lastMainNum = 0;
			lastSta = 0;
			
#if GUI_SUPPORT_TOUCH
			dev.keyNum = 0;
#else			
		  dev.keyNum = 1;
#endif	
		
			isFirstDraw = true;
			isPress = false;
			isDelay = false;
			isDrawTim = false;
			
      WM_SetFocus(hWin);  
		  BUTTON_CreateEx(0, 0, 2, 2, hWin, WM_CF_HIDE, 0, GUI_ID_BUTTON1); 
		
		  WM_CreateTimer(pMsg->hWin, 0, 50, 0);
      break;
    
    case WM_PAINT:	

			GUI_SetTextMode(GUI_TM_NORMAL);	
			if(isDrawTim)
			{ 
				isDrawTim = false;
				GUI_SetColor(GUI_WHITE);
				GUI_SetBkColor(COLOR(0,76,152));
				
				GUI_SetFont(&GUI_Font20B_1);
				GUI_DispDecAt(dev.year,0,5,4);
				GUI_DispCharAt('/',42,5);
				GUI_DispDecAt(dev.month,49,5,2);
				GUI_DispCharAt('/',72,5);
				GUI_DispDecAt(dev.day,79,5,2);
			  GUI_DispDecAt(dev.hour,420,5,2);
				GUI_DispDecAt(dev.minute,451,5,2);		
				
				
				if(isBlink)
					GUI_DispCharAt(':',442,3);
				else
					GUI_DispCharAt(' ',442,3);
				
				break;
			}
			
			GUI_SetTextMode(GUI_TM_TRANS);	
			GUI_UC_SetEncodeUTF8();
			GUI_SetFont(&st16Font);
			
			if(isFirstDraw)
			{
				isFirstDraw = false;
				_PaintFrame();
				GUI_SetBkColor(COLOR(0,76,152));
				GUI_Clear();
				
				GUI_SetColor(GUI_WHITE);
			  GUI_FillRect(105,35,375,65);
				
	      GUI_DispStringHCenterAt("液晶屏演示系统",240,5);
				#if GUI_SUPPORT_TOUCH
				GUI_DispStringAt("<触屏版>",400,42);
				#else
				GUI_DispStringAt("<按键版>",400,42);
				#endif
				for(i=1;i<7;i++)
				{
					hMem1 = GUI_MEMDEV_Create(bkAddr[i-1][0],bkAddr[i-1][1],132,127);
					GUI_MEMDEV_Select(hMem1);
					GUI_SetColor(COLOR(0,76,152));	
					GUI_FillRect(bkAddr[i-1][0],bkAddr[i-1][1],bkAddr[i-1][2],bkAddr[i-1][3]);
					
					GUI_SetColor(GUI_WHITE);
					switch(i)
					{
						case 1:GUI_DrawBitmap(&bmi1,60,90);GUI_DispStringHCenterAt("TF卡相册",104,182);break;
						case 2:GUI_DrawBitmap(&bmi2,200,90);GUI_DispStringHCenterAt("RGB",244,182);break;  
						case 3:GUI_DrawBitmap(&bmi3,335,90);GUI_DispStringHCenterAt("按键",380,182);break;		
						case 4:GUI_DrawBitmap(&bmi4,60,224);GUI_DispStringHCenterAt("emWin",104,300);break;				
						case 5:GUI_DrawBitmap(&bmi5,200,215);GUI_DispStringHCenterAt("时钟",244,300);break;	
						case 6:GUI_DrawBitmap(&bmi6,335,215);GUI_DispStringHCenterAt("关于我们",380,300);break;						
					}
					GUI_MEMDEV_Write(hMem1);
					GUI_MEMDEV_CopyToLCDAt(hMem1,bkAddr[i-1][0],bkAddr[i-1][1]);
					GUI_MEMDEV_Delete(hMem1);									
				}
			}

#if 	GUI_SUPPORT_TOUCH		
			if(dev.keyNum != 0)
			{
				//恢复
				if(lastMainNum==0) goto CUR_DRAW;
				
				hMem1 = GUI_MEMDEV_Create(bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1],132,127);
		    GUI_MEMDEV_Select(hMem1);
				GUI_SetColor(COLOR(0,76,152));	
				GUI_FillRect(bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1],bkAddr[lastMainNum-1][2],bkAddr[lastMainNum-1][3]);	
				GUI_SetColor(GUI_WHITE);
				switch(lastMainNum)
				{
						case 1:GUI_DrawBitmap(&bmi1,60,90);GUI_DispStringHCenterAt("TF卡相册",104,182);break;
						case 2:GUI_DrawBitmap(&bmi2,200,90);GUI_DispStringHCenterAt("RGB",244,182);break;  
						case 3:GUI_DrawBitmap(&bmi3,335,90);GUI_DispStringHCenterAt("按键",380,182);break;		
						case 4:GUI_DrawBitmap(&bmi4,60,224);GUI_DispStringHCenterAt("emWin",104,300);break;				
						case 5:GUI_DrawBitmap(&bmi5,200,215);GUI_DispStringHCenterAt("时钟",244,300);break;	
						case 6:GUI_DrawBitmap(&bmi6,335,215);GUI_DispStringHCenterAt("关于我们",380,300);break;							
				}
				GUI_MEMDEV_Write(hMem1);
				GUI_MEMDEV_CopyToLCDAt(hMem1,bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1]);
				GUI_MEMDEV_Delete(hMem1);	
				dev.keyNum = 0; //按键标记清除
			  lastMainNum = 0;    //按键标记清除
				isPress = false;
			  break;

CUR_DRAW:
        if((dev.keyNum > 6)||(isPress==true))  //大于6则跳出
					goto DRAWDATE;
				
				isPress = true;
				//触屏变形
				hMem0 = GUI_MEMDEV_Create(bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1],132,127);
		    GUI_MEMDEV_Select(hMem0);				
        GUI_SetColor(COLOR(0,76,152));	
				GUI_FillRect(bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1],bkAddr[dev.keyNum-1][2],bkAddr[dev.keyNum-1][3]);
			
				GUI_SetColor(GUI_WHITE);
				switch(dev.keyNum)
				{
						case 1:GUI_DrawBitmap(&bmi1,65,95);GUI_DispStringHCenterAt("TF卡相册",104,182);break;
						case 2:GUI_DrawBitmap(&bmi2,205,95);GUI_DispStringHCenterAt("RGB",244,182);break;  
						case 3:GUI_DrawBitmap(&bmi3,340,95);GUI_DispStringHCenterAt("按键",380,182);break;		
						case 4:GUI_DrawBitmap(&bmi4,65,229);GUI_DispStringHCenterAt("emWin",104,300);break;				
						case 5:GUI_DrawBitmap(&bmi5,205,220);GUI_DispStringHCenterAt("时钟",244,300);break;	
						case 6:GUI_DrawBitmap(&bmi6,340,220);GUI_DispStringHCenterAt("关于我们",380,300);break;							
				}		
				GUI_MEMDEV_Write(hMem0);
				GUI_MEMDEV_CopyToLCDAt(hMem0,bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1]);
				GUI_MEMDEV_Delete(hMem0);					
			}
#else
			if(dev.keyNum != 0) //当前选中
			{   
				if(lastSta == dev.keyNum) goto DRAWDATE; //防止静止时不断重绘界面
				else lastSta = dev.keyNum;
				
				hMem1 = GUI_MEMDEV_Create(bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1],132,127);
				GUI_MEMDEV_Select(hMem1);
				GUI_SetColor(COLOR(230,230,230));	
				GUI_FillRoundedRect(bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1],bkAddr[dev.keyNum-1][2]-5,bkAddr[dev.keyNum-1][3]-5,5);	
				GUI_SetColor(GUI_WHITE);
				switch(dev.keyNum)
				{
					case 1:GUI_DrawBitmap(&bmi1,60,90);GUI_DispStringHCenterAt("TF卡相册",104,182);break;
					case 2:GUI_DrawBitmap(&bmi2,200,90);GUI_DispStringHCenterAt("RGB",244,182);break;  
					case 3:GUI_DrawBitmap(&bmi3,335,90);GUI_DispStringHCenterAt("按键",380,182);break;		
					case 4:GUI_DrawBitmap(&bmi4,60,224);GUI_DispStringHCenterAt("emWin",104,300);break;				
					case 5:GUI_DrawBitmap(&bmi5,200,215);GUI_DispStringHCenterAt("时钟",244,300);break;	
					case 6:GUI_DrawBitmap(&bmi6,335,215);GUI_DispStringHCenterAt("关于我们",380,300);break;							
				}
				GUI_MEMDEV_Write(hMem1);
				GUI_MEMDEV_CopyToLCDAt(hMem1,bkAddr[dev.keyNum-1][0],bkAddr[dev.keyNum-1][1]);
				GUI_MEMDEV_Delete(hMem1);	
			}
			
      if(lastMainNum != 0) //上一次选中背景色恢复
			{
				hMem1 = GUI_MEMDEV_Create(bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1],132,127);
				GUI_MEMDEV_Select(hMem1);
				GUI_SetColor(COLOR(0,76,152));	
				GUI_FillRect(bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1],bkAddr[lastMainNum-1][2],bkAddr[lastMainNum-1][3]);	
				GUI_SetColor(GUI_WHITE);
				switch(lastMainNum)
				{
					case 1:GUI_DrawBitmap(&bmi1,60,90);GUI_DispStringHCenterAt("TF卡相册",104,182);break;
					case 2:GUI_DrawBitmap(&bmi2,200,90);GUI_DispStringHCenterAt("RGB",244,182);break;  
					case 3:GUI_DrawBitmap(&bmi3,335,90);GUI_DispStringHCenterAt("按键",380,182);break;		
					case 4:GUI_DrawBitmap(&bmi4,60,224);GUI_DispStringHCenterAt("emWin",104,300);break;				
					case 5:GUI_DrawBitmap(&bmi5,200,215);GUI_DispStringHCenterAt("时钟",244,300);break;	
					case 6:GUI_DrawBitmap(&bmi6,335,215);GUI_DispStringHCenterAt("关于我们",380,300);break;							
				}
				GUI_MEMDEV_Write(hMem1);
				GUI_MEMDEV_CopyToLCDAt(hMem1,bkAddr[lastMainNum-1][0],bkAddr[lastMainNum-1][1]);
				GUI_MEMDEV_Delete(hMem1);	
				lastMainNum = 0;    //按键标记清除
			}
			else 
				goto DRAWDATE;
			
#endif
			
DRAWDATE:	
      break;

#if   !GUI_SUPPORT_TOUCH
		case WM_KEY:
			switch(((WM_KEY_INFO *)(pMsg->Data.p))->Key)
			{
				case GUI_KEY_RI:
					lastMainNum = dev.keyNum;	
				  dev.keyNum++;		
					dev.keyNum = dev.keyNum%6;
					
					if(dev.keyNum==0)dev.keyNum = 6;
					WM_Paint(hWin);						
					break;
						
				case GUI_KEY_LE: 
					lastMainNum = dev.keyNum;	
					if(dev.keyNum>1)
						dev.keyNum--;
					else
					  dev.keyNum = 6;
					
					WM_Paint(hWin);						
					break;
					
				case GUI_KEY_ENTER: //根据keyNum进入指定的界面
					if(dev.keyNum == 0)
						break;
					
					switch(dev.keyNum)
					{
						case 1: //TF卡
							lastMainNum = dev.keyNum;			
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();
						  ReadTF();
							_CreateFrame(_cbTF,MENU_TF);	
							break;
							
 						case 2: //RGB
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbRGB,MENU_RGB);
							break;
							
						case 3: //按键
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbKey,MENU_KEY);
							break;
							
						case 4: //emWin
							lastMainNum = dev.keyNum;;	  
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						

						  //用emWin例子
						  WIDGET_NumPad();//GUIDEMO_Main();
						  _CreateFrame(_cbMain,MENU_MAIN);	
							break;
							
						case 5: //时钟
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbSetDate,MENU_SETDATE);
							break;
						
						case 6: //关于我们
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbAboutUs,MENU_WEB);		
							break;		 				
					}
					break;
			}					
			break;	

#else
			case WM_TOUCH:
			{
				GUI_PID_STATE *pBtn = (GUI_PID_STATE *)pMsg->Data.p;
				u8 id = GetTouchAreaID(pBtn);
				
				if(pBtn->Pressed == 0){    //按键释放	
					switch(id){
						case TOUCH_PIC_ID:            		
							lastMainNum = dev.keyNum;			
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();
						  ReadTF();
							_CreateFrame(_cbTF,MENU_TF);							 
							break;
							
						case TOUCH_RGB_ID:
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbRGB,MENU_RGB);
					    break;
							
						case TOUCH_KEY_ID:				
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbKey,MENU_KEY);
	            break;
						
						case TOUCH_GUI_ID:
							lastMainNum = dev.keyNum;;	  
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();	
						
						  //用emWin例子
//							Tp_TIM5_Config();
							WIDGET_NumPad();//GUIDEMO_Main();
//							Tp_TIM5_Close();			  
							_CreateFrame(_cbMain,MENU_MAIN);	
							break;

						case TOUCH_CLOCK_ID:
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbSetDate,MENU_SETDATE);
							break;
							
				    case TOUCH_WEB_ID:
							lastMainNum = dev.keyNum;
							WM_DeleteWindow(pContext->hWin);
							_DeleteFrame();						
							_CreateFrame(_cbAboutUs,MENU_WEB);						
							break;
							
						default:
							lastMainNum =0;
							dev.keyNum = 0;									
							break;
					}
					WM_Paint(hWin);		
				}
				else{  									//按键按下					
					switch(id){
						case TOUCH_PIC_ID:
							dev.keyNum = 1;		
							lastMainNum = 0;
							break;
							
						case TOUCH_RGB_ID:
							dev.keyNum = 2;
							lastMainNum = 0;
					    break;
							
						case TOUCH_KEY_ID:				
							dev.keyNum = 3;
							lastMainNum = 0;
	            break;
						
						case TOUCH_GUI_ID:
							dev.keyNum = 4; 	
							lastMainNum = 0;
							break;

						case TOUCH_CLOCK_ID:
							dev.keyNum = 5;
							lastMainNum = 0;
							break;
							
				    case TOUCH_WEB_ID:
							dev.keyNum = 6;
							lastMainNum = 0;
							break;
							
						default:
							lastMainNum = dev.keyNum ;
							break;
					}				
					WM_Paint(hWin);					
				}
			}
			break;
#endif	
	
	  case WM_TIMER: 
		  if(isDelay == false)  //演示打开滚动条
			{
				isDelay = true;
				GUI_SetFont(&st16Font);    
				ySize = GUI_GetFontSizeY();
				
				pContext->Ticker.xPos      = xPos; //滚动条起始X坐标
				pContext->Ticker.yPos      = yPos; //滚动条起始Y坐标
				pContext->Ticker.xSize     = xSize;//滚动条宽度
				pContext->Ticker.ySize     = ySize;//滚动条高度
				pContext->Ticker.dx        = dx;   //每次偏移的像素
				pContext->Ticker.xSizeText = (strlen(pTextWM)/3)*16 + 40;  //显示的字符占用的X轴像素点 , 中文
				
				if (dx > 0){
					pContext->Ticker.vxPos = -(pContext->Ticker.xSizeText - 1) * 8;
				} else {
					pContext->Ticker.vxPos = +(pContext->Ticker.xSize - 1) * 8;
				}
				pContext->hWin = WM_CreateWindowAsChild(xPos, yPos, xSize, ySize, pMsg->hWin, WM_CF_SHOW | WM_CF_MEMDEV, _cbTickerWM, sizeof(pContext));
				WM_SetUserData(pContext->hWin, &pContext, sizeof(pContext));					
			}
			
			isDrawTim = true;
			isBlink = !isBlink;
			
			WM_RestartTimer(pMsg->Data.v, 100);
			WM_Paint(pMsg->hWin);
			break;
			
    default:
      WM_DefaultProc(pMsg);
  }
}



void DispPPT(void)
{
	static u8 bmpC;
	
	if((dev.isPPT)&&(dev.isDrawPic == false))
	{
		display_picture((char *)&dev.tfBmpName[bmpC]);
		bmpC++;
		bmpC  = bmpC%dev.tfBmpCnt;
		dev.isDrawPic = true;
	}
}


extern volatile u8 keyId;
void MenuTask(void)
{
	Create_st16_Font();
	GUI_SetBkColor(COLOR(0,76,152));
	GUI_Clear();
			
	dev.bklight = 8;
	dev.volume = 0;
	dev.bat = 8;
	dev.keyNum = 0;
  
	_CreateFrame(_cbMain,MENU_MAIN);
	
		
	while(1)
	{
		
#if GUI_SUPPORT_TOUCH		
//		if(keyId == 1)
//		{
//			keyId = 0;	
//			GUI_TOUCH_Exec();	
//		}			
		DispPPT();
#endif
	
		if(dev.pressKey == NO_PRESS)
			goto next;
	
		keyPress = dev.pressKey;
		switch(keyPress)
		{
			case CENTER_KEY_LONGE_PRESS:    
        GUI_SendKeyMsg(GUI_KEY_BACKSPACE,1);	
				break;
				
			case CENTER_KEY_SHORT_PRESS:    
        GUI_SendKeyMsg(GUI_KEY_ENTER,1);	
				break;
			
			case UP_KEY_SHORT_PRESS:		
				GUI_SendKeyMsg(GUI_KEY_LE,1);		
				break;
			
			case DOWN_KEY_SHORT_PRESS:    
				GUI_SendKeyMsg(GUI_KEY_RI,1);	
				break;

			case LEFT_KEY_SHORT_PRESS:		
				GUI_SendKeyMsg( GUI_KEY_SUB ,1);		
				break;
			
			case RIGHT_KEY_SHORT_PRESS:    
				GUI_SendKeyMsg(GUI_KEY_ADD,1);	
				break;
			
			case NO_PRESS:
				//TurnOffKeyLed();
				break;
										
			default:
				break;
		}
		
		dev.pressKey = NO_PRESS;
next:
		GUI_Delay(1);
	}
}




