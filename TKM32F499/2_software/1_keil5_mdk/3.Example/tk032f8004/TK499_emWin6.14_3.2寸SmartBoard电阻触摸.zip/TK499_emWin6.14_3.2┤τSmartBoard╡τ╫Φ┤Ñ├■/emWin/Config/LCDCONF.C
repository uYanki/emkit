/*********************************************************************

----------------------------------------------------------------------
File        : LCDConf.c
Purpose     : ��ʾ��������

---------------------------END-OF-HEADER------------------------------
*/

#include "GUI.h"
#include "LCDCONF.H"
#include "GUIDRV_Template.h"
#include "GUIDRV_Lin.h"
/*********************************************************************
*
*       Layer configuration
*
**********************************************************************
*/
//static int                        _aPendingBuffer[GUI_NUM_LAYERS];




//
// ɫ��ת��
//
#define COLOR_CONVERSION GUICC_M888

//
// ��ʾ����
//
#if LCD_MODE_MCU_or_RGB
	#define DISPLAY_DRIVER      &GUIDRV_Lin_OS_32_API//   GUIDRV_Lin_32_API
#else
	#define DISPLAY_DRIVER &GUIDRV_Template_API  //GUIDRV_Lin_32_API  GUIDRV_Lin_OSX_32_API 
#endif

//
// ���� / ������Ļ
//
#define NUM_BUFFERS   1
#define NUM_VSCREENS  1

//
// ��ʾ����
//
// #define DISPLAY_ORIENTATION  GUI_MIRROR_X
// #define DISPLAY_ORIENTATION               (GUI_MIRROR_X | GUI_MIRROR_Y)
// #define DISPLAY_ORIENTATION (GUI_SWAP_XY | GUI_MIRROR_Y)
// #define DISPLAY_ORIENTATION (GUI_SWAP_XY | GUI_MIRROR_X)
// #define DISPLAY_ORIENTATION GUI_SWAP_XY



/*********************************************************************
*
*       Configuration checking
*
**********************************************************************
*/
#ifndef   XSIZE_PHYS
  #error Physical X size of display is not defined!
#endif
#ifndef   YSIZE_PHYS
  #error Physical Y size of display is not defined!
#endif
#ifndef   COLOR_CONVERSION
  #error Color conversion not defined!
#endif
#ifndef   DISPLAY_DRIVER
  #error No display driver defined!
#endif
#ifndef   NUM_VSCREENS
  #define NUM_VSCREENS 1
#else
  #if (NUM_VSCREENS <= 0)
    #error At least one screeen needs to be defined!
  #endif
#endif
#if (NUM_VSCREENS > 1) && (NUM_BUFFERS > 1)
  #error Virtual screens and multiple buffers are not allowed!
#endif
#ifndef   DISPLAY_ORIENTATION
  #define DISPLAY_ORIENTATION  0
#endif

#if ((DISPLAY_ORIENTATION & GUI_SWAP_XY) != 0)
#define LANDSCAPE   1
#else
#define LANDSCAPE   0
#endif

#if (LANDSCAPE == 1)
#define WIDTH       YSIZE_PHYS  /* Screen Width (in pixels)         */
#define HEIGHT      XSIZE_PHYS  /* Screen Hight (in pixels)         */
#else
#define WIDTH       XSIZE_PHYS  /* Screen Width (in pixels)         */
#define HEIGHT      YSIZE_PHYS  /* Screen Hight (in pixels)         */
#endif

#if ((DISPLAY_ORIENTATION & GUI_SWAP_XY) != 0)
  #if ((DISPLAY_ORIENTATION & GUI_MIRROR_X) != 0)
    #define TOUCH_TOP    TOUCH_X_MAX
    #define TOUCH_BOTTOM TOUCH_X_MIN
  #else
    #define TOUCH_TOP    TOUCH_X_MIN
    #define TOUCH_BOTTOM TOUCH_X_MAX
  #endif
  #if ((DISPLAY_ORIENTATION & GUI_MIRROR_Y) != 0)
    #define TOUCH_LEFT   TOUCH_Y_MAX
    #define TOUCH_RIGHT  TOUCH_Y_MIN
  #else
    #define TOUCH_LEFT   TOUCH_Y_MIN
    #define TOUCH_RIGHT  TOUCH_Y_MAX
  #endif
#else
  #if ((DISPLAY_ORIENTATION & GUI_MIRROR_X) != 0)
    #define TOUCH_LEFT   TOUCH_X_MAX
    #define TOUCH_RIGHT  TOUCH_X_MIN
  #else
    #define TOUCH_LEFT   TOUCH_X_MIN
    #define TOUCH_RIGHT  TOUCH_X_MAX
  #endif
  #if ((DISPLAY_ORIENTATION & GUI_MIRROR_Y) != 0)
    #define TOUCH_TOP    TOUCH_Y_MAX
    #define TOUCH_BOTTOM TOUCH_Y_MIN
  #else
    #define TOUCH_TOP    TOUCH_Y_MIN
    #define TOUCH_BOTTOM TOUCH_Y_MAX
  #endif
#endif

/*********************************************************************
*
*       Driver Port functions
*
**********************************************************************
*/
void LCD_init_code(void)//Һ������ʼ������
{
		SPI_WriteComm(0x20);//exit_invert_mode
		SPI_WriteComm(0x29);//set_display_on

		SPI_WriteComm(0xB1);//RGB Interface Setting
		SPI_WriteData(0x00);
		SPI_WriteData(0x14);
		SPI_WriteData(0x06);

		SPI_WriteComm(0xB2);//Panel Characteristics Setting
		SPI_WriteData(0x10);//480 pixels
		SPI_WriteData(0xC8);//800 pixels

		SPI_WriteComm(0xB3);//Panel Drive Setting    Set the inversion mode


		SPI_WriteData(0x00);//1-dot inversion 0x01

		SPI_WriteComm(0xB4);//Display Mode Control
		SPI_WriteData(0x04);//Dither disable.

		SPI_WriteComm(0xB5);//Display Mode and Frame Memory Write Mode Setting
		SPI_WriteData(0x10);
		SPI_WriteData(0x30);
		SPI_WriteData(0x30);
		SPI_WriteData(0x00);
		SPI_WriteData(0x00);

		SPI_WriteComm(0xB6);//Display Control 2 ( GIP Specific )
		SPI_WriteData(0x01);
		SPI_WriteData(0x18);
		SPI_WriteData(0x02);
		SPI_WriteData(0x40);
		SPI_WriteData(0x10);
		SPI_WriteData(0x00);

		SPI_WriteComm(0xc0);
		SPI_WriteData(0x01);
		SPI_WriteData(0x18);


		SPI_WriteComm(0xC3); 
		SPI_WriteData(0x03);
		SPI_WriteData(0x04);
		SPI_WriteData(0x03);
		SPI_WriteData(0x03);
		SPI_WriteData(0x03);

		LCD_delay(10);

		SPI_WriteComm(0xC4);//VDD Regulator setting
		SPI_WriteData(0x02);
		SPI_WriteData(0x23);//GDC AP
		SPI_WriteData(0x11);//VRH1  Vreg1out=1.533xVCI(10)
		SPI_WriteData(0x12);//VRH2  Vreg2out=-1.533xVCI(10)
		SPI_WriteData(0x02);//BT 5 VGH/VGL  6/-4
		SPI_WriteData(0x77);//DDVDH 6C//0x56
		LCD_delay(10);

		SPI_WriteComm(0xC5);
		SPI_WriteData(0x73);
		LCD_delay(10);

		SPI_WriteComm(0xC6);
		SPI_WriteData(0x24);//VCI 23
		SPI_WriteData(0x60);//RESET RCO 53
		SPI_WriteData(0x00);//SBC GBC
		LCD_delay(10);
		//GAMMA SETTING
		SPI_WriteComm(0xD0);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x25);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);

		SPI_WriteComm(0xD1);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x07);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);



		SPI_WriteComm(0xD2);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x25);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);

		SPI_WriteComm(0xD3);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x07);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);


		SPI_WriteComm(0xD4);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x25);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);

		SPI_WriteComm(0xD5);
		SPI_WriteData(0x14);
		SPI_WriteData(0x01);
		SPI_WriteData(0x53);
		SPI_WriteData(0x07);
		SPI_WriteData(0x02);
		SPI_WriteData(0x02);
		SPI_WriteData(0x66);
		SPI_WriteData(0x14);
		SPI_WriteData(0x03);
		SPI_WriteComm(0x11);

		LCD_delay(10);

		SPI_WriteComm(0x3A); SPI_WriteData(0x66);//set_pixel_format 0X60 26k
		SPI_WriteComm(0x36); SPI_WriteData(0x02);
		
		SPI_WriteComm(0x29);
		SPI_WriteComm(0x2c);
}
#if TK020F9168
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend) 
{

	WriteComm(0x406);   
	WriteData(Ystart);
	WriteComm(0x407);   
	WriteData(Yend);
	WriteComm(0x408);   
	WriteData(Xstart);
	WriteComm(0x409);   
	WriteData(Xend);
	
	WriteComm(0x200);  //�ر�˵������ Xstart��ʼ��Yend������������ȫ����x��y�Ŀ�ͷ��ʼ
	WriteData(Yend);
	WriteComm(0x201);   
	WriteData(Xstart);

	WriteComm(0x202);
}
#elif TFT1P1061
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend) 
{
	LCD_WR_REG(0x80,Ystart>>8); // Set CAC=0x0000 
	LCD_WR_REG(0x81,Ystart);   
	LCD_WR_REG(0x82,Xstart>>8); // Set RAC=0x0000 
	LCD_WR_REG(0x83,Xstart);
	
	LCD_WR_REG(0x02,Xstart>>8); 
	LCD_WR_REG(0x03,Xstart);     //Column Start 
	LCD_WR_REG(0x04,Xend>>8); 
	LCD_WR_REG(0x05,Xend);     //Column End 
	 
	LCD_WR_REG(0x06,Ystart>>8); 
	LCD_WR_REG(0x07,Ystart);     //Row Start 
	LCD_WR_REG(0x08,Yend>>8); 
	LCD_WR_REG(0x09,Yend);     //Row End 

	WriteComm(0x22);
}
#else
void BlockWrite(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend) 
{
#if TK043F1508	
	WriteComm(0x2a00);   
	WriteData(Xstart>>8);
	WriteComm(0x2a01); 
	WriteData(Xstart);
	WriteComm(0x2a02); 
	WriteData(Xend>>8);
	WriteComm(0x2a03); 
	WriteData(Xend);

	WriteComm(0x2b00);   
	WriteData(Ystart>>8);
	WriteComm(0x2b01); 
	WriteData(Ystart);
	WriteComm(0x2b02); 
	WriteData(Yend>>8);
	WriteComm(0x2b03); 
	WriteData(Yend);

	WriteComm(0x2c00);
#elif TK022RB417
	WriteComm(0x0020);WriteData(Ystart);//H Start
	WriteComm(0x0021);WriteData(Xstart);//V Start

	WriteComm(0x0050);WriteData(Ystart);
	WriteComm(0x0051);WriteData(Yend);
	WriteComm(0x0052);WriteData(Xstart);
	WriteComm(0x0053);WriteData(Xend);
	WriteComm(0x0022);
#else
	WriteComm(0x2a);
	WriteData(Xstart>>8);
	WriteData(Xstart);
	WriteData(Xend>>8);
	WriteData(Xend);

	WriteComm(0x2b);   
	WriteData(Ystart>>8);
	WriteData(Ystart);
	WriteData(Yend>>8);
	WriteData(Yend);
	
	WriteComm(0x2c);
#endif
}
#endif
void LCD_DrawLineH(int x0, int x1,  int y, int LCD_COLORINDEX)
{
#if TK020F9168
	u32 i,j;
	BlockWrite(x0,x1,y,y);
	TK80->CR = 0x000c0b04;//��������CS������CS
	j=x1-x0+1;
	for(i=0;i<j;i++)
	{
		WriteData(LCD_COLORINDEX);
	}
	TK80->CR = 0x000c0b06;//��������CS������CS
#else	
	BlockWrite(x0,x1,y,y);
	TK80->CFGR3=x1-x0+1;
		TK80->DINR = LCD_COLORINDEX;
	while(TK80->SR & 0x10000);
#endif
}
void LCD_DrawLineV(int x, int y0,  int y1, int LCD_COLORINDEX)
{
#if TK020F9168
	u32 i,j;
	BlockWrite(x,x,y0,y1);
	TK80->CR = 0x000c0b04;//��������CS������CS
	j=y1-y0+1;
	for(i=0;i<j;i++)
	{
		WriteData(LCD_COLORINDEX);
	}
	TK80->CR = 0x000c0b06;//��������CS������CS
#else	
	BlockWrite(x,x,y0,y1);
	TK80->CFGR3=y1-y0+1;
		TK80->DINR = LCD_COLORINDEX;
	while(TK80->SR & 0x10000);
#endif
}
/*
*********************************************************************************************************
*	�� �� ��: DrawHColorLine
*	����˵��: ����һ����ɫˮƽ�� ����Ҫ����UCGUI�Ľӿں�����
*	��    �Σ�_usX1    ����ʼ��X����
*			  _usY1    ��ˮƽ�ߵ�Y����
*			  _usWidth ��ֱ�ߵĿ���
*			  _pColor : ��ɫ������
*	�� �� ֵ: ��
*********************************************************************************************************
*/
#if TK020F9168
void LCD_DrawHColorLine(U16 x1 , U16 y1, U16 Width, U16 *_pColor)
{
	BlockWrite(x1,x1+Width-1,y1,y1);
	TK80->CR = 0x000c0b04;//��������CS������CS
	for (x1 = 0; x1 < Width; x1++)
	{
		WriteData(*_pColor++);
	}
	TK80->CR = 0x000c0b06;//��������CS������CS
}
#elif TFT1P1061 | USE_16bit_LCD
void LCD_DrawHColorLine(U16 x1 , U16 y1, U16 Width, U16 *_pColor)
{
	BlockWrite(x1,x1+Width-1,y1,y1);
	for (x1 = 0; x1 < Width; x1++)
	{
		WriteData(*_pColor++);
	}
}
#else
void LCD_DrawHColorLine(U16 x1 , U16 y1, U16 Width, U32 *_pColor)
{
	BlockWrite(x1,x1+Width-1,y1,y1);
	TK80_DMA_Init((u32)_pColor,Width);
//	y1=x1+Width;
//	for (x1 = 0; x1 < y1; x1++)
//	{
//		TK80->DINR =  *_pColor++;
//	}
}
#endif
#if TK020F9168|TFT1P1061
void LCD_PutPixel(U16 x,U16 y,int PixelIndex)
{
	BlockWrite(x,x,y,y);
	WriteData(PixelIndex);
}
#else
void LCD_PutPixel(U16 x,U16 y,int PixelIndex)
{
#if TK043F1508	
	WriteComm(0x2a00);   
	WriteData(x>>8);
	WriteComm(0x2a01); 
	WriteData(x);

	WriteComm(0x2b00);   
	WriteData(y>>8);
	WriteComm(0x2b01); 
	WriteData(y);

	WriteComm(0x2c00);while(TK80->SR & 0x10000);
#else
	BlockWrite(x,x,y,y);
#endif
	TK80->DINR = PixelIndex;
}
#endif
 int  LCD_GetPixel(U16 x,U16 y)
{
int i;
#if TFT1P1061
	u16 dat;
 	LCD_WR_REG(0x80,x>>8); // Set CAC=0x0000 
	LCD_WR_REG(0x81,x);   
	LCD_WR_REG(0x82,y>>8); // Set RAC=0x0000 
	LCD_WR_REG(0x83,y);
	WriteComm(0x22);

	dat = TK80->DOUTR;
	dat = TK80->DOUTR;
	dat = (dat&0xf800)|((dat&0x00fc)<<3)|(TK80->DOUTR>>11);
	return dat; 
#elif TK043F1508
	WriteComm(0x2a00);   
	WriteData(x>>8);
	WriteComm(0x2a01); 
	WriteData(x);

	WriteComm(0x2b00);   
	WriteData(y>>8);
	WriteComm(0x2b01); 
	WriteData(y);

	WriteComm(0x2E00);while(TK80->SR & 0x10000);
	TK80->CFGR1 = 0x05180505;
  TK80->CFGR2 = 0x0505;
	i = TK80->BRDR;
	TK80->CFGR1 = 0x05050102;
  TK80->CFGR2 = 0x0501;
	return(i);
#elif TK022RB417
	WriteComm(0x0020);WriteData(y);//H Start
	WriteComm(0x0021);WriteData(x);//V Start

	WriteComm(0x0050);WriteData(y);
	WriteComm(0x0051);WriteData(y);
	WriteComm(0x0052);WriteData(x);
	WriteComm(0x0053);WriteData(x);
	WriteComm(0x0022);while(TK80->SR & 0x10000);
//	TK80->CFGR1 = 0x05050505;
//  TK80->CFGR2 = 0x0505;
	i = TK80->DOUTR;while(TK80->SR & 0x10000);
	i = TK80->DOUTR;while(TK80->SR & 0x10000);
//	TK80->CFGR1 = 0x05050102;
//  TK80->CFGR2 = 0x0501;
	return(i);
#else
	WriteComm(0x2a);   
	WriteData(x>>8);
	WriteData(x&0xff);
	WriteData(x>>8);
	WriteData(x&0xff);

	WriteComm(0x2b);   
	WriteData(y>>8);
	WriteData(y&0xff);
	WriteData(y>>8);
	WriteData(y&0xff);
//BlockWrite(x,x,y,y);
	WriteComm(0x2E);while(TK80->SR & 0x10000);
	
//	x = TK80->DOUTR;while(TK80->SR & 0x10000);
//	x = TK80->DOUTR;while(TK80->SR & 0x10000);
//	x = (x&0xf800)|((x&0x00fc)<<3);
//	y = TK80->DOUTR;while(TK80->SR & 0x10000);

//	return x|(y>>11);
	TK80->CFGR1 = 0x05080505;//���ٶȵ���
  TK80->CFGR2 = 0x0506;
	x = TK80->DOUTR;while(TK80->SR & 0x10000);
	i = TK80->DOUTR;while(TK80->SR & 0x10000);
	TK80->CFGR1 = 0x00050202;//�ָ�����д���ٶ�
  TK80->CFGR2 = 0x0502;
	return(i);
#endif
}


/*********************************************************************
*
*       LCD_X_Config
*
* Purpose:
*   Called during the initialization process in order to set up the
*   display driver configuration.
*   
*/
/****************************************************************************
* ��    �ƣ�LCD_X_Config(void)
* ��    �ܣ���ʾ������������
* ��ڲ�������
* ���ڲ�������
* ˵    ����
* ���÷������� 
****************************************************************************/ 
#if LCD_MODE_MCU_or_RGB
	extern __align(256) U32 LTDC_emWin[XSIZE_PHYS*YSIZE_PHYS];
#endif
void LCD_X_Config(void) 
{
//#if (NUM_BUFFERS > 1)
//	int i;	
//	for (i = 0; i < GUI_NUM_LAYERS; i++) {
//    GUI_MULTIBUF_ConfigEx(i, NUM_BUFFERS);
//	}
//#endif
	
  /* ���õ�һ�����ʾ��������ɫת�� */
  GUI_DEVICE_CreateAndLink(DISPLAY_DRIVER, COLOR_CONVERSION, 0, 0);
  /* ������ʾ�������� */
  LCD_SetSizeEx(0, YSIZE_PHYS, XSIZE_PHYS);               // ʵ����ʾ����
#if LCD_MODE_MCU_or_RGB
	LCD_SetVRAMAddrEx(0, LTDC_emWin);
	LTDC->DP_ADDR0 = (U32)LTDC_emWin;//��0���ַ
#endif
  if (LCD_GetSwapXY()) 
  {
    LCD_SetSizeEx (0, YSIZE_PHYS, XSIZE_PHYS);
    LCD_SetVSizeEx(0, YSIZE_PHYS * NUM_VSCREENS, XSIZE_PHYS);
  } 
  else 
  {
    LCD_SetSizeEx (0, XSIZE_PHYS, YSIZE_PHYS);
    LCD_SetVSizeEx(0, XSIZE_PHYS, YSIZE_PHYS * NUM_VSCREENS);
  }							     

  #if (GUI_SUPPORT_TOUCH == 1)
    /*������ʾ����*/
//    GUI_TOUCH_SetOrientation(GUI_SWAP_XY);//GUI_MIRROR_Y DISPLAY_ORIENTATION
    
    /* У׼������ */  
		#if LCD_MODE_MCU_or_RGB
		GUI_TOUCH_Calibrate(GUI_COORD_X, 0,   HEIGHT - 1,TOUCH_LEFT,  TOUCH_RIGHT);
    GUI_TOUCH_Calibrate(GUI_COORD_Y, 0, WIDTH - 1, TOUCH_TOP, TOUCH_BOTTOM);
		#else
		GUI_TOUCH_Calibrate(GUI_COORD_X, 0, WIDTH  - 1,TOUCH_LEFT,  TOUCH_RIGHT);
    GUI_TOUCH_Calibrate(GUI_COORD_Y, 0, HEIGHT - 1, TOUCH_TOP, TOUCH_BOTTOM);
		#endif
  #endif
}

/*********************************************************************
*
*       LCD_X_DisplayDriver
*
* Purpose:
*   This function is called by the display driver for several purposes.
*   To support the according task the routine needs to be adapted to
*   the display controller. Please note that the commands marked with
*   'optional' are not cogently required and should only be adapted if 
*   the display controller supports these features.
*
* Parameter:
*   LayerIndex - Index of layer to be configured
*   Cmd        - Please refer to the details in the switch statement below
*   pData      - Pointer to a LCD_X_DATA structure
*
* Return Value:
*   < -1 - Error
*     -1 - Command not handled
*      0 - OK
*/
int LCD_X_DisplayDriver(unsigned LayerIndex, unsigned Cmd, void * pData) {
  int r;

  switch (Cmd) {
  case LCD_X_SHOWBUFFER: { 
    // 
    // Required if multiple buffers are used. The 'Index' element of p contains the buffer index. 
    // 
//    LCD_X_SHOWBUFFER_INFO * p; 

//    p = (LCD_X_SHOWBUFFER_INFO *)pData; 
//    _aPendingBuffer[LayerIndex] = p->Index; 
    break; 
} 
  case LCD_X_INITCONTROLLER: {
    //
    // Called during the initialization process in order to set up the
    // display controller and put it into operation. If the display
    // controller is not initialized by any external routine this needs
    // to be adapted by the customer...
    //
//    _InitController();
    return 0;
  }
  default:
    r = -1;
  }
  return r;
}

/*************************** End of file ****************************/
