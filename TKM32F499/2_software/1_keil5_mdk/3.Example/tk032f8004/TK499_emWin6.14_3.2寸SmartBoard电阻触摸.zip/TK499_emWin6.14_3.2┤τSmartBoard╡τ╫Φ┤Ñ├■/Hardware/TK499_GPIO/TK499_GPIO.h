#ifndef __TK499_GPIO_H__
#define __TK499_GPIO_H__
#include "HAL_conf.h"
#include "sys.h"
//====  3.2smart board  ====//	
#define LCD_SPI_CS(a)	\
						if (a)	\
						GPIOE->BSRR = GPIO_Pin_9;	\
						else		\
						GPIOE->BRR  = GPIO_Pin_9;					
#define SPI_DCLK(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_23);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_23);	
#define SPI_SDA(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_22);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_22);	

#define LCD_RST(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_17);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_17);

#define Lcd_Light_ON   GPIO_SetBits(GPIOE, GPIO_Pin_16) //PE16Ϊ�ߵ�ƽ �����
#define Lcd_Light_OFF  GPIO_ResetBits(GPIOE, GPIO_Pin_16)  //PE16Ϊ�͵�ƽ ����ر�

void GPIO_TK80_init(void);
void GPIO_RGB_INIT(void);
void Touch_Pad_Config(void);

#endif

