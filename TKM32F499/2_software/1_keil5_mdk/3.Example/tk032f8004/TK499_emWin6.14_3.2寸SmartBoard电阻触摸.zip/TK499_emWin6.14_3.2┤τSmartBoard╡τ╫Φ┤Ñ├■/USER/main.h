#ifndef MAIN_H
#define MAIN_H

typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int  uint32;

#include "tk499.h"
#include "HAL_conf.h"
#include "GUI.H"
#include "GUICONF.H"
#include "LCDCONF.H"
#include <stdio.h>
#include <stdbool.h>
#include "WM.H"
#include "sys.h"
#include "Tiky_LCD_APP.h"
#include "TK499_GPIO.h"
#include "TK499_timer.h"
#include "touch_CTP.h"
#include "SDIO.h"
#include "UART.h" 
#include "lcd.h" 
#include "QSPI_REG.h"
#include "qspi_fun.h"
#include "xbf_font.h"
#include "menutask.h"

extern WM_HWIN standard_Icon(void);
extern WM_HWIN CreateFramewin(void);
extern void COLOR_ShowColorBar(void);
extern void WIDGET_NumPad(void);
extern void WIDGET_Effect(void);
void speed_test(void);
#endif
