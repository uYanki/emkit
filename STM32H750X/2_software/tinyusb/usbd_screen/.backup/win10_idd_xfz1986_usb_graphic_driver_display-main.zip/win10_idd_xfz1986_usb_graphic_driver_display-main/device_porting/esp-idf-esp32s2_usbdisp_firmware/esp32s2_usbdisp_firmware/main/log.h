

#ifndef __LOG_H__
#define __LOG_H__

#define LOGD(fmt,args...) do {;}while(0)


#endif
