# Dialog DA1469x MCU

**Dialog Semiconductors** provides SDKs for DA146x MCU family.
Most of the files there can't be redistributed.
Registers definition file `DA1469xAB.h` and some **ARM** originated headers are have licenses that allow
for redistribution.  
Whole SDK repository can be downloaded from Dialog Semiconductor web page `https://www.dialog.com`


