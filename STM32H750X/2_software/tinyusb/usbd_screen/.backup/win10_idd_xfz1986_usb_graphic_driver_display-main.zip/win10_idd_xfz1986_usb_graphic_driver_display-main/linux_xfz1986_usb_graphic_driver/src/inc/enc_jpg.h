
#include"enc_base.h"
#include"tiny_jpeg.h"


int create_enc_jpg(enc_base_t * this,int quality);
