
int create_enc_rgb565(enc_base_t * this);

int create_enc_rgb888a(enc_base_t * this);
