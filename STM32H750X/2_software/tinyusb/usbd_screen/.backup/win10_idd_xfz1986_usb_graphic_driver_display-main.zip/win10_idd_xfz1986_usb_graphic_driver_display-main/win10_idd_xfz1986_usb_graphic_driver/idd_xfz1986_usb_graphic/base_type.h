#pragma once



typedef unsigned __int32 uint32_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int8 uint8_t;

typedef uint8_t _u8;
typedef uint16_t _u16;
typedef uint32_t _u32;

typedef uint32_t  pixel_type_t;