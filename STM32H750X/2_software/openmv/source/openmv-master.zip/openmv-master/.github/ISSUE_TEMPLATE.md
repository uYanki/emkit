<!--
Thanks for reporting issues back to OpenMV!

For technical questions and projects please post a question to the [Forums](http://forums.openmv.io/index.php).

To make it possible for us to help you please fill out below information carefully.
-->

### Steps to reproduce
1.
2.
3.

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead

### Describe your setup

**IDE version:**

**Firmware version:**

**Operating system:**

### For developers

**GCC version:**

**Build target:**
