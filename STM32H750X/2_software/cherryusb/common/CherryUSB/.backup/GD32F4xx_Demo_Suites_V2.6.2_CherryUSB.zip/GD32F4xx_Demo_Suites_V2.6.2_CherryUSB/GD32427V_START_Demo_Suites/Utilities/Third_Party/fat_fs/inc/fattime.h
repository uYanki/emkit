#ifndef FATTIME_H_

#include "integer.h"

DWORD get_fattime (void);

#endif
