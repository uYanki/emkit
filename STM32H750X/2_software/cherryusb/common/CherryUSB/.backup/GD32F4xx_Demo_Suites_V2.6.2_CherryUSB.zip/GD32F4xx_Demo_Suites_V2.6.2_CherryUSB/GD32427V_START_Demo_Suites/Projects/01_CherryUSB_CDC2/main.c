/*!
    \file    main.c
    \brief   GPIO running led demo

    \version 2022-04-26, V2.0.0, demo for GD32F4xx
*/

/*
    Copyright (c) 2022, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors
       may be used to endorse or promote products derived from this software without
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

#include "gd32f4xx.h"
#include "gd32f427v_start.h"
#include "systick.h"
#include <stdio.h>
#include "usb_config.h"
  
void gd_eval_com_init(void);

/*!
    \brief    main function
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{
  /* configure systick */
  systick_config();
  
  gd_eval_com_init();
  
  cdc_acm_init();

  while (1) {
    /* Delay for 1s */
    delay_1ms(1000);

    /* Call the test function to send data to the USB host */
    cdc_acm_data_send_with_dtr_test();
  }
}

int fputc(int ch, FILE *f)
{
  usart_data_transmit(USART1, ch);
  while(RESET == usart_flag_get(USART1, USART_FLAG_TBE));
  return ch;
}

void usb_dc_low_level_init(void)
{
  rcu_periph_clock_enable(RCU_SYSCFG);
  rcu_periph_clock_enable(RCU_GPIOA);
  
  gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_11|GPIO_PIN_12);
  gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_MAX, GPIO_PIN_11|GPIO_PIN_12);
  gpio_af_set(GPIOA, GPIO_AF_10, GPIO_PIN_11|GPIO_PIN_12);
  
  rcu_pll48m_clock_config(RCU_PLL48MSRC_PLLQ);
  rcu_ck48m_clock_config(RCU_CK48MSRC_PLL48M);
  
  rcu_periph_clock_enable(RCU_USBFS);
  
  nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
  nvic_irq_enable((uint8_t)USBFS_IRQn, 2U, 0U);
}

void usb_dc_low_level_deinit(void)
{
  rcu_periph_clock_disable(RCU_SYSCFG);
  rcu_periph_clock_disable(RCU_GPIOA);  
  rcu_periph_clock_disable(RCU_USBFS);
  
  nvic_irq_disable((uint8_t)USBFS_IRQn);
}

/*!
    \brief    configure COM port
    \param[in]  COM: COM on the board
      \arg        EVAL_COM0: COM on the board
    \param[out] none
    \retval     none
*/
void gd_eval_com_init(void)
{
  /* enable GPIO clock */
  rcu_periph_clock_enable(RCU_GPIOA);

  /* enable USART clock */
  rcu_periph_clock_enable(RCU_USART1);

  /* connect port to USARTx_Tx */
  gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_2);

  /* configure USART Tx as alternate function push-pull */
  gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_2);
  gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_2);

  /* USART configure */
  usart_deinit(USART1);
  usart_baudrate_set(USART1, 115200U);
  usart_transmit_config(USART1, USART_TRANSMIT_ENABLE);
  usart_enable(USART1);
}
