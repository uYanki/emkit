/*
 * SPDX-FileCopyrightText: 2015-2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _CONSOLE_H
#define _CONSOLE_H

#include <stdio.h>

#define console_printf printf

#endif
