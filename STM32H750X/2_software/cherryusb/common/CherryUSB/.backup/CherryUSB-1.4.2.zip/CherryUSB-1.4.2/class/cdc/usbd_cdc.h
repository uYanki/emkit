/*
 * Copyright (c) 2024, sakumisu
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef USBD_CDC_H
#define USBD_CDC_H

// legacy for old version

#include "usbd_cdc_acm.h"

#endif