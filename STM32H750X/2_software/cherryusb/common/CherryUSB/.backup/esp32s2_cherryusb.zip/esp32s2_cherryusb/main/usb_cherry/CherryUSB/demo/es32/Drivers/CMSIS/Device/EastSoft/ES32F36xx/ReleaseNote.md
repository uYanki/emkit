# ES32F36xx Device Release Note

## V1.00 2019-12-16

1. First release

