#ifndef _USBD_XXX_H_
#define _USBD_XXX_H_

#include "usb_xxx.h"

#ifdef __cplusplus
extern "C" {
#endif

void usbd_xxx_add_interface(usbd_class_t *devclass, usbd_interface_t *intf);

#ifdef __cplusplus
}
#endif

#endif /* _USBD_XXX_H_ */
