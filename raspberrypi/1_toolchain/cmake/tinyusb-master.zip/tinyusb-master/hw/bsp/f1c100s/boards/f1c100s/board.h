/* metadata:
   name: Lctech Pi F1C200s
   url: https://linux-sunxi.org/Lctech_Pi_F1C200s
*/

#ifndef BOARD_H
#define BOARD_H

// Nothing valuable here

#endif
