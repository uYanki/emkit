#include <vector>
#include <string>

// TODO: Finish this.
std::vector<std::string> data_locs = {};
