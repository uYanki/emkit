
#include <vector>
#include <string>

std::vector<std::string> data_locs = {
    "${DATA_LOCS_VEC}"
};
